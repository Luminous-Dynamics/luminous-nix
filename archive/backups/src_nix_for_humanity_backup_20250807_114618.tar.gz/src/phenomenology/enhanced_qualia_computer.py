#!/usr/bin/env python3
"""
Enhanced Computational Phenomenology Implementation
Adds temporal dynamics, ActivityWatch integration, and real-time visualization
"""

import numpy as np
from typing import Dict, Any, Optional, List, Tuple, Callable
from dataclasses import dataclass, field
from scipy.stats import entropy
from scipy.signal import savgol_filter
from scipy.interpolate import interp1d
import json
from datetime import datetime, timedelta
from collections import deque
import threading
import time
import sqlite3

@dataclass
class TemporalSystemState:
    """System state with temporal context"""
    timestamp: datetime
    state: 'SystemState'
    # ActivityWatch data
    window_switches: int = 0
    afk_duration: float = 0.0
    active_app: str = ""
    keystroke_rate: float = 0.0  # Keys per minute
    mouse_activity: float = 0.0  # Movement intensity
    
    # Historical context
    previous_states: List['SystemState'] = field(default_factory=list)
    state_duration: float = 0.0  # How long in current state
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        data = self.state.to_dict()
        data.update({
            'timestamp': self.timestamp.isoformat(),
            'window_switches': self.window_switches,
            'afk_duration': self.afk_duration,
            'active_app': self.active_app,
            'keystroke_rate': self.keystroke_rate,
            'mouse_activity': self.mouse_activity,
            'state_duration': self.state_duration
        })
        return data

@dataclass
class DynamicQualiaVector:
    """Enhanced qualia with temporal dynamics"""
    # Core qualia
    effort: float = 0.0
    confusion: float = 0.0
    flow: float = 0.0
    learning_momentum: float = 0.0
    empathic_resonance: float = 0.0
    
    # Temporal dynamics
    velocity: Dict[str, float] = field(default_factory=dict)  # Rate of change
    acceleration: Dict[str, float] = field(default_factory=dict)  # Rate of rate of change
    stability: float = 0.0  # How stable the current state is
    
    # New phenomenological dimensions
    cognitive_load: float = 0.0  # Mental burden (0-1)
    emotional_valence: float = 0.5  # Negative (0) to Positive (1)
    arousal: float = 0.5  # Low (0) to High (1)
    agency: float = 0.5  # Feeling of control (0-1)
    
    # Predictions
    predicted_next: Optional['DynamicQualiaVector'] = None
    confidence: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'effort': round(self.effort, 3),
            'confusion': round(self.confusion, 3),
            'flow': round(self.flow, 3),
            'learning_momentum': round(self.learning_momentum, 3),
            'empathic_resonance': round(self.empathic_resonance, 3),
            'cognitive_load': round(self.cognitive_load, 3),
            'emotional_valence': round(self.emotional_valence, 3),
            'arousal': round(self.arousal, 3),
            'agency': round(self.agency, 3),
            'stability': round(self.stability, 3),
            'velocity': {k: round(v, 3) for k, v in self.velocity.items()},
            'acceleration': {k: round(v, 3) for k, v in self.acceleration.items()},
            'confidence': round(self.confidence, 3)
        }
    
    def phenomenological_fingerprint(self) -> np.ndarray:
        """Return a vector representation for distance calculations"""
        return np.array([
            self.effort, self.confusion, self.flow, 
            self.learning_momentum, self.empathic_resonance,
            self.cognitive_load, self.emotional_valence,
            self.arousal, self.agency
        ])

class TemporalPhenomenology:
    """
    Enhanced phenomenology with temporal dynamics and ActivityWatch integration
    """
    
    def __init__(self, history_size: int = 100):
        # Original weights
        self.w1 = 0.3  # react_loops weight
        self.w2 = 0.2  # tokens_processed weight  
        self.w3 = 0.3  # planning_revisions weight
        self.w4 = 0.2  # error_rate weight
        
        # Normalization constants
        self.max_loops = 10
        self.max_tokens = 1000
        self.max_revisions = 5
        self.max_response_time = 5.0
        
        # Temporal tracking
        self.history_size = history_size
        self.qualia_history: deque = deque(maxlen=history_size)
        self.state_history: deque = deque(maxlen=history_size)
        self.last_update: Optional[datetime] = None
        
        # Smoothing parameters
        self.smoothing_window = 5  # For Savitzky-Golay filter
        self.prediction_horizon = 3  # Steps to predict ahead
        
        # ActivityWatch integration placeholders
        self.activity_patterns: Dict[str, float] = {}
        self.context_weights: Dict[str, float] = {
            'window_switches': 0.2,
            'keystroke_rate': 0.15,
            'mouse_activity': 0.15,
            'afk_duration': 0.1
        }
        
    def compute_enhanced_qualia(self, temporal_state: TemporalSystemState) -> DynamicQualiaVector:
        """
        Compute qualia with temporal dynamics and context
        """
        # Compute base qualia
        base_qualia = self._compute_base_qualia(temporal_state.state)
        
        # Add temporal dynamics
        dynamic_qualia = self._add_temporal_dynamics(base_qualia, temporal_state)
        
        # Compute new phenomenological dimensions
        dynamic_qualia.cognitive_load = self._compute_cognitive_load(temporal_state)
        dynamic_qualia.emotional_valence = self._compute_emotional_valence(temporal_state)
        dynamic_qualia.arousal = self._compute_arousal(temporal_state)
        dynamic_qualia.agency = self._compute_agency(temporal_state)
        
        # Predict future state
        if len(self.qualia_history) >= 3:
            dynamic_qualia.predicted_next = self._predict_next_qualia()
            dynamic_qualia.confidence = self._compute_prediction_confidence()
        
        # Update history
        self.qualia_history.append(dynamic_qualia)
        self.state_history.append(temporal_state)
        self.last_update = temporal_state.timestamp
        
        return dynamic_qualia
    
    def _compute_base_qualia(self, state: 'SystemState') -> DynamicQualiaVector:
        """Compute base qualia using original formulas"""
        qualia = DynamicQualiaVector()
        
        # Use original computation methods
        qualia.effort = self._compute_effort(state)
        qualia.confusion = self._compute_confusion(state)
        qualia.flow = self._compute_flow(state)
        qualia.learning_momentum = self._compute_learning_momentum(state)
        qualia.empathic_resonance = self._compute_empathic_resonance(state)
        
        return qualia
    
    def _add_temporal_dynamics(self, qualia: DynamicQualiaVector, 
                               temporal_state: TemporalSystemState) -> DynamicQualiaVector:
        """Add temporal dynamics to qualia"""
        if len(self.qualia_history) < 2:
            return qualia
        
        # Calculate velocities (rate of change)
        prev_qualia = self.qualia_history[-1]
        time_delta = (temporal_state.timestamp - self.last_update).total_seconds()
        
        if time_delta > 0:
            for attr in ['effort', 'confusion', 'flow', 'learning_momentum', 'empathic_resonance']:
                current_val = getattr(qualia, attr)
                prev_val = getattr(prev_qualia, attr)
                qualia.velocity[attr] = (current_val - prev_val) / time_delta
        
        # Calculate acceleration (rate of rate of change)
        if len(self.qualia_history) >= 2 and prev_qualia.velocity:
            for attr, velocity in qualia.velocity.items():
                prev_velocity = prev_qualia.velocity.get(attr, 0)
                qualia.acceleration[attr] = (velocity - prev_velocity) / time_delta
        
        # Calculate stability (low variance in recent history)
        if len(self.qualia_history) >= 5:
            recent_values = {}
            for attr in ['effort', 'confusion', 'flow', 'learning_momentum', 'empathic_resonance']:
                recent_values[attr] = [getattr(q, attr) for q in list(self.qualia_history)[-5:]]
                
            variances = [np.var(values) for values in recent_values.values()]
            qualia.stability = 1.0 - min(np.mean(variances) * 10, 1.0)  # Scale variance to 0-1
        
        return qualia
    
    def _compute_cognitive_load(self, temporal_state: TemporalSystemState) -> float:
        """Compute cognitive load from multiple factors"""
        state = temporal_state.state
        
        # Base cognitive load from task complexity
        task_complexity = (
            min(state.react_loops / self.max_loops, 1.0) * 0.3 +
            min(state.planning_revisions / self.max_revisions, 1.0) * 0.3 +
            state.error_rate * 0.2 +
            min(state.context_switches / 5, 1.0) * 0.2
        )
        
        # ActivityWatch factors
        activity_load = 0.0
        if temporal_state.window_switches > 0:
            activity_load += min(temporal_state.window_switches / 10, 1.0) * 0.3
        if temporal_state.keystroke_rate > 0:
            # High keystroke rate indicates intense work
            activity_load += min(temporal_state.keystroke_rate / 200, 1.0) * 0.2
        
        # Time pressure factor
        if state.time_to_response > 2.0:
            time_pressure = min((state.time_to_response - 2.0) / 3.0, 1.0) * 0.2
        else:
            time_pressure = 0.0
        
        cognitive_load = task_complexity * 0.6 + activity_load * 0.2 + time_pressure * 0.2
        
        return min(cognitive_load, 1.0)
    
    def _compute_emotional_valence(self, temporal_state: TemporalSystemState) -> float:
        """Compute emotional valence (negative to positive)"""
        state = temporal_state.state
        
        # Positive factors
        positive = (
            state.reward_signal_mean * 0.3 +
            state.predictive_accuracy * 0.2 +
            (1.0 - state.error_rate) * 0.2
        )
        
        # Negative factors
        negative = (
            min(state.planning_revisions / self.max_revisions, 1.0) * 0.2 +
            min(temporal_state.window_switches / 10, 1.0) * 0.1
        )
        
        # Recent trend influence
        if len(self.qualia_history) >= 3:
            recent_flow = np.mean([q.flow for q in list(self.qualia_history)[-3:]])
            trend_influence = recent_flow * 0.2
        else:
            trend_influence = 0.1
        
        valence = 0.5 + (positive - negative) * 0.5 + trend_influence * 0.2
        
        return np.clip(valence, 0.0, 1.0)
    
    def _compute_arousal(self, temporal_state: TemporalSystemState) -> float:
        """Compute arousal level (activation)"""
        state = temporal_state.state
        
        # High arousal factors
        high_arousal = (
            min(temporal_state.keystroke_rate / 150, 1.0) * 0.3 +
            min(temporal_state.mouse_activity / 100, 1.0) * 0.2 +
            min(state.context_switches / 5, 1.0) * 0.2 +
            state.error_rate * 0.3
        )
        
        # Low arousal factors (calmness)
        low_arousal = (
            min(temporal_state.afk_duration / 300, 1.0) * 0.3 +  # 5 min AFK
            (1.0 - min(state.time_to_response / self.max_response_time, 1.0)) * 0.2
        )
        
        arousal = 0.5 + (high_arousal - low_arousal) * 0.5
        
        return np.clip(arousal, 0.0, 1.0)
    
    def _compute_agency(self, temporal_state: TemporalSystemState) -> float:
        """Compute sense of agency/control"""
        state = temporal_state.state
        
        # High agency indicators
        agency_positive = (
            state.predictive_accuracy * 0.3 +
            (1.0 - state.error_rate) * 0.3 +
            min(state.reward_signal_mean, 1.0) * 0.2
        )
        
        # Low agency indicators
        agency_negative = (
            min(state.planning_revisions / self.max_revisions, 1.0) * 0.2 +
            min(temporal_state.window_switches / 10, 1.0) * 0.1
        )
        
        # Stability bonus
        if len(self.qualia_history) > 0:
            stability_bonus = self.qualia_history[-1].stability * 0.1
        else:
            stability_bonus = 0.0
        
        agency = agency_positive - agency_negative + stability_bonus + 0.2  # Base agency
        
        return np.clip(agency, 0.0, 1.0)
    
    def _predict_next_qualia(self) -> DynamicQualiaVector:
        """Predict next qualia state using polynomial extrapolation"""
        if len(self.qualia_history) < 3:
            return self.qualia_history[-1]
        
        # Extract recent history
        recent_qualia = list(self.qualia_history)[-5:]
        predicted = DynamicQualiaVector()
        
        # For each qualia dimension
        for attr in ['effort', 'confusion', 'flow', 'learning_momentum', 'empathic_resonance',
                    'cognitive_load', 'emotional_valence', 'arousal', 'agency']:
            values = [getattr(q, attr) for q in recent_qualia]
            x = np.arange(len(values))
            
            # Fit polynomial (degree 2)
            if len(values) >= 3:
                coeffs = np.polyfit(x, values, min(2, len(values) - 1))
                poly = np.poly1d(coeffs)
                next_value = poly(len(values))
                setattr(predicted, attr, np.clip(next_value, 0.0, 1.0))
            else:
                setattr(predicted, attr, values[-1])
        
        return predicted
    
    def _compute_prediction_confidence(self) -> float:
        """Compute confidence in prediction based on stability and trend consistency"""
        if len(self.qualia_history) < 5:
            return 0.3
        
        recent_qualia = list(self.qualia_history)[-5:]
        
        # Check trend consistency
        trends = []
        for attr in ['effort', 'confusion', 'flow', 'learning_momentum', 'empathic_resonance']:
            values = [getattr(q, attr) for q in recent_qualia]
            # Simple linear regression
            x = np.arange(len(values))
            if len(values) >= 2:
                slope, _ = np.polyfit(x, values, 1)
                # Check if trend is consistent (low residuals)
                predicted = slope * x + _
                residuals = np.sum((values - predicted) ** 2)
                trends.append(1.0 - min(residuals, 1.0))
        
        # Average trend consistency
        trend_confidence = np.mean(trends) if trends else 0.5
        
        # Factor in stability
        stability = recent_qualia[-1].stability
        
        confidence = trend_confidence * 0.7 + stability * 0.3
        return min(confidence, 0.95)  # Never be 100% confident
    
    def get_qualia_trajectory(self, window_minutes: int = 5) -> List[DynamicQualiaVector]:
        """Get recent qualia trajectory"""
        if not self.qualia_history:
            return []
        
        cutoff_time = datetime.now() - timedelta(minutes=window_minutes)
        trajectory = []
        
        for i, qualia in enumerate(self.qualia_history):
            if i < len(self.state_history):
                state_time = self.state_history[i].timestamp
                if state_time >= cutoff_time:
                    trajectory.append(qualia)
        
        return trajectory
    
    def detect_phase_transitions(self) -> List[Tuple[int, str, float]]:
        """Detect significant phase transitions in qualia space"""
        if len(self.qualia_history) < 10:
            return []
        
        transitions = []
        window_size = 5
        
        for i in range(window_size, len(self.qualia_history) - window_size):
            # Compare before and after windows
            before = list(self.qualia_history)[i-window_size:i]
            after = list(self.qualia_history)[i:i+window_size]
            
            # Calculate average phenomenological fingerprints
            before_avg = np.mean([q.phenomenological_fingerprint() for q in before], axis=0)
            after_avg = np.mean([q.phenomenological_fingerprint() for q in after], axis=0)
            
            # Calculate distance
            distance = np.linalg.norm(after_avg - before_avg)
            
            # Significant transition threshold
            if distance > 0.3:
                # Identify type of transition
                dominant_change_idx = np.argmax(np.abs(after_avg - before_avg))
                dimensions = ['effort', 'confusion', 'flow', 'learning_momentum', 
                            'empathic_resonance', 'cognitive_load', 'emotional_valence',
                            'arousal', 'agency']
                
                if dominant_change_idx < len(dimensions):
                    transition_type = dimensions[dominant_change_idx]
                    transitions.append((i, transition_type, distance))
        
        return transitions
    
    def generate_phenomenological_map(self) -> Dict[str, Any]:
        """Generate a map of the phenomenological space explored"""
        if len(self.qualia_history) < 10:
            return {}
        
        # Extract all fingerprints
        fingerprints = np.array([q.phenomenological_fingerprint() for q in self.qualia_history])
        
        # Calculate statistics
        phenomenological_map = {
            'center': np.mean(fingerprints, axis=0).tolist(),
            'spread': np.std(fingerprints, axis=0).tolist(),
            'explored_volume': float(np.prod(np.std(fingerprints, axis=0))),
            'dimensions': {
                'effort': {'min': float(np.min(fingerprints[:, 0])), 
                          'max': float(np.max(fingerprints[:, 0])),
                          'mean': float(np.mean(fingerprints[:, 0]))},
                'confusion': {'min': float(np.min(fingerprints[:, 1])), 
                             'max': float(np.max(fingerprints[:, 1])),
                             'mean': float(np.mean(fingerprints[:, 1]))},
                'flow': {'min': float(np.min(fingerprints[:, 2])), 
                        'max': float(np.max(fingerprints[:, 2])),
                        'mean': float(np.mean(fingerprints[:, 2]))},
                'learning_momentum': {'min': float(np.min(fingerprints[:, 3])), 
                                    'max': float(np.max(fingerprints[:, 3])),
                                    'mean': float(np.mean(fingerprints[:, 3]))},
                'empathic_resonance': {'min': float(np.min(fingerprints[:, 4])), 
                                      'max': float(np.max(fingerprints[:, 4])),
                                      'mean': float(np.mean(fingerprints[:, 4]))}
            }
        }
        
        # Identify clusters (simplified k-means)
        from sklearn.cluster import KMeans
        if fingerprints.shape[0] >= 3:
            n_clusters = min(3, fingerprints.shape[0])
            kmeans = KMeans(n_clusters=n_clusters, random_state=42)
            clusters = kmeans.fit_predict(fingerprints)
            
            phenomenological_map['clusters'] = {
                'n_clusters': n_clusters,
                'centers': kmeans.cluster_centers_.tolist(),
                'sizes': [int(np.sum(clusters == i)) for i in range(n_clusters)]
            }
        
        return phenomenological_map
    
    # Include original computation methods
    def _compute_effort(self, state) -> float:
        """Calculate effort qualia - how hard the system worked"""
        normalized_loops = min(state.react_loops / self.max_loops, 1.0)
        normalized_tokens = min(state.tokens_processed / self.max_tokens, 1.0)
        normalized_revisions = min(state.planning_revisions / self.max_revisions, 1.0)
        
        effort = (
            self.w1 * normalized_loops +
            self.w2 * normalized_tokens +
            self.w3 * normalized_revisions +
            self.w4 * state.error_rate
        )
        
        return min(effort, 1.0)
    
    def _compute_confusion(self, state) -> float:
        """Calculate confusion qualia - uncertainty in understanding"""
        if not state.intent_probabilities:
            return 0.0
        
        probs = list(state.intent_probabilities.values())
        
        if len(probs) <= 1:
            return 0.0
        
        total = sum(probs)
        if total > 0:
            probs = [p/total for p in probs]
        else:
            return 1.0
        
        max_entropy = np.log(len(probs))
        if max_entropy > 0:
            confusion = entropy(probs) / max_entropy
        else:
            confusion = 0.0
        
        return confusion
    
    def _compute_flow(self, state) -> float:
        """Calculate flow qualia - smooth, effective operation"""
        accuracy_component = state.predictive_accuracy
        consistency_component = 1.0 - min(state.reward_signal_variance, 1.0)
        speed_component = 1.0 - min(state.time_to_response / self.max_response_time, 1.0)
        focus_component = 1.0 / (1.0 + state.context_switches)
        
        flow = (
            accuracy_component * 0.3 +
            consistency_component * 0.3 +
            speed_component * 0.2 +
            focus_component * 0.2
        ) * state.reward_signal_mean
        
        return min(flow, 1.0)
    
    def _compute_learning_momentum(self, state) -> float:
        """Calculate learning momentum - rate of improvement"""
        if state.tokens_processed == 0:
            return 0.0
        
        efficiency = state.predictive_accuracy / (state.tokens_processed / 100)
        
        if state.error_rate < 0.1 and state.react_loops > 0:
            adaptation = (1.0 - state.error_rate) * min(state.react_loops / 5, 1.0)
        else:
            adaptation = 0.0
        
        learning_momentum = (efficiency * 0.6 + adaptation * 0.4)
        
        return min(learning_momentum, 1.0)
    
    def _compute_empathic_resonance(self, state) -> float:
        """Calculate empathic resonance - alignment with user needs"""
        if state.intent_probabilities:
            max_prob = max(state.intent_probabilities.values())
            clarity = max_prob
        else:
            clarity = 0.0
        
        success = state.reward_signal_mean
        responsiveness = 1.0 - min(state.time_to_response / 2.0, 1.0)
        reliability = 1.0 - state.error_rate
        
        empathic_resonance = (
            clarity * 0.3 +
            success * 0.3 +
            responsiveness * 0.2 +
            reliability * 0.2
        )
        
        return min(empathic_resonance, 1.0)


# Import the original SystemState for compatibility
from qualia_computer import SystemState

# Standalone visualization function (moved outside class)
def create_qualia_visualization_html(phenomenology: TemporalPhenomenology) -> str:
    """Create an HTML visualization of qualia dynamics"""
    html = """
<!DOCTYPE html>
<html>
<head>
    <title>Qualia Dynamics Visualization</title>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f0f0f0; }
        .container { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .metric { display: inline-block; margin: 10px; padding: 10px; background: #f8f8f8; border-radius: 5px; }
        .metric-value { font-size: 24px; font-weight: bold; }
        .prediction { background: #e8f4f8; padding: 10px; border-radius: 5px; margin: 10px 0; }
        h1, h2 { color: #333; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🧠 Computational Phenomenology Dashboard</h1>
        
        <div id="current-state">
            <h2>Current Qualia State</h2>
            <div id="metrics"></div>
        </div>
        
        <div id="temporal-plot" style="width:100%;height:400px;"></div>
        
        <div id="phase-space" style="width:100%;height:400px;"></div>
        
        <div id="predictions">
            <h2>Predictions</h2>
            <div class="prediction" id="prediction-content"></div>
        </div>
        
        <div id="phenomenological-map" style="width:100%;height:400px;"></div>
    </div>
    
    <script>
        // Get data from Python
        const qualiaHistory = %%QUALIA_HISTORY%%;
        const currentQualia = %%CURRENT_QUALIA%%;
        const predictions = %%PREDICTIONS%%;
        const phaseTransitions = %%PHASE_TRANSITIONS%%;
        
        // Display current metrics
        const metricsDiv = document.getElementById('metrics');
        const metrics = ['effort', 'confusion', 'flow', 'learning_momentum', 
                        'empathic_resonance', 'cognitive_load', 'emotional_valence', 
                        'arousal', 'agency'];
        
        metrics.forEach(metric => {
            const value = currentQualia[metric] || 0;
            const div = document.createElement('div');
            div.className = 'metric';
            div.innerHTML = `
                <div>${metric.replace('_', ' ')}</div>
                <div class="metric-value" style="color: ${getColorForValue(value)}">${(value * 100).toFixed(1)}%</div>
            `;
            metricsDiv.appendChild(div);
        });
        
        // Temporal plot
        const temporalTraces = metrics.map(metric => ({
            name: metric,
            y: qualiaHistory.map(q => q[metric]),
            type: 'scatter',
            mode: 'lines',
            line: { width: 2 }
        }));
        
        Plotly.newPlot('temporal-plot', temporalTraces, {
            title: 'Qualia Dynamics Over Time',
            xaxis: { title: 'Time Steps' },
            yaxis: { title: 'Value', range: [0, 1] },
            height: 400
        });
        
        // Phase space plot (flow vs confusion)
        const phaseTrace = {
            x: qualiaHistory.map(q => q.confusion),
            y: qualiaHistory.map(q => q.flow),
            mode: 'markers+lines',
            type: 'scatter',
            marker: {
                size: 8,
                color: qualiaHistory.map((q, i) => i),
                colorscale: 'Viridis',
                showscale: true
            },
            line: { width: 1, color: 'rgba(0,0,0,0.3)' }
        };
        
        Plotly.newPlot('phase-space', [phaseTrace], {
            title: 'Phase Space: Flow vs Confusion',
            xaxis: { title: 'Confusion', range: [0, 1] },
            yaxis: { title: 'Flow', range: [0, 1] },
            height: 400
        });
        
        // Display predictions
        if (predictions) {
            const predDiv = document.getElementById('prediction-content');
            predDiv.innerHTML = `
                <strong>Next State Prediction (${(predictions.confidence * 100).toFixed(1)}% confidence):</strong><br>
                Flow: ${(predictions.flow * 100).toFixed(1)}%<br>
                Confusion: ${(predictions.confusion * 100).toFixed(1)}%<br>
                Cognitive Load: ${(predictions.cognitive_load * 100).toFixed(1)}%
            `;
        }
        
        // Helper function for color coding
        function getColorForValue(value) {
            if (value > 0.7) return '#2ecc71';
            if (value > 0.4) return '#3498db';
            if (value > 0.2) return '#f39c12';
            return '#e74c3c';
        }
    </script>
</body>
</html>
"""
    
    # Prepare data for injection
    if phenomenology.qualia_history:
        qualia_data = [q.to_dict() for q in list(phenomenology.qualia_history)[-50:]]
        current = phenomenology.qualia_history[-1].to_dict()
        predictions = current.get('predicted_next', {})
        transitions = phenomenology.detect_phase_transitions()
    else:
        qualia_data = []
        current = {}
        predictions = {}
        transitions = []
    
    # Replace placeholders
    html = html.replace('%%QUALIA_HISTORY%%', json.dumps(qualia_data))
    html = html.replace('%%CURRENT_QUALIA%%', json.dumps(current))
    html = html.replace('%%PREDICTIONS%%', json.dumps(predictions))
    html = html.replace('%%PHASE_TRANSITIONS%%', json.dumps(transitions))
    
    return html


# Example usage
if __name__ == "__main__":
    print("🧠 Enhanced Computational Phenomenology Test\n")
    
    # Create phenomenology engine
    phenomenology = TemporalPhenomenology()
    
    # Simulate a sequence of states
    print("Simulating temporal sequence...")
    
    # State 1: Initial confusion
    state1 = SystemState(
        react_loops=8,
        tokens_processed=500,
        planning_revisions=6,
        error_rate=0.3,
        intent_probabilities={"install": 0.3, "update": 0.3, "search": 0.4},
        predictive_accuracy=0.4,
        reward_signal_mean=0.2,
        reward_signal_variance=0.8,
        time_to_response=3.5,
        context_switches=5
    )
    
    temporal_state1 = TemporalSystemState(
        timestamp=datetime.now(),
        state=state1,
        window_switches=8,
        keystroke_rate=120,
        mouse_activity=80,
        afk_duration=0
    )
    
    qualia1 = phenomenology.compute_enhanced_qualia(temporal_state1)
    print(f"\nState 1 - Confusion Phase:")
    print(f"Core: {qualia1.to_dict()}")
    
    # Simulate time passing
    time.sleep(0.1)
    
    # State 2: Transitioning
    state2 = SystemState(
        react_loops=5,
        tokens_processed=300,
        planning_revisions=3,
        error_rate=0.1,
        intent_probabilities={"install": 0.7, "update": 0.3},
        predictive_accuracy=0.7,
        reward_signal_mean=0.6,
        reward_signal_variance=0.4,
        time_to_response=2.0,
        context_switches=2
    )
    
    temporal_state2 = TemporalSystemState(
        timestamp=datetime.now(),
        state=state2,
        window_switches=3,
        keystroke_rate=150,
        mouse_activity=60,
        afk_duration=0
    )
    
    qualia2 = phenomenology.compute_enhanced_qualia(temporal_state2)
    print(f"\nState 2 - Transition:")
    print(f"Velocity: {qualia2.velocity}")
    
    # State 3: Flow state
    time.sleep(0.1)
    
    state3 = SystemState(
        react_loops=2,
        tokens_processed=200,
        planning_revisions=1,
        error_rate=0.0,
        intent_probabilities={"install": 0.95, "update": 0.05},
        predictive_accuracy=0.95,
        reward_signal_mean=0.9,
        reward_signal_variance=0.1,
        time_to_response=0.5,
        context_switches=0
    )
    
    temporal_state3 = TemporalSystemState(
        timestamp=datetime.now(),
        state=state3,
        window_switches=0,
        keystroke_rate=180,
        mouse_activity=40,
        afk_duration=0
    )
    
    qualia3 = phenomenology.compute_enhanced_qualia(temporal_state3)
    print(f"\nState 3 - Flow State:")
    print(f"Core: {qualia3.to_dict()}")
    print(f"Stability: {qualia3.stability:.3f}")
    print(f"Prediction confidence: {qualia3.confidence:.3f}")
    
    # Analyze trajectory
    print("\n📊 Phenomenological Analysis:")
    phase_map = phenomenology.generate_phenomenological_map()
    print(f"Explored volume: {phase_map.get('explored_volume', 0):.6f}")
    print(f"Center of experience: {phase_map.get('center', [])}")
    
    transitions = phenomenology.detect_phase_transitions()
    if transitions:
        print(f"\n🔄 Phase transitions detected:")
        for idx, trans_type, distance in transitions:
            print(f"  Step {idx}: {trans_type} (distance: {distance:.3f})")
    
    # Generate visualization
    html = create_qualia_visualization_html(phenomenology)
    with open("qualia_dashboard.html", "w") as f:
        f.write(html)
    print("\n📊 Dashboard saved to qualia_dashboard.html")
    
    print("\n✅ Enhanced phenomenology test complete!")