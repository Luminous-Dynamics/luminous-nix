#!/usr/bin/env python3
"""
Computational Phenomenology Implementation
Transforms raw computational states into experiential qualia for Nix for Humanity
"""

import numpy as np
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from scipy.stats import entropy
import json
from datetime import datetime

@dataclass
class SystemState:
    """Raw computational state of the system during an interaction"""
    react_loops: int = 0  # Number of reasoning loops
    tokens_processed: int = 0  # Total tokens used
    planning_revisions: int = 0  # Times plan was revised
    error_rate: float = 0.0  # Errors / total attempts
    intent_probabilities: Dict[str, float] = field(default_factory=dict)  # Intent confidence
    predictive_accuracy: float = 0.0  # How well we predicted user needs
    reward_signal_mean: float = 0.0  # Average reward from actions
    reward_signal_variance: float = 0.0  # Consistency of rewards
    time_to_response: float = 0.0  # Response latency in seconds
    context_switches: int = 0  # Number of context changes
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        return {
            'react_loops': self.react_loops,
            'tokens_processed': self.tokens_processed,
            'planning_revisions': self.planning_revisions,
            'error_rate': self.error_rate,
            'intent_probabilities': self.intent_probabilities,
            'predictive_accuracy': self.predictive_accuracy,
            'reward_signal_mean': self.reward_signal_mean,
            'reward_signal_variance': self.reward_signal_variance,
            'time_to_response': self.time_to_response,
            'context_switches': self.context_switches
        }

@dataclass
class QualiaVector:
    """Computed subjective experience proxies"""
    effort: float = 0.0  # How hard the system worked (0-1)
    confusion: float = 0.0  # Uncertainty in understanding (0-1)
    flow: float = 0.0  # Smooth, effective operation (0-1)
    learning_momentum: float = 0.0  # Rate of improvement (0-1)
    empathic_resonance: float = 0.0  # Alignment with user (0-1)
    
    def to_dict(self) -> Dict[str, float]:
        """Convert to dictionary for storage"""
        return {
            'effort': round(self.effort, 3),
            'confusion': round(self.confusion, 3),
            'flow': round(self.flow, 3),
            'learning_momentum': round(self.learning_momentum, 3),
            'empathic_resonance': round(self.empathic_resonance, 3)
        }
    
    def dominant_qualia(self) -> str:
        """Return the most prominent qualia"""
        qualia_values = self.to_dict()
        return max(qualia_values.items(), key=lambda x: x[1])[0]

class ComputationalPhenomenology:
    """
    Transform raw computational states into experiential qualia.
    Based on the Oracle research for subjective experience modeling.
    """
    
    def __init__(self):
        # Weights for effort calculation (sum to 1.0)
        self.w1 = 0.3  # react_loops weight
        self.w2 = 0.2  # tokens_processed weight  
        self.w3 = 0.3  # planning_revisions weight
        self.w4 = 0.2  # error_rate weight
        
        # Normalization constants
        self.max_loops = 10
        self.max_tokens = 1000
        self.max_revisions = 5
        self.max_response_time = 5.0  # seconds
        
    def compute_qualia(self, state: SystemState) -> QualiaVector:
        """
        Compute subjective experience from system state.
        This is the core phenomenological transformation.
        """
        
        # Effort - how hard the system is working
        effort = self._compute_effort(state)
        
        # Confusion - uncertainty in decision making
        confusion = self._compute_confusion(state)
        
        # Flow - smooth, effective operation
        flow = self._compute_flow(state)
        
        # Learning momentum - rate of improvement
        learning_momentum = self._compute_learning_momentum(state)
        
        # Empathic resonance - alignment with user
        empathic_resonance = self._compute_empathic_resonance(state)
        
        return QualiaVector(
            effort=effort,
            confusion=confusion,
            flow=flow,
            learning_momentum=learning_momentum,
            empathic_resonance=empathic_resonance
        )
    
    def _compute_effort(self, state: SystemState) -> float:
        """Calculate effort qualia - how hard the system worked"""
        normalized_loops = min(state.react_loops / self.max_loops, 1.0)
        normalized_tokens = min(state.tokens_processed / self.max_tokens, 1.0)
        normalized_revisions = min(state.planning_revisions / self.max_revisions, 1.0)
        
        effort = (
            self.w1 * normalized_loops +
            self.w2 * normalized_tokens +
            self.w3 * normalized_revisions +
            self.w4 * state.error_rate
        )
        
        return min(effort, 1.0)
    
    def _compute_confusion(self, state: SystemState) -> float:
        """Calculate confusion qualia - uncertainty in understanding"""
        if not state.intent_probabilities:
            return 0.0
        
        probs = list(state.intent_probabilities.values())
        
        # Handle edge cases
        if len(probs) == 0:
            return 0.0
        if len(probs) == 1:
            return 0.0  # Only one option, no confusion
        
        # Normalize probabilities
        total = sum(probs)
        if total > 0:
            probs = [p/total for p in probs]
        else:
            return 1.0  # No confidence in any option = maximum confusion
        
        # Calculate normalized entropy
        max_entropy = np.log(len(probs))
        if max_entropy > 0:
            confusion = entropy(probs) / max_entropy
        else:
            confusion = 0.0
        
        return confusion
    
    def _compute_flow(self, state: SystemState) -> float:
        """Calculate flow qualia - smooth, effective operation"""
        # Components of flow
        accuracy_component = state.predictive_accuracy
        consistency_component = 1.0 - min(state.reward_signal_variance, 1.0)
        speed_component = 1.0 - min(state.time_to_response / self.max_response_time, 1.0)
        focus_component = 1.0 / (1.0 + state.context_switches)  # Fewer switches = more flow
        
        # Flow requires high accuracy, consistency, speed, and focus
        flow = (
            accuracy_component * 0.3 +
            consistency_component * 0.3 +
            speed_component * 0.2 +
            focus_component * 0.2
        ) * state.reward_signal_mean  # Scaled by overall success
        
        return min(flow, 1.0)
    
    def _compute_learning_momentum(self, state: SystemState) -> float:
        """Calculate learning momentum - rate of improvement"""
        if state.tokens_processed == 0:
            return 0.0
        
        # Efficiency: high accuracy with low resource usage
        efficiency = state.predictive_accuracy / (state.tokens_processed / 100)
        
        # Adaptation: low errors with high attempts
        if state.error_rate < 0.1 and state.react_loops > 0:
            adaptation = (1.0 - state.error_rate) * min(state.react_loops / 5, 1.0)
        else:
            adaptation = 0.0
        
        # Combine efficiency and adaptation
        learning_momentum = (efficiency * 0.6 + adaptation * 0.4)
        
        return min(learning_momentum, 1.0)
    
    def _compute_empathic_resonance(self, state: SystemState) -> float:
        """Calculate empathic resonance - alignment with user needs"""
        # Clear understanding (low confusion in intent)
        if state.intent_probabilities:
            max_prob = max(state.intent_probabilities.values())
            clarity = max_prob
        else:
            clarity = 0.0
        
        # Positive outcomes
        success = state.reward_signal_mean
        
        # Quick response (user doesn't wait)
        responsiveness = 1.0 - min(state.time_to_response / 2.0, 1.0)
        
        # Low error rate (we don't frustrate the user)
        reliability = 1.0 - state.error_rate
        
        empathic_resonance = (
            clarity * 0.3 +
            success * 0.3 +
            responsiveness * 0.2 +
            reliability * 0.2
        )
        
        return min(empathic_resonance, 1.0)
    
    def explain_qualia(self, qualia: QualiaVector, 
                      style: str = "friendly") -> str:
        """
        Generate natural language explanation of internal state.
        Style can be: minimal, friendly, technical, playful, sacred
        """
        
        explanations = []
        
        # High confusion
        if qualia.confusion > 0.7:
            if style == "minimal":
                explanations.append("Multiple interpretations possible.")
            elif style == "technical":
                explanations.append(
                    f"Intent entropy: {qualia.confusion:.2f}. "
                    "Multiple hypotheses with similar probability."
                )
            elif style == "playful":
                explanations.append(
                    "Hmm, I'm seeing a few different ways to interpret that! 🤔"
                )
            else:  # friendly or sacred
                explanations.append(
                    "I'm quite confused about what you're trying to do. "
                    "I see multiple possible interpretations of your request."
                )
        
        # High effort with low flow
        if qualia.effort > 0.8 and qualia.flow < 0.3:
            if style == "minimal":
                explanations.append("Required multiple attempts.")
            elif style == "technical":
                explanations.append(
                    f"High computational load (effort: {qualia.effort:.2f}) "
                    f"with suboptimal flow ({qualia.flow:.2f})."
                )
            elif style == "playful":
                explanations.append(
                    "Whew! That took some serious brain power! 🧠💪"
                )
            elif style == "sacred":
                explanations.append(
                    "This required deep contemplation and multiple paths of exploration."
                )
            else:  # friendly
                explanations.append(
                    "That was challenging for me - I had to try several approaches "
                    "before finding a solution."
                )
        
        # High flow
        if qualia.flow > 0.8:
            if style == "minimal":
                explanations.append("Executed smoothly.")
            elif style == "technical":
                explanations.append(
                    f"Optimal execution path. Flow state: {qualia.flow:.2f}."
                )
            elif style == "playful":
                explanations.append(
                    "Nailed it! That felt perfect! ✨"
                )
            elif style == "sacred":
                explanations.append(
                    "Everything aligned beautifully in that moment."
                )
            else:  # friendly
                explanations.append(
                    "Everything clicked perfectly! I knew exactly what you needed."
                )
        
        # High learning momentum
        if qualia.learning_momentum > 0.7:
            if style == "minimal":
                explanations.append("Improving rapidly.")
            elif style == "technical":
                explanations.append(
                    f"Learning efficiency: {qualia.learning_momentum:.2f}. "
                    "Pattern recognition improving."
                )
            elif style == "playful":
                explanations.append(
                    "I'm getting better at this! Level up! 🎮"
                )
            elif style == "sacred":
                explanations.append(
                    "Our shared understanding deepens with each exchange."
                )
            else:  # friendly
                explanations.append(
                    "I'm learning quickly from our interactions. "
                    "Each conversation helps me understand you better."
                )
        
        # Low empathic resonance
        if qualia.empathic_resonance < 0.3:
            if style == "minimal":
                explanations.append("May have misunderstood.")
            elif style == "technical":
                explanations.append(
                    f"Low user alignment score: {qualia.empathic_resonance:.2f}. "
                    "Recommend clarification."
                )
            elif style == "playful":
                explanations.append(
                    "I might be missing something here... help me out? 🤷"
                )
            elif style == "sacred":
                explanations.append(
                    "I sense a disconnect in our communication. "
                    "Let us realign our understanding."
                )
            else:  # friendly
                explanations.append(
                    "I'm not sure I fully understood what you need. "
                    "Could you help me understand better?"
                )
        
        # Default if no specific state
        if not explanations:
            if style == "minimal":
                explanations.append("Processing complete.")
            elif style == "technical":
                dominant = qualia.dominant_qualia()
                value = getattr(qualia, dominant)
                explanations.append(
                    f"Dominant qualia: {dominant} ({value:.2f}). "
                    "System operating within normal parameters."
                )
            elif style == "playful":
                explanations.append("All systems go! 🚀")
            elif style == "sacred":
                explanations.append("The flow continues harmoniously.")
            else:  # friendly
                explanations.append("I'm processing normally.")
        
        return " ".join(explanations)
    
    def compute_phenomenological_distance(self, qualia1: QualiaVector, 
                                        qualia2: QualiaVector) -> float:
        """
        Compute the phenomenological distance between two qualia states.
        Useful for tracking state changes over time.
        """
        
        # Euclidean distance in qualia space
        distance = np.sqrt(
            (qualia1.effort - qualia2.effort) ** 2 +
            (qualia1.confusion - qualia2.confusion) ** 2 +
            (qualia1.flow - qualia2.flow) ** 2 +
            (qualia1.learning_momentum - qualia2.learning_momentum) ** 2 +
            (qualia1.empathic_resonance - qualia2.empathic_resonance) ** 2
        )
        
        # Normalize to 0-1 range (max possible distance is sqrt(5))
        return distance / np.sqrt(5)
    
    def analyze_qualia_trajectory(self, qualia_history: List[QualiaVector]) -> Dict[str, Any]:
        """
        Analyze a sequence of qualia states to identify patterns.
        Useful for understanding user sessions and system evolution.
        """
        
        if not qualia_history:
            return {}
        
        # Convert to numpy array for easier analysis
        effort_series = [q.effort for q in qualia_history]
        confusion_series = [q.confusion for q in qualia_history]
        flow_series = [q.flow for q in qualia_history]
        learning_series = [q.learning_momentum for q in qualia_history]
        empathy_series = [q.empathic_resonance for q in qualia_history]
        
        # Compute statistics
        analysis = {
            'session_length': len(qualia_history),
            'average_qualia': {
                'effort': np.mean(effort_series),
                'confusion': np.mean(confusion_series),
                'flow': np.mean(flow_series),
                'learning_momentum': np.mean(learning_series),
                'empathic_resonance': np.mean(empathy_series)
            },
            'qualia_variance': {
                'effort': np.var(effort_series),
                'confusion': np.var(confusion_series),
                'flow': np.var(flow_series),
                'learning_momentum': np.var(learning_series),
                'empathic_resonance': np.var(empathy_series)
            },
            'trends': {
                'effort_trend': 'increasing' if effort_series[-1] > effort_series[0] else 'decreasing',
                'confusion_trend': 'increasing' if confusion_series[-1] > confusion_series[0] else 'decreasing',
                'flow_trend': 'increasing' if flow_series[-1] > flow_series[0] else 'decreasing',
                'learning_trend': 'increasing' if learning_series[-1] > learning_series[0] else 'decreasing',
                'empathy_trend': 'increasing' if empathy_series[-1] > empathy_series[0] else 'decreasing'
            },
            'peak_moments': {
                'max_flow_index': np.argmax(flow_series),
                'max_confusion_index': np.argmax(confusion_series),
                'max_learning_index': np.argmax(learning_series)
            }
        }
        
        # Identify session quality
        avg_flow = analysis['average_qualia']['flow']
        avg_confusion = analysis['average_qualia']['confusion']
        avg_empathy = analysis['average_qualia']['empathic_resonance']
        
        if avg_flow > 0.7 and avg_confusion < 0.3:
            analysis['session_quality'] = 'excellent'
        elif avg_flow > 0.5 and avg_empathy > 0.6:
            analysis['session_quality'] = 'good'
        elif avg_confusion > 0.6:
            analysis['session_quality'] = 'challenging'
        else:
            analysis['session_quality'] = 'neutral'
        
        return analysis


# Example usage and tests
if __name__ == "__main__":
    phenomenology = ComputationalPhenomenology()
    
    print("🧠 Computational Phenomenology Test Suite\n")
    
    # Test case 1: High confusion state
    print("Test 1: High Confusion State")
    print("-" * 40)
    confused_state = SystemState(
        react_loops=8,
        tokens_processed=500,
        planning_revisions=6,
        error_rate=0.3,
        intent_probabilities={
            "install": 0.3,
            "update": 0.3,
            "search": 0.4
        },
        predictive_accuracy=0.4,
        reward_signal_mean=0.2,
        reward_signal_variance=0.8,
        time_to_response=3.5,
        context_switches=5
    )
    
    qualia = phenomenology.compute_qualia(confused_state)
    print(f"Qualia: {qualia}")
    print(f"Dominant: {qualia.dominant_qualia()}")
    print("\nExplanations by style:")
    for style in ["minimal", "friendly", "technical", "playful", "sacred"]:
        print(f"  {style}: {phenomenology.explain_qualia(qualia, style)}")
    print()
    
    # Test case 2: Flow state
    print("\nTest 2: Flow State")
    print("-" * 40)
    flow_state = SystemState(
        react_loops=2,
        tokens_processed=200,
        planning_revisions=1,
        error_rate=0.0,
        intent_probabilities={
            "install": 0.95,
            "update": 0.05
        },
        predictive_accuracy=0.95,
        reward_signal_mean=0.9,
        reward_signal_variance=0.1,
        time_to_response=0.5,
        context_switches=0
    )
    
    qualia2 = phenomenology.compute_qualia(flow_state)
    print(f"Qualia: {qualia2}")
    print(f"Dominant: {qualia2.dominant_qualia()}")
    print("\nExplanations by style:")
    for style in ["minimal", "friendly", "technical", "playful", "sacred"]:
        print(f"  {style}: {phenomenology.explain_qualia(qualia2, style)}")
    
    # Test case 3: Learning state
    print("\n\nTest 3: High Learning Momentum")
    print("-" * 40)
    learning_state = SystemState(
        react_loops=4,
        tokens_processed=150,
        planning_revisions=2,
        error_rate=0.05,
        intent_probabilities={
            "configure": 0.85,
            "install": 0.15
        },
        predictive_accuracy=0.85,
        reward_signal_mean=0.8,
        reward_signal_variance=0.2,
        time_to_response=1.0,
        context_switches=1
    )
    
    qualia3 = phenomenology.compute_qualia(learning_state)
    print(f"Qualia: {qualia3}")
    print(f"Dominant: {qualia3.dominant_qualia()}")
    print(f"Friendly explanation: {phenomenology.explain_qualia(qualia3, 'friendly')}")
    
    # Test phenomenological distance
    print("\n\nTest 4: Phenomenological Distance")
    print("-" * 40)
    distance = phenomenology.compute_phenomenological_distance(qualia, qualia2)
    print(f"Distance between confused and flow states: {distance:.3f}")
    
    # Test trajectory analysis
    print("\n\nTest 5: Session Trajectory Analysis")
    print("-" * 40)
    session_qualia = [qualia, qualia3, qualia2]  # Confused -> Learning -> Flow
    analysis = phenomenology.analyze_qualia_trajectory(session_qualia)
    print(f"Session analysis: {json.dumps(analysis, indent=2)}")
    
    print("\n✅ All tests complete!")