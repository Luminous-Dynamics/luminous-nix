#!/usr/bin/env python3
"""
Real-time Qualia Dashboard Server
Streams ActivityWatch data through phenomenological engine
"""

import asyncio
import json
import time
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List
from pathlib import Path
import logging
from aiohttp import web
import aiohttp_cors
from weakref import WeakSet
import threading

# Import our phenomenological components
from enhanced_qualia_computer import (
    TemporalPhenomenology, 
    TemporalSystemState,
    DynamicQualiaVector,
    create_qualia_visualization_html
)
from qualia_computer import SystemState

# Import metrics collector
import sys
sys.path.append(str(Path(__file__).parent.parent / "benchmarks"))
from consciousness_metrics import ConsciousnessMetricsCollector

# ActivityWatch client (will be available after installation)
try:
    from aw_client import ActivityWatchClient
    ACTIVITYWATCH_AVAILABLE = True
except ImportError:
    ACTIVITYWATCH_AVAILABLE = False
    print("ActivityWatch not available. Running in demo mode.")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class QualiaRealtimeServer:
    """
    Real-time server that:
    1. Connects to ActivityWatch for behavioral data
    2. Processes through phenomenological engine
    3. Serves live dashboard via WebSocket
    4. Records consciousness metrics
    """
    
    def __init__(self, port: int = 8765):
        self.port = port
        self.app = web.Application()
        self.phenomenology = TemporalPhenomenology()
        self.metrics_collector = ConsciousnessMetricsCollector()
        self.websockets: WeakSet = WeakSet()
        
        # Start new session
        self.metrics_collector.start_session()
        
        # ActivityWatch client
        if ACTIVITYWATCH_AVAILABLE:
            self.aw_client = ActivityWatchClient("qualia-dashboard")
        else:
            self.aw_client = None
            
        # Background task handle
        self.background_task = None
        
        # Setup routes
        self._setup_routes()
        
    def _setup_routes(self):
        """Setup HTTP and WebSocket routes"""
        # Enable CORS
        cors = aiohttp_cors.setup(self.app, defaults={
            "*": aiohttp_cors.ResourceOptions(
                allow_credentials=True,
                expose_headers="*",
                allow_headers="*",
                allow_methods="*"
            )
        })
        
        # Dashboard route
        self.app.router.add_get('/', self.serve_dashboard)
        self.app.router.add_get('/ws', self.websocket_handler)
        self.app.router.add_post('/api/interaction', self.record_interaction)
        self.app.router.add_get('/api/metrics', self.get_metrics)
        
        # Apply CORS to all routes
        for route in list(self.app.router.routes()):
            cors.add(route)
    
    async def serve_dashboard(self, request):
        """Serve the main dashboard HTML"""
        # Create initial visualization
        html = create_qualia_visualization_html(self.phenomenology)
        
        # Modify to add WebSocket connection
        websocket_script = """
        <script>
            // WebSocket connection for real-time updates
            const ws = new WebSocket('ws://localhost:8765/ws');
            
            ws.onopen = () => {
                console.log('Connected to qualia stream');
                document.getElementById('connection-status').textContent = '🟢 Connected';
            };
            
            ws.onmessage = (event) => {
                const data = JSON.parse(event.data);
                
                if (data.type === 'qualia_update') {
                    updateQualia(data.qualia);
                } else if (data.type === 'activity_update') {
                    updateActivity(data.activity);
                }
            };
            
            ws.onclose = () => {
                console.log('Disconnected from qualia stream');
                document.getElementById('connection-status').textContent = '🔴 Disconnected';
            };
            
            function updateQualia(qualia) {
                // Update metrics display
                const metricsDiv = document.getElementById('metrics');
                metricsDiv.innerHTML = '';
                
                const metrics = ['effort', 'confusion', 'flow', 'learning_momentum', 
                                'empathic_resonance', 'cognitive_load', 'emotional_valence', 
                                'arousal', 'agency'];
                
                metrics.forEach(metric => {
                    const value = qualia[metric] || 0;
                    const div = document.createElement('div');
                    div.className = 'metric';
                    div.innerHTML = `
                        <div>${metric.replace('_', ' ')}</div>
                        <div class="metric-value" style="color: ${getColorForValue(value)}">${(value * 100).toFixed(1)}%</div>
                    `;
                    metricsDiv.appendChild(div);
                });
                
                // Update stability indicator
                if (qualia.stability !== undefined) {
                    document.getElementById('stability-indicator').textContent = 
                        `Stability: ${(qualia.stability * 100).toFixed(0)}%`;
                }
            }
            
            function updateActivity(activity) {
                // Update activity indicators
                document.getElementById('activity-app').textContent = activity.active_app || 'Unknown';
                document.getElementById('activity-switches').textContent = activity.window_switches || 0;
                document.getElementById('activity-typing').textContent = 
                    `${activity.keystroke_rate?.toFixed(0) || 0} keys/min`;
            }
        </script>
        """
        
        # Add connection status and activity display
        status_html = """
        <div style="position: fixed; top: 10px; right: 10px; padding: 10px; background: rgba(255,255,255,0.9); border-radius: 5px;">
            <div id="connection-status">🟡 Connecting...</div>
            <div style="margin-top: 10px;">
                <strong>Current Activity:</strong><br>
                App: <span id="activity-app">-</span><br>
                Switches: <span id="activity-switches">0</span><br>
                Typing: <span id="activity-typing">0 keys/min</span>
            </div>
            <div id="stability-indicator" style="margin-top: 10px; font-weight: bold;">
                Stability: -
            </div>
        </div>
        """
        
        # Insert scripts and status before closing body tag
        html = html.replace('</body>', f'{status_html}{websocket_script}</body>')
        
        return web.Response(text=html, content_type='text/html')
    
    async def websocket_handler(self, request):
        """Handle WebSocket connections"""
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        self.websockets.add(ws)
        
        try:
            async for msg in ws:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    # Handle client messages if needed
                    pass
                elif msg.type == aiohttp.WSMsgType.ERROR:
                    logger.error(f'WebSocket error: {ws.exception()}')
        finally:
            self.websockets.discard(ws)
            
        return ws
    
    async def broadcast_update(self, data: Dict[str, Any]):
        """Broadcast update to all connected clients"""
        if self.websockets:
            await asyncio.gather(
                *[ws.send_str(json.dumps(data)) for ws in self.websockets],
                return_exceptions=True
            )
    
    async def collect_activity_data(self) -> Dict[str, Any]:
        """Collect current activity data from ActivityWatch"""
        if not ACTIVITYWATCH_AVAILABLE or not self.aw_client:
            # Return demo data
            return {
                'active_app': 'demo_app',
                'window_switches': 2,
                'keystroke_rate': 85.0,
                'mouse_activity': 45.0,
                'afk_duration': 0.0
            }
        
        try:
            # Get recent events
            buckets = self.aw_client.get_buckets()
            
            # Find window bucket
            window_bucket = None
            for bucket_id in buckets:
                if "window" in bucket_id:
                    window_bucket = bucket_id
                    break
            
            if not window_bucket:
                return {}
            
            # Get last minute of events
            end_time = datetime.now(timezone.utc)
            start_time = end_time - timedelta(minutes=1)
            
            events = self.aw_client.get_events(
                window_bucket,
                start=start_time,
                end=end_time,
                limit=10
            )
            
            # Calculate metrics
            if events:
                current_app = events[0]['data'].get('app', 'unknown')
                window_switches = len(set(e['data'].get('app', '') for e in events)) - 1
                
                # Simulated keystroke rate (would need keylogger bucket)
                keystroke_rate = 60.0 + (window_switches * 20)
                
                return {
                    'active_app': current_app,
                    'window_switches': window_switches,
                    'keystroke_rate': keystroke_rate,
                    'mouse_activity': 50.0,
                    'afk_duration': 0.0
                }
            
        except Exception as e:
            logger.error(f"Error collecting ActivityWatch data: {e}")
            
        return {}
    
    def simulate_system_state(self, activity: Dict[str, Any]) -> SystemState:
        """Create system state from activity data"""
        # Simulate based on activity
        window_switches = activity.get('window_switches', 0)
        keystroke_rate = activity.get('keystroke_rate', 0)
        
        # High switching = confusion
        confusion_level = min(window_switches / 5, 1.0)
        
        # High keystroke = effort
        effort_level = min(keystroke_rate / 150, 1.0)
        
        # Create simulated state
        return SystemState(
            react_loops=int(effort_level * 8),
            tokens_processed=int(keystroke_rate * 2),
            planning_revisions=window_switches,
            error_rate=confusion_level * 0.3,
            intent_probabilities={'work': 1.0 - confusion_level, 'explore': confusion_level},
            predictive_accuracy=1.0 - confusion_level,
            reward_signal_mean=0.5 + (1.0 - confusion_level) * 0.5,
            reward_signal_variance=confusion_level * 0.5,
            time_to_response=0.5 + confusion_level * 2.5,
            context_switches=window_switches
        )
    
    async def background_processor(self):
        """Background task to process activity and update qualia"""
        logger.info("Starting background qualia processor")
        
        while True:
            try:
                # Collect activity data
                activity = await self.collect_activity_data()
                
                # Create temporal state
                system_state = self.simulate_system_state(activity)
                temporal_state = TemporalSystemState(
                    timestamp=datetime.now(),
                    state=system_state,
                    window_switches=activity.get('window_switches', 0),
                    keystroke_rate=activity.get('keystroke_rate', 0),
                    mouse_activity=activity.get('mouse_activity', 0),
                    afk_duration=activity.get('afk_duration', 0),
                    active_app=activity.get('active_app', ''),
                    state_duration=1.0  # 1 second updates
                )
                
                # Compute enhanced qualia
                qualia = self.phenomenology.compute_enhanced_qualia(temporal_state)
                
                # Update consciousness metrics
                self.metrics_collector.update_flow_state(qualia.flow, stable=qualia.stability > 0.7)
                
                if qualia.confusion > 0.7:
                    self.metrics_collector.record_confusion()
                elif qualia.flow > 0.7:
                    self.metrics_collector.record_clarity()
                
                # Broadcast updates
                await self.broadcast_update({
                    'type': 'qualia_update',
                    'timestamp': datetime.now().isoformat(),
                    'qualia': qualia.to_dict()
                })
                
                await self.broadcast_update({
                    'type': 'activity_update',
                    'timestamp': datetime.now().isoformat(),
                    'activity': activity
                })
                
                # Log state
                logger.debug(f"Qualia state: Flow={qualia.flow:.2f}, Confusion={qualia.confusion:.2f}, "
                           f"Load={qualia.cognitive_load:.2f}, Stability={qualia.stability:.2f}")
                
            except Exception as e:
                logger.error(f"Error in background processor: {e}")
            
            # Update every second
            await asyncio.sleep(1)
    
    async def record_interaction(self, request):
        """Record an interaction via API"""
        try:
            data = await request.json()
            
            # Create interaction metrics
            from consciousness_metrics import InteractionMetrics
            interaction = InteractionMetrics(
                input_complexity=data.get('complexity', 0.5),
                response_latency=data.get('latency', 1.0),
                successful=data.get('successful', True),
                learning_moment=data.get('learning', False)
            )
            interaction.end_time = datetime.now()
            
            # Record in collector
            self.metrics_collector.record_interaction(interaction)
            
            return web.json_response({'status': 'recorded'})
            
        except Exception as e:
            return web.json_response({'error': str(e)}, status=400)
    
    async def get_metrics(self, request):
        """Get current consciousness metrics"""
        summary = self.metrics_collector.get_session_summary()
        return web.json_response(summary)
    
    async def start_background_tasks(self, app):
        """Start background tasks on app startup"""
        app['background_task'] = asyncio.create_task(self.background_processor())
    
    async def cleanup_background_tasks(self, app):
        """Cleanup on app shutdown"""
        app['background_task'].cancel()
        await app['background_task']
        
        # Save metrics
        self.metrics_collector.save_session()
        logger.info("Saved consciousness metrics")
    
    def run(self):
        """Run the server"""
        self.app.on_startup.append(self.start_background_tasks)
        self.app.on_cleanup.append(self.cleanup_background_tasks)
        
        logger.info(f"🧠 Qualia Dashboard starting on http://localhost:{self.port}")
        logger.info("📊 Open your browser to see real-time phenomenological states")
        
        if not ACTIVITYWATCH_AVAILABLE:
            logger.warning("⚠️  ActivityWatch not available - running in demo mode")
            logger.info("Install ActivityWatch for real behavioral data")
        
        web.run_app(self.app, host='0.0.0.0', port=self.port)


if __name__ == "__main__":
    server = QualiaRealtimeServer()
    server.run()