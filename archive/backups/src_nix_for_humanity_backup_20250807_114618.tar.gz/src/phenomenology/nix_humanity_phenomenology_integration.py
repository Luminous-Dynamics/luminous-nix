#!/usr/bin/env python3
"""
Nix for Humanity + Phenomenology Integration
Shows how system's internal state affects user interactions
"""

import json
import sqlite3
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from pathlib import Path
import sys

# Import our phenomenological components
from enhanced_qualia_computer import (
    TemporalPhenomenology,
    TemporalSystemState,
    DynamicQualiaVector
)
from qualia_computer import SystemState, ComputationalPhenomenology

# Import from Nix for Humanity
sys.path.append(str(Path(__file__).parent.parent))
from nlp.intent_engine import IntentEngine
from utils.response_generator import ResponseGenerator
from models.personas import PersonaManager

@dataclass
class PhenomenologicalContext:
    """Context that includes both user intent and system phenomenology"""
    intent: str
    confidence: float
    user_query: str
    system_state: SystemState
    temporal_state: TemporalSystemState
    qualia: DynamicQualiaVector
    behavioral_context: Dict[str, Any]

class PhenomenologicalNixAssistant:
    """
    Enhanced Nix for Humanity assistant that adapts based on phenomenological state
    """
    
    def __init__(self):
        self.phenomenology = TemporalPhenomenology()
        self.basic_phenomenology = ComputationalPhenomenology()
        self.intent_engine = IntentEngine()
        self.response_generator = ResponseGenerator()
        self.persona_manager = PersonaManager()
        
        # Response modulation strategies
        self.response_strategies = {
            'flow': self._flow_optimized_response,
            'confused': self._confusion_aware_response,
            'overloaded': self._load_reducing_response,
            'learning': self._pedagogical_response,
            'struggling': self._supportive_response
        }
        
    def process_query(self, query: str, activity_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process user query with phenomenological awareness"""
        
        # 1. Basic intent recognition
        intent_result = self.intent_engine.classify_intent(query)
        
        # 2. Create system state from processing
        system_state = SystemState(
            react_loops=len(intent_result.get('alternatives', [])),
            tokens_processed=len(query.split()),
            planning_revisions=0,
            error_rate=0.0,
            intent_probabilities=intent_result.get('probabilities', {}),
            predictive_accuracy=intent_result.get('confidence', 0.5),
            reward_signal_mean=0.5,
            reward_signal_variance=0.1,
            time_to_response=0.0,
            context_switches=activity_data.get('window_switches', 0)
        )
        
        # 3. Create temporal state with activity data
        temporal_state = TemporalSystemState(
            timestamp=datetime.now(),
            state=system_state,
            window_switches=activity_data.get('window_switches', 0),
            keystroke_rate=activity_data.get('keystroke_rate', 60),
            mouse_activity=activity_data.get('mouse_activity', 50),
            afk_duration=activity_data.get('afk_duration', 0),
            active_app=activity_data.get('active_app', 'terminal')
        )
        
        # 4. Compute phenomenological state
        qualia = self.phenomenology.compute_enhanced_qualia(temporal_state)
        
        # 5. Create full context
        context = PhenomenologicalContext(
            intent=intent_result.get('intent', 'unknown'),
            confidence=intent_result.get('confidence', 0.5),
            user_query=query,
            system_state=system_state,
            temporal_state=temporal_state,
            qualia=qualia,
            behavioral_context=activity_data
        )
        
        # 6. Generate phenomenologically-aware response
        response = self._generate_aware_response(context)
        
        # 7. Add metadata for transparency
        response['phenomenological_transparency'] = {
            'current_state': self._describe_state(qualia),
            'adaptation_reason': self._explain_adaptation(qualia),
            'confidence_level': qualia.confidence if qualia.confidence else 0.5
        }
        
        return response
    
    def _generate_aware_response(self, context: PhenomenologicalContext) -> Dict[str, Any]:
        """Generate response adapted to phenomenological state"""
        
        # Determine primary state
        state = self._categorize_state(context.qualia)
        
        # Get appropriate strategy
        strategy = self.response_strategies.get(state, self._default_response)
        
        # Generate response
        return strategy(context)
    
    def _categorize_state(self, qualia: DynamicQualiaVector) -> str:
        """Categorize the phenomenological state"""
        
        if qualia.flow > 0.7 and qualia.confusion < 0.3:
            return 'flow'
        elif qualia.confusion > 0.6:
            return 'confused'
        elif qualia.cognitive_load > 0.7:
            return 'overloaded'
        elif qualia.learning_momentum > 0.6:
            return 'learning'
        elif qualia.frustration_level > 0.5:
            return 'struggling'
        else:
            return 'neutral'
    
    def _flow_optimized_response(self, context: PhenomenologicalContext) -> Dict[str, Any]:
        """Response optimized for flow state - minimal interruption"""
        
        # Quick, efficient responses
        if context.intent == 'install':
            return {
                'response': f"Installing {context.user_query.split()[-1]}...",
                'command': f"nix-env -iA nixpkgs.{context.user_query.split()[-1]}",
                'style': 'minimal',
                'explanation': None,  # Don't break flow with explanations
                'follow_up': None,    # No questions
                'timing': 'immediate'
            }
        
        return {
            'response': "Done.",
            'style': 'minimal',
            'preserve_flow': True
        }
    
    def _confusion_aware_response(self, context: PhenomenologicalContext) -> Dict[str, Any]:
        """Response for confused state - clarify and guide"""
        
        # Detect source of confusion
        alternatives = self._get_intent_alternatives(context)
        
        return {
            'response': "I notice there might be some uncertainty. Let me help clarify:",
            'clarifications': alternatives,
            'style': 'patient',
            'explanation': "I detected multiple possible interpretations of your request",
            'suggestions': [
                f"Did you mean to {alt}?" for alt in alternatives[:3]
            ],
            'visual_aid': self._generate_decision_tree(alternatives)
        }
    
    def _load_reducing_response(self, context: PhenomenologicalContext) -> Dict[str, Any]:
        """Response for cognitive overload - simplify and chunk"""
        
        # Break down complex requests
        steps = self._decompose_task(context.user_query)
        
        return {
            'response': "Let's break this down into manageable steps:",
            'steps': steps,
            'current_step': steps[0] if steps else None,
            'style': 'simplified',
            'pace': 'slow',
            'confirmation_required': True,
            'cognitive_aids': {
                'progress_tracker': True,
                'single_focus': True,
                'auto_save_state': True
            }
        }
    
    def _pedagogical_response(self, context: PhenomenologicalContext) -> Dict[str, Any]:
        """Response for learning state - educational and encouraging"""
        
        # Enhanced explanations
        concept = self._identify_learning_concept(context)
        
        return {
            'response': f"Great question! Let's explore {concept} together.",
            'explanation': self._generate_progressive_explanation(concept),
            'examples': self._get_relevant_examples(concept),
            'style': 'educational',
            'encouragement': "You're building strong understanding!",
            'related_concepts': self._find_related_concepts(concept),
            'practice_suggestion': f"Try: {self._suggest_practice(concept)}"
        }
    
    def _supportive_response(self, context: PhenomenologicalContext) -> Dict[str, Any]:
        """Response for struggling state - extra support and options"""
        
        return {
            'response': "I understand this can be challenging. Here are some options:",
            'alternatives': [
                {
                    'approach': 'guided',
                    'description': 'I'll walk you through step-by-step',
                    'command': 'ask-nix --guided'
                },
                {
                    'approach': 'example',
                    'description': 'See a similar example first',
                    'command': 'ask-nix --example'
                },
                {
                    'approach': 'simpler',
                    'description': 'Try a simpler version',
                    'suggestion': self._simplify_request(context.user_query)
                }
            ],
            'style': 'supportive',
            'reassurance': "There's no rush - we'll find an approach that works for you",
            'escape_hatch': "Type 'reset' anytime to start fresh"
        }
    
    def _default_response(self, context: PhenomenologicalContext) -> Dict[str, Any]:
        """Standard response for neutral state"""
        
        return self.response_generator.generate(
            context.intent,
            context.user_query,
            style='friendly'
        )
    
    def _describe_state(self, qualia: DynamicQualiaVector) -> str:
        """Human-readable description of phenomenological state"""
        
        descriptors = []
        
        if qualia.flow > 0.7:
            descriptors.append("in flow")
        if qualia.confusion > 0.5:
            descriptors.append("experiencing uncertainty")
        if qualia.cognitive_load > 0.6:
            descriptors.append("processing complex information")
        if qualia.learning_momentum > 0.5:
            descriptors.append("actively learning")
        
        return ", ".join(descriptors) if descriptors else "balanced"
    
    def _explain_adaptation(self, qualia: DynamicQualiaVector) -> str:
        """Explain why response was adapted"""
        
        if qualia.flow > 0.7:
            return "Keeping response minimal to preserve your flow state"
        elif qualia.confusion > 0.6:
            return "Providing extra clarity due to detected uncertainty"
        elif qualia.cognitive_load > 0.7:
            return "Simplifying response to reduce cognitive burden"
        elif qualia.learning_momentum > 0.6:
            return "Adding educational context to support your learning"
        else:
            return "Using standard response style"
    
    # Helper methods
    def _get_intent_alternatives(self, context: PhenomenologicalContext) -> List[str]:
        """Get alternative interpretations"""
        return [
            "install a package",
            "update your system", 
            "search for software",
            "check package info"
        ]
    
    def _decompose_task(self, query: str) -> List[str]:
        """Break complex task into steps"""
        # Simplified for demo
        return [
            "First, let's identify what you need",
            "Next, we'll check available options",
            "Then, we'll execute the action",
            "Finally, we'll verify it worked"
        ]
    
    def _identify_learning_concept(self, context: PhenomenologicalContext) -> str:
        """Identify what concept user is learning"""
        if "generation" in context.user_query:
            return "NixOS generations"
        elif "flake" in context.user_query:
            return "Nix flakes"
        else:
            return "NixOS concepts"
    
    def _generate_progressive_explanation(self, concept: str) -> str:
        """Generate explanation that builds understanding"""
        return f"{concept} is a way to... [progressive explanation would go here]"
    
    def _get_relevant_examples(self, concept: str) -> List[str]:
        """Get examples relevant to concept"""
        return [f"Example of {concept}: ...", f"Another {concept} example: ..."]
    
    def _find_related_concepts(self, concept: str) -> List[str]:
        """Find related concepts for deeper learning"""
        return ["Related concept 1", "Related concept 2"]
    
    def _suggest_practice(self, concept: str) -> str:
        """Suggest practice exercise"""
        return f"list all {concept} on your system"
    
    def _simplify_request(self, query: str) -> str:
        """Simplify a complex request"""
        # Very basic simplification
        return query.split()[0] + " " + query.split()[-1]
    
    def _generate_decision_tree(self, alternatives: List[str]) -> str:
        """Generate ASCII decision tree"""
        tree = "Your request?\n"
        for alt in alternatives[:3]:
            tree += f"  ├─ {alt}\n"
        return tree


# Demo function
def demo_phenomenological_responses():
    """Demo showing how responses adapt to user state"""
    
    assistant = PhenomenologicalNixAssistant()
    
    print("🧠 Phenomenological Response Adaptation Demo")
    print("==========================================\n")
    
    # Test scenarios
    scenarios = [
        {
            'name': 'User in Flow',
            'query': 'install firefox',
            'activity': {
                'window_switches': 0,
                'keystroke_rate': 150,
                'active_app': 'terminal'
            }
        },
        {
            'name': 'Confused User',
            'query': 'i need the thing for web stuff',
            'activity': {
                'window_switches': 8,
                'keystroke_rate': 40,
                'active_app': 'firefox'
            }
        },
        {
            'name': 'Overloaded User',
            'query': 'setup nginx with ssl and reverse proxy for nodejs app on port 3000',
            'activity': {
                'window_switches': 6,
                'keystroke_rate': 30,
                'active_app': 'multiple'
            }
        },
        {
            'name': 'Learning User',
            'query': 'what are nix generations and how do they work',
            'activity': {
                'window_switches': 2,
                'keystroke_rate': 80,
                'active_app': 'terminal'
            }
        }
    ]
    
    for scenario in scenarios:
        print(f"\n{'='*60}")
        print(f"Scenario: {scenario['name']}")
        print(f"Query: \"{scenario['query']}\"")
        print(f"Activity: {scenario['activity']}")
        
        # Process query
        result = assistant.process_query(scenario['query'], scenario['activity'])
        
        print(f"\nPhenomenological State: {result['phenomenological_transparency']['current_state']}")
        print(f"Adaptation: {result['phenomenological_transparency']['adaptation_reason']}")
        print(f"\nResponse Style: {result.get('style', 'default')}")
        print(f"Response: {result['response']}")
        
        if 'steps' in result:
            print("\nSteps:")
            for i, step in enumerate(result['steps']):
                print(f"  {i+1}. {step}")
        
        if 'suggestions' in result:
            print("\nSuggestions:")
            for suggestion in result['suggestions']:
                print(f"  • {suggestion}")
        
        if 'alternatives' in result and isinstance(result['alternatives'], list):
            print("\nAlternatives offered:")
            for alt in result['alternatives']:
                if isinstance(alt, dict):
                    print(f"  • {alt['description']}")


if __name__ == "__main__":
    demo_phenomenological_responses()