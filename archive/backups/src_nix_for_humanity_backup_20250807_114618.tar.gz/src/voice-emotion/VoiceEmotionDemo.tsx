/**
 * Voice Emotion Demo
 * Interactive demonstration of voice emotion detection
 */

import React, { useState, useEffect, useRef } from 'react';
import { VoiceEmotionDetector } from './emotion-detector';
import { EmotionalState, VoiceSegment } from './types';

export const VoiceEmotionDemo: React.FC = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [emotionalState, setEmotionalState] = useState<EmotionalState | null>(null);
  const [history, setHistory] = useState<EmotionalState[]>([]);
  const [error, setError] = useState<string | null>(null);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const detectorRef = useRef<VoiceEmotionDetector>(new VoiceEmotionDetector());
  
  useEffect(() => {
    // Cleanup on unmount
    return () => {
      stopRecording();
    };
  }, []);
  
  const startRecording = async () => {
    try {
      // Get microphone access
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });
      
      mediaStreamRef.current = stream;
      
      // Create audio context
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      
      // Create analyser
      analyserRef.current = audioContextRef.current.createAnalyser();
      analyserRef.current.fftSize = 2048;
      
      // Create processor
      processorRef.current = audioContextRef.current.createScriptProcessor(4096, 1, 1);
      
      // Connect nodes
      source.connect(analyserRef.current);
      analyserRef.current.connect(processorRef.current);
      processorRef.current.connect(audioContextRef.current.destination);
      
      // Process audio
      let audioBuffer: Float32Array[] = [];
      const sampleRate = audioContextRef.current.sampleRate;
      
      processorRef.current.onaudioprocess = async (event) => {
        const inputData = event.inputBuffer.getChannelData(0);
        audioBuffer.push(new Float32Array(inputData));
        
        // Process every 2 seconds
        const bufferDuration = (audioBuffer.length * 4096) / sampleRate;
        if (bufferDuration >= 2) {
          // Combine buffers
          const totalLength = audioBuffer.reduce((sum, buf) => sum + buf.length, 0);
          const combinedBuffer = new Float32Array(totalLength);
          let offset = 0;
          
          for (const buf of audioBuffer) {
            combinedBuffer.set(buf, offset);
            offset += buf.length;
          }
          
          // Create voice segment
          const segment: VoiceSegment = {
            audio: combinedBuffer,
            sampleRate,
            duration: bufferDuration,
            timestamp: new Date()
          };
          
          // Detect emotions
          try {
            const state = await detectorRef.current.detectEmotion(segment);
            setEmotionalState(state);
            setHistory(prev => [...prev.slice(-9), state]);
          } catch (err) {
            console.error('Emotion detection error:', err);
          }
          
          // Reset buffer
          audioBuffer = [];
        }
      };
      
      setIsRecording(true);
      setError(null);
    } catch (err) {
      setError('Microphone access denied');
      console.error('Recording error:', err);
    }
  };
  
  const stopRecording = () => {
    // Stop media stream
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
    }
    
    // Disconnect audio nodes
    if (processorRef.current) {
      processorRef.current.disconnect();
    }
    if (analyserRef.current) {
      analyserRef.current.disconnect();
    }
    
    // Close audio context
    if (audioContextRef.current) {
      audioContextRef.current.close();
    }
    
    setIsRecording(false);
  };
  
  const getEmotionColor = (emotion: keyof EmotionalState, value: number): string => {
    const colors = {
      frustration: `rgba(239, 68, 68, ${value})`,
      confidence: `rgba(34, 197, 94, ${value})`,
      confusion: `rgba(251, 146, 60, ${value})`,
      excitement: `rgba(250, 204, 21, ${value})`,
      calmness: `rgba(59, 130, 246, ${value})`,
      stress: `rgba(239, 68, 68, ${value * 0.7})`,
      engagement: `rgba(168, 85, 247, ${value})`,
      needsHelp: `rgba(251, 146, 60, ${value * 0.7})`
    };
    return colors[emotion] || `rgba(156, 163, 175, ${value})`;
  };
  
  const getEmotionEmoji = (emotion: keyof EmotionalState): string => {
    const emojis = {
      frustration: '😤',
      confidence: '😎',
      confusion: '🤔',
      excitement: '🎉',
      calmness: '😌',
      stress: '😰',
      engagement: '🤩',
      needsHelp: '🆘'
    };
    return emojis[emotion] || '😐';
  };
  
  return (
    <div className="voice-emotion-demo">
      <div className="demo-header">
        <h2>Voice Emotion Detection Demo</h2>
        <p>Speak naturally and watch as the system detects your emotional state in real-time!</p>
      </div>
      
      {error && (
        <div className="error-message">
          {error}
        </div>
      )}
      
      <div className="recording-controls">
        <button
          className={`record-button ${isRecording ? 'recording' : ''}`}
          onClick={isRecording ? stopRecording : startRecording}
        >
          <span className="icon">{isRecording ? '⏹️' : '🎤'}</span>
          <span className="label">{isRecording ? 'Stop Recording' : 'Start Recording'}</span>
        </button>
        
        {isRecording && (
          <div className="recording-indicator">
            <span className="pulse"></span>
            Recording...
          </div>
        )}
      </div>
      
      {emotionalState && (
        <div className="current-state">
          <h3>Current Emotional State</h3>
          <div className="emotion-grid">
            {(['frustration', 'confidence', 'confusion', 'excitement', 'calmness'] as const).map(emotion => (
              <div key={emotion} className="emotion-card">
                <div className="emotion-header">
                  <span className="emoji">{getEmotionEmoji(emotion)}</span>
                  <span className="name">{emotion}</span>
                </div>
                <div className="emotion-bar">
                  <div 
                    className="emotion-fill"
                    style={{
                      width: `${emotionalState[emotion] * 100}%`,
                      backgroundColor: getEmotionColor(emotion, 1)
                    }}
                  />
                </div>
                <span className="value">{(emotionalState[emotion] * 100).toFixed(0)}%</span>
              </div>
            ))}
          </div>
          
          <div className="composite-states">
            <h4>Composite States</h4>
            <div className="state-badges">
              <div className="badge" style={{ opacity: emotionalState.stress }}>
                😰 Stress: {(emotionalState.stress * 100).toFixed(0)}%
              </div>
              <div className="badge" style={{ opacity: emotionalState.engagement }}>
                🤩 Engagement: {(emotionalState.engagement * 100).toFixed(0)}%
              </div>
              <div className="badge" style={{ opacity: emotionalState.needsHelp }}>
                🆘 Needs Help: {(emotionalState.needsHelp * 100).toFixed(0)}%
              </div>
            </div>
          </div>
          
          <div className="confidence-meter">
            <h4>Detection Confidence</h4>
            <div className="meter">
              <div 
                className="meter-fill"
                style={{ width: `${emotionalState.certainty * 100}%` }}
              />
            </div>
            <span>{(emotionalState.certainty * 100).toFixed(0)}% certain</span>
          </div>
        </div>
      )}
      
      {history.length > 0 && (
        <div className="emotion-history">
          <h3>Emotion History (Last 10 readings)</h3>
          <div className="history-chart">
            {history.map((state, index) => (
              <div key={index} className="history-column">
                <div className="bars">
                  {(['frustration', 'confidence', 'confusion', 'excitement', 'calmness'] as const).map(emotion => (
                    <div
                      key={emotion}
                      className="bar"
                      style={{
                        height: `${state[emotion] * 100}px`,
                        backgroundColor: getEmotionColor(emotion, 0.8)
                      }}
                      title={`${emotion}: ${(state[emotion] * 100).toFixed(0)}%`}
                    />
                  ))}
                </div>
                <span className="time">{index === history.length - 1 ? 'Now' : `-${(history.length - index - 1) * 2}s`}</span>
              </div>
            ))}
          </div>
        </div>
      )}
      
      <div className="demo-tips">
        <h4>Try These Scenarios:</h4>
        <ul>
          <li>Speak with frustration: "This isn't working at all!"</li>
          <li>Show confusion: "I don't understand what you mean..."</li>
          <li>Express excitement: "Wow, this is amazing!"</li>
          <li>Be calm: "Everything is working perfectly."</li>
          <li>Sound stressed: "I need to fix this RIGHT NOW!"</li>
        </ul>
      </div>
      
      <style jsx>{`
        .voice-emotion-demo {
          max-width: 800px;
          margin: 0 auto;
          padding: 2rem;
          font-family: -apple-system, system-ui, sans-serif;
        }
        
        .demo-header {
          text-align: center;
          margin-bottom: 2rem;
        }
        
        .demo-header h2 {
          color: #1976d2;
          margin-bottom: 0.5rem;
        }
        
        .demo-header p {
          color: #666;
        }
        
        .error-message {
          background: #fee;
          color: #c00;
          padding: 1rem;
          border-radius: 8px;
          margin-bottom: 1rem;
        }
        
        .recording-controls {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 2rem;
          margin-bottom: 2rem;
        }
        
        .record-button {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 1rem 2rem;
          font-size: 1.125rem;
          background: #1976d2;
          color: white;
          border: none;
          border-radius: 50px;
          cursor: pointer;
          transition: all 0.3s;
        }
        
        .record-button:hover {
          background: #1565c0;
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(25, 118, 210, 0.3);
        }
        
        .record-button.recording {
          background: #dc2626;
        }
        
        .record-button.recording:hover {
          background: #b91c1c;
        }
        
        .record-button .icon {
          font-size: 1.5rem;
        }
        
        .recording-indicator {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          color: #dc2626;
          font-weight: 500;
        }
        
        .pulse {
          width: 12px;
          height: 12px;
          background: #dc2626;
          border-radius: 50%;
          animation: pulse 1.5s infinite;
        }
        
        @keyframes pulse {
          0% {
            transform: scale(1);
            opacity: 1;
          }
          50% {
            transform: scale(1.5);
            opacity: 0.5;
          }
          100% {
            transform: scale(1);
            opacity: 1;
          }
        }
        
        .current-state {
          background: white;
          border-radius: 12px;
          padding: 2rem;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
          margin-bottom: 2rem;
        }
        
        .current-state h3 {
          margin: 0 0 1.5rem 0;
          color: #333;
        }
        
        .emotion-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 1.5rem;
          margin-bottom: 2rem;
        }
        
        .emotion-card {
          text-align: center;
        }
        
        .emotion-header {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          margin-bottom: 0.5rem;
        }
        
        .emotion-header .emoji {
          font-size: 1.5rem;
        }
        
        .emotion-header .name {
          font-weight: 500;
          text-transform: capitalize;
        }
        
        .emotion-bar {
          height: 8px;
          background: #e5e7eb;
          border-radius: 4px;
          overflow: hidden;
          margin-bottom: 0.5rem;
        }
        
        .emotion-fill {
          height: 100%;
          transition: width 0.5s ease;
        }
        
        .value {
          font-size: 0.875rem;
          color: #666;
        }
        
        .composite-states {
          margin-bottom: 1.5rem;
        }
        
        .composite-states h4 {
          margin: 0 0 1rem 0;
          color: #666;
        }
        
        .state-badges {
          display: flex;
          gap: 1rem;
          flex-wrap: wrap;
        }
        
        .badge {
          padding: 0.5rem 1rem;
          background: #f3f4f6;
          border-radius: 20px;
          font-size: 0.875rem;
          transition: opacity 0.3s;
        }
        
        .confidence-meter h4 {
          margin: 0 0 0.5rem 0;
          color: #666;
        }
        
        .meter {
          height: 12px;
          background: #e5e7eb;
          border-radius: 6px;
          overflow: hidden;
          margin-bottom: 0.5rem;
        }
        
        .meter-fill {
          height: 100%;
          background: #10b981;
          transition: width 0.5s ease;
        }
        
        .emotion-history {
          background: white;
          border-radius: 12px;
          padding: 2rem;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
          margin-bottom: 2rem;
        }
        
        .emotion-history h3 {
          margin: 0 0 1.5rem 0;
          color: #333;
        }
        
        .history-chart {
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          height: 150px;
          padding: 0 1rem;
        }
        
        .history-column {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 0.5rem;
        }
        
        .bars {
          display: flex;
          align-items: flex-end;
          gap: 2px;
          height: 100px;
        }
        
        .bar {
          width: 8px;
          min-height: 2px;
          transition: height 0.5s ease;
        }
        
        .time {
          font-size: 0.75rem;
          color: #666;
        }
        
        .demo-tips {
          background: #f8f9fa;
          border-radius: 12px;
          padding: 1.5rem;
        }
        
        .demo-tips h4 {
          margin: 0 0 1rem 0;
          color: #333;
        }
        
        .demo-tips ul {
          margin: 0;
          padding-left: 1.5rem;
        }
        
        .demo-tips li {
          margin-bottom: 0.5rem;
          color: #666;
        }
      `}</style>
    </div>
  );
};