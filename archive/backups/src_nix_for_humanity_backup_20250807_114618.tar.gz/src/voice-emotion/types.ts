/**
 * Voice Emotion Detection Types
 * Core types for emotional awareness through voice
 */

export interface EmotionalState {
  // Primary emotions (0.0 - 1.0)
  frustration: number;
  confidence: number;
  confusion: number;
  excitement: number;
  calmness: number;
  
  // Composite states
  stress: number;        // Derived from frustration + speed
  engagement: number;    // Derived from excitement + focus
  needsHelp: number;     // Derived from confusion + frustration
  
  // Meta information
  certainty: number;     // How confident we are in this reading
  timestamp: Date;
}

export interface ProsodyFeatures {
  // Fundamental frequency (pitch)
  pitchMean: number;
  pitchStdDev: number;
  pitchRange: number;
  pitchSlope: number;    // Rising or falling intonation
  
  // Temporal features
  speechRate: number;    // Words per minute
  pauseFrequency: number;
  pauseDuration: number;
  rhythmVariability: number;
  
  // Energy/volume
  volumeMean: number;
  volumeStdDev: number;
  volumeRange: number;
  
  // Voice quality
  jitter: number;        // Pitch variability
  shimmer: number;       // Amplitude variability
  harmonicity: number;   // Voice clarity
}

export interface EmotionPattern {
  emotion: keyof EmotionalState;
  features: Partial<ProsodyFeatures>;
  weight: number;
}

export interface VoiceSegment {
  audio: Float32Array;
  sampleRate: number;
  duration: number;
  timestamp: Date;
}

export interface EmotionDetectionConfig {
  // Sensitivity settings
  minSegmentDuration: number;    // Minimum audio length to analyze (ms)
  maxSegmentDuration: number;    // Maximum segment to process at once
  smoothingFactor: number;       // Temporal smoothing (0-1)
  
  // Calibration
  baselinePitch?: number;        // User's baseline pitch
  baselineSpeechRate?: number;   // User's normal speech rate
  
  // Adaptation
  adaptToUser: boolean;          // Learn user's patterns
  culturalContext?: string;      // Cultural emotion expression norms
}

export interface EmotionHistory {
  states: EmotionalState[];
  averageState: EmotionalState;
  dominantEmotion: keyof EmotionalState;
  emotionalJourney: EmotionTransition[];
}

export interface EmotionTransition {
  from: keyof EmotionalState;
  to: keyof EmotionalState;
  trigger?: string;
  timestamp: Date;
}

export interface EmotionFeedback {
  detectedEmotion: EmotionalState;
  suggestedAction: EmotionResponse;
  confidence: number;
}

export interface EmotionResponse {
  type: 'adjust-pace' | 'offer-help' | 'celebrate' | 'provide-comfort' | 'maintain';
  intensity: number;
  specificActions: string[];
}

// Emotion profiles for different situations
export interface EmotionProfile {
  name: string;
  description: string;
  patterns: EmotionPattern[];
  responses: Map<keyof EmotionalState, EmotionResponse>;
}

// Cultural emotion expression patterns
export interface CulturalEmotionNorms {
  culture: string;
  emotionExpressionIntensity: number;  // How expressively emotions are shown
  preferredCommunicationStyle: 'direct' | 'indirect' | 'contextual';
  emotionPatterns: EmotionPattern[];
}