/**
 * Voice Emotion Integration
 * Connects voice emotion detection with personality and UI adaptation
 */

import { 
  EmotionalState, 
  VoiceSegment,
  EmotionFeedback,
  EmotionResponse,
  EmotionHistory
} from './types';
import { VoiceEmotionDetector } from './emotion-detector';
import { PersonalityAdapter } from '../personality/personality-adapter';
import { AdaptiveUIFramework, UIStage } from '../adaptive-ui/adaptive-ui-framework';
import { NLPEngine } from '../nlp/nlp-engine';

export interface VoiceEmotionConfig {
  enableRealTimeAdaptation: boolean;
  emotionThresholds: {
    frustration: number;
    confusion: number;
    stress: number;
    needsHelp: number;
  };
  adaptationSensitivity: number;
  bufferSize: number;
}

export class VoiceEmotionIntegration {
  private detector: VoiceEmotionDetector;
  private personalityAdapter: PersonalityAdapter;
  private uiFramework: AdaptiveUIFramework;
  private nlpEngine: NLPEngine;
  
  private config: VoiceEmotionConfig;
  private emotionBuffer: EmotionalState[] = [];
  private lastAdaptation: Date = new Date();
  private adaptationCooldown = 5000; // 5 seconds between major adaptations
  
  constructor(
    personalityAdapter: PersonalityAdapter,
    uiFramework: AdaptiveUIFramework,
    nlpEngine: NLPEngine,
    config: Partial<VoiceEmotionConfig> = {}
  ) {
    this.detector = new VoiceEmotionDetector();
    this.personalityAdapter = personalityAdapter;
    this.uiFramework = uiFramework;
    this.nlpEngine = nlpEngine;
    
    this.config = {
      enableRealTimeAdaptation: true,
      emotionThresholds: {
        frustration: 0.6,
        confusion: 0.5,
        stress: 0.7,
        needsHelp: 0.6
      },
      adaptationSensitivity: 0.3,
      bufferSize: 10,
      ...config
    };
  }
  
  /**
   * Process voice segment and adapt system
   */
  async processVoiceSegment(segment: VoiceSegment): Promise<EmotionFeedback> {
    // Detect emotions
    const emotionalState = await this.detector.detectEmotion(segment);
    
    // Buffer for stability
    this.updateEmotionBuffer(emotionalState);
    
    // Get average state over buffer
    const avgState = this.getAverageEmotionalState();
    
    // Determine response
    const response = this.determineResponse(avgState);
    
    // Apply adaptations if needed
    if (this.config.enableRealTimeAdaptation) {
      await this.applyAdaptations(avgState, response);
    }
    
    return {
      detectedEmotion: emotionalState,
      suggestedAction: response,
      confidence: emotionalState.certainty
    };
  }
  
  /**
   * Update emotion buffer with new state
   */
  private updateEmotionBuffer(state: EmotionalState) {
    this.emotionBuffer.push(state);
    
    // Keep buffer size limited
    if (this.emotionBuffer.length > this.config.bufferSize) {
      this.emotionBuffer.shift();
    }
  }
  
  /**
   * Calculate average emotional state over buffer
   */
  private getAverageEmotionalState(): EmotionalState {
    if (this.emotionBuffer.length === 0) {
      return this.createNeutralState();
    }
    
    const sum = this.emotionBuffer.reduce((acc, state) => ({
      frustration: acc.frustration + state.frustration,
      confidence: acc.confidence + state.confidence,
      confusion: acc.confusion + state.confusion,
      excitement: acc.excitement + state.excitement,
      calmness: acc.calmness + state.calmness,
      stress: acc.stress + state.stress,
      engagement: acc.engagement + state.engagement,
      needsHelp: acc.needsHelp + state.needsHelp,
      certainty: acc.certainty + state.certainty,
      timestamp: new Date()
    }), this.createNeutralState());
    
    const count = this.emotionBuffer.length;
    
    return {
      frustration: sum.frustration / count,
      confidence: sum.confidence / count,
      confusion: sum.confusion / count,
      excitement: sum.excitement / count,
      calmness: sum.calmness / count,
      stress: sum.stress / count,
      engagement: sum.engagement / count,
      needsHelp: sum.needsHelp / count,
      certainty: sum.certainty / count,
      timestamp: new Date()
    };
  }
  
  /**
   * Determine appropriate response based on emotional state
   */
  private determineResponse(state: EmotionalState): EmotionResponse {
    const { emotionThresholds } = this.config;
    
    // Check critical states first
    if (state.frustration > emotionThresholds.frustration) {
      return {
        type: 'provide-comfort',
        intensity: state.frustration,
        specificActions: [
          'Slow down response pace',
          'Use simpler language',
          'Offer to switch to a different approach',
          'Suggest a break if appropriate'
        ]
      };
    }
    
    if (state.confusion > emotionThresholds.confusion) {
      return {
        type: 'offer-help',
        intensity: state.confusion,
        specificActions: [
          'Provide clearer explanations',
          'Break down complex tasks',
          'Show examples',
          'Check understanding frequently'
        ]
      };
    }
    
    if (state.stress > emotionThresholds.stress) {
      return {
        type: 'adjust-pace',
        intensity: state.stress,
        specificActions: [
          'Reduce information density',
          'Minimize visual complexity',
          'Focus on one task at a time',
          'Add calming elements'
        ]
      };
    }
    
    if (state.excitement > 0.7) {
      return {
        type: 'celebrate',
        intensity: state.excitement,
        specificActions: [
          'Match enthusiasm level',
          'Add celebratory feedback',
          'Suggest next challenges',
          'Maintain momentum'
        ]
      };
    }
    
    // Default: maintain current approach
    return {
      type: 'maintain',
      intensity: 0.5,
      specificActions: ['Continue current approach']
    };
  }
  
  /**
   * Apply system adaptations based on emotional state
   */
  private async applyAdaptations(state: EmotionalState, response: EmotionResponse) {
    // Check cooldown
    const now = new Date();
    if (now.getTime() - this.lastAdaptation.getTime() < this.adaptationCooldown) {
      return; // Too soon for major changes
    }
    
    // Personality adaptation
    if (response.type !== 'maintain') {
      await this.adaptPersonality(state, response);
    }
    
    // UI adaptation
    await this.adaptUI(state, response);
    
    // NLP adaptation
    await this.adaptNLP(state, response);
    
    this.lastAdaptation = now;
  }
  
  /**
   * Adapt personality based on emotional state
   */
  private async adaptPersonality(state: EmotionalState, response: EmotionResponse) {
    // Adjust warmth based on stress/frustration
    if (state.stress > 0.6 || state.frustration > 0.6) {
      await this.personalityAdapter.adjustTrait('warmth', 0.8);
      await this.personalityAdapter.adjustTrait('patience', 0.9);
    }
    
    // Adjust clarity based on confusion
    if (state.confusion > 0.5) {
      await this.personalityAdapter.adjustTrait('clarity', 0.9);
      await this.personalityAdapter.adjustTrait('detailLevel', 0.8);
    }
    
    // Adjust enthusiasm based on excitement
    if (state.excitement > 0.7) {
      await this.personalityAdapter.adjustTrait('enthusiasm', 0.8);
      await this.personalityAdapter.adjustTrait('energy', 0.8);
    }
  }
  
  /**
   * Adapt UI based on emotional state
   */
  private async adaptUI(state: EmotionalState, response: EmotionResponse) {
    const uiState = await this.uiFramework.getState();
    
    // Move to simpler UI if stressed/confused
    if ((state.stress > 0.7 || state.confusion > 0.6) && uiState.currentStage !== UIStage.SANCTUARY) {
      await this.uiFramework.transitionToStage(UIStage.SANCTUARY);
    }
    
    // Reduce complexity for frustration
    if (state.frustration > 0.6) {
      await this.uiFramework.adjustComplexity(-0.3);
    }
    
    // Add celebration for excitement
    if (state.excitement > 0.7) {
      await this.uiFramework.celebrate();
    }
  }
  
  /**
   * Adapt NLP processing based on emotional state
   */
  private async adaptNLP(state: EmotionalState, response: EmotionResponse) {
    // Increase error tolerance for frustration
    if (state.frustration > 0.6) {
      this.nlpEngine.setErrorTolerance(0.8);
    }
    
    // Use simpler vocabulary for confusion
    if (state.confusion > 0.5) {
      this.nlpEngine.setVocabularyComplexity('simple');
    }
    
    // Speed up responses for excitement
    if (state.excitement > 0.7) {
      this.nlpEngine.setResponseSpeed('fast');
    }
  }
  
  /**
   * Get emotion history and insights
   */
  async getEmotionHistory(): Promise<EmotionHistory> {
    return this.detector.getEmotionHistory();
  }
  
  /**
   * Get personalized recommendations based on emotional patterns
   */
  async getRecommendations(): Promise<string[]> {
    const history = await this.getEmotionHistory();
    const recommendations: string[] = [];
    
    // Analyze patterns
    if (history.averageState.frustration > 0.5) {
      recommendations.push('Consider using voice commands for easier interaction');
      recommendations.push('Try the guided mode for step-by-step help');
    }
    
    if (history.averageState.confusion > 0.5) {
      recommendations.push('Check out our tutorials for clearer understanding');
      recommendations.push('Enable tooltips for more context');
    }
    
    if (history.averageState.stress > 0.5) {
      recommendations.push('Take regular breaks - enable break reminders');
      recommendations.push('Try the calm theme for a more relaxing experience');
    }
    
    if (history.dominantEmotion === 'excitement') {
      recommendations.push('Explore advanced features to maintain engagement');
      recommendations.push('Join our community to share your enthusiasm');
    }
    
    return recommendations;
  }
  
  /**
   * Create neutral emotional state
   */
  private createNeutralState(): EmotionalState {
    return {
      frustration: 0,
      confidence: 0.5,
      confusion: 0,
      excitement: 0.3,
      calmness: 0.7,
      stress: 0,
      engagement: 0.5,
      needsHelp: 0,
      certainty: 0.5,
      timestamp: new Date()
    };
  }
  
  /**
   * Reset emotion detection
   */
  reset() {
    this.emotionBuffer = [];
    this.detector.reset();
    this.lastAdaptation = new Date();
  }
}

/**
 * Factory function for easy integration
 */
export function createVoiceEmotionIntegration(
  personalityAdapter: PersonalityAdapter,
  uiFramework: AdaptiveUIFramework,
  nlpEngine: NLPEngine,
  config?: Partial<VoiceEmotionConfig>
): VoiceEmotionIntegration {
  return new VoiceEmotionIntegration(
    personalityAdapter,
    uiFramework,
    nlpEngine,
    config
  );
}