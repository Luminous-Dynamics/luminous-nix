/**
 * Voice Emotion Detector
 * Maps prosody features to emotional states
 */

import { 
  EmotionalState, 
  ProsodyFeatures, 
  VoiceSegment,
  EmotionPattern,
  EmotionDetectionConfig,
  EmotionHistory
} from './types';
import { ProsodyAnalyzer } from './prosody-analyzer';

export class VoiceEmotionDetector {
  private analyzer: ProsodyAnalyzer;
  private config: EmotionDetectionConfig;
  private history: EmotionalState[] = [];
  private baseline: Partial<ProsodyFeatures> = {};
  
  // Emotion patterns based on research
  private emotionPatterns: EmotionPattern[] = [
    // Frustration: Higher pitch variance, faster speech, louder
    {
      emotion: 'frustration',
      features: {
        pitchStdDev: 1.3,      // 30% above baseline
        pitchRange: 1.4,
        speechRate: 1.2,
        volumeMean: 1.2,
        jitter: 1.2
      },
      weight: 1.0
    },
    
    // Confidence: Steady pitch, moderate pace, clear voice
    {
      emotion: 'confidence',
      features: {
        pitchStdDev: 0.8,      // 20% below baseline (steady)
        speechRate: 1.0,       // Normal pace
        pauseFrequency: 0.9,   // Fewer hesitations
        harmonicity: 1.2,      // Clearer voice
        rhythmVariability: 0.8
      },
      weight: 1.0
    },
    
    // Confusion: Rising intonation, more pauses, quieter
    {
      emotion: 'confusion',
      features: {
        pitchSlope: 1.5,       // Rising pitch
        pauseFrequency: 1.4,
        pauseDuration: 1.3,
        volumeMean: 0.8,
        speechRate: 0.8
      },
      weight: 1.0
    },
    
    // Excitement: Higher pitch, faster speech, more energy
    {
      emotion: 'excitement',
      features: {
        pitchMean: 1.2,
        speechRate: 1.3,
        volumeMean: 1.3,
        volumeRange: 1.4,
        pitchRange: 1.3
      },
      weight: 1.0
    },
    
    // Calmness: Lower pitch, slower speech, steady rhythm
    {
      emotion: 'calmness',
      features: {
        pitchMean: 0.9,
        speechRate: 0.9,
        volumeStdDev: 0.8,
        rhythmVariability: 0.7,
        pauseDuration: 1.1
      },
      weight: 1.0
    }
  ];
  
  constructor(config: EmotionDetectionConfig = {
    minSegmentDuration: 500,
    maxSegmentDuration: 10000,
    smoothingFactor: 0.3,
    adaptToUser: true
  }) {
    this.analyzer = new ProsodyAnalyzer();
    this.config = config;
  }
  
  /**
   * Detect emotions from voice segment
   */
  async detectEmotion(segment: VoiceSegment): Promise<EmotionalState> {
    // Check segment duration
    const duration = segment.duration * 1000; // Convert to ms
    if (duration < this.config.minSegmentDuration) {
      throw new Error(`Segment too short: ${duration}ms < ${this.config.minSegmentDuration}ms`);
    }
    
    // Extract prosody features
    const features = await this.analyzer.extractFeatures(segment);
    
    // Calibrate to baseline if available
    const calibratedFeatures = this.calibrateFeatures(features);
    
    // Calculate emotion scores
    const emotionScores = this.calculateEmotionScores(calibratedFeatures);
    
    // Apply temporal smoothing if we have history
    const smoothedScores = this.applyTemporalSmoothing(emotionScores);
    
    // Calculate composite states
    const compositeStates = this.calculateCompositeStates(smoothedScores);
    
    // Create emotional state
    const state: EmotionalState = {
      ...smoothedScores,
      ...compositeStates,
      certainty: this.calculateCertainty(features),
      timestamp: new Date()
    };
    
    // Update history
    this.history.push(state);
    if (this.history.length > 100) {
      this.history.shift(); // Keep last 100 states
    }
    
    // Update baseline if adapting
    if (this.config.adaptToUser && state.calmness > 0.7) {
      this.updateBaseline(features);
    }
    
    return state;
  }
  
  /**
   * Calibrate features to user's baseline
   */
  private calibrateFeatures(features: ProsodyFeatures): ProsodyFeatures {
    const calibrated = { ...features };
    
    // If we have baseline data, normalize features
    if (this.baseline.pitchMean) {
      calibrated.pitchMean = features.pitchMean / this.baseline.pitchMean!;
      calibrated.pitchStdDev = features.pitchStdDev / (this.baseline.pitchStdDev || 1);
      calibrated.pitchRange = features.pitchRange / (this.baseline.pitchRange || 1);
    }
    
    if (this.baseline.speechRate) {
      calibrated.speechRate = features.speechRate / this.baseline.speechRate;
    }
    
    if (this.baseline.volumeMean) {
      calibrated.volumeMean = features.volumeMean / this.baseline.volumeMean;
      calibrated.volumeStdDev = features.volumeStdDev / (this.baseline.volumeStdDev || 1);
    }
    
    return calibrated;
  }
  
  /**
   * Calculate emotion scores from features
   */
  private calculateEmotionScores(features: ProsodyFeatures): Partial<EmotionalState> {
    const scores: Partial<EmotionalState> = {
      frustration: 0,
      confidence: 0,
      confusion: 0,
      excitement: 0,
      calmness: 0
    };
    
    // For each emotion pattern
    for (const pattern of this.emotionPatterns) {
      let score = 0;
      let featureCount = 0;
      
      // Compare features to pattern
      for (const [feature, targetRatio] of Object.entries(pattern.features)) {
        const actualValue = features[feature as keyof ProsodyFeatures] as number;
        if (actualValue !== undefined) {
          // Calculate similarity (inverse of distance)
          const distance = Math.abs(actualValue - targetRatio);
          const similarity = Math.exp(-distance); // Exponential decay
          score += similarity;
          featureCount++;
        }
      }
      
      // Normalize and apply weight
      if (featureCount > 0) {
        scores[pattern.emotion] = (score / featureCount) * pattern.weight;
      }
    }
    
    // Normalize scores to sum to 1
    const total = Object.values(scores).reduce((sum, val) => sum + (val || 0), 0);
    if (total > 0) {
      for (const emotion in scores) {
        scores[emotion as keyof EmotionalState] = (scores[emotion as keyof EmotionalState] || 0) / total;
      }
    }
    
    return scores;
  }
  
  /**
   * Apply temporal smoothing to reduce noise
   */
  private applyTemporalSmoothing(scores: Partial<EmotionalState>): Partial<EmotionalState> {
    if (this.history.length === 0 || this.config.smoothingFactor === 0) {
      return scores;
    }
    
    const lastState = this.history[this.history.length - 1];
    const smoothed: Partial<EmotionalState> = {};
    const alpha = this.config.smoothingFactor;
    
    // Exponential moving average
    for (const emotion of ['frustration', 'confidence', 'confusion', 'excitement', 'calmness'] as const) {
      const current = scores[emotion] || 0;
      const previous = lastState[emotion] || 0;
      smoothed[emotion] = alpha * previous + (1 - alpha) * current;
    }
    
    return smoothed;
  }
  
  /**
   * Calculate composite emotional states
   */
  private calculateCompositeStates(primaryStates: Partial<EmotionalState>): Partial<EmotionalState> {
    return {
      stress: (primaryStates.frustration || 0) * 0.7 + 
              (1 - (primaryStates.calmness || 0)) * 0.3,
              
      engagement: (primaryStates.excitement || 0) * 0.5 + 
                  (primaryStates.confidence || 0) * 0.5,
                  
      needsHelp: (primaryStates.confusion || 0) * 0.6 + 
                 (primaryStates.frustration || 0) * 0.4
    };
  }
  
  /**
   * Calculate certainty of emotion detection
   */
  private calculateCertainty(features: ProsodyFeatures): number {
    // Factors that increase certainty:
    // - Clear voice (high harmonicity)
    // - Consistent features
    // - Strong emotion signals
    
    let certainty = 0.5; // Base certainty
    
    // Voice clarity
    if (features.harmonicity > 10) {
      certainty += 0.2;
    }
    
    // Feature consistency (low variability)
    if (features.rhythmVariability < 0.3) {
      certainty += 0.1;
    }
    
    // Strong pitch signals
    if (features.pitchRange > 50 || features.pitchStdDev > 20) {
      certainty += 0.1;
    }
    
    // Sufficient speech content
    if (features.speechRate > 100 && features.pauseFrequency < 0.5) {
      certainty += 0.1;
    }
    
    return Math.min(certainty, 1.0);
  }
  
  /**
   * Update baseline from calm speech
   */
  private updateBaseline(features: ProsodyFeatures) {
    const alpha = 0.1; // Learning rate
    
    // Update baseline with exponential moving average
    for (const key of Object.keys(features) as Array<keyof ProsodyFeatures>) {
      const value = features[key];
      if (typeof value === 'number') {
        if (this.baseline[key]) {
          this.baseline[key] = alpha * value + (1 - alpha) * this.baseline[key]!;
        } else {
          this.baseline[key] = value;
        }
      }
    }
  }
  
  /**
   * Get emotion history and trends
   */
  getEmotionHistory(): EmotionHistory {
    if (this.history.length === 0) {
      return {
        states: [],
        averageState: this.createNeutralState(),
        dominantEmotion: 'calmness',
        emotionalJourney: []
      };
    }
    
    // Calculate average state
    const averageState = this.calculateAverageState();
    
    // Find dominant emotion
    const emotions = ['frustration', 'confidence', 'confusion', 'excitement', 'calmness'] as const;
    let dominantEmotion = emotions[0];
    let maxScore = averageState[dominantEmotion];
    
    for (const emotion of emotions) {
      if (averageState[emotion] > maxScore) {
        maxScore = averageState[emotion];
        dominantEmotion = emotion;
      }
    }
    
    // Track emotional journey
    const journey = this.detectEmotionalTransitions();
    
    return {
      states: [...this.history],
      averageState,
      dominantEmotion,
      emotionalJourney: journey
    };
  }
  
  /**
   * Calculate average emotional state
   */
  private calculateAverageState(): EmotionalState {
    const sum = this.createNeutralState();
    
    for (const state of this.history) {
      for (const key of Object.keys(state) as Array<keyof EmotionalState>) {
        if (typeof state[key] === 'number' && typeof sum[key] === 'number') {
          (sum[key] as number) += state[key] as number;
        }
      }
    }
    
    // Average
    const count = this.history.length;
    for (const key of Object.keys(sum) as Array<keyof EmotionalState>) {
      if (typeof sum[key] === 'number') {
        (sum[key] as number) /= count;
      }
    }
    
    return sum;
  }
  
  /**
   * Detect significant emotional transitions
   */
  private detectEmotionalTransitions() {
    const transitions = [];
    const threshold = 0.3; // Minimum change to count as transition
    
    for (let i = 1; i < this.history.length; i++) {
      const prev = this.history[i - 1];
      const curr = this.history[i];
      
      // Find the emotion with biggest change
      let maxChange = 0;
      let fromEmotion = 'calmness' as keyof EmotionalState;
      let toEmotion = 'calmness' as keyof EmotionalState;
      
      const emotions = ['frustration', 'confidence', 'confusion', 'excitement', 'calmness'] as const;
      
      for (const emotion of emotions) {
        const change = Math.abs(curr[emotion] - prev[emotion]);
        if (change > maxChange && change > threshold) {
          maxChange = change;
          fromEmotion = this.getDominantEmotion(prev);
          toEmotion = this.getDominantEmotion(curr);
        }
      }
      
      if (maxChange > threshold && fromEmotion !== toEmotion) {
        transitions.push({
          from: fromEmotion,
          to: toEmotion,
          timestamp: curr.timestamp
        });
      }
    }
    
    return transitions;
  }
  
  /**
   * Get dominant emotion from state
   */
  private getDominantEmotion(state: EmotionalState): keyof EmotionalState {
    const emotions = ['frustration', 'confidence', 'confusion', 'excitement', 'calmness'] as const;
    let dominant = emotions[0];
    let maxScore = state[dominant];
    
    for (const emotion of emotions) {
      if (state[emotion] > maxScore) {
        maxScore = state[emotion];
        dominant = emotion;
      }
    }
    
    return dominant;
  }
  
  /**
   * Create neutral emotional state
   */
  private createNeutralState(): EmotionalState {
    return {
      frustration: 0,
      confidence: 0,
      confusion: 0,
      excitement: 0,
      calmness: 1,
      stress: 0,
      engagement: 0.5,
      needsHelp: 0,
      certainty: 0.5,
      timestamp: new Date()
    };
  }
  
  /**
   * Reset detector state
   */
  reset() {
    this.history = [];
    this.baseline = {};
  }
}