/**
 * Voice Emotion Detection Module
 * Exports for emotional awareness through voice
 */

export * from './types';
export { VoiceEmotionDetector } from './emotion-detector';
export { ProsodyAnalyzer } from './prosody-analyzer';
export { VoiceEmotionIntegration } from './voice-emotion-integration';