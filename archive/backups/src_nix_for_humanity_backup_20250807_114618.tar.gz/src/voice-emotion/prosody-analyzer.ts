/**
 * Prosody Analyzer
 * Extracts voice features for emotion detection
 */

import { ProsodyFeatures, VoiceSegment } from './types';

export class ProsodyAnalyzer {
  private fftSize = 2048;
  private hopLength = 512;
  
  /**
   * Extract prosody features from audio segment
   */
  async extractFeatures(segment: VoiceSegment): Promise<ProsodyFeatures> {
    const { audio, sampleRate } = segment;
    
    // Extract pitch features
    const pitchFeatures = this.extractPitchFeatures(audio, sampleRate);
    
    // Extract temporal features
    const temporalFeatures = this.extractTemporalFeatures(audio, sampleRate);
    
    // Extract energy features
    const energyFeatures = this.extractEnergyFeatures(audio);
    
    // Extract voice quality features
    const qualityFeatures = this.extractVoiceQuality(audio, sampleRate);
    
    return {
      ...pitchFeatures,
      ...temporalFeatures,
      ...energyFeatures,
      ...qualityFeatures
    };
  }
  
  /**
   * Extract pitch-related features
   */
  private extractPitchFeatures(audio: Float32Array, sampleRate: number): Partial<ProsodyFeatures> {
    const pitchValues = this.estimatePitch(audio, sampleRate);
    
    // Filter out unvoiced segments (0 Hz)
    const voicedPitches = pitchValues.filter(p => p > 50 && p < 500);
    
    if (voicedPitches.length === 0) {
      return {
        pitchMean: 0,
        pitchStdDev: 0,
        pitchRange: 0,
        pitchSlope: 0
      };
    }
    
    // Calculate statistics
    const mean = this.mean(voicedPitches);
    const stdDev = this.standardDeviation(voicedPitches);
    const range = Math.max(...voicedPitches) - Math.min(...voicedPitches);
    const slope = this.calculateSlope(voicedPitches);
    
    return {
      pitchMean: mean,
      pitchStdDev: stdDev,
      pitchRange: range,
      pitchSlope: slope
    };
  }
  
  /**
   * Estimate pitch using autocorrelation method
   */
  private estimatePitch(audio: Float32Array, sampleRate: number): number[] {
    const windowSize = Math.floor(sampleRate * 0.04); // 40ms windows
    const hopSize = Math.floor(windowSize / 2);
    const pitches: number[] = [];
    
    for (let i = 0; i < audio.length - windowSize; i += hopSize) {
      const window = audio.slice(i, i + windowSize);
      const pitch = this.autocorrelationPitch(window, sampleRate);
      pitches.push(pitch);
    }
    
    return pitches;
  }
  
  /**
   * Autocorrelation-based pitch detection
   */
  private autocorrelationPitch(window: Float32Array, sampleRate: number): number {
    // Apply window function to reduce edge effects
    const windowed = this.applyHammingWindow(window);
    
    // Calculate autocorrelation
    const autocorr = this.autocorrelation(windowed);
    
    // Find the first peak after the zero lag
    const minPeriod = Math.floor(sampleRate / 500); // 500 Hz max
    const maxPeriod = Math.floor(sampleRate / 50);  // 50 Hz min
    
    let maxValue = 0;
    let maxIndex = 0;
    
    for (let i = minPeriod; i < Math.min(maxPeriod, autocorr.length); i++) {
      if (autocorr[i] > maxValue) {
        maxValue = autocorr[i];
        maxIndex = i;
      }
    }
    
    // Convert lag to frequency
    if (maxIndex > 0 && maxValue > 0.3) { // Threshold for voiced detection
      return sampleRate / maxIndex;
    }
    
    return 0; // Unvoiced
  }
  
  /**
   * Calculate autocorrelation
   */
  private autocorrelation(signal: Float32Array): Float32Array {
    const result = new Float32Array(signal.length);
    
    for (let lag = 0; lag < signal.length; lag++) {
      let sum = 0;
      for (let i = 0; i < signal.length - lag; i++) {
        sum += signal[i] * signal[i + lag];
      }
      result[lag] = sum / (signal.length - lag);
    }
    
    // Normalize
    const max = Math.max(...result);
    if (max > 0) {
      for (let i = 0; i < result.length; i++) {
        result[i] /= max;
      }
    }
    
    return result;
  }
  
  /**
   * Extract temporal features (speech rate, pauses)
   */
  private extractTemporalFeatures(audio: Float32Array, sampleRate: number): Partial<ProsodyFeatures> {
    // Detect speech/silence segments
    const segments = this.detectSpeechSegments(audio, sampleRate);
    
    // Calculate pause statistics
    const pauses = segments.filter(s => s.type === 'silence' && s.duration > 0.1);
    const speechSegments = segments.filter(s => s.type === 'speech');
    
    const totalDuration = audio.length / sampleRate;
    const speechDuration = speechSegments.reduce((sum, s) => sum + s.duration, 0);
    
    // Estimate speech rate (simplified - would need phoneme detection for accuracy)
    const estimatedSyllables = speechSegments.length * 3; // Rough estimate
    const speechRate = (estimatedSyllables / speechDuration) * 60; // Per minute
    
    // Calculate rhythm variability
    const segmentDurations = speechSegments.map(s => s.duration);
    const rhythmVariability = segmentDurations.length > 1 
      ? this.standardDeviation(segmentDurations) / this.mean(segmentDurations)
      : 0;
    
    return {
      speechRate,
      pauseFrequency: pauses.length / totalDuration,
      pauseDuration: pauses.length > 0 ? this.mean(pauses.map(p => p.duration)) : 0,
      rhythmVariability
    };
  }
  
  /**
   * Detect speech and silence segments
   */
  private detectSpeechSegments(audio: Float32Array, sampleRate: number): Array<{type: 'speech' | 'silence', duration: number}> {
    const frameSize = Math.floor(sampleRate * 0.02); // 20ms frames
    const threshold = 0.02; // Energy threshold
    const segments = [];
    
    let currentType: 'speech' | 'silence' = 'silence';
    let segmentStart = 0;
    
    for (let i = 0; i < audio.length - frameSize; i += frameSize) {
      const frame = audio.slice(i, i + frameSize);
      const energy = this.calculateEnergy(frame);
      
      const frameType = energy > threshold ? 'speech' : 'silence';
      
      if (frameType !== currentType) {
        const duration = (i - segmentStart) / sampleRate;
        segments.push({ type: currentType, duration });
        currentType = frameType;
        segmentStart = i;
      }
    }
    
    // Add final segment
    const duration = (audio.length - segmentStart) / sampleRate;
    segments.push({ type: currentType, duration });
    
    return segments;
  }
  
  /**
   * Extract energy/volume features
   */
  private extractEnergyFeatures(audio: Float32Array): Partial<ProsodyFeatures> {
    const frameSize = 512;
    const energies: number[] = [];
    
    for (let i = 0; i < audio.length - frameSize; i += frameSize) {
      const frame = audio.slice(i, i + frameSize);
      const energy = this.calculateEnergy(frame);
      energies.push(energy);
    }
    
    return {
      volumeMean: this.mean(energies),
      volumeStdDev: this.standardDeviation(energies),
      volumeRange: Math.max(...energies) - Math.min(...energies)
    };
  }
  
  /**
   * Extract voice quality features
   */
  private extractVoiceQuality(audio: Float32Array, sampleRate: number): Partial<ProsodyFeatures> {
    // Simplified jitter and shimmer calculation
    const pitches = this.estimatePitch(audio, sampleRate);
    const voicedPitches = pitches.filter(p => p > 0);
    
    // Jitter: pitch period variability
    const jitter = this.calculateJitter(voicedPitches);
    
    // Shimmer: amplitude variability
    const shimmer = this.calculateShimmer(audio);
    
    // Harmonicity: signal-to-noise ratio in voiced segments
    const harmonicity = this.calculateHarmonicity(audio, sampleRate);
    
    return {
      jitter,
      shimmer,
      harmonicity
    };
  }
  
  /**
   * Calculate jitter (pitch period variability)
   */
  private calculateJitter(pitches: number[]): number {
    if (pitches.length < 2) return 0;
    
    const periods = pitches.map(f => 1 / f);
    const differences: number[] = [];
    
    for (let i = 1; i < periods.length; i++) {
      differences.push(Math.abs(periods[i] - periods[i - 1]));
    }
    
    return this.mean(differences) / this.mean(periods);
  }
  
  /**
   * Calculate shimmer (amplitude variability)
   */
  private calculateShimmer(audio: Float32Array): number {
    const frameSize = 256;
    const amplitudes: number[] = [];
    
    for (let i = 0; i < audio.length - frameSize; i += frameSize) {
      const frame = audio.slice(i, i + frameSize);
      const amplitude = Math.max(...frame.map(Math.abs));
      amplitudes.push(amplitude);
    }
    
    const differences: number[] = [];
    for (let i = 1; i < amplitudes.length; i++) {
      differences.push(Math.abs(amplitudes[i] - amplitudes[i - 1]));
    }
    
    return this.mean(differences) / this.mean(amplitudes);
  }
  
  /**
   * Calculate harmonicity (simplified HNR)
   */
  private calculateHarmonicity(audio: Float32Array, sampleRate: number): number {
    // Simplified harmonics-to-noise ratio
    // In practice, this would use cepstral analysis
    const autocorr = this.autocorrelation(audio.slice(0, Math.min(audio.length, 2048)));
    const maxAutocorr = Math.max(...autocorr.slice(Math.floor(sampleRate / 500)));
    
    return 10 * Math.log10(maxAutocorr / (1 - maxAutocorr + 0.0001));
  }
  
  // Utility functions
  
  private applyHammingWindow(signal: Float32Array): Float32Array {
    const windowed = new Float32Array(signal.length);
    for (let i = 0; i < signal.length; i++) {
      const window = 0.54 - 0.46 * Math.cos(2 * Math.PI * i / (signal.length - 1));
      windowed[i] = signal[i] * window;
    }
    return windowed;
  }
  
  private calculateEnergy(frame: Float32Array): number {
    return frame.reduce((sum, sample) => sum + sample * sample, 0) / frame.length;
  }
  
  private mean(values: number[]): number {
    return values.reduce((sum, val) => sum + val, 0) / values.length;
  }
  
  private standardDeviation(values: number[]): number {
    const avg = this.mean(values);
    const squaredDiffs = values.map(val => Math.pow(val - avg, 2));
    return Math.sqrt(this.mean(squaredDiffs));
  }
  
  private calculateSlope(values: number[]): number {
    if (values.length < 2) return 0;
    
    const n = values.length;
    const xMean = (n - 1) / 2;
    const yMean = this.mean(values);
    
    let numerator = 0;
    let denominator = 0;
    
    for (let i = 0; i < n; i++) {
      const xDiff = i - xMean;
      const yDiff = values[i] - yMean;
      numerator += xDiff * yDiff;
      denominator += xDiff * xDiff;
    }
    
    return denominator > 0 ? numerator / denominator : 0;
  }
}