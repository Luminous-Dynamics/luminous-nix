/**
 * Live System Demo
 * Demonstrates the full Nix for Humanity system in action
 */

import React, { useState, useEffect, useRef } from 'react';
import { NLPEngine } from '../nlp/NLPEngine';
import { PersonalityEngine } from '../personality/PersonalityEngine';
import { EmotionalStateTracker } from '../emotional/EmotionalStateTracker';
import { VoiceEngine } from '../voice/VoiceEngine';
import { ThemeEngine } from '../visual/ThemeEngine';
import { GestureEngine } from '../gestures/GestureEngine';
import { UIComplexityManager } from '../complexity/UIComplexityManager';

interface ChatMessage {
  id: string;
  type: 'user' | 'system';
  content: string;
  timestamp: Date;
  emotion?: string;
  personality?: string;
}

interface SystemStats {
  intentAccuracy: number;
  responseTime: number;
  emotionalState: string;
  personalityMode: string;
  complexityLevel: number;
  voiceEnabled: boolean;
  gesturesEnabled: boolean;
}

export const LiveSystemDemo: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [systemStats, setSystemStats] = useState<SystemStats>({
    intentAccuracy: 0.95,
    responseTime: 0,
    emotionalState: 'neutral',
    personalityMode: 'friendly',
    complexityLevel: 5,
    voiceEnabled: false,
    gesturesEnabled: false
  });

  // System engines
  const nlpEngine = useRef<NLPEngine>();
  const personalityEngine = useRef<PersonalityEngine>();
  const emotionalTracker = useRef<EmotionalStateTracker>();
  const voiceEngine = useRef<VoiceEngine>();
  const themeEngine = useRef<ThemeEngine>();
  const gestureEngine = useRef<GestureEngine>();
  const complexityManager = useRef<UIComplexityManager>();

  // Initialize systems
  useEffect(() => {
    const initSystems = async () => {
      nlpEngine.current = new NLPEngine();
      await nlpEngine.current.initialize();

      personalityEngine.current = new PersonalityEngine();
      await personalityEngine.current.initialize();

      emotionalTracker.current = new EmotionalStateTracker();
      await emotionalTracker.current.initialize();

      voiceEngine.current = new VoiceEngine();
      await voiceEngine.current.initialize();

      themeEngine.current = new ThemeEngine();
      themeEngine.current.loadPreferences();

      gestureEngine.current = new GestureEngine();
      gestureEngine.current.initialize();

      complexityManager.current = new UIComplexityManager();

      // Add welcome message
      addSystemMessage("Hello! I'm Nix for Humanity. I'll help you manage your NixOS system using natural conversation. Just tell me what you need!");
    };

    initSystems();
  }, []);

  const addSystemMessage = (content: string) => {
    const message: ChatMessage = {
      id: Date.now().toString(),
      type: 'system',
      content,
      timestamp: new Date(),
      personality: systemStats.personalityMode,
      emotion: systemStats.emotionalState
    };
    setMessages(prev => [...prev, message]);
  };

  const addUserMessage = (content: string) => {
    const message: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, message]);
  };

  const processCommand = async (userInput: string) => {
    const startTime = Date.now();
    
    // Add user message
    addUserMessage(userInput);

    // Process with NLP
    const intent = await nlpEngine.current?.parse(userInput);
    
    // Track emotional state
    const emotion = await emotionalTracker.current?.analyzeInput(userInput);
    
    // Get personality response
    const personality = await personalityEngine.current?.getStyle();
    
    // Update stats
    const responseTime = Date.now() - startTime;
    setSystemStats(prev => ({
      ...prev,
      responseTime,
      emotionalState: emotion?.state || 'neutral',
      personalityMode: personality || 'friendly'
    }));

    // Generate response based on intent
    let response = '';
    
    switch (intent?.intent) {
      case 'install':
        response = generateInstallResponse(intent.entities.package, personality);
        break;
      case 'update':
        response = generateUpdateResponse(personality);
        break;
      case 'troubleshoot':
        response = generateTroubleshootResponse(intent.entities.issue, personality);
        break;
      case 'help':
        response = generateHelpResponse(personality);
        break;
      default:
        response = generateFallbackResponse(userInput, personality);
    }

    // Add system response
    setTimeout(() => {
      addSystemMessage(response);
    }, 300); // Simulate processing time
  };

  const generateInstallResponse = (packageName: string, personality: string) => {
    const responses = {
      minimal: `Installing ${packageName}... Done.`,
      friendly: `I'll install ${packageName} for you! This will just take a moment... All set! ${packageName} is now ready to use.`,
      encouraging: `Great choice! Installing ${packageName} now... You're doing awesome! ${packageName} is installed and ready.`,
      playful: `${packageName} coming right up! 🎉 *installation magic happens* Ta-da! ${packageName} is ready to rock!`,
      sacred: `✨ Manifesting ${packageName} into your system... The digital essence flows... ${packageName} now dwells within your realm.`
    };
    return responses[personality as keyof typeof responses] || responses.friendly;
  };

  const generateUpdateResponse = (personality: string) => {
    const responses = {
      minimal: `System updated.`,
      friendly: `I'm updating your system now. This might take a few minutes... All done! Your system is up to date.`,
      encouraging: `Let's get your system updated! You're taking great care of your computer... Excellent! Everything is current now.`,
      playful: `Update party time! 🚀 *whoosh* Your system is now fresh and shiny!`,
      sacred: `🌊 The river of updates flows... Your system harmonizes with the latest energies... Balance restored.`
    };
    return responses[personality as keyof typeof responses] || responses.friendly;
  };

  const generateTroubleshootResponse = (issue: string, personality: string) => {
    const responses = {
      minimal: `Checking ${issue}... Fixed.`,
      friendly: `I see you're having trouble with ${issue}. Let me help you fix that... There we go! The issue should be resolved now.`,
      encouraging: `Don't worry, we'll figure out this ${issue} together! Let me check... You handled that perfectly! It's working now.`,
      playful: `Oh no, ${issue} is being naughty! Let me give it a gentle fix... *boop* All better now! 😊`,
      sacred: `🔮 Sensing disharmony in ${issue}... Applying sacred debugging rituals... Harmony restored to ${issue}.`
    };
    return responses[personality as keyof typeof responses] || responses.friendly;
  };

  const generateHelpResponse = (personality: string) => {
    const responses = {
      minimal: `Commands: install, update, remove, search, status.`,
      friendly: `I can help you with lots of things! Try: installing software, updating your system, troubleshooting issues, or just ask me anything about NixOS.`,
      encouraging: `You're doing great! I can help you install programs, update your system, fix problems, and more. What would you like to try?`,
      playful: `I'm your friendly NixOS buddy! I can: 🎁 Install cool stuff, 🔄 Update everything, 🔧 Fix problems, 🔍 Search for things!`,
      sacred: `🌟 I am here to guide your digital journey. Speak your intentions: manifest software, harmonize updates, heal disruptions, seek wisdom.`
    };
    return responses[personality as keyof typeof responses] || responses.friendly;
  };

  const generateFallbackResponse = (input: string, personality: string) => {
    const responses = {
      minimal: `Unknown command. Try 'help'.`,
      friendly: `I'm not quite sure what you mean by "${input}". Could you try rephrasing that? Or type 'help' to see what I can do.`,
      encouraging: `That's an interesting request! I'm still learning about "${input}". Could you tell me more about what you'd like to do?`,
      playful: `Hmm, "${input}" is a new one for me! 🤔 Can you give me another hint about what you're looking for?`,
      sacred: `🌙 The meaning of "${input}" eludes my current understanding. Perhaps you could illuminate your intention further?`
    };
    return responses[personality as keyof typeof responses] || responses.friendly;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      processCommand(input);
      setInput('');
    }
  };

  const toggleVoice = async () => {
    if (isListening) {
      voiceEngine.current?.stopListening();
      setIsListening(false);
    } else {
      const result = await voiceEngine.current?.startListening();
      setIsListening(true);
      
      // Simulate voice input after 2 seconds
      setTimeout(() => {
        if (result) {
          processCommand("install firefox");
          setIsListening(false);
        }
      }, 2000);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-white shadow-sm border-b border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button
                onClick={onBack}
                className="mr-4 text-blue-600 hover:text-blue-700"
              >
                ← Back
              </button>
              <h1 className="text-xl font-semibold">Live System Demo</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={toggleVoice}
                className={`
                  px-4 py-2 rounded-lg flex items-center
                  ${isListening 
                    ? 'bg-red-500 text-white' 
                    : 'bg-gray-100 hover:bg-gray-200'
                  }
                `}
              >
                <span className="mr-2">{isListening ? '🎤' : '🎙️'}</span>
                {isListening ? 'Listening...' : 'Voice Input'}
              </button>
            </div>
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="max-w-3xl mx-auto space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`
                    max-w-lg px-4 py-3 rounded-lg
                    ${message.type === 'user'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white border border-gray-200'
                    }
                  `}
                >
                  {message.type === 'system' && (
                    <div className="flex items-center mb-1">
                      <span className="text-xs text-gray-500">
                        {message.personality} mode
                      </span>
                      {message.emotion && (
                        <span className="ml-2 text-xs text-gray-400">
                          • feeling {message.emotion}
                        </span>
                      )}
                    </div>
                  )}
                  <p className={message.type === 'user' ? 'text-white' : 'text-gray-800'}>
                    {message.content}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Input Area */}
        <div className="bg-white border-t border-gray-200 p-4">
          <form onSubmit={handleSubmit} className="max-w-3xl mx-auto">
            <div className="flex space-x-4">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type a command or ask for help..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="submit"
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Send
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Stats Sidebar */}
      <div className="w-80 bg-white border-l border-gray-200 p-6">
        <h2 className="text-lg font-semibold mb-4">System Statistics</h2>
        
        <div className="space-y-4">
          <StatItem
            label="Response Time"
            value={`${systemStats.responseTime}ms`}
            icon="⚡"
          />
          
          <StatItem
            label="Intent Accuracy"
            value={`${(systemStats.intentAccuracy * 100).toFixed(0)}%`}
            icon="🎯"
          />
          
          <StatItem
            label="Emotional State"
            value={systemStats.emotionalState}
            icon="😊"
          />
          
          <StatItem
            label="Personality Mode"
            value={systemStats.personalityMode}
            icon="🎭"
          />
          
          <StatItem
            label="Complexity Level"
            value={`${systemStats.complexityLevel}/10`}
            icon="📊"
          />
        </div>

        <div className="mt-6 pt-6 border-t border-gray-200">
          <h3 className="font-medium mb-3">Active Features</h3>
          <div className="space-y-2">
            <FeatureToggle
              label="Voice Input"
              enabled={systemStats.voiceEnabled}
              icon="🎤"
            />
            <FeatureToggle
              label="Gesture Recognition"
              enabled={systemStats.gesturesEnabled}
              icon="👋"
            />
            <FeatureToggle
              label="Emotional Adaptation"
              enabled={true}
              icon="💗"
            />
            <FeatureToggle
              label="Learning System"
              enabled={true}
              icon="🧠"
            />
          </div>
        </div>

        <div className="mt-6 pt-6 border-t border-gray-200">
          <h3 className="font-medium mb-3">Quick Commands</h3>
          <div className="space-y-2 text-sm">
            <QuickCommand text="install firefox" />
            <QuickCommand text="update system" />
            <QuickCommand text="my wifi isn't working" />
            <QuickCommand text="show installed packages" />
            <QuickCommand text="help" />
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper Components
const StatItem: React.FC<{ label: string; value: string; icon: string }> = ({ 
  label, value, icon 
}) => (
  <div className="flex items-center justify-between">
    <div className="flex items-center">
      <span className="text-lg mr-2">{icon}</span>
      <span className="text-sm text-gray-600">{label}</span>
    </div>
    <span className="font-medium">{value}</span>
  </div>
);

const FeatureToggle: React.FC<{ label: string; enabled: boolean; icon: string }> = ({ 
  label, enabled, icon 
}) => (
  <div className="flex items-center justify-between">
    <div className="flex items-center">
      <span className="mr-2">{icon}</span>
      <span className="text-sm">{label}</span>
    </div>
    <div className={`
      w-2 h-2 rounded-full
      ${enabled ? 'bg-green-500' : 'bg-gray-300'}
    `} />
  </div>
);

const QuickCommand: React.FC<{ text: string }> = ({ text }) => {
  const handleClick = () => {
    // In a real implementation, this would insert the command
    console.log('Quick command:', text);
  };

  return (
    <button
      onClick={handleClick}
      className="block w-full text-left px-3 py-2 rounded hover:bg-gray-100 transition-colors text-gray-700"
    >
      {text}
    </button>
  );
};