/**
 * Integrated System Demo
 * Showcases all features of Nix for Humanity in a unified experience
 */

import React, { useState, useEffect } from 'react';
import { EnhancedOnboarding } from '../onboarding/EnhancedOnboarding';
import { NLPEngine } from '../nlp/NLPEngine';
import { PersonalityEngine } from '../personality/PersonalityEngine';
import { EmotionalStateTracker } from '../emotional/EmotionalStateTracker';
import { VoiceEngine } from '../voice/VoiceEngine';
import { ThemeEngine } from '../visual/ThemeEngine';
import { GestureEngine } from '../gestures/GestureEngine';
import { UIComplexityManager } from '../complexity/UIComplexityManager';
import { LiveSystemDemo } from './LiveSystemDemo';
import { FeatureShowcase } from './FeatureShowcase';
import { PersonaTestMode } from './PersonaTestMode';

interface DemoState {
  mode: 'menu' | 'onboarding' | 'live-demo' | 'feature-showcase' | 'persona-test';
  currentPersona?: string;
  featuresEnabled: string[];
  completedOnboarding: boolean;
}

export const IntegratedSystemDemo: React.FC = () => {
  const [demoState, setDemoState] = useState<DemoState>({
    mode: 'menu',
    featuresEnabled: [],
    completedOnboarding: false
  });

  const [systemState, setSystemState] = useState({
    nlpReady: false,
    voiceReady: false,
    personalityReady: false,
    emotionalReady: false,
    themeReady: false,
    gestureReady: false
  });

  // Initialize all systems
  useEffect(() => {
    const initSystems = async () => {
      // Initialize NLP Engine
      const nlp = new NLPEngine();
      await nlp.initialize();
      setSystemState(prev => ({ ...prev, nlpReady: true }));

      // Initialize Personality Engine
      const personality = new PersonalityEngine();
      await personality.initialize();
      setSystemState(prev => ({ ...prev, personalityReady: true }));

      // Initialize Emotional State Tracker
      const emotional = new EmotionalStateTracker();
      await emotional.initialize();
      setSystemState(prev => ({ ...prev, emotionalReady: true }));

      // Initialize Voice Engine
      const voice = new VoiceEngine();
      await voice.initialize();
      setSystemState(prev => ({ ...prev, voiceReady: true }));

      // Initialize Theme Engine
      const theme = new ThemeEngine();
      theme.loadPreferences();
      setSystemState(prev => ({ ...prev, themeReady: true }));

      // Initialize Gesture Engine
      const gesture = new GestureEngine();
      gesture.initialize();
      setSystemState(prev => ({ ...prev, gestureReady: true }));
    };

    initSystems();
  }, []);

  const allSystemsReady = Object.values(systemState).every(ready => ready);

  if (demoState.mode === 'menu') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-8">
        <div className="max-w-6xl mx-auto">
          <header className="text-center mb-12">
            <h1 className="text-5xl font-bold text-gray-800 mb-4">
              🌟 Nix for Humanity
            </h1>
            <p className="text-xl text-gray-600">
              Natural Language Interface for NixOS - Complete Demo
            </p>
            <div className="mt-4">
              {allSystemsReady ? (
                <p className="text-green-600">✅ All systems initialized</p>
              ) : (
                <p className="text-yellow-600">⏳ Initializing systems...</p>
              )}
            </div>
          </header>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Full Onboarding Experience */}
            <DemoCard
              title="Complete Onboarding"
              description="Experience the full first-time user journey with privacy transparency and feature walkthroughs"
              emoji="🚀"
              features={[
                'Privacy-first approach',
                'Adaptive personality',
                'Visual customization',
                'Feature education'
              ]}
              onClick={() => setDemoState({ ...demoState, mode: 'onboarding' })}
              disabled={!allSystemsReady}
            />

            {/* Live System Demo */}
            <DemoCard
              title="Live System Demo"
              description="Try the fully functional system with all features enabled"
              emoji="💬"
              features={[
                'Natural language commands',
                'Voice interaction',
                'Gesture recognition',
                'Real-time adaptation'
              ]}
              onClick={() => setDemoState({ ...demoState, mode: 'live-demo' })}
              disabled={!allSystemsReady || !demoState.completedOnboarding}
              notice={!demoState.completedOnboarding ? 'Complete onboarding first' : undefined}
            />

            {/* Feature Showcase */}
            <DemoCard
              title="Feature Showcase"
              description="Interactive demonstration of each major feature"
              emoji="🎯"
              features={[
                'Voice emotion detection',
                'Personality adaptation',
                'Visual simplification',
                'Privacy controls'
              ]}
              onClick={() => setDemoState({ ...demoState, mode: 'feature-showcase' })}
              disabled={!allSystemsReady}
            />

            {/* Persona Testing */}
            <DemoCard
              title="Persona Testing"
              description="Test the system as different user personas"
              emoji="👥"
              features={[
                'Grandma Rose (75)',
                'Teen Maya (16)',
                'Parent David (42)',
                'Anxious Sam (28)'
              ]}
              onClick={() => setDemoState({ ...demoState, mode: 'persona-test' })}
              disabled={!allSystemsReady}
            />

            {/* System Status */}
            <DemoCard
              title="System Status"
              description="View current system state and statistics"
              emoji="📊"
              features={[
                `NLP: ${systemState.nlpReady ? 'Ready' : 'Loading'}`,
                `Voice: ${systemState.voiceReady ? 'Ready' : 'Loading'}`,
                `Personality: ${systemState.personalityReady ? 'Ready' : 'Loading'}`,
                `Theme: ${systemState.themeReady ? 'Ready' : 'Loading'}`
              ]}
              onClick={() => {}}
              disabled={true}
              isStatus={true}
            />

            {/* Privacy Dashboard */}
            <DemoCard
              title="Privacy Dashboard"
              description="Review and manage all privacy settings"
              emoji="🛡️"
              features={[
                'Data collection overview',
                'Feature permissions',
                'Export/delete data',
                'Privacy history'
              ]}
              onClick={() => {}}
              disabled={true}
              notice="Coming soon"
            />
          </div>

          {/* Feature Matrix */}
          <div className="mt-12 bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-bold mb-6">Feature Implementation Status</h2>
            <FeatureMatrix />
          </div>
        </div>
      </div>
    );
  }

  // Handle different demo modes
  switch (demoState.mode) {
    case 'onboarding':
      return (
        <div className="demo-container">
          <DemoHeader onBack={() => setDemoState({ ...demoState, mode: 'menu' })} />
          <EnhancedOnboarding 
            onComplete={(data) => {
              setDemoState({
                ...demoState,
                mode: 'menu',
                completedOnboarding: true,
                featuresEnabled: data.enabledFeatures || []
              });
            }}
          />
        </div>
      );

    case 'live-demo':
      return <LiveSystemDemo onBack={() => setDemoState({ ...demoState, mode: 'menu' })} />;

    case 'feature-showcase':
      return <FeatureShowcase onBack={() => setDemoState({ ...demoState, mode: 'menu' })} />;

    case 'persona-test':
      return <PersonaTestMode onBack={() => setDemoState({ ...demoState, mode: 'menu' })} />;

    default:
      return null;
  }
};

// Demo Card Component
const DemoCard: React.FC<{
  title: string;
  description: string;
  emoji: string;
  features: string[];
  onClick: () => void;
  disabled?: boolean;
  notice?: string;
  isStatus?: boolean;
}> = ({ title, description, emoji, features, onClick, disabled, notice, isStatus }) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`
        bg-white rounded-lg shadow-lg p-6 text-left
        transition-all duration-200
        ${disabled && !isStatus 
          ? 'opacity-50 cursor-not-allowed' 
          : 'hover:shadow-xl hover:scale-105 cursor-pointer'
        }
      `}
    >
      <div className="flex items-start mb-4">
        <span className="text-4xl mr-4">{emoji}</span>
        <div>
          <h3 className="text-xl font-semibold">{title}</h3>
          <p className="text-gray-600 text-sm mt-1">{description}</p>
        </div>
      </div>
      
      <ul className="space-y-1">
        {features.map((feature, idx) => (
          <li key={idx} className="text-sm text-gray-700 flex items-center">
            <span className="text-green-500 mr-2">•</span>
            {feature}
          </li>
        ))}
      </ul>

      {notice && (
        <p className="mt-4 text-xs text-yellow-600 bg-yellow-50 p-2 rounded">
          {notice}
        </p>
      )}
    </button>
  );
};

// Demo Header Component
const DemoHeader: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  return (
    <div className="bg-white shadow-sm border-b border-gray-200 p-4">
      <button
        onClick={onBack}
        className="flex items-center text-blue-600 hover:text-blue-700"
      >
        <span className="mr-2">←</span>
        Back to Menu
      </button>
    </div>
  );
};

// Feature Matrix Component
const FeatureMatrix: React.FC = () => {
  const features = [
    { name: 'Natural Language Processing', status: 'complete', complexity: 'Core' },
    { name: 'Voice Integration', status: 'complete', complexity: 'Advanced' },
    { name: 'Emotion Detection', status: 'complete', complexity: 'Advanced' },
    { name: 'Personality Adaptation', status: 'complete', complexity: 'Core' },
    { name: 'Visual Simplification', status: 'complete', complexity: 'Core' },
    { name: 'Color Themes', status: 'complete', complexity: 'Basic' },
    { name: 'Gesture Recognition', status: 'complete', complexity: 'Advanced' },
    { name: 'Privacy Transparency', status: 'complete', complexity: 'Core' },
    { name: 'Feature Walkthroughs', status: 'complete', complexity: 'Core' },
    { name: 'Multi-Persona Support', status: 'complete', complexity: 'Core' },
    { name: 'Profession Detection', status: 'pending', complexity: 'Future' },
    { name: 'Natural Pause Detection', status: 'pending', complexity: 'Future' }
  ];

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
      {features.map((feature, idx) => (
        <div
          key={idx}
          className={`
            p-4 rounded-lg border-2
            ${feature.status === 'complete' 
              ? 'border-green-200 bg-green-50' 
              : 'border-gray-200 bg-gray-50'
            }
          `}
        >
          <div className="flex items-center justify-between mb-2">
            <h4 className="font-medium">{feature.name}</h4>
            <span className={`
              text-xs px-2 py-1 rounded
              ${feature.complexity === 'Core' && 'bg-blue-100 text-blue-700'}
              ${feature.complexity === 'Basic' && 'bg-gray-100 text-gray-700'}
              ${feature.complexity === 'Advanced' && 'bg-purple-100 text-purple-700'}
              ${feature.complexity === 'Future' && 'bg-yellow-100 text-yellow-700'}
            `}>
              {feature.complexity}
            </span>
          </div>
          <div className="flex items-center">
            {feature.status === 'complete' ? (
              <>
                <span className="text-green-600 mr-2">✅</span>
                <span className="text-sm text-green-700">Implemented</span>
              </>
            ) : (
              <>
                <span className="text-gray-400 mr-2">⏳</span>
                <span className="text-sm text-gray-600">Planned</span>
              </>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

