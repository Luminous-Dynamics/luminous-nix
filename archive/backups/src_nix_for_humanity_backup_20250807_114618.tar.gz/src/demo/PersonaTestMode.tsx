/**
 * Persona Test Mode
 * Test the system as different user personas
 */

import React, { useState } from 'react';
import { EnhancedOnboarding } from '../onboarding/EnhancedOnboarding';

interface Persona {
  id: string;
  name: string;
  age: number;
  description: string;
  techLevel: 'beginner' | 'intermediate' | 'advanced';
  preferences: {
    personality: string;
    voiceFirst: boolean;
    visualComplexity: number;
    learningSpeed: string;
  };
  challenges: string[];
  goals: string[];
  avatar: string;
}

export const PersonaTestMode: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [selectedPersona, setSelectedPersona] = useState<string | null>(null);
  const [testMode, setTestMode] = useState<'onboarding' | 'interaction' | null>(null);

  const personas: Persona[] = [
    {
      id: 'grandma-rose',
      name: 'Grandma Rose',
      age: 75,
      description: 'First time using a computer properly, wants to video chat with grandkids',
      techLevel: 'beginner',
      preferences: {
        personality: 'friendly',
        voiceFirst: true,
        visualComplexity: 1,
        learningSpeed: 'patient'
      },
      challenges: ['Vision not perfect', 'No technical vocabulary', 'Easily overwhelmed'],
      goals: ['Video chat with family', 'Look at photos', 'Send emails'],
      avatar: '👵'
    },
    {
      id: 'maya-teen',
      name: 'Maya',
      age: 16,
      description: 'Tech-savvy teen with ADHD, wants fast results with minimal friction',
      techLevel: 'advanced',
      preferences: {
        personality: 'minimal',
        voiceFirst: false,
        visualComplexity: 8,
        learningSpeed: 'fast'
      },
      challenges: ['ADHD - needs focus', 'Impatient with slow systems', 'Multitasking constantly'],
      goals: ['Gaming setup', 'Development environment', 'Social apps'],
      avatar: '👩‍💻'
    },
    {
      id: 'david-parent',
      name: 'David',
      age: 42,
      description: 'Tired parent trying to fix computer issues after work',
      techLevel: 'intermediate',
      preferences: {
        personality: 'friendly',
        voiceFirst: false,
        visualComplexity: 5,
        learningSpeed: 'moderate'
      },
      challenges: ['Limited time', 'Stressed from work', 'Kids interrupting'],
      goals: ['Fix problems quickly', 'Keep system secure', 'Manage family accounts'],
      avatar: '👨'
    },
    {
      id: 'dr-sarah',
      name: 'Dr. Sarah',
      age: 35,
      description: 'Medical researcher needing reliable tools for data analysis',
      techLevel: 'intermediate',
      preferences: {
        personality: 'minimal',
        voiceFirst: false,
        visualComplexity: 6,
        learningSpeed: 'efficient'
      },
      challenges: ['Time-critical work', 'Need for precision', 'Data security concerns'],
      goals: ['Statistical analysis', 'Secure data handling', 'Reproducible research'],
      avatar: '👩‍⚕️'
    },
    {
      id: 'alex-blind',
      name: 'Alex',
      age: 28,
      description: 'Blind software developer who relies on screen readers',
      techLevel: 'advanced',
      preferences: {
        personality: 'minimal',
        voiceFirst: true,
        visualComplexity: 0,
        learningSpeed: 'adaptive'
      },
      challenges: ['No visual feedback', 'Screen reader compatibility', 'Keyboard-only navigation'],
      goals: ['Development work', 'System administration', 'Accessibility testing'],
      avatar: '🧑‍💻'
    },
    {
      id: 'carlos-career',
      name: 'Carlos',
      age: 52,
      description: 'Construction worker switching careers to IT',
      techLevel: 'beginner',
      preferences: {
        personality: 'encouraging',
        voiceFirst: false,
        visualComplexity: 3,
        learningSpeed: 'supportive'
      },
      challenges: ['Starting from scratch', 'Fear of breaking things', 'Learning new vocabulary'],
      goals: ['Learn IT basics', 'Get certified', 'Find IT job'],
      avatar: '👷'
    },
    {
      id: 'priya-mom',
      name: 'Priya',
      age: 34,
      description: 'Single mom working from home while managing kids',
      techLevel: 'intermediate',
      preferences: {
        personality: 'friendly',
        voiceFirst: true,
        visualComplexity: 4,
        learningSpeed: 'flexible'
      },
      challenges: ['Constant interruptions', 'Multitasking', 'Quick context switches'],
      goals: ['Work efficiently', 'Manage kids\' accounts', 'Quick troubleshooting'],
      avatar: '👩‍👧‍👦'
    },
    {
      id: 'jamie-privacy',
      name: 'Jamie',
      age: 19,
      description: 'Privacy-conscious college student',
      techLevel: 'advanced',
      preferences: {
        personality: 'playful',
        voiceFirst: false,
        visualComplexity: 7,
        learningSpeed: 'exploratory'
      },
      challenges: ['Trust issues with tech', 'Wants full control', 'Questions everything'],
      goals: ['Maximum privacy', 'Open source everything', 'Learn system internals'],
      avatar: '🧑‍🎓'
    },
    {
      id: 'viktor-esl',
      name: 'Viktor',
      age: 67,
      description: 'Recent immigrant, English is third language',
      techLevel: 'beginner',
      preferences: {
        personality: 'friendly',
        voiceFirst: false,
        visualComplexity: 2,
        learningSpeed: 'patient'
      },
      challenges: ['Language barrier', 'Cultural differences', 'Fear of technology'],
      goals: ['Stay connected with family', 'Learn English', 'Access services'],
      avatar: '👴'
    },
    {
      id: 'luna-autistic',
      name: 'Luna',
      age: 14,
      description: 'Autistic teenager with special interest in Linux',
      techLevel: 'advanced',
      preferences: {
        personality: 'minimal',
        voiceFirst: false,
        visualComplexity: 6,
        learningSpeed: 'detailed'
      },
      challenges: ['Needs predictability', 'Sensory sensitivities', 'Literal interpretation'],
      goals: ['Master Linux', 'Create perfect setup', 'Contribute to projects'],
      avatar: '🧑'
    }
  ];

  const currentPersona = personas.find(p => p.id === selectedPersona);

  if (testMode === 'onboarding' && currentPersona) {
    return (
      <PersonaOnboardingTest
        persona={currentPersona}
        onBack={() => setTestMode(null)}
      />
    );
  }

  if (testMode === 'interaction' && currentPersona) {
    return (
      <PersonaInteractionTest
        persona={currentPersona}
        onBack={() => setTestMode(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200 p-4">
        <div className="flex items-center">
          <button
            onClick={onBack}
            className="mr-4 text-blue-600 hover:text-blue-700"
          >
            ← Back to Menu
          </button>
          <h1 className="text-xl font-semibold">Persona Test Mode</h1>
        </div>
      </div>

      <div className="p-8">
        <div className="max-w-6xl mx-auto">
          {!selectedPersona ? (
            <>
              <h2 className="text-2xl font-bold mb-6">Choose a Persona to Test</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {personas.map((persona) => (
                  <button
                    key={persona.id}
                    onClick={() => setSelectedPersona(persona.id)}
                    className="bg-white rounded-lg shadow-lg p-6 text-left hover:shadow-xl transition-shadow"
                  >
                    <div className="flex items-start mb-4">
                      <span className="text-4xl mr-4">{persona.avatar}</span>
                      <div>
                        <h3 className="text-lg font-semibold">
                          {persona.name}, {persona.age}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {persona.techLevel} user
                        </p>
                      </div>
                    </div>
                    <p className="text-sm mb-4">{persona.description}</p>
                    <div className="space-y-2">
                      <div>
                        <p className="text-xs font-medium text-gray-500">Main Goals:</p>
                        <p className="text-xs text-gray-600">
                          {persona.goals.slice(0, 2).join(', ')}
                        </p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </>
          ) : (
            <PersonaDetail
              persona={currentPersona!}
              onStartOnboarding={() => setTestMode('onboarding')}
              onStartInteraction={() => setTestMode('interaction')}
              onBack={() => setSelectedPersona(null)}
            />
          )}
        </div>
      </div>
    </div>
  );
};

// Persona Detail View
const PersonaDetail: React.FC<{
  persona: Persona;
  onStartOnboarding: () => void;
  onStartInteraction: () => void;
  onBack: () => void;
}> = ({ persona, onStartOnboarding, onStartInteraction, onBack }) => {
  return (
    <div className="max-w-4xl mx-auto">
      <button
        onClick={onBack}
        className="mb-6 text-blue-600 hover:text-blue-700"
      >
        ← Choose different persona
      </button>

      <div className="bg-white rounded-lg shadow-lg p-8">
        <div className="flex items-start mb-6">
          <span className="text-6xl mr-6">{persona.avatar}</span>
          <div>
            <h2 className="text-3xl font-bold">{persona.name}</h2>
            <p className="text-lg text-gray-600">Age {persona.age} • {persona.techLevel} user</p>
            <p className="mt-2">{persona.description}</p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <div>
            <h3 className="font-semibold mb-3">Challenges</h3>
            <ul className="space-y-2">
              {persona.challenges.map((challenge, idx) => (
                <li key={idx} className="flex items-start">
                  <span className="text-red-500 mr-2">•</span>
                  <span className="text-sm">{challenge}</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-3">Goals</h3>
            <ul className="space-y-2">
              {persona.goals.map((goal, idx) => (
                <li key={idx} className="flex items-start">
                  <span className="text-green-500 mr-2">•</span>
                  <span className="text-sm">{goal}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-6 mb-8">
          <h3 className="font-semibold mb-3">System Preferences</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600">Personality Style</p>
              <p className="font-medium capitalize">{persona.preferences.personality}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Primary Input</p>
              <p className="font-medium">{persona.preferences.voiceFirst ? 'Voice' : 'Text/Mouse'}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Visual Complexity</p>
              <p className="font-medium">{persona.preferences.visualComplexity}/10</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Learning Speed</p>
              <p className="font-medium capitalize">{persona.preferences.learningSpeed}</p>
            </div>
          </div>
        </div>

        <div className="flex space-x-4">
          <button
            onClick={onStartOnboarding}
            className="flex-1 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Test Onboarding Experience
          </button>
          <button
            onClick={onStartInteraction}
            className="flex-1 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700"
          >
            Test Live Interaction
          </button>
        </div>
      </div>
    </div>
  );
};

// Persona Onboarding Test
const PersonaOnboardingTest: React.FC<{
  persona: Persona;
  onBack: () => void;
}> = ({ persona, onBack }) => {
  // Set up persona-specific configuration
  React.useEffect(() => {
    // Configure system for this persona
    window.__DEBUG_PROFILE__ = {
      name: persona.name,
      comfort: persona.techLevel,
      preferences: persona.preferences
    };
  }, [persona]);

  return (
    <div>
      <div className="bg-yellow-50 border-b border-yellow-200 p-4">
        <div className="flex items-center justify-between">
          <p className="text-sm">
            <strong>Testing as:</strong> {persona.name} ({persona.age}) - {persona.description}
          </p>
          <button
            onClick={onBack}
            className="text-blue-600 hover:text-blue-700 text-sm"
          >
            Exit persona test
          </button>
        </div>
      </div>
      
      <EnhancedOnboarding />
    </div>
  );
};

// Persona Interaction Test
const PersonaInteractionTest: React.FC<{
  persona: Persona;
  onBack: () => void;
}> = ({ persona, onBack }) => {
  const [messages, setMessages] = useState<Array<{
    type: 'user' | 'system';
    content: string;
  }>>([]);

  const sampleInteractions = {
    'grandma-rose': [
      'How do I video chat with my grandchildren?',
      'The screen is too small, I can\'t read it',
      'What does "install" mean?'
    ],
    'maya-teen': [
      'install discord and steam',
      'set up rust dev environment',
      'why is this so slow'
    ],
    'david-parent': [
      'my computer is running slow',
      'how do I set up parental controls',
      'quick fix for wifi not working'
    ],
    'dr-sarah': [
      'install R and RStudio',
      'set up encrypted backup',
      'configure jupyter for data analysis'
    ],
    'alex-blind': [
      'configure screen reader settings',
      'install accessible terminal',
      'keyboard shortcuts for everything'
    ],
    'carlos-career': [
      'what is a terminal?',
      'how do I practice linux commands safely',
      'explain package manager simply'
    ],
    'priya-mom': [
      'kids account broke something help',
      'need zoom for meeting in 5 minutes',
      'quick way to free up space'
    ],
    'jamie-privacy': [
      'show me what data you collect',
      'how do I verify nothing leaves my computer',
      'install tor browser'
    ],
    'viktor-esl': [
      'help computer no work',
      'how make bigger text',
      'install program for learn english'
    ],
    'luna-autistic': [
      'exactly how does package management work',
      'I need consistent behavior always',
      'show me the source code'
    ]
  };

  const addMessage = (type: 'user' | 'system', content: string) => {
    setMessages(prev => [...prev, { type, content }]);
  };

  const handleSampleInteraction = (interaction: string) => {
    addMessage('user', interaction);
    
    // Simulate system response based on persona
    setTimeout(() => {
      const response = generatePersonaResponse(persona, interaction);
      addMessage('system', response);
    }, 500);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="bg-yellow-50 border-b border-yellow-200 p-4">
        <div className="flex items-center justify-between">
          <p className="text-sm">
            <strong>Testing as:</strong> {persona.name} - {persona.preferences.personality} personality mode
          </p>
          <button
            onClick={onBack}
            className="text-blue-600 hover:text-blue-700 text-sm"
          >
            Exit persona test
          </button>
        </div>
      </div>

      <div className="flex-1 flex">
        <div className="flex-1 flex flex-col">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-6">
            <div className="max-w-3xl mx-auto space-y-4">
              {messages.length === 0 && (
                <div className="text-center text-gray-500 py-8">
                  <p>Start a conversation using the sample interactions →</p>
                </div>
              )}
              
              {messages.map((message, idx) => (
                <div
                  key={idx}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`
                      max-w-lg px-4 py-3 rounded-lg
                      ${message.type === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-white border border-gray-200'
                      }
                    `}
                  >
                    {message.content}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Input */}
          <div className="bg-white border-t border-gray-200 p-4">
            <div className="max-w-3xl mx-auto">
              <input
                type="text"
                placeholder={`Type as ${persona.name}...`}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && e.currentTarget.value) {
                    handleSampleInteraction(e.currentTarget.value);
                    e.currentTarget.value = '';
                  }
                }}
              />
            </div>
          </div>
        </div>

        {/* Sample Interactions */}
        <div className="w-80 bg-white border-l border-gray-200 p-6">
          <h3 className="font-semibold mb-4">Sample Interactions</h3>
          <div className="space-y-2">
            {sampleInteractions[persona.id as keyof typeof sampleInteractions]?.map((interaction, idx) => (
              <button
                key={idx}
                onClick={() => handleSampleInteraction(interaction)}
                className="w-full text-left p-3 bg-gray-50 rounded-lg hover:bg-gray-100 text-sm"
              >
                "{interaction}"
              </button>
            ))}
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <h4 className="font-medium mb-2 text-sm">Persona Traits Active:</h4>
            <ul className="text-xs space-y-1 text-gray-600">
              <li>• {persona.preferences.personality} personality</li>
              <li>• Complexity level {persona.preferences.visualComplexity}</li>
              <li>• {persona.preferences.learningSpeed} learning pace</li>
              {persona.preferences.voiceFirst && <li>• Voice-first interaction</li>}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper function to generate persona-appropriate responses
function generatePersonaResponse(persona: Persona, input: string): string {
  const responses: Record<string, Record<string, string>> = {
    friendly: {
      default: "I'd be happy to help you with that! Let me explain step by step...",
      confused: "I understand this might be confusing. Let's take it slow..."
    },
    minimal: {
      default: "Processing... Done.",
      confused: "Unclear. Specify."
    },
    encouraging: {
      default: "Great question! You're doing wonderfully. Here's what we'll do...",
      confused: "No worries at all! Everyone finds this tricky at first. Let's figure it out together..."
    },
    playful: {
      default: "Ooh, fun request! Let's make some magic happen! ✨",
      confused: "Hmm, that's a puzzler! 🤔 Can you give me another hint?"
    }
  };

  const style = persona.preferences.personality;
  const response = responses[style]?.default || "I'll help you with that.";
  
  // Add persona-specific adjustments
  if (persona.id === 'grandma-rose') {
    return response + " Don't worry, we'll go nice and slow.";
  } else if (persona.id === 'maya-teen') {
    return response.replace(/!|\.{3}/g, '');
  }
  
  return response;
}