/**
 * Feature Showcase
 * Interactive demonstrations of each major feature
 */

import React, { useState } from 'react';

interface Feature {
  id: string;
  name: string;
  description: string;
  icon: string;
  demo: React.ReactNode;
}

export const FeatureShowcase: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [selectedFeature, setSelectedFeature] = useState<string>('nlp');

  const features: Feature[] = [
    {
      id: 'nlp',
      name: 'Natural Language Processing',
      description: 'Understand commands in plain English with 95%+ accuracy',
      icon: '💬',
      demo: <NLPDemo />
    },
    {
      id: 'voice',
      name: 'Voice Integration',
      description: 'Speak naturally to control your system',
      icon: '🎤',
      demo: <VoiceDemo />
    },
    {
      id: 'emotion',
      name: 'Emotion Detection',
      description: 'System adapts to your emotional state',
      icon: '😊',
      demo: <EmotionDemo />
    },
    {
      id: 'personality',
      name: 'Personality Adaptation',
      description: '5 personality styles that match your preference',
      icon: '🎭',
      demo: <PersonalityDemo />
    },
    {
      id: 'visual',
      name: 'Visual Simplification',
      description: 'Interface complexity that adapts to your skill level',
      icon: '🎨',
      demo: <VisualDemo />
    },
    {
      id: 'gesture',
      name: 'Gesture Recognition',
      description: 'Automatic help when you\'re confused',
      icon: '👋',
      demo: <GestureDemo />
    },
    {
      id: 'privacy',
      name: 'Privacy Transparency',
      description: 'Complete control over your data',
      icon: '🛡️',
      demo: <PrivacyDemo />
    },
    {
      id: 'learning',
      name: 'Learning System',
      description: 'AI that learns your preferences',
      icon: '🧠',
      demo: <LearningDemo />
    }
  ];

  const currentFeature = features.find(f => f.id === selectedFeature);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200 p-4">
        <div className="flex items-center">
          <button
            onClick={onBack}
            className="mr-4 text-blue-600 hover:text-blue-700"
          >
            ← Back to Menu
          </button>
          <h1 className="text-xl font-semibold">Feature Showcase</h1>
        </div>
      </div>

      <div className="flex h-[calc(100vh-64px)]">
        {/* Feature List */}
        <div className="w-80 bg-white border-r border-gray-200 overflow-y-auto">
          <div className="p-4">
            <h2 className="text-lg font-semibold mb-4">Features</h2>
            <div className="space-y-2">
              {features.map((feature) => (
                <button
                  key={feature.id}
                  onClick={() => setSelectedFeature(feature.id)}
                  className={`
                    w-full text-left p-4 rounded-lg transition-all
                    ${selectedFeature === feature.id
                      ? 'bg-blue-50 border-2 border-blue-500'
                      : 'hover:bg-gray-50 border-2 border-transparent'
                    }
                  `}
                >
                  <div className="flex items-start">
                    <span className="text-2xl mr-3">{feature.icon}</span>
                    <div>
                      <h3 className="font-medium">{feature.name}</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Feature Demo Area */}
        <div className="flex-1 overflow-y-auto">
          {currentFeature && (
            <div className="p-8">
              <div className="max-w-4xl mx-auto">
                <div className="mb-8">
                  <div className="flex items-center mb-4">
                    <span className="text-4xl mr-4">{currentFeature.icon}</span>
                    <div>
                      <h1 className="text-3xl font-bold">{currentFeature.name}</h1>
                      <p className="text-lg text-gray-600 mt-1">
                        {currentFeature.description}
                      </p>
                    </div>
                  </div>
                </div>
                
                {currentFeature.demo}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Individual Feature Demos

const NLPDemo: React.FC = () => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<any>(null);

  const examples = [
    "install firefox",
    "I need a text editor",
    "my wifi isn't working",
    "update everything",
    "show me what's installed"
  ];

  const processInput = () => {
    // Simulate NLP processing
    const mockResults = {
      "install firefox": {
        intent: "package.install",
        entities: { package: "firefox" },
        confidence: 0.98
      },
      "I need a text editor": {
        intent: "package.search",
        entities: { category: "text-editor" },
        confidence: 0.92
      },
      "my wifi isn't working": {
        intent: "network.troubleshoot",
        entities: { component: "wifi" },
        confidence: 0.95
      }
    };

    setResult(mockResults[input] || {
      intent: "unknown",
      confidence: 0.4,
      suggestion: "Could you rephrase that?"
    });
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Try Natural Language Input</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Type a command in plain English:
            </label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Try: install firefox"
              />
              <button
                onClick={processInput}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Process
              </button>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {examples.map((example) => (
              <button
                key={example}
                onClick={() => setInput(example)}
                className="px-3 py-1 bg-gray-100 text-sm rounded-full hover:bg-gray-200"
              >
                {example}
              </button>
            ))}
          </div>
        </div>

        {result && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h4 className="font-medium mb-2">NLP Analysis Result:</h4>
            <pre className="text-sm bg-white p-3 rounded border border-gray-200">
              {JSON.stringify(result, null, 2)}
            </pre>
          </div>
        )}
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">How It Works</h3>
        <div className="space-y-3">
          <p>Our hybrid NLP system combines three approaches:</p>
          <ol className="list-decimal list-inside space-y-2 ml-4">
            <li>
              <strong>Rule-based patterns</strong> for common commands (fastest)
            </li>
            <li>
              <strong>Statistical models</strong> for flexibility
            </li>
            <li>
              <strong>Neural networks</strong> for deep understanding
            </li>
          </ol>
          <p className="mt-4">
            This achieves 95%+ accuracy while keeping response times under 50ms.
          </p>
        </div>
      </div>
    </div>
  );
};

const VoiceDemo: React.FC = () => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [emotion, setEmotion] = useState('neutral');

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Voice Control Demo</h3>
        
        <div className="text-center py-8">
          <button
            onClick={() => {
              setIsListening(!isListening);
              if (!isListening) {
                setTimeout(() => {
                  setTranscript("install firefox");
                  setEmotion("confident");
                  setIsListening(false);
                }, 2000);
              }
            }}
            className={`
              w-32 h-32 rounded-full flex items-center justify-center text-5xl
              transition-all transform
              ${isListening 
                ? 'bg-red-500 scale-110 animate-pulse' 
                : 'bg-gray-200 hover:bg-gray-300'
              }
            `}
          >
            🎤
          </button>
          <p className="mt-4 text-lg">
            {isListening ? 'Listening...' : 'Click to speak'}
          </p>
        </div>

        {transcript && (
          <div className="mt-6 space-y-4">
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600">Transcript:</p>
              <p className="text-lg font-medium">{transcript}</p>
            </div>
            
            <div className="p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-gray-600">Detected emotion:</p>
              <p className="text-lg font-medium capitalize">{emotion}</p>
            </div>
          </div>
        )}
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Voice Features</h3>
        <ul className="space-y-3">
          <li className="flex items-start">
            <span className="text-green-500 mr-2">✓</span>
            <div>
              <strong>Natural speech recognition</strong> - No robotic commands
            </div>
          </li>
          <li className="flex items-start">
            <span className="text-green-500 mr-2">✓</span>
            <div>
              <strong>Emotion detection</strong> - Responds to your tone
            </div>
          </li>
          <li className="flex items-start">
            <span className="text-green-500 mr-2">✓</span>
            <div>
              <strong>Privacy-first</strong> - All processing happens locally
            </div>
          </li>
          <li className="flex items-start">
            <span className="text-green-500 mr-2">✓</span>
            <div>
              <strong>Multi-language</strong> - Supports 6+ languages
            </div>
          </li>
        </ul>
      </div>
    </div>
  );
};

const EmotionDemo: React.FC = () => {
  const [typingSpeed, setTypingSpeed] = useState(50);
  const [backspaces, setBackspaces] = useState(2);
  const [emotion, setEmotion] = useState('neutral');

  const analyzeEmotion = () => {
    if (typingSpeed > 80 && backspaces > 5) {
      setEmotion('frustrated');
    } else if (typingSpeed < 30) {
      setEmotion('uncertain');
    } else if (typingSpeed > 60) {
      setEmotion('confident');
    } else {
      setEmotion('neutral');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Emotion Detection Simulator</h3>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Typing Speed (WPM)
            </label>
            <input
              type="range"
              min="10"
              max="120"
              value={typingSpeed}
              onChange={(e) => setTypingSpeed(Number(e.target.value))}
              className="w-full"
            />
            <p className="text-center mt-1">{typingSpeed} WPM</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Backspaces per minute
            </label>
            <input
              type="range"
              min="0"
              max="20"
              value={backspaces}
              onChange={(e) => setBackspaces(Number(e.target.value))}
              className="w-full"
            />
            <p className="text-center mt-1">{backspaces} backspaces</p>
          </div>

          <button
            onClick={analyzeEmotion}
            className="w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Analyze Emotional State
          </button>
        </div>

        {emotion !== 'neutral' && (
          <div className={`
            mt-6 p-4 rounded-lg text-center
            ${emotion === 'frustrated' && 'bg-red-50 text-red-700'}
            ${emotion === 'uncertain' && 'bg-yellow-50 text-yellow-700'}
            ${emotion === 'confident' && 'bg-green-50 text-green-700'}
          `}>
            <p className="text-lg font-medium">
              Detected emotion: {emotion}
            </p>
            <p className="text-sm mt-2">
              {emotion === 'frustrated' && "I'll slow down and be more patient"}
              {emotion === 'uncertain' && "Let me provide more guidance"}
              {emotion === 'confident' && "Great! Moving at your pace"}
            </p>
          </div>
        )}
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Emotion Response Adaptations</h3>
        <div className="space-y-4">
          <div className="p-4 border border-red-200 rounded-lg">
            <h4 className="font-medium text-red-700">When Frustrated:</h4>
            <ul className="text-sm mt-2 space-y-1">
              <li>• Slower, more patient responses</li>
              <li>• Clearer step-by-step instructions</li>
              <li>• Offer to take a break</li>
              <li>• Simplified language</li>
            </ul>
          </div>
          
          <div className="p-4 border border-yellow-200 rounded-lg">
            <h4 className="font-medium text-yellow-700">When Uncertain:</h4>
            <ul className="text-sm mt-2 space-y-1">
              <li>• More detailed explanations</li>
              <li>• Suggest examples</li>
              <li>• Provide reassurance</li>
              <li>• Offer tutorials</li>
            </ul>
          </div>
          
          <div className="p-4 border border-green-200 rounded-lg">
            <h4 className="font-medium text-green-700">When Confident:</h4>
            <ul className="text-sm mt-2 space-y-1">
              <li>• Faster, concise responses</li>
              <li>• Advanced options visible</li>
              <li>• Less hand-holding</li>
              <li>• Power user features</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

const PersonalityDemo: React.FC = () => {
  const [selectedPersonality, setSelectedPersonality] = useState('friendly');
  const [sampleCommand] = useState('install firefox');

  const personalities = {
    minimal: {
      name: 'Minimal Technical',
      description: 'Just the facts, maximum efficiency',
      response: 'Installing firefox... Done.',
      emoji: '🤖'
    },
    friendly: {
      name: 'Friendly Assistant',
      description: 'Warm, helpful, professional',
      response: "I'll install Firefox for you! This will just take a moment... All set! Firefox is now ready to use.",
      emoji: '😊'
    },
    encouraging: {
      name: 'Encouraging Mentor',
      description: 'Supportive, celebrates progress',
      response: "Great choice! Installing Firefox now... You're doing awesome! Firefox is installed and ready.",
      emoji: '🌟'
    },
    playful: {
      name: 'Playful Companion',
      description: 'Light humor, makes computing fun',
      response: "Firefox coming right up! 🎉 *installation magic happens* Ta-da! Firefox is ready to rock!",
      emoji: '🎮'
    },
    sacred: {
      name: 'Sacred Technology',
      description: 'Mindful language with mantras (optional)',
      response: "✨ Manifesting Firefox into your system... The digital essence flows... Firefox now dwells within your realm.",
      emoji: '🕉️'
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Personality Styles</h3>
        
        <div className="space-y-4">
          {Object.entries(personalities).map(([key, personality]) => (
            <label
              key={key}
              className={`
                block p-4 rounded-lg border-2 cursor-pointer transition-all
                ${selectedPersonality === key
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
                }
              `}
            >
              <input
                type="radio"
                name="personality"
                value={key}
                checked={selectedPersonality === key}
                onChange={(e) => setSelectedPersonality(e.target.value)}
                className="sr-only"
              />
              <div className="flex items-start">
                <span className="text-2xl mr-3">{personality.emoji}</span>
                <div className="flex-1">
                  <h4 className="font-medium">{personality.name}</h4>
                  <p className="text-sm text-gray-600 mt-1">{personality.description}</p>
                </div>
              </div>
            </label>
          ))}
        </div>

        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600 mb-2">
            Response to "{sampleCommand}":
          </p>
          <p className="text-lg">
            {personalities[selectedPersonality as keyof typeof personalities].response}
          </p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">How Personality Adapts</h3>
        <div className="space-y-3">
          <p>The system learns your preferred style through:</p>
          <ul className="list-disc list-inside ml-4 space-y-2">
            <li>Your vocabulary choices</li>
            <li>Response to different styles</li>
            <li>Time of day patterns</li>
            <li>Context awareness</li>
          </ul>
          <p className="mt-4 text-sm text-gray-600">
            You can always manually switch styles or let the system adapt naturally.
          </p>
        </div>
      </div>
    </div>
  );
};

const VisualDemo: React.FC = () => {
  const [complexityLevel, setComplexityLevel] = useState(5);

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Visual Complexity Adaptation</h3>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Complexity Level: {complexityLevel}/10
            </label>
            <input
              type="range"
              min="1"
              max="10"
              value={complexityLevel}
              onChange={(e) => setComplexityLevel(Number(e.target.value))}
              className="w-full"
            />
          </div>

          <div className="p-6 border-2 border-gray-200 rounded-lg">
            {/* Beginner Level */}
            {complexityLevel <= 3 && (
              <div className="space-y-4">
                <h4 className="text-xl font-bold">Install Programs</h4>
                <button className="w-full py-4 bg-blue-600 text-white text-lg rounded-lg">
                  Install Firefox
                </button>
                <button className="w-full py-4 bg-green-600 text-white text-lg rounded-lg">
                  Update Computer
                </button>
              </div>
            )}

            {/* Intermediate Level */}
            {complexityLevel > 3 && complexityLevel <= 7 && (
              <div className="space-y-4">
                <div className="flex space-x-4">
                  <button className="flex-1 py-3 bg-blue-600 text-white rounded-lg">
                    Install
                  </button>
                  <button className="flex-1 py-3 bg-green-600 text-white rounded-lg">
                    Update
                  </button>
                  <button className="flex-1 py-3 bg-gray-600 text-white rounded-lg">
                    Search
                  </button>
                </div>
                <input
                  type="text"
                  placeholder="Type a command..."
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                />
              </div>
            )}

            {/* Advanced Level */}
            {complexityLevel > 7 && (
              <div className="space-y-2">
                <input
                  type="text"
                  placeholder="Command..."
                  className="w-full px-3 py-1 border border-gray-300 rounded text-sm"
                />
                <div className="flex space-x-2 text-xs">
                  <span className="text-gray-500">Recent:</span>
                  <button className="text-blue-600 hover:underline">nix-env -iA</button>
                  <button className="text-blue-600 hover:underline">nixos-rebuild</button>
                  <button className="text-blue-600 hover:underline">nix search</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">The Disappearing Path</h3>
        <div className="space-y-4">
          <div className="flex items-center space-x-4">
            <div className="w-20 h-20 bg-blue-100 rounded-lg flex items-center justify-center">
              <span className="text-2xl">🏰</span>
            </div>
            <div>
              <h4 className="font-medium">Sanctuary (Levels 1-3)</h4>
              <p className="text-sm text-gray-600">Rich visual guidance for new users</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="w-20 h-20 bg-purple-100 rounded-lg flex items-center justify-center">
              <span className="text-2xl">🏋️</span>
            </div>
            <div>
              <h4 className="font-medium">Gymnasium (Levels 4-7)</h4>
              <p className="text-sm text-gray-600">Adaptive learning with the user</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center">
              <span className="text-2xl">☁️</span>
            </div>
            <div>
              <h4 className="font-medium">Open Sky (Levels 8-10)</h4>
              <p className="text-sm text-gray-600">Nearly invisible excellence</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const GestureDemo: React.FC = () => {
  const [mousePattern, setMousePattern] = useState('normal');
  const [suggestion, setSuggestion] = useState('');

  const patterns = {
    circling: {
      description: 'Mouse circling indicates confusion',
      response: 'I notice you might be looking for something. Can I help?'
    },
    rapidClicks: {
      description: 'Rapid clicking shows frustration',
      response: "Let's slow down. What are you trying to do?"
    },
    hovering: {
      description: 'Hovering suggests uncertainty',
      response: 'Would you like more information about this?'
    },
    normal: {
      description: 'Normal movement',
      response: ''
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Gesture Recognition Demo</h3>
        
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            {Object.entries(patterns).map(([key, pattern]) => (
              <button
                key={key}
                onClick={() => {
                  setMousePattern(key);
                  setSuggestion(pattern.response);
                }}
                className={`
                  p-4 rounded-lg border-2 text-left
                  ${mousePattern === key
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                  }
                `}
              >
                <h4 className="font-medium capitalize">{key}</h4>
                <p className="text-sm text-gray-600 mt-1">{pattern.description}</p>
              </button>
            ))}
          </div>

          {suggestion && (
            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-800">System response:</p>
              <p className="font-medium mt-1">{suggestion}</p>
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Privacy-First Implementation</h3>
        <ul className="space-y-3">
          <li className="flex items-start">
            <span className="text-green-500 mr-2">✓</span>
            <div>
              <strong>Opt-in only</strong> - Must be explicitly enabled
            </div>
          </li>
          <li className="flex items-start">
            <span className="text-green-500 mr-2">✓</span>
            <div>
              <strong>Local processing</strong> - No data sent anywhere
            </div>
          </li>
          <li className="flex items-start">
            <span className="text-green-500 mr-2">✓</span>
            <div>
              <strong>Patterns only</strong> - No screen recording
            </div>
          </li>
          <li className="flex items-start">
            <span className="text-green-500 mr-2">✓</span>
            <div>
              <strong>Instant disable</strong> - Turn off anytime
            </div>
          </li>
        </ul>
      </div>
    </div>
  );
};

const PrivacyDemo: React.FC = () => {
  const [enabledFeatures, setEnabledFeatures] = useState({
    voice: false,
    gestures: false,
    learning: true,
    emotion: false
  });

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Privacy Control Center</h3>
        
        <div className="space-y-4">
          {Object.entries(enabledFeatures).map(([feature, enabled]) => (
            <label
              key={feature}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
            >
              <div>
                <h4 className="font-medium capitalize">{feature} Processing</h4>
                <p className="text-sm text-gray-600">
                  {feature === 'voice' && 'Process voice commands locally'}
                  {feature === 'gestures' && 'Detect confusion through mouse patterns'}
                  {feature === 'learning' && 'Learn your preferences over time'}
                  {feature === 'emotion' && 'Adapt to your emotional state'}
                </p>
              </div>
              <input
                type="checkbox"
                checked={enabled}
                onChange={(e) => setEnabledFeatures({
                  ...enabledFeatures,
                  [feature]: e.target.checked
                })}
                className="w-5 h-5"
              />
            </label>
          ))}
        </div>

        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-medium text-blue-900 mb-2">Your Privacy Summary:</h4>
          <ul className="text-sm space-y-1">
            <li className="flex items-center">
              <span className="text-green-600 mr-2">✓</span>
              All data stays on your device
            </li>
            <li className="flex items-center">
              <span className="text-green-600 mr-2">✓</span>
              No cloud services or accounts required
            </li>
            <li className="flex items-center">
              <span className="text-green-600 mr-2">✓</span>
              You can delete everything anytime
            </li>
            <li className="flex items-center">
              <span className="text-green-600 mr-2">✓</span>
              Open source and auditable
            </li>
          </ul>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Data Control Options</h3>
        <div className="space-y-3">
          <button className="w-full py-3 px-4 bg-gray-100 text-left rounded-lg hover:bg-gray-200">
            📊 View all collected data
          </button>
          <button className="w-full py-3 px-4 bg-gray-100 text-left rounded-lg hover:bg-gray-200">
            💾 Export your data
          </button>
          <button className="w-full py-3 px-4 bg-gray-100 text-left rounded-lg hover:bg-gray-200">
            🗑️ Delete specific data
          </button>
          <button className="w-full py-3 px-4 bg-red-100 text-red-700 text-left rounded-lg hover:bg-red-200">
            ⚠️ Factory reset (delete everything)
          </button>
        </div>
      </div>
    </div>
  );
};

const LearningDemo: React.FC = () => {
  const [interactions, setInteractions] = useState(0);
  const [patterns, setPatterns] = useState<string[]>([]);

  const simulateLearning = () => {
    setInteractions(prev => prev + 10);
    
    if (interactions >= 10) {
      setPatterns(prev => [...prev, 'Prefers Firefox over Chrome']);
    }
    if (interactions >= 20) {
      setPatterns(prev => [...prev, 'Usually updates on weekends']);
    }
    if (interactions >= 30) {
      setPatterns(prev => [...prev, 'Uses friendly personality mode']);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Learning System Demo</h3>
        
        <div className="space-y-6">
          <div className="text-center">
            <p className="text-3xl font-bold">{interactions}</p>
            <p className="text-gray-600">Interactions analyzed</p>
            
            <button
              onClick={simulateLearning}
              className="mt-4 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Simulate 10 interactions
            </button>
          </div>

          {patterns.length > 0 && (
            <div>
              <h4 className="font-medium mb-3">Learned Patterns:</h4>
              <ul className="space-y-2">
                {patterns.map((pattern, idx) => (
                  <li key={idx} className="flex items-center p-3 bg-green-50 rounded-lg">
                    <span className="text-green-600 mr-2">✓</span>
                    {pattern}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">What the System Learns</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <h4 className="font-medium mb-2">Preferences</h4>
            <ul className="text-sm space-y-1 text-gray-600">
              <li>• Favorite applications</li>
              <li>• Installation methods</li>
              <li>• Update timing</li>
              <li>• Communication style</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium mb-2">Patterns</h4>
            <ul className="text-sm space-y-1 text-gray-600">
              <li>• Work schedules</li>
              <li>• Common workflows</li>
              <li>• Error recovery</li>
              <li>• Skill progression</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};