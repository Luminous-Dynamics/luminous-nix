/**
 * Demo: How onboarding profiles create different response styles
 */

import { OnboardingNLPBridge, OnboardingProfile } from './onboarding-nlp-bridge';
import { PersonalityStyle } from '../personality/types';

// Sample profiles from different onboarding paths
const sampleProfiles: Record<string, OnboardingProfile> = {
  minimal: {
    primaryStyle: 'Minimal & Efficient',
    styleWeights: { minimal: 0.8, friendly: 0.2 },
    answers: [
      {
        question: "How do you like to communicate?",
        selectedOption: { id: 'minimal', weight: { minimal: 1.0 } }
      },
      {
        question: "What brings you delight?",
        selectedOption: { id: 'efficiency', weight: { minimal: 0.8 } }
      },
      {
        question: "How do you prefer to learn?",
        selectedOption: { id: 'examples', weight: { minimal: 0.5, friendly: 0.5 } }
      },
      {
        question: "What matters most to you?",
        selectedOption: { id: 'results', weight: { minimal: 0.9 } }
      }
    ],
    completedAt: new Date().toISOString(),
    hasCompletedOnboarding: true
  },
  
  friendly: {
    primaryStyle: 'Friendly & Warm',
    styleWeights: { friendly: 0.7, encouraging: 0.3 },
    answers: [
      {
        question: "How do you like to communicate?",
        selectedOption: { id: 'friendly', weight: { friendly: 1.0 } }
      },
      {
        question: "What brings you delight?",
        selectedOption: { id: 'connection', weight: { friendly: 0.6, encouraging: 0.4 } }
      },
      {
        question: "How do you prefer to learn?",
        selectedOption: { id: 'explanations', weight: { friendly: 0.6, encouraging: 0.4 } }
      },
      {
        question: "What matters most to you?",
        selectedOption: { id: 'understanding', weight: { friendly: 0.5, sacred: 0.5 } }
      }
    ],
    completedAt: new Date().toISOString(),
    hasCompletedOnboarding: true
  },
  
  playful: {
    primaryStyle: 'Playful & Fun',
    styleWeights: { playful: 0.8, friendly: 0.2 },
    answers: [
      {
        question: "How do you like to communicate?",
        selectedOption: { id: 'playful', weight: { playful: 1.0 } }
      },
      {
        question: "What brings you delight?",
        selectedOption: { id: 'creativity', weight: { playful: 0.8, sacred: 0.2 } }
      },
      {
        question: "How do you prefer to learn?",
        selectedOption: { id: 'exploration', weight: { playful: 0.6, minimal: 0.4 } }
      },
      {
        question: "What matters most to you?",
        selectedOption: { id: 'journey', weight: { playful: 0.5, encouraging: 0.3, sacred: 0.2 } }
      }
    ],
    completedAt: new Date().toISOString(),
    hasCompletedOnboarding: true
  }
};

/**
 * Demo showing how different profiles create different responses
 */
export async function demoPersonalityResponses() {
  console.log('🎭 Personality Response Demo\n');
  console.log('Showing how the same command gets different responses based on onboarding...\n');
  
  const testQueries = [
    "install firefox",
    "my wifi isn't working",
    "help me learn nix",
    "what can you do?"
  ];
  
  for (const [profileName, profile] of Object.entries(sampleProfiles)) {
    console.log(`\n${'='.repeat(60)}`);
    console.log(`👤 Profile: ${profile.primaryStyle}`);
    console.log(`   Style weights:`, profile.styleWeights);
    console.log(`${'='.repeat(60)}\n`);
    
    // Create bridge with this profile
    const bridge = new OnboardingNLPBridge();
    
    // Mock localStorage for demo
    const originalGetItem = global.localStorage?.getItem;
    if (typeof global !== 'undefined' && global.localStorage) {
      global.localStorage.getItem = () => JSON.stringify(profile);
    }
    
    await bridge.initializeWithProfile(profile);
    
    // Process each query
    for (const query of testQueries) {
      console.log(`💬 User: "${query}"`);
      
      try {
        const response = await bridge.processQuery(query);
        console.log(`🤖 Nix: ${response}\n`);
      } catch (error) {
        console.log(`🤖 Nix: [Response would be adapted to ${profileName} style]\n`);
      }
    }
    
    // Restore localStorage
    if (typeof global !== 'undefined' && global.localStorage) {
      global.localStorage.getItem = originalGetItem!;
    }
  }
  
  console.log('\n✨ Notice how each personality creates a unique interaction style!');
}

/**
 * Demo showing profile evolution through interactions
 */
export async function demoProfileEvolution() {
  console.log('\n📈 Profile Evolution Demo\n');
  
  const bridge = new OnboardingNLPBridge();
  const initialProfile = sampleProfiles.friendly;
  
  await bridge.initializeWithProfile(initialProfile);
  
  console.log('Initial personality: Friendly & Warm');
  console.log('Let\'s see how it adapts based on user feedback...\n');
  
  const interactions = [
    {
      query: "explain package management",
      expectedResponse: "I'd be happy to explain package management!...",
      feedback: 'negative' as const,
      comment: "User seems to want shorter responses"
    },
    {
      query: "install git",
      expectedResponse: "Installing git...",
      feedback: 'positive' as const,
      comment: "User likes concise responses for simple tasks"
    },
    {
      query: "how does nix work?",
      expectedResponse: "Here's a friendly overview of Nix...",
      feedback: 'positive' as const,
      comment: "But appreciates detail for complex topics"
    }
  ];
  
  for (const interaction of interactions) {
    console.log(`💬 User: "${interaction.query}"`);
    console.log(`🤖 Nix: ${interaction.expectedResponse}`);
    console.log(`👍/👎 Feedback: ${interaction.feedback}`);
    console.log(`📝 Note: ${interaction.comment}\n`);
    
    await bridge.updateProfileFromInteraction({
      query: interaction.query,
      response: interaction.expectedResponse,
      feedback: interaction.feedback
    });
  }
  
  console.log('🎯 Result: The system learns to be concise for commands but detailed for explanations!');
}

// Example output generator
export function generateExampleResponses() {
  const examples: Record<string, Record<PersonalityStyle, string>> = {
    "install firefox": {
      [PersonalityStyle.MINIMAL]: "Installing firefox... Done.",
      [PersonalityStyle.FRIENDLY]: "I'll install Firefox for you! Just a moment... All done! Firefox is ready to use.",
      [PersonalityStyle.ENCOURAGING]: "Great choice! Installing Firefox now... Wonderful! You've got Firefox all set up. You're doing great!",
      [PersonalityStyle.PLAYFUL]: "Firefox coming right up! 🦊 *whoosh* Installed! Your foxy browser awaits!",
      [PersonalityStyle.SACRED]: "Manifesting Firefox into your digital realm... ✨ The browser flows into being. Installation complete."
    },
    
    "my wifi isn't working": {
      [PersonalityStyle.MINIMAL]: "Checking wifi... Interface down. Run: `sudo systemctl restart NetworkManager`",
      [PersonalityStyle.FRIENDLY]: "Oh no! Let me help you with your WiFi. I'll check what's happening... It looks like the network service stopped. Shall I restart it for you?",
      [PersonalityStyle.ENCOURAGING]: "Don't worry, we'll get your WiFi working! Let me investigate... I found the issue! With just one command, we can fix this together.",
      [PersonalityStyle.PLAYFUL]: "WiFi on strike? Let's negotiate! 📡 Hmm, looks like NetworkManager took a nap. Want me to give it a gentle wake-up call?",
      [PersonalityStyle.SACRED]: "The connection seeks to flow again... I sense a disruption in NetworkManager. Shall we restore the digital harmony? 🌊"
    }
  };
  
  console.log('\n📚 Example Response Variations:\n');
  
  for (const [query, responses] of Object.entries(examples)) {
    console.log(`Query: "${query}"\n`);
    for (const [style, response] of Object.entries(responses)) {
      console.log(`${style}:`);
      console.log(`  ${response}\n`);
    }
    console.log('-'.repeat(60) + '\n');
  }
}

// Run demos if called directly
if (require.main === module) {
  (async () => {
    await demoPersonalityResponses();
    await demoProfileEvolution();
    generateExampleResponses();
  })();
}