/**
 * Integrated Chat Interface
 * Combines onboarding UI, personality system, and NLP engine
 */

import { OnboardingNLPBridge } from './onboarding-nlp-bridge';
import { PersonalityStyle } from '../personality/types';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  personality?: PersonalityStyle;
}

export class IntegratedChatInterface {
  private bridge: OnboardingNLPBridge;
  private messages: ChatMessage[] = [];
  private hasProfile: boolean = false;
  
  constructor() {
    this.bridge = new OnboardingNLPBridge();
  }
  
  /**
   * Initialize chat - check for existing profile or prompt onboarding
   */
  async initialize(): Promise<{ needsOnboarding: boolean }> {
    try {
      // Check for existing profile
      const profileData = this.getStoredProfile();
      
      if (profileData) {
        await this.bridge.initializeWithProfile(profileData);
        this.hasProfile = true;
        
        // Add welcome back message
        this.addMessage({
          role: 'assistant',
          content: this.getWelcomeBackMessage(profileData.primaryStyle),
          personality: this.getCurrentPersonality()
        });
        
        return { needsOnboarding: false };
      }
    } catch (error) {
      console.log('No profile found, onboarding needed');
    }
    
    return { needsOnboarding: true };
  }
  
  /**
   * Complete onboarding and initialize with new profile
   */
  async completeOnboarding(profile: any): Promise<void> {
    // Store profile
    this.storeProfile(profile);
    
    // Initialize NLP with profile
    await this.bridge.initializeWithProfile(profile);
    this.hasProfile = true;
    
    // Add personalized welcome message
    this.addMessage({
      role: 'assistant',
      content: this.getPersonalizedWelcomeMessage(profile.primaryStyle),
      personality: this.getCurrentPersonality()
    });
  }
  
  /**
   * Process user input with personality-aware responses
   */
  async sendMessage(userInput: string): Promise<ChatMessage> {
    if (!this.hasProfile) {
      throw new Error('Chat not initialized - run onboarding first');
    }
    
    // Add user message
    const userMessage = this.addMessage({
      role: 'user',
      content: userInput
    });
    
    try {
      // Process with personality-aware NLP
      const response = await this.bridge.processQuery(userInput);
      
      // Add assistant response
      const assistantMessage = this.addMessage({
        role: 'assistant',
        content: response,
        personality: this.getCurrentPersonality()
      });
      
      return assistantMessage;
    } catch (error) {
      // Fallback response with personality
      const errorResponse = this.getErrorMessage(error as Error);
      return this.addMessage({
        role: 'assistant',
        content: errorResponse,
        personality: this.getCurrentPersonality()
      });
    }
  }
  
  /**
   * Get chat history
   */
  getMessages(): ChatMessage[] {
    return this.messages;
  }
  
  /**
   * Provide feedback on a response
   */
  async provideFeedback(messageId: string, feedback: 'positive' | 'negative'): Promise<void> {
    const message = this.messages.find(m => m.id === messageId);
    if (!message || message.role !== 'assistant') {
      throw new Error('Invalid message for feedback');
    }
    
    // Find the preceding user message
    const messageIndex = this.messages.indexOf(message);
    const userMessage = this.messages[messageIndex - 1];
    
    if (userMessage && userMessage.role === 'user') {
      await this.bridge.updateProfileFromInteraction({
        query: userMessage.content,
        response: message.content,
        feedback
      });
    }
  }
  
  /**
   * Reset chat but keep personality
   */
  clearChat(): void {
    this.messages = [];
    
    if (this.hasProfile) {
      this.addMessage({
        role: 'assistant',
        content: this.getFreshStartMessage(),
        personality: this.getCurrentPersonality()
      });
    }
  }
  
  /**
   * Change personality style on the fly
   */
  async updatePersonalityStyle(newStyle: PersonalityStyle): Promise<void> {
    const profile = this.getStoredProfile();
    if (!profile) return;
    
    // Update profile with new primary style
    profile.primaryStyle = this.getStyleName(newStyle);
    profile.styleWeights = {
      [newStyle]: 0.8,
      [PersonalityStyle.FRIENDLY]: 0.2 // Always keep a bit of friendliness
    };
    
    // Re-initialize
    this.storeProfile(profile);
    await this.bridge.initializeWithProfile(profile);
    
    // Acknowledge the change
    this.addMessage({
      role: 'assistant',
      content: this.getStyleChangeMessage(newStyle),
      personality: newStyle
    });
  }
  
  // Private helper methods
  
  private addMessage(message: Omit<ChatMessage, 'id' | 'timestamp'>): ChatMessage {
    const fullMessage: ChatMessage = {
      ...message,
      id: this.generateId(),
      timestamp: new Date()
    };
    
    this.messages.push(fullMessage);
    return fullMessage;
  }
  
  private generateId(): string {
    return `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
  
  private getStoredProfile(): any {
    if (typeof window !== 'undefined' && window.localStorage) {
      const data = localStorage.getItem('nfh-user-profile');
      return data ? JSON.parse(data) : null;
    }
    return null;
  }
  
  private storeProfile(profile: any): void {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem('nfh-user-profile', JSON.stringify(profile));
    }
  }
  
  private getCurrentPersonality(): PersonalityStyle {
    // This would be retrieved from the bridge
    return PersonalityStyle.FRIENDLY;
  }
  
  private getWelcomeBackMessage(style: string): string {
    const messages = {
      'Minimal & Efficient': 'Ready.',
      'Friendly & Warm': 'Welcome back! How can I help you today?',
      'Encouraging & Supportive': 'Great to see you again! Ready for another productive session?',
      'Playful & Fun': 'Hey, you\'re back! 🎉 What shall we tackle today?',
      'Sacred & Mindful': 'Welcome back to our sacred digital space. How may I serve?'
    };
    return messages[style] || messages['Friendly & Warm'];
  }
  
  private getPersonalizedWelcomeMessage(style: string): string {
    const messages = {
      'Minimal & Efficient': 'Setup complete. Ready for commands.',
      'Friendly & Warm': 'Wonderful! I\'m all set up to communicate in a way that feels natural to you. How can I help?',
      'Encouraging & Supportive': 'Fantastic! You\'ve completed the setup beautifully. I\'m here to support you every step of the way!',
      'Playful & Fun': 'Woohoo! We\'re all calibrated and ready to roll! 🚀 What adventure shall we embark on?',
      'Sacred & Mindful': 'Our connection is established. Together, we\'ll navigate technology with mindfulness and intention.'
    };
    return messages[style] || messages['Friendly & Warm'];
  }
  
  private getFreshStartMessage(): string {
    return 'Fresh start! What would you like to do?';
  }
  
  private getErrorMessage(error: Error): string {
    // Personality-aware error messages
    const style = this.getCurrentPersonality();
    
    const templates = {
      [PersonalityStyle.MINIMAL]: `Error: ${error.message}`,
      [PersonalityStyle.FRIENDLY]: `Oops! I ran into a small issue: ${error.message}. Let me try to help differently!`,
      [PersonalityStyle.ENCOURAGING]: `No worries! We hit a small bump: ${error.message}. Let's try another approach!`,
      [PersonalityStyle.PLAYFUL]: `Whoopsie! 🙈 Hit a snag: ${error.message}. Let's shake it off and try again!`,
      [PersonalityStyle.SACRED]: `A disturbance in the flow: ${error.message}. Let us find another path.`
    };
    
    return templates[style] || templates[PersonalityStyle.FRIENDLY];
  }
  
  private getStyleChangeMessage(newStyle: PersonalityStyle): string {
    const messages = {
      [PersonalityStyle.MINIMAL]: 'Style updated.',
      [PersonalityStyle.FRIENDLY]: 'I\'ve adjusted my communication style! Let me know if this feels better.',
      [PersonalityStyle.ENCOURAGING]: 'Great choice! I\'ve updated my style to be more supportive. You\'re doing wonderfully!',
      [PersonalityStyle.PLAYFUL]: 'Style makeover complete! 🎨 Ready to have some fun?',
      [PersonalityStyle.SACRED]: 'The communication channel has been retuned to a new frequency. We flow in harmony.'
    };
    
    return messages[newStyle];
  }
  
  private getStyleName(style: PersonalityStyle): string {
    const names = {
      [PersonalityStyle.MINIMAL]: 'Minimal & Efficient',
      [PersonalityStyle.FRIENDLY]: 'Friendly & Warm',
      [PersonalityStyle.ENCOURAGING]: 'Encouraging & Supportive',
      [PersonalityStyle.PLAYFUL]: 'Playful & Fun',
      [PersonalityStyle.SACRED]: 'Sacred & Mindful'
    };
    
    return names[style];
  }
}

// Example usage
export async function exampleChatFlow() {
  console.log('💬 Integrated Chat Interface Example\n');
  
  const chat = new IntegratedChatInterface();
  
  // Initialize
  const { needsOnboarding } = await chat.initialize();
  
  if (needsOnboarding) {
    console.log('📋 User needs onboarding...\n');
    
    // Simulate onboarding completion
    const mockProfile = {
      primaryStyle: 'Friendly & Warm',
      styleWeights: { friendly: 0.7, encouraging: 0.3 },
      answers: [], // Would come from UI
      completedAt: new Date().toISOString(),
      hasCompletedOnboarding: true
    };
    
    await chat.completeOnboarding(mockProfile);
  }
  
  // Simulate conversation
  const queries = [
    "Hi! Can you help me install a text editor?",
    "What's the best one for beginners?",
    "Okay, install vscode please",
    "How do I open it?"
  ];
  
  for (const query of queries) {
    console.log(`👤 User: ${query}`);
    const response = await chat.sendMessage(query);
    console.log(`🤖 Nix: ${response.content}\n`);
    
    // Simulate feedback on first response
    if (query.includes('text editor')) {
      await chat.provideFeedback(response.id, 'positive');
      console.log('   (User gave positive feedback)\n');
    }
  }
  
  // Show personality change
  console.log('🎭 User requests personality change...\n');
  await chat.updatePersonalityStyle(PersonalityStyle.MINIMAL);
  
  console.log('👤 User: status');
  const response = await chat.sendMessage('status');
  console.log(`🤖 Nix: ${response.content}\n`);
}