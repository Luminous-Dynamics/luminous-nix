/**
 * Onboarding-NLP Bridge
 * Connects the onboarding UI personality calibration to the NLP engine
 */

import { PersonalityStyle, PersonalityProfile } from '../personality/types';
import { NLPEngine } from '../nlp/intent-engine';
import { PersonalityAdaptationEngine } from '../personality/personality-adaptation-engine';

export interface OnboardingProfile {
  primaryStyle: string;
  styleWeights: Record<string, number>;
  answers: Array<{
    question: string;
    selectedOption: {
      id: string;
      weight: Record<string, number>;
    };
  }>;
  completedAt: string;
  hasCompletedOnboarding: boolean;
}

export class OnboardingNLPBridge {
  private nlpEngine: NLPEngine;
  private personalityEngine: PersonalityAdaptationEngine;
  
  constructor() {
    this.nlpEngine = new NLPEngine();
    this.personalityEngine = new PersonalityAdaptationEngine();
  }
  
  /**
   * Initialize NLP with user's onboarding profile
   */
  async initializeWithProfile(profile: OnboardingProfile): Promise<void> {
    // Convert onboarding profile to personality profile
    const personalityProfile = this.convertToPersonalityProfile(profile);
    
    // Set the personality in the engine
    this.personalityEngine.setUserProfile({
      userId: 'current-user',
      personalityProfile,
      preferences: {
        responseLength: this.inferResponseLength(profile),
        technicalLevel: this.inferTechnicalLevel(profile),
        emojiUse: this.inferEmojiPreference(profile)
      }
    });
    
    // Configure NLP engine with personality
    this.nlpEngine.setPersonalityAdapter(this.personalityEngine);
    
    console.log('NLP initialized with personality:', personalityProfile.primary);
  }
  
  /**
   * Convert onboarding answers to personality profile
   */
  private convertToPersonalityProfile(profile: OnboardingProfile): PersonalityProfile {
    // Calculate style weights from all answers
    const styleWeights: Record<PersonalityStyle, number> = {
      [PersonalityStyle.MINIMAL]: 0,
      [PersonalityStyle.FRIENDLY]: 0,
      [PersonalityStyle.ENCOURAGING]: 0,
      [PersonalityStyle.PLAYFUL]: 0,
      [PersonalityStyle.SACRED]: 0
    };
    
    // Aggregate weights from all answers
    profile.answers.forEach(answer => {
      Object.entries(answer.selectedOption.weight).forEach(([style, weight]) => {
        if (style in styleWeights) {
          styleWeights[style as PersonalityStyle] += weight as number;
        }
      });
    });
    
    // Normalize weights
    const total = Object.values(styleWeights).reduce((sum, w) => sum + w, 0);
    if (total > 0) {
      Object.keys(styleWeights).forEach(style => {
        styleWeights[style as PersonalityStyle] /= total;
      });
    }
    
    // Find primary and secondary styles
    const sortedStyles = Object.entries(styleWeights)
      .sort(([, a], [, b]) => b - a)
      .filter(([, weight]) => weight > 0.1);
    
    const primary = sortedStyles[0]?.[0] as PersonalityStyle || PersonalityStyle.FRIENDLY;
    const secondary = sortedStyles[1]?.[0] as PersonalityStyle | undefined;
    
    return {
      primary,
      secondary,
      blend: secondary ? {
        [primary]: sortedStyles[0][1],
        [secondary]: sortedStyles[1][1]
      } : undefined
    };
  }
  
  /**
   * Infer response length preference from profile
   */
  private inferResponseLength(profile: OnboardingProfile): 'concise' | 'balanced' | 'detailed' {
    const answers = profile.answers;
    
    // Look for efficiency/results focused answers
    const efficiencyScore = answers.filter(a => 
      a.selectedOption.id === 'minimal' || 
      a.selectedOption.id === 'efficiency' ||
      a.selectedOption.id === 'results'
    ).length;
    
    if (efficiencyScore >= 2) return 'concise';
    if (efficiencyScore === 0) return 'detailed';
    return 'balanced';
  }
  
  /**
   * Infer technical level from profile
   */
  private inferTechnicalLevel(profile: OnboardingProfile): 'beginner' | 'intermediate' | 'advanced' {
    const answers = profile.answers;
    
    // Look for exploration/understanding focused answers
    const techScore = answers.filter(a =>
      a.selectedOption.id === 'exploration' ||
      a.selectedOption.id === 'understanding' ||
      a.selectedOption.id === 'examples'
    ).length;
    
    if (techScore >= 2) return 'intermediate';
    
    // Look for guidance needs
    const guidanceScore = answers.filter(a =>
      a.selectedOption.id === 'guidance' ||
      a.selectedOption.id === 'learning'
    ).length;
    
    if (guidanceScore >= 2) return 'beginner';
    
    return 'intermediate';
  }
  
  /**
   * Infer emoji preference from profile
   */
  private inferEmojiPreference(profile: OnboardingProfile): 'none' | 'minimal' | 'expressive' {
    const playfulWeight = profile.styleWeights?.playful || 0;
    const minimalWeight = profile.styleWeights?.minimal || 0;
    
    if (playfulWeight > 0.3) return 'expressive';
    if (minimalWeight > 0.5) return 'none';
    return 'minimal';
  }
  
  /**
   * Process a user query with their personality
   */
  async processQuery(query: string): Promise<string> {
    const intent = await this.nlpEngine.processQuery(query);
    const response = await this.personalityEngine.adaptResponse(intent.response, {
      intent: intent.intent,
      confidence: intent.confidence,
      context: {}
    });
    
    return response;
  }
  
  /**
   * Update profile based on interactions
   */
  async updateProfileFromInteraction(
    interaction: { query: string; response: string; feedback?: 'positive' | 'negative' }
  ): Promise<void> {
    // Learn from user feedback
    if (interaction.feedback) {
      await this.personalityEngine.learnFromFeedback(
        interaction.response,
        interaction.feedback === 'positive' ? 1.0 : -0.5
      );
    }
    
    // Detect patterns for future adaptation
    // This could evolve the personality over time
  }
}

// Example usage:
export async function initializeNLPWithOnboarding(): Promise<OnboardingNLPBridge> {
  // Load profile from localStorage (in real app)
  const profileData = localStorage.getItem('nfh-user-profile');
  if (!profileData) {
    throw new Error('No onboarding profile found');
  }
  
  const profile: OnboardingProfile = JSON.parse(profileData);
  
  // Create bridge and initialize
  const bridge = new OnboardingNLPBridge();
  await bridge.initializeWithProfile(profile);
  
  return bridge;
}