#!/usr/bin/env python3
"""
Consciousness-First Metrics Suite for Nix for Humanity
Measures what truly matters: human flourishing, not just performance
"""

import time
import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field, asdict
from pathlib import Path
import numpy as np
from scipy import stats
import hashlib

@dataclass
class ConsciousnessMetrics:
    """Metrics that measure impact on human consciousness and wellbeing"""
    
    # Flow State Metrics
    flow_depth: float = 0.0  # 0-1, how deep in flow
    flow_duration: int = 0  # seconds in flow state
    flow_stability: float = 0.0  # 0-1, how stable the flow
    interruption_count: int = 0  # number of flow interruptions
    
    # Cognitive Load Metrics
    cognitive_load: float = 0.0  # 0-1, mental burden
    confusion_events: int = 0  # times user was confused
    clarity_moments: int = 0  # times of sudden understanding
    learning_velocity: float = 0.0  # rate of skill acquisition
    
    # Emotional Wellbeing Metrics
    frustration_level: float = 0.0  # 0-1, current frustration
    satisfaction_score: float = 0.0  # 0-1, overall satisfaction
    trust_level: float = 0.0  # 0-1, trust in system
    empowerment_feeling: float = 0.0  # 0-1, sense of capability
    
    # Efficiency Metrics (Traditional but Reframed)
    task_completion_rate: float = 0.0  # percentage
    time_to_understanding: int = 0  # seconds to grasp concept
    error_recovery_time: int = 0  # seconds to recover from error
    autonomy_growth: float = 0.0  # increasing self-sufficiency
    
    # Meta Metrics
    measurement_timestamp: datetime = field(default_factory=datetime.now)
    session_id: str = field(default_factory=lambda: hashlib.md5(str(time.time()).encode()).hexdigest()[:8])
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        data = asdict(self)
        data['measurement_timestamp'] = self.measurement_timestamp.isoformat()
        return data
    
    def wellbeing_score(self) -> float:
        """Composite score of human wellbeing (0-100)"""
        # Weighted combination emphasizing flow and satisfaction
        weights = {
            'flow': 0.25,
            'cognitive': 0.20,
            'emotional': 0.30,
            'efficiency': 0.15,
            'growth': 0.10
        }
        
        flow_score = (self.flow_depth * 0.4 + 
                      min(self.flow_duration / 1800, 1.0) * 0.3 +  # 30 min max
                      self.flow_stability * 0.3)
        
        cognitive_score = (1.0 - self.cognitive_load) * 0.5 + \
                         (self.clarity_moments / max(self.confusion_events + self.clarity_moments, 1)) * 0.5
        
        emotional_score = (1.0 - self.frustration_level) * 0.25 + \
                         self.satisfaction_score * 0.35 + \
                         self.trust_level * 0.20 + \
                         self.empowerment_feeling * 0.20
        
        efficiency_score = self.task_completion_rate * 0.6 + \
                          (1.0 - min(self.error_recovery_time / 300, 1.0)) * 0.4  # 5 min max
        
        growth_score = self.learning_velocity * 0.5 + self.autonomy_growth * 0.5
        
        total = (flow_score * weights['flow'] +
                cognitive_score * weights['cognitive'] +
                emotional_score * weights['emotional'] +
                efficiency_score * weights['efficiency'] +
                growth_score * weights['growth'])
        
        return round(total * 100, 1)


@dataclass
class InteractionMetrics:
    """Metrics for a single interaction"""
    start_time: datetime = field(default_factory=datetime.now)
    end_time: Optional[datetime] = None
    
    # Input characteristics
    input_complexity: float = 0.0  # 0-1, how complex the request
    input_ambiguity: float = 0.0  # 0-1, how ambiguous
    typo_count: int = 0
    
    # Response characteristics
    response_latency: float = 0.0  # seconds
    response_length: int = 0  # characters
    explanation_depth: int = 0  # 0-3 levels
    empathy_expressed: bool = False
    
    # Outcome
    successful: bool = False
    user_satisfied: Optional[bool] = None
    follow_up_needed: bool = False
    learning_moment: bool = False
    
    def duration(self) -> float:
        """Calculate interaction duration in seconds"""
        if self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return 0.0


class ConsciousnessMetricsCollector:
    """Collects and analyzes consciousness-first metrics"""
    
    def __init__(self, db_path: str = "consciousness_metrics.db"):
        self.db_path = db_path
        self.current_session: Optional[ConsciousnessMetrics] = None
        self.interaction_history: List[InteractionMetrics] = []
        self._init_db()
    
    def _init_db(self):
        """Initialize SQLite database for metrics storage"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Consciousness metrics table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS consciousness_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            measurement_timestamp TEXT NOT NULL,
            flow_depth REAL,
            flow_duration INTEGER,
            flow_stability REAL,
            interruption_count INTEGER,
            cognitive_load REAL,
            confusion_events INTEGER,
            clarity_moments INTEGER,
            learning_velocity REAL,
            frustration_level REAL,
            satisfaction_score REAL,
            trust_level REAL,
            empowerment_feeling REAL,
            task_completion_rate REAL,
            time_to_understanding INTEGER,
            error_recovery_time INTEGER,
            autonomy_growth REAL,
            wellbeing_score REAL
        )
        """)
        
        # Interaction metrics table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS interaction_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT,
            duration REAL,
            input_complexity REAL,
            input_ambiguity REAL,
            typo_count INTEGER,
            response_latency REAL,
            response_length INTEGER,
            explanation_depth INTEGER,
            empathy_expressed BOOLEAN,
            successful BOOLEAN,
            user_satisfied BOOLEAN,
            follow_up_needed BOOLEAN,
            learning_moment BOOLEAN
        )
        """)
        
        conn.commit()
        conn.close()
    
    def start_session(self) -> ConsciousnessMetrics:
        """Start a new measurement session"""
        self.current_session = ConsciousnessMetrics()
        self.interaction_history = []
        return self.current_session
    
    def update_flow_state(self, depth: float, stable: bool = True):
        """Update flow state metrics"""
        if not self.current_session:
            return
        
        self.current_session.flow_depth = depth
        if depth > 0.7:  # In flow
            self.current_session.flow_duration += 1  # Called each second
        self.current_session.flow_stability = 0.8 if stable else 0.3
    
    def record_interruption(self):
        """Record a flow interruption"""
        if self.current_session:
            self.current_session.interruption_count += 1
            self.current_session.flow_stability *= 0.7  # Reduce stability
    
    def record_confusion(self):
        """Record a confusion event"""
        if self.current_session:
            self.current_session.confusion_events += 1
            self.current_session.cognitive_load = min(1.0, self.current_session.cognitive_load + 0.1)
    
    def record_clarity(self):
        """Record a clarity/understanding moment"""
        if self.current_session:
            self.current_session.clarity_moments += 1
            self.current_session.cognitive_load = max(0.0, self.current_session.cognitive_load - 0.15)
            self.current_session.learning_velocity = min(1.0, self.current_session.learning_velocity + 0.1)
    
    def record_interaction(self, interaction: InteractionMetrics):
        """Record a completed interaction"""
        self.interaction_history.append(interaction)
        
        if self.current_session and interaction.successful:
            self.current_session.task_completion_rate = self._calculate_completion_rate()
            
            if interaction.learning_moment:
                self.current_session.learning_velocity = min(1.0, self.current_session.learning_velocity + 0.05)
                self.current_session.autonomy_growth = min(1.0, self.current_session.autonomy_growth + 0.02)
    
    def _calculate_completion_rate(self) -> float:
        """Calculate task completion rate from interaction history"""
        if not self.interaction_history:
            return 0.0
        
        successful = sum(1 for i in self.interaction_history if i.successful)
        return successful / len(self.interaction_history)
    
    def save_session(self):
        """Save current session metrics to database"""
        if not self.current_session:
            return
        
        # Calculate final wellbeing score
        wellbeing = self.current_session.wellbeing_score()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Save consciousness metrics
        metrics_data = self.current_session.to_dict()
        metrics_data['wellbeing_score'] = wellbeing
        
        columns = ', '.join(metrics_data.keys())
        placeholders = ', '.join(['?' for _ in metrics_data])
        cursor.execute(
            f"INSERT INTO consciousness_metrics ({columns}) VALUES ({placeholders})",
            list(metrics_data.values())
        )
        
        # Save interaction metrics
        for interaction in self.interaction_history:
            interaction_data = {
                'session_id': self.current_session.session_id,
                'start_time': interaction.start_time.isoformat(),
                'end_time': interaction.end_time.isoformat() if interaction.end_time else None,
                'duration': interaction.duration(),
                'input_complexity': interaction.input_complexity,
                'input_ambiguity': interaction.input_ambiguity,
                'typo_count': interaction.typo_count,
                'response_latency': interaction.response_latency,
                'response_length': interaction.response_length,
                'explanation_depth': interaction.explanation_depth,
                'empathy_expressed': interaction.empathy_expressed,
                'successful': interaction.successful,
                'user_satisfied': interaction.user_satisfied,
                'follow_up_needed': interaction.follow_up_needed,
                'learning_moment': interaction.learning_moment
            }
            
            columns = ', '.join(interaction_data.keys())
            placeholders = ', '.join(['?' for _ in interaction_data])
            cursor.execute(
                f"INSERT INTO interaction_metrics ({columns}) VALUES ({placeholders})",
                list(interaction_data.values())
            )
        
        conn.commit()
        conn.close()
    
    def get_session_summary(self) -> Dict[str, Any]:
        """Get summary of current session"""
        if not self.current_session:
            return {}
        
        return {
            'session_id': self.current_session.session_id,
            'wellbeing_score': self.current_session.wellbeing_score(),
            'flow_percentage': (self.current_session.flow_duration / 
                               max((datetime.now() - self.current_session.measurement_timestamp).total_seconds(), 1)) * 100,
            'interactions': len(self.interaction_history),
            'successful_interactions': sum(1 for i in self.interaction_history if i.successful),
            'learning_moments': sum(1 for i in self.interaction_history if i.learning_moment),
            'average_response_time': np.mean([i.response_latency for i in self.interaction_history]) if self.interaction_history else 0
        }
    
    def get_historical_trends(self, days: int = 7) -> Dict[str, List[float]]:
        """Get historical trends for key metrics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        since = (datetime.now() - timedelta(days=days)).isoformat()
        
        cursor.execute("""
        SELECT 
            measurement_timestamp,
            wellbeing_score,
            flow_depth,
            cognitive_load,
            frustration_level,
            learning_velocity
        FROM consciousness_metrics
        WHERE measurement_timestamp > ?
        ORDER BY measurement_timestamp
        """, (since,))
        
        results = cursor.fetchall()
        conn.close()
        
        if not results:
            return {}
        
        trends = {
            'timestamps': [],
            'wellbeing_scores': [],
            'flow_depths': [],
            'cognitive_loads': [],
            'frustration_levels': [],
            'learning_velocities': []
        }
        
        for row in results:
            trends['timestamps'].append(row[0])
            trends['wellbeing_scores'].append(row[1])
            trends['flow_depths'].append(row[2])
            trends['cognitive_loads'].append(row[3])
            trends['frustration_levels'].append(row[4])
            trends['learning_velocities'].append(row[5])
        
        return trends


# Example usage and tests
if __name__ == "__main__":
    # Initialize collector
    collector = ConsciousnessMetricsCollector("test_consciousness_metrics.db")
    
    # Start a session
    session = collector.start_session()
    print(f"Started session: {session.session_id}")
    
    # Simulate some interactions
    print("\nSimulating user interactions...")
    
    # Interaction 1: Quick success
    interaction1 = InteractionMetrics()
    interaction1.input_complexity = 0.2
    interaction1.response_latency = 0.5
    interaction1.successful = True
    interaction1.end_time = datetime.now()
    collector.record_interaction(interaction1)
    collector.update_flow_state(0.8)
    print("✓ Quick successful interaction")
    
    # Interaction 2: Confusion then clarity
    interaction2 = InteractionMetrics()
    interaction2.input_complexity = 0.7
    interaction2.response_latency = 2.1
    collector.record_confusion()
    print("? User confused...")
    time.sleep(1)
    collector.record_clarity()
    interaction2.successful = True
    interaction2.learning_moment = True
    interaction2.end_time = datetime.now()
    collector.record_interaction(interaction2)
    print("💡 Clarity achieved! Learning moment recorded")
    
    # Update emotional metrics
    session.satisfaction_score = 0.8
    session.trust_level = 0.75
    session.empowerment_feeling = 0.7
    session.frustration_level = 0.2
    
    # Get session summary
    print("\nSession Summary:")
    summary = collector.get_session_summary()
    for key, value in summary.items():
        print(f"  {key}: {value}")
    
    print(f"\nWellbeing Score: {session.wellbeing_score()}/100")
    
    # Save session
    collector.save_session()
    print("\nSession saved to database!")
    
    # Show trends (if any historical data)
    print("\nHistorical trends (last 7 days):")
    trends = collector.get_historical_trends(7)
    if trends:
        print(f"  Found {len(trends['timestamps'])} historical sessions")
        if trends['wellbeing_scores']:
            print(f"  Average wellbeing: {np.mean(trends['wellbeing_scores']):.1f}")
            print(f"  Wellbeing trend: {'↑' if trends['wellbeing_scores'][-1] > trends['wellbeing_scores'][0] else '↓'}")
    else:
        print("  No historical data yet")