/**
 * Personality Style System for Nix for Humanity
 * 
 * Implements 5 adaptive personality styles that learn from user preferences:
 * 1. Minimal Technical - Just the facts
 * 2. Friendly Assistant - Warm and helpful
 * 3. Encouraging Mentor - Supportive growth
 * 4. Playful Companion - Light humor
 * 5. Sacred Technology - Optional mindful language
 */

export enum PersonalityStyle {
  Minimal = 'minimal',
  Friendly = 'friendly',
  Encouraging = 'encouraging',
  Playful = 'playful',
  Sacred = 'sacred'
}

export interface PersonalityTraits {
  style: PersonalityStyle;
  verbosity: number; // 0-1 (minimal to verbose)
  emotiveness: number; // 0-1 (neutral to emotional)
  formality: number; // 0-1 (casual to formal)
  encouragement: number; // 0-1 (neutral to highly encouraging)
  playfulness: number; // 0-1 (serious to playful)
  spirituality: number; // 0-1 (secular to sacred)
}

export const PERSONALITY_PRESETS: Record<PersonalityStyle, PersonalityTraits> = {
  [PersonalityStyle.Minimal]: {
    style: PersonalityStyle.Minimal,
    verbosity: 0.1,
    emotiveness: 0.1,
    formality: 0.7,
    encouragement: 0.1,
    playfulness: 0.0,
    spirituality: 0.0
  },
  [PersonalityStyle.Friendly]: {
    style: PersonalityStyle.Friendly,
    verbosity: 0.5,
    emotiveness: 0.6,
    formality: 0.3,
    encouragement: 0.5,
    playfulness: 0.3,
    spirituality: 0.0
  },
  [PersonalityStyle.Encouraging]: {
    style: PersonalityStyle.Encouraging,
    verbosity: 0.7,
    emotiveness: 0.8,
    formality: 0.4,
    encouragement: 0.9,
    playfulness: 0.4,
    spirituality: 0.1
  },
  [PersonalityStyle.Playful]: {
    style: PersonalityStyle.Playful,
    verbosity: 0.6,
    emotiveness: 0.7,
    formality: 0.1,
    encouragement: 0.6,
    playfulness: 0.9,
    spirituality: 0.0
  },
  [PersonalityStyle.Sacred]: {
    style: PersonalityStyle.Sacred,
    verbosity: 0.6,
    emotiveness: 0.7,
    formality: 0.5,
    encouragement: 0.7,
    playfulness: 0.3,
    spirituality: 0.9
  }
};

export interface ResponseTemplate {
  success: string[];
  error: string[];
  confirmation: string[];
  greeting: string[];
  thinking: string[];
  completion: string[];
}

export const RESPONSE_TEMPLATES: Record<PersonalityStyle, ResponseTemplate> = {
  [PersonalityStyle.Minimal]: {
    success: ['Done.', 'Complete.', 'OK.'],
    error: ['Failed: {error}', 'Error: {error}'],
    confirmation: ['Proceed?', 'Continue?', 'OK?'],
    greeting: ['Ready.', 'Yes?'],
    thinking: ['...', 'Working...'],
    completion: ['Finished.', 'Done.']
  },
  [PersonalityStyle.Friendly]: {
    success: [
      'All done!',
      'That worked perfectly!',
      'Success! Everything went smoothly.',
      'Great, that\'s complete!'
    ],
    error: [
      'Oh no, something went wrong: {error}',
      'I ran into a problem: {error}',
      'Sorry, there was an issue: {error}'
    ],
    confirmation: [
      'Shall I go ahead with that?',
      'Does that sound good to you?',
      'Would you like me to proceed?'
    ],
    greeting: [
      'Hi there! How can I help?',
      'Hello! What can I do for you?',
      'Hey! Ready to help!'
    ],
    thinking: [
      'Let me work on that...',
      'Just a moment...',
      'Working on it...'
    ],
    completion: [
      'All set!',
      'That\'s done!',
      'Finished!'
    ]
  },
  [PersonalityStyle.Encouraging]: {
    success: [
      'Fantastic! You did it!',
      'Excellent work! That\'s complete.',
      'Amazing! Everything worked perfectly.',
      'You\'re doing great! Task completed successfully.'
    ],
    error: [
      'Don\'t worry, we can fix this: {error}',
      'It\'s okay, errors happen. Here\'s what went wrong: {error}',
      'No problem, let\'s work through this together: {error}'
    ],
    confirmation: [
      'Ready when you are! Shall we proceed?',
      'This is going to be great! Continue?',
      'You\'ve got this! Ready to move forward?'
    ],
    greeting: [
      'Welcome back! You\'re doing awesome!',
      'Great to see you! How can I help today?',
      'Hello! Ready for another productive session?'
    ],
    thinking: [
      'Working on this for you...',
      'I\'m on it! Just a moment...',
      'Making progress...'
    ],
    completion: [
      'Wonderful! All done!',
      'You did it! Complete!',
      'Success! Great job!'
    ]
  },
  [PersonalityStyle.Playful]: {
    success: [
      'Boom! Nailed it! 🎉',
      'Woohoo! Success! 🚀',
      'High five! That worked! ✋',
      'Victory dance time! 💃'
    ],
    error: [
      'Oops! Hit a snag: {error} 😅',
      'Uh oh, plot twist: {error} 🙃',
      'Well, that was unexpected: {error} 🤔'
    ],
    confirmation: [
      'Ready to rock? 🎸',
      'Shall we do this thing? 🚀',
      'Want me to work my magic? ✨'
    ],
    greeting: [
      'Hey there, superstar! 🌟',
      'Howdy! What adventure today? 🗺️',
      'Yo! Ready to have some fun? 🎮'
    ],
    thinking: [
      'Cooking something up... 👨‍🍳',
      'Brain gears turning... ⚙️',
      'Magic in progress... ✨'
    ],
    completion: [
      'Ta-da! 🎩',
      'Mission accomplished! 🏆',
      'And... done! 🎯'
    ]
  },
  [PersonalityStyle.Sacred]: {
    success: [
      '✨ Manifestation complete.',
      '🌟 The intention has crystallized into reality.',
      '🕉️ As above, so below. It is done.',
      '💫 The digital prayer has been answered.'
    ],
    error: [
      '🌊 The flow encountered resistance: {error}',
      '⚡ A disturbance in the field: {error}',
      '🍃 The path revealed an obstacle: {error}'
    ],
    confirmation: [
      '🤲 Shall we proceed with sacred intention?',
      '🌙 Are you ready to manifest this change?',
      '⭐ Does this align with your highest purpose?'
    ],
    greeting: [
      '🙏 Blessed be your presence. How may I serve?',
      '🌈 Welcome, sacred being. What shall we co-create?',
      '💝 Namaste. I honor the light within you.'
    ],
    thinking: [
      '🌀 Weaving the digital tapestry...',
      '🕯️ Focusing intention...',
      '🌺 Cultivating the sacred solution...'
    ],
    completion: [
      '🙏 It is complete. We flow.',
      '✨ The sacred work is done.',
      '🌟 Blessed completion.'
    ]
  }
};

export class PersonalityAdapter {
  private currentTraits: PersonalityTraits;
  private learningEnabled: boolean = true;
  
  constructor(initialStyle: PersonalityStyle = PersonalityStyle.Friendly) {
    this.currentTraits = { ...PERSONALITY_PRESETS[initialStyle] };
  }
  
  /**
   * Get a response template based on current personality
   */
  getResponse(type: keyof ResponseTemplate, variables?: Record<string, string>): string {
    const templates = RESPONSE_TEMPLATES[this.currentTraits.style];
    const options = templates[type];
    const template = options[Math.floor(Math.random() * options.length)];
    
    // Replace variables in template
    let response = template;
    if (variables) {
      Object.entries(variables).forEach(([key, value]) => {
        response = response.replace(`{${key}}`, value);
      });
    }
    
    return response;
  }
  
  /**
   * Learn from user interaction patterns
   */
  learnFromInteraction(interaction: {
    userInput: string;
    responseAccepted: boolean;
    emotionalState?: 'frustrated' | 'confident' | 'neutral' | 'happy';
    interactionSpeed?: 'slow' | 'normal' | 'fast';
  }): void {
    if (!this.learningEnabled) return;
    
    // Adjust traits based on interaction
    if (interaction.emotionalState === 'frustrated') {
      // User is frustrated - be more encouraging, less playful
      this.adjustTrait('encouragement', 0.1);
      this.adjustTrait('playfulness', -0.1);
      this.adjustTrait('verbosity', -0.05);
    } else if (interaction.emotionalState === 'confident') {
      // User is confident - can be more minimal
      this.adjustTrait('verbosity', -0.05);
      this.adjustTrait('formality', 0.05);
    }
    
    if (interaction.interactionSpeed === 'fast') {
      // User is moving fast - be more minimal
      this.adjustTrait('verbosity', -0.1);
      this.adjustTrait('emotiveness', -0.05);
    } else if (interaction.interactionSpeed === 'slow') {
      // User is taking time - can be more verbose
      this.adjustTrait('verbosity', 0.05);
      this.adjustTrait('encouragement', 0.05);
    }
    
    // Detect personality preferences from language
    this.detectStyleFromLanguage(interaction.userInput);
  }
  
  /**
   * Detect user's preferred style from their language
   */
  private detectStyleFromLanguage(input: string): void {
    const lowerInput = input.toLowerCase();
    
    // Technical/minimal indicators
    if (lowerInput.match(/^(install|remove|update|list|show|get)\s+\w+$/)) {
      this.adjustTrait('verbosity', -0.02);
      this.adjustTrait('formality', 0.02);
    }
    
    // Friendly indicators
    if (lowerInput.includes('please') || lowerInput.includes('thanks') || 
        lowerInput.includes('could you')) {
      this.adjustTrait('emotiveness', 0.02);
      this.adjustTrait('formality', -0.02);
    }
    
    // Playful indicators
    if (lowerInput.includes('!') || lowerInput.includes('😊') || 
        lowerInput.includes('lol') || lowerInput.includes('haha')) {
      this.adjustTrait('playfulness', 0.03);
      this.adjustTrait('formality', -0.03);
    }
    
    // Sacred/mindful indicators
    if (lowerInput.includes('manifest') || lowerInput.includes('sacred') || 
        lowerInput.includes('blessing') || lowerInput.includes('mindful')) {
      this.adjustTrait('spirituality', 0.05);
    }
    
    // Update style based on traits
    this.updateStyleFromTraits();
  }
  
  /**
   * Adjust a personality trait
   */
  private adjustTrait(trait: keyof Omit<PersonalityTraits, 'style'>, delta: number): void {
    const current = this.currentTraits[trait] as number;
    const newValue = Math.max(0, Math.min(1, current + delta));
    (this.currentTraits[trait] as number) = newValue;
  }
  
  /**
   * Update the style based on current traits
   */
  private updateStyleFromTraits(): void {
    // Calculate distance to each preset
    const distances = Object.entries(PERSONALITY_PRESETS).map(([style, preset]) => {
      const distance = Math.sqrt(
        Math.pow(preset.verbosity - this.currentTraits.verbosity, 2) +
        Math.pow(preset.emotiveness - this.currentTraits.emotiveness, 2) +
        Math.pow(preset.formality - this.currentTraits.formality, 2) +
        Math.pow(preset.encouragement - this.currentTraits.encouragement, 2) +
        Math.pow(preset.playfulness - this.currentTraits.playfulness, 2) +
        Math.pow(preset.spirituality - this.currentTraits.spirituality, 2)
      );
      return { style: style as PersonalityStyle, distance };
    });
    
    // Find closest style
    const closest = distances.reduce((min, curr) => 
      curr.distance < min.distance ? curr : min
    );
    
    this.currentTraits.style = closest.style;
  }
  
  /**
   * Get current personality style
   */
  getCurrentStyle(): PersonalityStyle {
    return this.currentTraits.style;
  }
  
  /**
   * Set personality style manually
   */
  setStyle(style: PersonalityStyle): void {
    this.currentTraits = { ...PERSONALITY_PRESETS[style] };
  }
  
  /**
   * Enable or disable learning
   */
  setLearningEnabled(enabled: boolean): void {
    this.learningEnabled = enabled;
  }
  
  /**
   * Get current traits for persistence
   */
  getTraits(): PersonalityTraits {
    return { ...this.currentTraits };
  }
  
  /**
   * Load traits from persistence
   */
  loadTraits(traits: PersonalityTraits): void {
    this.currentTraits = { ...traits };
  }
}