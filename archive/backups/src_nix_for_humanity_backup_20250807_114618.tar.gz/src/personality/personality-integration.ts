/**
 * Personality Integration Layer for Nix for Humanity
 * 
 * Connects the personality style system with the Tauri command execution
 * and NLP engine to provide adaptive, personalized responses.
 * 
 * Enhanced with Integral Theory (AQAL) tracking for holistic user understanding.
 */

import { PersonalityAdapter, PersonalityStyle, PERSONALITY_PRESETS } from './personality-styles';
import { invoke } from '@tauri-apps/api/tauri';
import { HobbyDetector, HobbyType, DetectedHobby } from '../hobbies/hobby-detector';
import { HobbyResponseGenerator } from '../hobbies/hobby-responses';
import { IntegralMetricsTracker, IntegralProfile, PrivacyLevel } from '../integral/integral-metrics-tracker';

export interface PersonalityConfig {
  enabled: boolean;
  defaultStyle: PersonalityStyle;
  learningEnabled: boolean;
  adaptationSpeed: number; // 0-1 (slow to fast)
  integralTracking?: {
    enabled: boolean;
    privacyLevel?: PrivacyLevel;
  };
}

export interface CommandRequest {
  input: string;
  context?: any;
  dryRun?: boolean;
}

export interface PersonalizedResponse {
  message: string;
  command?: string;
  result?: any;
  personality: {
    style: PersonalityStyle;
    confidence: number;
  };
  hobbies?: DetectedHobby[];
  suggestions?: string[];
  integralInsights?: IntegralInsights;
}

export interface IntegralInsights {
  developmentStage?: string;
  growthEdges?: string[];
  quadrantBalance?: {
    upperLeft: number;
    upperRight: number;
    lowerLeft: number;
    lowerRight: number;
  };
}

export class PersonalizedNixInterface {
  private personalityAdapter: PersonalityAdapter;
  private hobbyDetector: HobbyDetector;
  private hobbyResponseGen: HobbyResponseGenerator;
  private integralTracker?: IntegralMetricsTracker;
  private config: PersonalityConfig;
  private sessionStartTime: number;
  private interactionCount: number = 0;
  
  constructor(config: PersonalityConfig) {
    this.config = config;
    this.personalityAdapter = new PersonalityAdapter(config.defaultStyle);
    this.personalityAdapter.setLearningEnabled(config.learningEnabled);
    this.hobbyDetector = new HobbyDetector();
    this.hobbyResponseGen = new HobbyResponseGenerator();
    this.sessionStartTime = Date.now();
    
    // Initialize integral tracking if enabled
    if (config.integralTracking?.enabled) {
      this.integralTracker = new IntegralMetricsTracker(
        this.getUserId(),
        config.integralTracking.privacyLevel || PrivacyLevel.Standard
      );
      
      // Subscribe to integral patterns
      this.integralTracker.on('pattern-detected', (pattern) => {
        this.handleIntegralPattern(pattern);
      });
    }
    
    // Load saved personality traits if available
    this.loadPersonalityState();
    
    // Load saved hobby data if available
    this.loadHobbyState();
  }
  
  /**
   * Process a user command with personality adaptation
   */
  async processCommand(request: CommandRequest): Promise<PersonalizedResponse> {
    this.interactionCount++;
    
    // Add command to hobby detector
    this.hobbyDetector.addCommand(request.input);
    
    // Detect emotional state from input
    const emotionalState = this.detectEmotionalState(request.input);
    const interactionSpeed = this.calculateInteractionSpeed();
    
    // Track interaction integrally if enabled
    if (this.integralTracker) {
      const interaction = {
        input: request.input,
        timestamp: new Date(),
        context: request.context,
        emotionalState,
        interactionSpeed,
        seekingHelp: this.isSeekingHelp(request.input)
      };
      this.integralTracker.trackInteraction(interaction);
    }
    
    // Detect hobby from current query
    const queryHobby = this.hobbyDetector.detectHobbyFromQuery(request.input);
    const userHobbies = this.hobbyDetector.detectHobbies();
    
    // Learn from this interaction pattern
    if (this.config.learningEnabled) {
      this.personalityAdapter.learnFromInteraction({
        userInput: request.input,
        responseAccepted: true, // Will be updated based on user feedback
        emotionalState,
        interactionSpeed
      });
    }
    
    try {
      // Execute the actual Nix command
      const result = await this.executeNixCommand(request);
      
      // Generate personalized response based on result
      const response = this.generatePersonalizedResponse(result, request, queryHobby, userHobbies);
      
      // Add integral insights if available
      if (this.integralTracker) {
        response.integralInsights = await this.generateIntegralInsights();
      }
      
      // Save personality state periodically
      if (this.interactionCount % 10 === 0) {
        this.savePersonalityState();
        this.saveHobbyState();
      }
      
      return response;
      
    } catch (error) {
      // Handle errors with personality-appropriate responses
      return this.generateErrorResponse(error, request, queryHobby, userHobbies);
    }
  }
  
  /**
   * Execute the Nix command through Tauri
   */
  private async executeNixCommand(request: CommandRequest): Promise<any> {
    // Parse the natural language input into a command
    const parsedCommand = await this.parseNaturalLanguage(request.input);
    
    if (request.dryRun) {
      parsedCommand.args.push('--dry-run');
    }
    
    // Call Tauri backend
    const result = await invoke('execute_nix_command', {
      command: parsedCommand
    });
    
    return result;
  }
  
  /**
   * Parse natural language into Nix commands
   */
  private async parseNaturalLanguage(input: string): Promise<any> {
    // This would integrate with the full NLP engine
    // For now, basic pattern matching
    const patterns = {
      install: /(?:install|add|get)\s+(.+)/i,
      remove: /(?:remove|uninstall|delete)\s+(.+)/i,
      update: /(?:update|upgrade)(?:\s+(.+))?/i,
      search: /(?:search|find|look for)\s+(.+)/i,
    };
    
    for (const [action, pattern] of Object.entries(patterns)) {
      const match = input.match(pattern);
      if (match) {
        return {
          command: 'nix',
          args: this.buildNixArgs(action, match[1]),
          action,
          package: match[1]
        };
      }
    }
    
    throw new Error('Could not understand command');
  }
  
  /**
   * Build Nix command arguments
   */
  private buildNixArgs(action: string, target?: string): string[] {
    switch (action) {
      case 'install':
        return ['profile', 'install', `nixpkgs#${target}`];
      case 'remove':
        return ['profile', 'remove', target || ''];
      case 'update':
        return target ? ['profile', 'upgrade', target] : ['profile', 'upgrade'];
      case 'search':
        return ['search', 'nixpkgs', target || ''];
      default:
        return [];
    }
  }
  
  /**
   * Generate a personalized response based on command result
   */
  private generatePersonalizedResponse(
    result: any, 
    request: CommandRequest,
    queryHobby: DetectedHobby | null,
    userHobbies: DetectedHobby[]
  ): PersonalizedResponse {
    const currentStyle = this.personalityAdapter.getCurrentStyle();
    
    // Get appropriate response template
    const message = result.success
      ? this.personalityAdapter.getResponse('success')
      : this.personalityAdapter.getResponse('error', { error: result.error });
    
    // Add contextual information based on personality
    let enhancedMessage = this.enhanceMessage(message, result, currentStyle);
    
    // Add hobby-specific enhancements
    if (queryHobby) {
      const hobbyMessage = this.hobbyResponseGen.generateContextualHelp(queryHobby.type, request.input);
      if (hobbyMessage) {
        enhancedMessage += `\n\n${hobbyMessage}`;
      }
      
      // Add hobby-specific encouragement
      if (result.success) {
        enhancedMessage += ` ${this.hobbyResponseGen.generateEncouragement(queryHobby.type)}`;
      }
    }
    
    // Generate suggestions based on context and hobbies
    const suggestions = this.generateSuggestions(result, request, currentStyle);
    
    // Add hobby-specific suggestions
    if (queryHobby && queryHobby.suggestedPackages) {
      const relevantPackages = queryHobby.suggestedPackages
        .filter(pkg => !result.package || !pkg.includes(result.package))
        .slice(0, 3);
      
      if (relevantPackages.length > 0) {
        suggestions.push(`Based on your ${this.getHobbyName(queryHobby.type)} interest, you might like: ${relevantPackages.join(', ')}`);
      }
    }
    
    // Add community info if first time detecting hobby
    if (queryHobby && this.isFirstTimeHobbyDetection(queryHobby.type)) {
      suggestions.push(this.hobbyResponseGen.generateCommunityInfo(queryHobby.type));
    }
    
    return {
      message: enhancedMessage,
      command: result.command,
      result: result.output,
      personality: {
        style: currentStyle,
        confidence: this.calculateConfidence()
      },
      hobbies: userHobbies.length > 0 ? userHobbies : undefined,
      suggestions
    };
  }
  
  /**
   * Enhance message based on personality style
   */
  private enhanceMessage(
    baseMessage: string, 
    result: any, 
    style: PersonalityStyle
  ): string {
    const traits = PERSONALITY_PRESETS[style];
    
    // Add verbosity based on trait
    if (traits.verbosity > 0.7 && result.output) {
      baseMessage += `\n\nHere's what happened:\n${result.output}`;
    }
    
    // Add encouragement if appropriate
    if (traits.encouragement > 0.5 && result.success) {
      const encouragements = [
        "You're getting the hang of this!",
        "Great job!",
        "You're making excellent progress!",
        "Well done!"
      ];
      const encouragement = encouragements[Math.floor(Math.random() * encouragements.length)];
      baseMessage = `${baseMessage} ${encouragement}`;
    }
    
    // Add playfulness if appropriate
    if (traits.playfulness > 0.7) {
      baseMessage = this.addPlayfulTouch(baseMessage);
    }
    
    // Add sacred elements if appropriate
    if (traits.spirituality > 0.5) {
      baseMessage = this.addSacredTouch(baseMessage);
    }
    
    return baseMessage;
  }
  
  /**
   * Generate contextual suggestions
   */
  private generateSuggestions(
    result: any, 
    request: CommandRequest,
    style: PersonalityStyle
  ): string[] {
    const suggestions: string[] = [];
    const traits = PERSONALITY_PRESETS[style];
    
    // Suggest next steps based on context
    if (result.action === 'install' && result.success) {
      if (traits.verbosity > 0.5) {
        suggestions.push(`You can now run ${result.package} from the terminal`);
      }
      if (traits.encouragement > 0.5) {
        suggestions.push("Want to install something else? Just ask!");
      }
    }
    
    // Suggest help if error occurred
    if (!result.success) {
      if (traits.encouragement > 0.3) {
        suggestions.push("Would you like me to help troubleshoot?");
      }
      suggestions.push("Try 'search' to find the correct package name");
    }
    
    return suggestions;
  }
  
  /**
   * Generate error response with appropriate personality
   */
  private generateErrorResponse(
    error: any, 
    request: CommandRequest,
    queryHobby: DetectedHobby | null,
    userHobbies: DetectedHobby[]
  ): PersonalizedResponse {
    const errorMessage = this.personalityAdapter.getResponse('error', {
      error: error.message || 'Unknown error'
    });
    
    // Add hobby-specific troubleshooting if relevant
    const suggestions = [
      "Let me know if you need help",
      "We can try a different approach"
    ];
    
    if (queryHobby) {
      const hobbyTips = this.hobbyDetector.getHobbyTips(queryHobby.type);
      if (hobbyTips.length > 0) {
        suggestions.push(hobbyTips[0]); // Add most relevant tip
      }
    }
    
    return {
      message: errorMessage,
      personality: {
        style: this.personalityAdapter.getCurrentStyle(),
        confidence: this.calculateConfidence()
      },
      hobbies: userHobbies.length > 0 ? userHobbies : undefined,
      suggestions
    };
  }
  
  /**
   * Detect emotional state from user input
   */
  private detectEmotionalState(input: string): 'frustrated' | 'confident' | 'neutral' | 'happy' | undefined {
    const lowercaseInput = input.toLowerCase();
    
    // Frustration indicators
    if (lowercaseInput.includes('!') || 
        lowercaseInput.includes('not working') ||
        lowercaseInput.includes('broken') ||
        lowercaseInput.includes('help')) {
      return 'frustrated';
    }
    
    // Confidence indicators
    if (lowercaseInput.match(/^[a-z]+ [a-z]+$/)) { // Simple command structure
      return 'confident';
    }
    
    // Happy indicators
    if (lowercaseInput.includes('thanks') ||
        lowercaseInput.includes('great') ||
        lowercaseInput.includes('😊')) {
      return 'happy';
    }
    
    return 'neutral';
  }
  
  /**
   * Calculate interaction speed based on timing
   */
  private calculateInteractionSpeed(): 'slow' | 'normal' | 'fast' {
    const sessionDuration = Date.now() - this.sessionStartTime;
    const avgTimeBetweenInteractions = sessionDuration / this.interactionCount;
    
    if (avgTimeBetweenInteractions < 5000) return 'fast';
    if (avgTimeBetweenInteractions > 30000) return 'slow';
    return 'normal';
  }
  
  /**
   * Calculate confidence in current personality adaptation
   */
  private calculateConfidence(): number {
    // Based on number of interactions and consistency
    const baseConfidence = Math.min(this.interactionCount / 50, 0.5);
    const adaptationBonus = this.config.learningEnabled ? 0.3 : 0;
    const timeBonus = Math.min((Date.now() - this.sessionStartTime) / (30 * 60 * 1000), 0.2);
    
    return baseConfidence + adaptationBonus + timeBonus;
  }
  
  /**
   * Add playful elements to message
   */
  private addPlayfulTouch(message: string): string {
    const playfulEndings = [
      " 🎉", " 🚀", " ✨", " 🎮", " 🌟"
    ];
    return message + playfulEndings[Math.floor(Math.random() * playfulEndings.length)];
  }
  
  /**
   * Add sacred elements to message
   */
  private addSacredTouch(message: string): string {
    const sacredPhrases = [
      "✨ ", "🌟 ", "💫 ", "🕉️ "
    ];
    return sacredPhrases[Math.floor(Math.random() * sacredPhrases.length)] + message;
  }
  
  /**
   * Save personality state to localStorage
   */
  private savePersonalityState(): void {
    if (typeof window !== 'undefined' && window.localStorage) {
      const state = {
        traits: this.personalityAdapter.getTraits(),
        interactionCount: this.interactionCount,
        lastSaved: Date.now()
      };
      localStorage.setItem('nix-humanity-personality', JSON.stringify(state));
    }
  }
  
  /**
   * Load personality state from localStorage
   */
  private loadPersonalityState(): void {
    if (typeof window !== 'undefined' && window.localStorage) {
      const saved = localStorage.getItem('nix-humanity-personality');
      if (saved) {
        try {
          const state = JSON.parse(saved);
          this.personalityAdapter.loadTraits(state.traits);
          this.interactionCount = state.interactionCount || 0;
        } catch (e) {
          console.error('Failed to load personality state:', e);
        }
      }
    }
  }
  
  /**
   * Get current personality information
   */
  getPersonalityInfo(): {
    currentStyle: PersonalityStyle;
    traits: any;
    confidence: number;
    interactionCount: number;
  } {
    return {
      currentStyle: this.personalityAdapter.getCurrentStyle(),
      traits: this.personalityAdapter.getTraits(),
      confidence: this.calculateConfidence(),
      interactionCount: this.interactionCount
    };
  }
  
  /**
   * Manually set personality style
   */
  setPersonalityStyle(style: PersonalityStyle): void {
    this.personalityAdapter.setStyle(style);
    this.savePersonalityState();
  }
  
  /**
   * Toggle learning on/off
   */
  setLearningEnabled(enabled: boolean): void {
    this.config.learningEnabled = enabled;
    this.personalityAdapter.setLearningEnabled(enabled);
  }
  
  /**
   * Process user feedback on response
   */
  processFeedback(responseAccepted: boolean): void {
    // This would be called when user indicates satisfaction/dissatisfaction
    // Used to refine personality adaptation
    if (this.config.learningEnabled) {
      // Future: Implement feedback learning
    }
  }
  
  /**
   * Get human-readable hobby name
   */
  private getHobbyName(hobby: HobbyType): string {
    const names: Record<HobbyType, string> = {
      [HobbyType.Gaming]: 'gaming',
      [HobbyType.MusicProduction]: 'music production',
      [HobbyType.DigitalArt]: 'digital art',
      [HobbyType.Writing]: 'writing',
      [HobbyType.Photography]: 'photography',
      [HobbyType.Programming]: 'programming',
      [HobbyType.VideoEditing]: 'video editing',
      [HobbyType.Unknown]: 'interests'
    };
    return names[hobby] || hobby;
  }
  
  /**
   * Check if this is the first time detecting a hobby
   */
  private isFirstTimeHobbyDetection(hobbyType: HobbyType): boolean {
    const state = this.loadHobbyStateData();
    return !state.detectedHobbies || !state.detectedHobbies.includes(hobbyType);
  }
  
  /**
   * Save hobby state to localStorage
   */
  private saveHobbyState(): void {
    if (typeof window !== 'undefined' && window.localStorage) {
      const detectedHobbies = this.hobbyDetector.detectHobbies();
      const state = {
        detectedHobbies: detectedHobbies.map(h => h.type),
        commandHistory: this.getRecentCommands(),
        lastSaved: Date.now()
      };
      localStorage.setItem('nix-humanity-hobbies', JSON.stringify(state));
    }
  }
  
  /**
   * Load hobby state from localStorage
   */
  private loadHobbyState(): void {
    if (typeof window !== 'undefined' && window.localStorage) {
      const saved = localStorage.getItem('nix-humanity-hobbies');
      if (saved) {
        try {
          const state = JSON.parse(saved);
          // Restore command history
          if (state.commandHistory && Array.isArray(state.commandHistory)) {
            state.commandHistory.forEach((cmd: string) => {
              this.hobbyDetector.addCommand(cmd);
            });
          }
        } catch (e) {
          console.error('Failed to load hobby state:', e);
        }
      }
    }
  }
  
  /**
   * Load hobby state data
   */
  private loadHobbyStateData(): any {
    if (typeof window !== 'undefined' && window.localStorage) {
      const saved = localStorage.getItem('nix-humanity-hobbies');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch (e) {
          console.error('Failed to load hobby state data:', e);
        }
      }
    }
    return {};
  }
  
  /**
   * Get recent commands for saving
   */
  private getRecentCommands(): string[] {
    // This is a placeholder - in real implementation,
    // we'd access the hobby detector's command history
    return [];
  }
  
  /**
   * Update installed packages for hobby detection
   */
  updateInstalledPackages(packages: string[]): void {
    this.hobbyDetector.updateInstalledPackages(packages);
  }
  
  /**
   * Get detected hobbies
   */
  getDetectedHobbies(): DetectedHobby[] {
    return this.hobbyDetector.detectHobbies();
  }
  
  /**
   * Get or generate a user ID for integral tracking
   */
  private getUserId(): string {
    if (typeof window !== 'undefined' && window.localStorage) {
      let userId = localStorage.getItem('nix-humanity-user-id');
      if (!userId) {
        userId = this.generateAnonymousId();
        localStorage.setItem('nix-humanity-user-id', userId);
      }
      return userId;
    }
    return 'anonymous';
  }
  
  /**
   * Generate anonymous user ID
   */
  private generateAnonymousId(): string {
    return 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }
  
  /**
   * Check if user is seeking help
   */
  private isSeekingHelp(input: string): boolean {
    const helpIndicators = ['help', 'how', 'what', 'why', 'explain', 'show me', 'teach'];
    const lowercaseInput = input.toLowerCase();
    return helpIndicators.some(indicator => lowercaseInput.includes(indicator));
  }
  
  /**
   * Handle patterns detected by integral tracker
   */
  private handleIntegralPattern(pattern: any): void {
    switch (pattern.type) {
      case 'efficiency-need':
        // Adapt to minimal style for efficient users
        if (pattern.confidence > 0.7) {
          this.personalityAdapter.setStyle(PersonalityStyle.Minimal);
        }
        break;
        
      case 'mentor-potential':
        // Recognize user as potential helper
        this.personalityAdapter.addTrait('community-minded', 0.8);
        break;
        
      case 'creative-user':
        // Enhance creative suggestions
        this.personalityAdapter.addTrait('creative', 0.9);
        break;
    }
  }
  
  /**
   * Generate integral insights for response
   */
  private async generateIntegralInsights(): Promise<IntegralInsights> {
    if (!this.integralTracker) {
      return {};
    }
    
    const profile = await this.integralTracker.getProfile();
    
    return {
      developmentStage: profile.development.stage,
      growthEdges: this.identifyGrowthEdges(profile),
      quadrantBalance: this.calculateQuadrantBalance(profile)
    };
  }
  
  /**
   * Identify growth edges from integral profile
   */
  private identifyGrowthEdges(profile: IntegralProfile): string[] {
    const edges: string[] = [];
    
    // Check technical growth potential
    if (profile.quadrants.upperRight.technical.skillLevel < 5) {
      edges.push('Technical skill development');
    }
    
    // Check community engagement
    if (profile.quadrants.lowerLeft.community.participationLevel === 'none') {
      edges.push('Community connection');
    }
    
    // Check consciousness development
    if (profile.quadrants.upperLeft.consciousness.awareness < 0.6) {
      edges.push('Mindful computing practices');
    }
    
    return edges;
  }
  
  /**
   * Calculate balance across quadrants
   */
  private calculateQuadrantBalance(profile: IntegralProfile): any {
    return {
      upperLeft: this.scoreQuadrant(profile.quadrants.upperLeft),
      upperRight: this.scoreQuadrant(profile.quadrants.upperRight),
      lowerLeft: this.scoreQuadrant(profile.quadrants.lowerLeft),
      lowerRight: this.scoreQuadrant(profile.quadrants.lowerRight)
    };
  }
  
  /**
   * Score a quadrant's development (0-1)
   */
  private scoreQuadrant(quadrant: any): number {
    // Simple scoring - would be more sophisticated in production
    let score = 0;
    let count = 0;
    
    const traverse = (obj: any) => {
      for (const key in obj) {
        if (typeof obj[key] === 'number') {
          score += Math.min(1, Math.max(0, obj[key]));
          count++;
        } else if (typeof obj[key] === 'object' && obj[key] !== null) {
          traverse(obj[key]);
        }
      }
    };
    
    traverse(quadrant);
    return count > 0 ? score / count : 0;
  }
}

// Export a factory function for easy initialization
export function createPersonalizedInterface(config?: Partial<PersonalityConfig>): PersonalizedNixInterface {
  const defaultConfig: PersonalityConfig = {
    enabled: true,
    defaultStyle: PersonalityStyle.Friendly,
    learningEnabled: true,
    adaptationSpeed: 0.5
  };
  
  return new PersonalizedNixInterface({
    ...defaultConfig,
    ...config
  });
}