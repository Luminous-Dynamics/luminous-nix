// Mock PersonalityEngine for demo
export interface PersonalityStyle {
  emotional: number;
  analytical: number;
  practical: number;
  creative: number;
}

export interface PersonalityProfile {
  dominantStyle: string;
  scores: PersonalityStyle;
  preferences: {
    detailLevel: 'minimal' | 'moderate' | 'detailed';
    learningPace: 'slow' | 'moderate' | 'fast';
    interactionStyle: 'guided' | 'exploratory' | 'independent';
  };
}

export class PersonalityEngine {
  private profile: PersonalityProfile = {
    dominantStyle: 'balanced',
    scores: {
      emotional: 0.5,
      analytical: 0.5,
      practical: 0.5,
      creative: 0.5
    },
    preferences: {
      detailLevel: 'moderate',
      learningPace: 'moderate',
      interactionStyle: 'guided'
    }
  };

  async initialize() {
    console.log('Personality Engine initialized');
  }

  analyzeInput(text: string): PersonalityStyle {
    // Mock analysis - in real version would use NLP
    const words = text.toLowerCase().split(/\s+/);
    
    return {
      emotional: words.some(w => ['feel', 'love', 'happy', 'worried'].includes(w)) ? 0.7 : 0.3,
      analytical: words.some(w => ['why', 'how', 'explain', 'understand'].includes(w)) ? 0.7 : 0.3,
      practical: words.some(w => ['do', 'install', 'setup', 'configure'].includes(w)) ? 0.7 : 0.3,
      creative: words.some(w => ['imagine', 'create', 'design', 'customize'].includes(w)) ? 0.7 : 0.3
    };
  }

  getProfile(): PersonalityProfile {
    return this.profile;
  }

  updateProfile(newScores: Partial<PersonalityStyle>) {
    this.profile.scores = { ...this.profile.scores, ...newScores };
    
    // Determine dominant style
    const styles = Object.entries(this.profile.scores);
    const dominant = styles.reduce((a, b) => a[1] > b[1] ? a : b);
    this.profile.dominantStyle = dominant[0];
  }

  getUIComplexity(): 'simple' | 'moderate' | 'advanced' {
    const analytical = this.profile.scores.analytical;
    if (analytical > 0.7) return 'advanced';
    if (analytical > 0.4) return 'moderate';
    return 'simple';
  }

  getSuggestedPace(): 'slow' | 'moderate' | 'fast' {
    return this.profile.preferences.learningPace;
  }
}