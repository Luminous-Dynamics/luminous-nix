/**
 * Integral Metrics Tracker
 * 
 * Tracks user development across all four quadrants of Ken Wilber's AQAL framework
 * Privacy-first implementation with local storage only
 */

import { EventEmitter } from 'events';

export enum PrivacyLevel {
  Minimal = 'minimal',
  Standard = 'standard',
  Enhanced = 'enhanced',
  Research = 'research'
}

export enum DevelopmentStage {
  Archaic = 'archaic',
  Magic = 'magic',
  Mythic = 'mythic',
  Rational = 'rational',
  Pluralistic = 'pluralistic',
  Integral = 'integral',
  SuperIntegral = 'super-integral'
}

export interface IntegralProfile {
  id: string;
  quadrants: {
    upperLeft: any;    // Interior-Individual (I)
    upperRight: any;   // Exterior-Individual (IT) 
    lowerLeft: any;    // Interior-Collective (WE)
    lowerRight: any;   // Exterior-Collective (ITS)
  };
  development: {
    stage: DevelopmentStage;
    trajectory: any[];
    milestones: any[];
  };
  metadata: {
    createdAt: Date;
    lastUpdated: Date;
    profileVersion: string;
    privacyLevel: PrivacyLevel;
  };
}

export interface UserInteraction {
  input: string;
  timestamp: Date;
  context?: any;
  emotionalState?: string;
  interactionSpeed?: string;
  seekingHelp?: boolean;
  command?: string;
  hadError?: boolean;
  recoveryMethod?: string;
}

export class IntegralMetricsTracker extends EventEmitter {
  private profile: IntegralProfile;
  private privacyLevel: PrivacyLevel;
  private trackingEnabled: boolean = true;
  
  constructor(userId: string, privacyLevel: PrivacyLevel = PrivacyLevel.Standard) {
    super();
    this.privacyLevel = privacyLevel;
    this.profile = this.loadOrCreateProfile(userId);
  }
  
  /**
   * Track a user interaction across all quadrants
   */
  trackInteraction(interaction: UserInteraction): void {
    if (!this.trackingEnabled || this.privacyLevel === PrivacyLevel.Minimal) {
      return;
    }
    
    // Update quadrants based on interaction
    this.updateUpperLeft(interaction);
    this.updateUpperRight(interaction);
    this.updateLowerLeft(interaction);
    this.updateLowerRight(interaction);
    
    // Check for patterns
    this.detectPatterns(interaction);
    
    // Update last modified
    this.profile.metadata.lastUpdated = new Date();
    
    // Save periodically
    this.saveProfile();
  }
  
  /**
   * Get the current profile
   */
  async getProfile(): Promise<IntegralProfile> {
    return this.profile;
  }
  
  /**
   * Update Upper Left quadrant (consciousness/subjective)
   */
  private updateUpperLeft(interaction: UserInteraction): void {
    const ul = this.profile.quadrants.upperLeft;
    
    // Update awareness based on help-seeking
    if (interaction.seekingHelp) {
      ul.awareness = Math.min(1, (ul.awareness || 0.3) + 0.01);
    }
    
    // Track emotional states
    if (interaction.emotionalState) {
      ul.emotionalStates = ul.emotionalStates || [];
      ul.emotionalStates.push({
        state: interaction.emotionalState,
        timestamp: interaction.timestamp
      });
    }
  }
  
  /**
   * Update Upper Right quadrant (behavior/objective)
   */
  private updateUpperRight(interaction: UserInteraction): void {
    const ur = this.profile.quadrants.upperRight;
    
    // Track command usage
    ur.commandCount = (ur.commandCount || 0) + 1;
    
    // Track error patterns
    if (interaction.hadError) {
      ur.errorCount = (ur.errorCount || 0) + 1;
      ur.errorRecoveryMethods = ur.errorRecoveryMethods || [];
      if (interaction.recoveryMethod) {
        ur.errorRecoveryMethods.push(interaction.recoveryMethod);
      }
    }
    
    // Update skill estimation
    if (interaction.command) {
      const complexCommands = ['pipe', 'script', 'config', 'build'];
      if (complexCommands.some(cmd => interaction.command!.includes(cmd))) {
        ur.skillLevel = Math.min(10, (ur.skillLevel || 3) + 0.1);
      }
    }
  }
  
  /**
   * Update Lower Left quadrant (culture/intersubjective)
   */
  private updateLowerLeft(interaction: UserInteraction): void {
    const ll = this.profile.quadrants.lowerLeft;
    
    // Detect communication style
    const formalWords = ['please', 'thank you', 'could you', 'would you'];
    const informalWords = ['hey', 'yeah', 'gonna', 'wanna'];
    
    const input = interaction.input.toLowerCase();
    const hasFormal = formalWords.some(word => input.includes(word));
    const hasInformal = informalWords.some(word => input.includes(word));
    
    if (hasFormal) {
      ll.formalityLevel = Math.min(1, (ll.formalityLevel || 0.5) + 0.02);
    } else if (hasInformal) {
      ll.formalityLevel = Math.max(0, (ll.formalityLevel || 0.5) - 0.02);
    }
  }
  
  /**
   * Update Lower Right quadrant (systems/interobjective)
   */
  private updateLowerRight(interaction: UserInteraction): void {
    const lr = this.profile.quadrants.lowerRight;
    
    // Track package ecosystem
    if (interaction.command === 'install') {
      lr.installedPackageCount = (lr.installedPackageCount || 0) + 1;
    }
    
    // Track automation level
    if (interaction.input.includes('script') || interaction.input.includes('automate')) {
      lr.automationInterest = Math.min(1, (lr.automationInterest || 0) + 0.1);
    }
  }
  
  /**
   * Detect cross-quadrant patterns
   */
  private detectPatterns(interaction: UserInteraction): void {
    const { upperLeft: ul, upperRight: ur, lowerLeft: ll, lowerRight: lr } = this.profile.quadrants;
    
    // Pattern: High skill + low patience = efficiency need
    if (ur.skillLevel > 7 && ul.emotionalStates?.filter((e: any) => e.state === 'frustrated').length > 3) {
      this.emit('pattern-detected', {
        type: 'efficiency-need',
        confidence: 0.8,
        recommendation: 'Switch to minimal response mode'
      });
    }
    
    // Pattern: Growing skill + help-seeking = learning mindset
    if (ur.skillLevel > 4 && ur.skillLevel < 7 && interaction.seekingHelp) {
      this.emit('pattern-detected', {
        type: 'active-learner',
        confidence: 0.7,
        recommendation: 'Provide detailed explanations'
      });
    }
  }
  
  /**
   * Load or create profile
   */
  private loadOrCreateProfile(userId: string): IntegralProfile {
    // Try to load from localStorage
    if (typeof window !== 'undefined' && window.localStorage) {
      const saved = localStorage.getItem(`integral-profile-${userId}`);
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch (e) {
          console.error('Failed to load integral profile:', e);
        }
      }
    }
    
    // Create new profile
    return {
      id: userId,
      quadrants: {
        upperLeft: {
          awareness: 0.3,
          emotionalStates: [],
          developmentStage: DevelopmentStage.Rational
        },
        upperRight: {
          skillLevel: 3,
          commandCount: 0,
          errorCount: 0
        },
        lowerLeft: {
          formalityLevel: 0.5,
          communityParticipation: 'none'
        },
        lowerRight: {
          installedPackageCount: 0,
          automationLevel: 0
        }
      },
      development: {
        stage: DevelopmentStage.Rational,
        trajectory: [],
        milestones: []
      },
      metadata: {
        createdAt: new Date(),
        lastUpdated: new Date(),
        profileVersion: '1.0.0',
        privacyLevel: this.privacyLevel
      }
    };
  }
  
  /**
   * Save profile to localStorage
   */
  private saveProfile(): void {
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        const serialized = JSON.stringify(this.profile);
        localStorage.setItem(`integral-profile-${this.profile.id}`, serialized);
      } catch (e) {
        console.error('Failed to save integral profile:', e);
      }
    }
  }
  
  /**
   * Enable or disable tracking
   */
  setTrackingEnabled(enabled: boolean): void {
    this.trackingEnabled = enabled;
  }
  
  /**
   * Get privacy-safe export of data
   */
  exportAnonymized(): any {
    // Return anonymized version based on privacy level
    if (this.privacyLevel === PrivacyLevel.Minimal) {
      return {
        developmentStage: this.profile.development.stage,
        profileVersion: this.profile.metadata.profileVersion
      };
    }
    
    // Standard privacy level - aggregate metrics only
    return {
      quadrants: {
        upperLeft: {
          awarenessLevel: Math.round(this.profile.quadrants.upperLeft.awareness * 10) / 10,
          developmentStage: this.profile.development.stage
        },
        upperRight: {
          skillLevel: Math.round(this.profile.quadrants.upperRight.skillLevel),
          totalCommands: this.profile.quadrants.upperRight.commandCount
        },
        lowerLeft: {
          communicationStyle: this.profile.quadrants.lowerLeft.formalityLevel > 0.6 ? 'formal' : 'casual'
        },
        lowerRight: {
          ecosystemSize: this.profile.quadrants.lowerRight.installedPackageCount
        }
      },
      metadata: {
        daysActive: Math.floor((Date.now() - new Date(this.profile.metadata.createdAt).getTime()) / (1000 * 60 * 60 * 24)),
        privacyLevel: this.privacyLevel
      }
    };
  }
  
  /**
   * Delete all user data
   */
  async deleteAllData(): Promise<void> {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.removeItem(`integral-profile-${this.profile.id}`);
    }
    
    // Reset profile
    this.profile = this.loadOrCreateProfile(this.profile.id);
    
    this.emit('data-deleted', {
      userId: this.profile.id,
      timestamp: new Date()
    });
  }
}