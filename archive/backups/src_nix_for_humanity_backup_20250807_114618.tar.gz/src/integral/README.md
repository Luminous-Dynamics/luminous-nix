# 🌀 Integral Metrics Module

This module implements Ken Wilber's AQAL (All Quadrants, All Levels) framework for holistic user understanding in Nix for Humanity.

## Overview

The integral metrics system tracks user development across four fundamental quadrants:

1. **Upper Left (UL)** - Interior Individual: Consciousness, values, emotions
2. **Upper Right (UR)** - Exterior Individual: Observable behaviors and skills
3. **Lower Left (LL)** - Interior Collective: Cultural context and shared values
4. **Lower Right (LR)** - Exterior Collective: Systems and infrastructure

## Privacy-First Design

All tracking is:
- **Local only** - No data leaves the user's device
- **Anonymized** - No personally identifiable information
- **Transparent** - Users can view and delete all data
- **Consent-based** - Users choose their privacy level

## Usage

```typescript
import { IntegralMetricsTracker, PrivacyLevel } from './integral-metrics-tracker';

// Initialize tracker
const tracker = new IntegralMetricsTracker('anonymous-user-id', PrivacyLevel.Standard);

// Track interactions
tracker.trackInteraction({
  input: "install firefox",
  timestamp: new Date(),
  emotionalState: 'curious',
  seekingHelp: true
});

// Listen for patterns
tracker.on('pattern-detected', (pattern) => {
  console.log(`Detected pattern: ${pattern.type}`);
  console.log(`Recommendation: ${pattern.recommendation}`);
});

// Get insights
const profile = await tracker.getProfile();
console.log(`Development stage: ${profile.development.stage}`);
```

## Integration with Personality System

The integral metrics enhance personality detection by providing deeper context:

```typescript
const nixInterface = new PersonalizedNixInterface({
  integralTracking: {
    enabled: true,
    privacyLevel: PrivacyLevel.Standard
  }
});

// Process commands with integral awareness
const response = await nixInterface.processCommand({
  input: "help me learn programming"
});

// Response includes integral insights
console.log(response.integralInsights?.developmentStage);
console.log(response.integralInsights?.growthEdges);
```

## Privacy Levels

### Minimal
- Only essential metrics
- 7-day retention
- No detailed tracking

### Standard (Default)
- Balanced tracking
- 30-day retention
- Aggregated metrics only

### Enhanced
- Detailed tracking
- 90-day retention
- Full quadrant analysis

### Research
- Complete tracking
- 1-year retention
- Requires explicit consent

## Data Management

### View Your Data
```typescript
const anonymizedData = tracker.exportAnonymized();
console.log(anonymizedData);
```

### Delete Your Data
```typescript
await tracker.deleteAllData();
// All integral metrics are permanently deleted
```

## Quadrant Metrics

### Upper Left (Consciousness)
- Awareness level
- Intention clarity
- Emotional patterns
- Value alignment
- Learning preferences

### Upper Right (Behavior)
- Technical skill level
- Command patterns
- Error recovery
- Session metrics
- Feature adoption

### Lower Left (Culture)
- Communication style
- Community participation
- Shared values
- Cultural alignment
- Collaboration preferences

### Lower Right (Systems)
- Installed packages
- Tool complexity
- Automation level
- Resource usage
- Infrastructure patterns

## Pattern Detection

The system detects cross-quadrant patterns like:

- **Efficiency Need**: High skill + low patience → Minimal UI
- **Active Learner**: Growing skill + help-seeking → Detailed explanations
- **Mentor Potential**: Community involvement + helping → Teaching opportunities
- **Creative Flow**: Creative tools + exploration → Artistic suggestions

## Development Stages

Based on integral theory, users progress through stages:

1. **Archaic**: Basic survival mode
2. **Magic**: Superstitious thinking
3. **Mythic**: Rule-based thinking
4. **Rational**: Logic and analysis
5. **Pluralistic**: Multiple perspectives
6. **Integral**: Integrated awareness
7. **Super-Integral**: Transcendent unity

## Future Enhancements

- Biometric integration (with consent)
- Community pattern sharing (anonymized)
- Developmental milestone celebrations
- Personalized growth recommendations
- Cross-session continuity

## Contributing

When adding new metrics:
1. Respect user privacy above all
2. Make tracking transparent
3. Provide clear value to users
4. Allow easy opt-out
5. Document thoroughly

---

*"The map is not the territory, but a good map helps us navigate the territory with wisdom."*