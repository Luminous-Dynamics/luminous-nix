// Mock GestureEngine for demo
export type GestureType = 
  | 'tap'
  | 'double-tap'
  | 'long-press'
  | 'swipe-left'
  | 'swipe-right'
  | 'swipe-up'
  | 'swipe-down'
  | 'pinch-in'
  | 'pinch-out'
  | 'circle'
  | 'shake';

export interface Gesture {
  type: GestureType;
  timestamp: number;
  duration: number;
  velocity?: number;
  direction?: number;
  points?: { x: number; y: number }[];
}

export interface GesturePattern {
  name: string;
  sequence: GestureType[];
  maxInterval: number; // ms between gestures
}

export class GestureEngine {
  private gestureHistory: Gesture[] = [];
  private patterns: Map<string, GesturePattern> = new Map();
  private listeners: Map<string, (gesture: Gesture) => void> = new Map();

  async initialize() {
    console.log('Gesture Engine initialized');
    this.registerDefaultPatterns();
  }

  private registerDefaultPatterns() {
    // Common gesture patterns
    this.patterns.set('undo', {
      name: 'undo',
      sequence: ['swipe-left', 'swipe-left'],
      maxInterval: 1000
    });

    this.patterns.set('help', {
      name: 'help',
      sequence: ['circle'],
      maxInterval: 2000
    });

    this.patterns.set('pause', {
      name: 'pause',
      sequence: ['long-press'],
      maxInterval: 0
    });

    this.patterns.set('confirm', {
      name: 'confirm',
      sequence: ['double-tap'],
      maxInterval: 500
    });
  }

  registerGesture(gesture: Gesture) {
    this.gestureHistory.push(gesture);
    
    // Keep history limited
    if (this.gestureHistory.length > 50) {
      this.gestureHistory.shift();
    }

    // Check for patterns
    const pattern = this.detectPattern();
    if (pattern) {
      this.emitPattern(pattern);
    }

    // Emit individual gesture
    this.listeners.forEach(listener => listener(gesture));
  }

  onGesture(callback: (gesture: Gesture) => void): () => void {
    const id = Math.random().toString(36);
    this.listeners.set(id, callback);
    
    // Return unsubscribe function
    return () => this.listeners.delete(id);
  }

  detectMouseGesture(movements: { x: number; y: number; time: number }[]): Gesture | null {
    if (movements.length < 2) return null;

    const start = movements[0];
    const end = movements[movements.length - 1];
    const duration = end.time - start.time;

    // Detect swipe
    const dx = end.x - start.x;
    const dy = end.y - start.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const velocity = distance / duration;

    if (velocity > 0.5 && duration < 500) {
      const angle = Math.atan2(dy, dx);
      
      if (Math.abs(dx) > Math.abs(dy)) {
        return {
          type: dx > 0 ? 'swipe-right' : 'swipe-left',
          timestamp: end.time,
          duration,
          velocity,
          direction: angle
        };
      } else {
        return {
          type: dy > 0 ? 'swipe-down' : 'swipe-up',
          timestamp: end.time,
          duration,
          velocity,
          direction: angle
        };
      }
    }

    // Detect circle
    if (this.isCircularMotion(movements)) {
      return {
        type: 'circle',
        timestamp: end.time,
        duration,
        points: movements.map(m => ({ x: m.x, y: m.y }))
      };
    }

    return null;
  }

  private isCircularMotion(movements: { x: number; y: number }[]): boolean {
    // Simplified circle detection
    if (movements.length < 8) return false;
    
    const start = movements[0];
    const end = movements[movements.length - 1];
    const distance = Math.sqrt(
      Math.pow(end.x - start.x, 2) + 
      Math.pow(end.y - start.y, 2)
    );
    
    // Check if start and end are close
    return distance < 50;
  }

  private detectPattern(): string | null {
    for (const [name, pattern] of this.patterns.entries()) {
      if (this.matchesPattern(pattern)) {
        return name;
      }
    }
    return null;
  }

  private matchesPattern(pattern: GesturePattern): boolean {
    if (this.gestureHistory.length < pattern.sequence.length) {
      return false;
    }

    const recent = this.gestureHistory.slice(-pattern.sequence.length);
    
    for (let i = 0; i < pattern.sequence.length; i++) {
      if (recent[i].type !== pattern.sequence[i]) {
        return false;
      }
      
      // Check timing
      if (i > 0 && pattern.maxInterval > 0) {
        const interval = recent[i].timestamp - recent[i - 1].timestamp;
        if (interval > pattern.maxInterval) {
          return false;
        }
      }
    }
    
    return true;
  }

  private emitPattern(patternName: string) {
    console.log('Pattern detected:', patternName);
    // In real implementation, would emit pattern events
  }

  getGestureVelocity(gesture: Gesture): number {
    return gesture.velocity || 0;
  }

  isUrgentGesture(gesture: Gesture): boolean {
    // Fast swipes or shakes indicate urgency
    return (
      gesture.type === 'shake' ||
      (gesture.velocity && gesture.velocity > 1.0)
    );
  }

  registerCustomPattern(name: string, sequence: GestureType[], maxInterval = 1000) {
    this.patterns.set(name, {
      name,
      sequence,
      maxInterval
    });
  }
}