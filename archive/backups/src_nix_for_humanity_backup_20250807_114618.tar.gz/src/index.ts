#!/usr/bin/env node

import { CLI } from '@nix-humanity/ui';

async function main() {
  const cli = new CLI();
  await cli.start();
}

main().catch(console.error);
