/**
 * Shared type definitions for Nix for Humanity
 */

export interface CommandResult {
  success: boolean;
  response: string;
  command: string;
  output?: string;
  error?: string;
  timestamp?: Date;
}

export interface User {
  id: string;
  preferences: UserPreferences;
  history: CommandHistory;
  profile: UserProfile;
}

export interface UserPreferences {
  personalityStyle: 'minimal' | 'friendly' | 'encouraging' | 'playful' | 'sacred';
  voiceEnabled: boolean;
  visualComplexity: 'minimal' | 'moderate' | 'rich';
  confirmDestructive: boolean;
  language: string;
}

export interface CommandHistory {
  commands: HistoryEntry[];
  maxEntries: number;
}

export interface HistoryEntry {
  command: string;
  timestamp: Date;
  success: boolean;
  duration: number;
}

export interface UserProfile {
  expertiseLevel: 'beginner' | 'intermediate' | 'advanced';
  commonTasks: string[];
  preferredWorkflow: 'declarative' | 'imperative' | 'mixed';
  hobbies?: string[];
  profession?: string;
}

export interface SystemState {
  isOnline: boolean;
  nixosVersion: string;
  lastUpdate: Date;
  systemHealth: 'healthy' | 'warning' | 'error';
}

export interface NixCommand {
  command: string;
  args: string[];
  options: Record<string, any>;
  requiresSudo: boolean;
  isDestructive: boolean;
}

export interface IntentResult {
  intent: string;
  confidence: number;
  entities: Record<string, any>;
  command?: NixCommand;
  clarificationNeeded?: string;
  emotionalContext?: any;
}