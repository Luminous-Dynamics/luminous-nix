/**
 * Visualize persona test results in a readable format
 */

import { PersonaTestResult, AllPersonasTestResult } from './persona-testing-framework';

export class PersonaTestVisualizer {
  /**
   * Generate a visual summary of test results
   */
  static visualizeSummary(results: AllPersonasTestResult): string {
    let output = '';
    
    // Header
    output += this.generateHeader();
    
    // Overall metrics visualization
    output += this.generateOverallMetrics(results.overallMetrics);
    
    // Individual persona results
    output += this.generatePersonaResults(results.results);
    
    // Recommendations
    output += this.generateRecommendations(results);
    
    return output;
  }
  
  private static generateHeader(): string {
    return `
╔════════════════════════════════════════════════════════════════╗
║          NIX FOR HUMANITY - PERSONA TEST RESULTS               ║
║                Personality & Hobby Detection                    ║
╚════════════════════════════════════════════════════════════════╝
`;
  }
  
  private static generateOverallMetrics(metrics: any): string {
    let output = '\n📊 OVERALL METRICS\n';
    output += '─'.repeat(60) + '\n';
    
    // Create visual bars for metrics
    output += this.createMetricBar('Success Rate', metrics.averageSuccessRate);
    output += this.createMetricBar('Personality', metrics.averagePersonalityAccuracy);
    output += this.createMetricBar('Hobby Detection', metrics.averageHobbyAccuracy);
    output += this.createMetricBar('Adaptation Speed', metrics.averageAdaptationSpeed);
    output += this.createMetricBar('Consistency', metrics.averageConsistencyScore);
    
    output += `\n📈 Coverage: ${metrics.personasCovered}/10 personas tested\n`;
    output += `📝 Total interactions: ${metrics.totalInteractions}\n`;
    
    return output;
  }
  
  private static createMetricBar(label: string, value: number): string {
    const percentage = Math.round(value * 100);
    const barLength = 30;
    const filledLength = Math.round(barLength * value);
    const emptyLength = barLength - filledLength;
    
    const bar = '█'.repeat(filledLength) + '░'.repeat(emptyLength);
    const status = this.getStatusEmoji(value);
    
    return `${label.padEnd(20)} ${bar} ${percentage}% ${status}\n`;
  }
  
  private static getStatusEmoji(value: number): string {
    if (value >= 0.9) return '✅';
    if (value >= 0.8) return '🟢';
    if (value >= 0.7) return '🟡';
    if (value >= 0.6) return '🟠';
    return '🔴';
  }
  
  private static generatePersonaResults(results: PersonaTestResult[]): string {
    let output = '\n\n👥 INDIVIDUAL PERSONA RESULTS\n';
    output += '═'.repeat(60) + '\n';
    
    for (const result of results) {
      output += this.generatePersonaCard(result);
    }
    
    return output;
  }
  
  private static generatePersonaCard(result: PersonaTestResult): string {
    const persona = result.persona;
    let card = `\n┌─ ${persona.name} (${persona.age}, ${persona.background})\n`;
    card += `│  Goal: "${persona.goal}"\n`;
    card += `│  Tech Level: ${persona.techLevel} | Preferred: ${persona.preferredStyle}\n`;
    card += `│\n`;
    
    // Success metrics
    const successEmoji = result.metrics.successRate >= 0.8 ? '✅' : '❌';
    card += `│  ${successEmoji} Success Rate: ${(result.metrics.successRate * 100).toFixed(0)}%\n`;
    
    // Personality adaptation
    card += `│  🎭 Personality Match: ${(result.metrics.personalityAccuracy * 100).toFixed(0)}%\n`;
    
    // Hobby detection
    if (persona.hobbies && persona.hobbies.length > 0) {
      card += `│  🎮 Hobbies Detected: ${(result.metrics.hobbyAccuracy * 100).toFixed(0)}%\n`;
      card += `│     Expected: ${persona.hobbies.join(', ')}\n`;
    }
    
    // Sample interactions
    card += `│\n│  Sample Interactions:\n`;
    const sampleCount = Math.min(3, result.interactions.length);
    for (let i = 0; i < sampleCount; i++) {
      const interaction = result.interactions[i];
      const icon = interaction.success ? '✓' : '✗';
      card += `│  ${icon} "${interaction.command.substring(0, 40)}..."\n`;
    }
    
    card += `└${'─'.repeat(58)}\n`;
    
    return card;
  }
  
  private static generateRecommendations(results: AllPersonasTestResult): string {
    let output = '\n\n💡 RECOMMENDATIONS\n';
    output += '─'.repeat(60) + '\n';
    
    const metrics = results.overallMetrics;
    const recommendations: string[] = [];
    
    // Analyze weak areas
    if (metrics.averagePersonalityAccuracy < 0.8) {
      recommendations.push('🎭 Enhance personality detection algorithms for better adaptation');
    }
    
    if (metrics.averageHobbyAccuracy < 0.7) {
      recommendations.push('🎮 Expand hobby pattern database and recognition logic');
    }
    
    if (metrics.averageAdaptationSpeed < 0.6) {
      recommendations.push('⚡ Implement faster initial personality detection');
    }
    
    if (metrics.averageConsistencyScore < 0.8) {
      recommendations.push('🔄 Improve personality consistency across conversations');
    }
    
    // Specific persona recommendations
    const strugglingPersonas = results.results
      .filter(r => r.metrics.successRate < 0.7)
      .map(r => r.persona.name);
    
    if (strugglingPersonas.length > 0) {
      recommendations.push(`👥 Focus on improving support for: ${strugglingPersonas.join(', ')}`);
    }
    
    if (recommendations.length === 0) {
      recommendations.push('✨ Excellent performance! Consider adding more edge cases');
    }
    
    recommendations.forEach(rec => {
      output += `  • ${rec}\n`;
    });
    
    return output;
  }
  
  /**
   * Generate a detailed interaction log for debugging
   */
  static generateDetailedLog(results: AllPersonasTestResult): string {
    let log = '# DETAILED INTERACTION LOG\n\n';
    
    for (const personaResult of results.results) {
      log += `## ${personaResult.persona.name}\n\n`;
      
      for (const interaction of personaResult.interactions) {
        log += `### Command: "${interaction.command}"\n`;
        log += `- Intent: ${interaction.intent.type}\n`;
        log += `- Detected Personality: ${interaction.detectedPersonality}\n`;
        log += `- Detected Hobbies: ${interaction.detectedHobbies.join(', ') || 'none'}\n`;
        log += `- Success: ${interaction.success ? 'YES' : 'NO'}\n`;
        log += `- Personality Match: ${interaction.personalityMatch ? 'YES' : 'NO'}\n`;
        log += `- Hobby Match: ${interaction.hobbyMatch ? 'YES' : 'NO'}\n`;
        log += '\n';
      }
    }
    
    return log;
  }
  
  /**
   * Generate a CSV export of results
   */
  static generateCSVExport(results: AllPersonasTestResult): string {
    let csv = 'Persona,Age,Background,Success Rate,Personality Accuracy,Hobby Accuracy,Adaptation Speed,Consistency\n';
    
    for (const result of results.results) {
      const p = result.persona;
      const m = result.metrics;
      
      csv += `"${p.name}",${p.age},"${p.background}",`;
      csv += `${(m.successRate * 100).toFixed(1)},`;
      csv += `${(m.personalityAccuracy * 100).toFixed(1)},`;
      csv += `${(m.hobbyAccuracy * 100).toFixed(1)},`;
      csv += `${(m.adaptationSpeed * 100).toFixed(1)},`;
      csv += `${(m.consistencyScore * 100).toFixed(1)}\n`;
    }
    
    return csv;
  }
}

// Example usage function
export function displayTestResults(results: AllPersonasTestResult): void {
  // Console output with colors
  console.log(PersonaTestVisualizer.visualizeSummary(results));
  
  // Save detailed logs
  const fs = require('fs');
  const path = require('path');
  
  const resultsDir = path.join(__dirname, '../../test-results');
  if (!fs.existsSync(resultsDir)) {
    fs.mkdirSync(resultsDir, { recursive: true });
  }
  
  // Save visualization
  fs.writeFileSync(
    path.join(resultsDir, 'test-visualization.txt'),
    PersonaTestVisualizer.visualizeSummary(results)
  );
  
  // Save detailed log
  fs.writeFileSync(
    path.join(resultsDir, 'detailed-log.md'),
    PersonaTestVisualizer.generateDetailedLog(results)
  );
  
  // Save CSV
  fs.writeFileSync(
    path.join(resultsDir, 'results.csv'),
    PersonaTestVisualizer.generateCSVExport(results)
  );
}