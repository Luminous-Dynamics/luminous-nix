/**
 * Persona Test Runner
 * Executes comprehensive persona tests and generates honest reports
 */

import { PersonaTestFramework, PersonaTestResult } from './persona-test-framework';
import { PersonalityAdapter } from '../personality/personality-adapter';
import { AdaptiveUIFramework } from '../adaptive-ui/adaptive-ui-framework';
import { NLPEngine } from '../nlp/nlp-engine';
import { VoiceEmotionIntegration } from '../voice-emotion/voice-emotion-integration';

export interface TestReport {
  timestamp: Date;
  summary: {
    totalPersonas: number;
    averageScore: number;
    passedPersonas: number;
    failedPersonas: number;
    criticalIssues: number;
  };
  personaResults: PersonaTestResult[];
  criticalFailuresSummary: string[];
  topRecommendations: string[];
  accessibilityGaps: string[];
  overallAssessment: string;
}

export class PersonaTestRunner {
  private framework: PersonaTestFramework;
  
  constructor() {
    // Initialize all systems
    const nlpEngine = new NLPEngine();
    const personalityAdapter = new PersonalityAdapter(nlpEngine);
    const uiFramework = new AdaptiveUIFramework();
    const emotionIntegration = new VoiceEmotionIntegration(
      personalityAdapter,
      uiFramework,
      nlpEngine
    );
    
    this.framework = new PersonaTestFramework(
      nlpEngine,
      personalityAdapter,
      uiFramework,
      emotionIntegration
    );
  }
  
  /**
   * Run all persona tests and generate comprehensive report
   */
  async runTests(): Promise<TestReport> {
    console.log('🧪 Starting Comprehensive Persona Testing...\n');
    console.log('⚠️  This test will provide HONEST feedback about failures.\n');
    
    // Run all tests
    const personaResults = await this.framework.runAllTests();
    
    // Analyze results
    const summary = this.generateSummary(personaResults);
    const criticalFailures = this.extractCriticalFailures(personaResults);
    const recommendations = this.prioritizeRecommendations(personaResults);
    const accessibilityGaps = this.identifyAccessibilityGaps(personaResults);
    const assessment = this.generateOverallAssessment(personaResults, summary);
    
    const report: TestReport = {
      timestamp: new Date(),
      summary,
      personaResults,
      criticalFailuresSummary: criticalFailures,
      topRecommendations: recommendations,
      accessibilityGaps,
      overallAssessment: assessment
    };
    
    // Generate console report
    this.printReport(report);
    
    return report;
  }
  
  /**
   * Generate summary statistics
   */
  private generateSummary(results: PersonaTestResult[]): TestReport['summary'] {
    const totalPersonas = results.length;
    const scores = results.map(r => r.overallScore);
    const averageScore = scores.reduce((sum, score) => sum + score, 0) / totalPersonas;
    const passedPersonas = results.filter(r => r.overallScore >= 70).length;
    const failedPersonas = totalPersonas - passedPersonas;
    const criticalIssues = results.reduce((sum, r) => sum + r.criticalFailures.length, 0);
    
    return {
      totalPersonas,
      averageScore,
      passedPersonas,
      failedPersonas,
      criticalIssues
    };
  }
  
  /**
   * Extract all critical failures across personas
   */
  private extractCriticalFailures(results: PersonaTestResult[]): string[] {
    const failures = new Set<string>();
    
    for (const result of results) {
      for (const failure of result.criticalFailures) {
        failures.add(`${result.persona}: ${failure}`);
      }
    }
    
    return Array.from(failures);
  }
  
  /**
   * Prioritize recommendations by frequency and impact
   */
  private prioritizeRecommendations(results: PersonaTestResult[]): string[] {
    const recommendationCounts = new Map<string, number>();
    
    for (const result of results) {
      for (const rec of result.recommendations) {
        recommendationCounts.set(rec, (recommendationCounts.get(rec) || 0) + 1);
      }
    }
    
    // Sort by frequency
    return Array.from(recommendationCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([rec, count]) => `${rec} (affects ${count} personas)`);
  }
  
  /**
   * Identify accessibility gaps
   */
  private identifyAccessibilityGaps(results: PersonaTestResult[]): string[] {
    const gaps: string[] = [];
    
    // Check Alex (blind developer)
    const alex = results.find(r => r.persona.includes('Alex'));
    if (alex && alex.detailedScores.accessibility < 95) {
      gaps.push(`Screen reader support inadequate (${alex.detailedScores.accessibility.toFixed(0)}% vs 95% required)`);
    }
    
    // Check Maya (ADHD)
    const maya = results.find(r => r.persona.includes('Maya'));
    if (maya && maya.detailedScores.timeToSuccess < 90) {
      gaps.push(`Response time too slow for ADHD users (${maya.detailedScores.timeToSuccess.toFixed(0)}% speed score)`);
    }
    
    // Check Luna (autistic)
    const luna = results.find(r => r.persona.includes('Luna'));
    if (luna && luna.detailedScores.taskCompletion < 100) {
      gaps.push(`Inconsistent behavior problematic for autistic users (${luna.detailedScores.taskCompletion.toFixed(0)}% consistency)`);
    }
    
    // Check Grandma Rose (elderly)
    const rose = results.find(r => r.persona.includes('Rose'));
    if (rose && rose.detailedScores.nlpAccuracy < 80) {
      gaps.push(`Natural language understanding fails for non-technical users (${rose.detailedScores.nlpAccuracy.toFixed(0)}% accuracy)`);
    }
    
    return gaps;
  }
  
  /**
   * Generate honest overall assessment
   */
  private generateOverallAssessment(results: PersonaTestResult[], summary: TestReport['summary']): string {
    const { averageScore, passedPersonas, totalPersonas, criticalIssues } = summary;
    
    let assessment = '';
    
    // Overall grade
    if (averageScore >= 85) {
      assessment = '✅ EXCELLENT: System works well for most users. ';
    } else if (averageScore >= 70) {
      assessment = '🟡 ADEQUATE: System is usable but needs improvement. ';
    } else if (averageScore >= 55) {
      assessment = '🟠 POOR: System fails many users. Major work needed. ';
    } else {
      assessment = '❌ FAILING: System is not ready for real users. ';
    }
    
    // Specific issues
    assessment += `\n\nWe successfully serve ${passedPersonas}/${totalPersonas} personas. `;
    
    if (criticalIssues > 0) {
      assessment += `\n\n⚠️  ${criticalIssues} CRITICAL FAILURES that exclude users completely. `;
    }
    
    // Worst performers
    const worstPerformers = results
      .filter(r => r.overallScore < 60)
      .sort((a, b) => a.overallScore - b.overallScore)
      .slice(0, 3);
      
    if (worstPerformers.length > 0) {
      assessment += '\n\n😰 We are failing these users badly:\n';
      for (const performer of worstPerformers) {
        assessment += `- ${performer.persona} (${performer.overallScore.toFixed(0)}% score)\n`;
      }
    }
    
    // Best performers
    const bestPerformers = results
      .filter(r => r.overallScore > 85)
      .sort((a, b) => b.overallScore - a.overallScore)
      .slice(0, 3);
      
    if (bestPerformers.length > 0) {
      assessment += '\n\n😊 We serve these users well:\n';
      for (const performer of bestPerformers) {
        assessment += `- ${performer.persona} (${performer.overallScore.toFixed(0)}% score)\n`;
      }
    }
    
    // Bottom line
    assessment += '\n\n📊 BOTTOM LINE: ';
    if (averageScore >= 70 && criticalIssues === 0) {
      assessment += 'Ready for beta testing with improvements needed.';
    } else if (criticalIssues > 0) {
      assessment += 'NOT ready for users - critical accessibility/usability failures must be fixed.';
    } else {
      assessment += 'Significant work needed before user testing.';
    }
    
    return assessment;
  }
  
  /**
   * Print formatted report to console
   */
  private printReport(report: TestReport) {
    console.log('\n' + '='.repeat(80));
    console.log('🧪 PERSONA TEST REPORT - HONEST ASSESSMENT');
    console.log('='.repeat(80));
    
    // Summary
    console.log('\n📊 SUMMARY:');
    console.log(`- Tested: ${report.summary.totalPersonas} personas`);
    console.log(`- Average Score: ${report.summary.averageScore.toFixed(1)}%`);
    console.log(`- Passed: ${report.summary.passedPersonas} personas`);
    console.log(`- Failed: ${report.summary.failedPersonas} personas`);
    console.log(`- Critical Issues: ${report.summary.criticalIssues}`);
    
    // Critical failures
    if (report.criticalFailuresSummary.length > 0) {
      console.log('\n❌ CRITICAL FAILURES:');
      report.criticalFailuresSummary.forEach(failure => {
        console.log(`- ${failure}`);
      });
    }
    
    // Individual results
    console.log('\n👥 INDIVIDUAL PERSONA RESULTS:');
    for (const result of report.personaResults) {
      console.log(`\n${result.persona}:`);
      console.log(`  Overall Score: ${result.overallScore.toFixed(1)}% ${this.getGrade(result.overallScore)}`);
      
      if (result.strengths.length > 0) {
        console.log('  ✅ Strengths:');
        result.strengths.forEach(s => console.log(`    - ${s}`));
      }
      
      if (result.weaknesses.length > 0) {
        console.log('  ⚠️  Weaknesses:');
        result.weaknesses.forEach(w => console.log(`    - ${w}`));
      }
      
      if (result.criticalFailures.length > 0) {
        console.log('  ❌ Critical Failures:');
        result.criticalFailures.forEach(f => console.log(`    - ${f}`));
      }
    }
    
    // Accessibility gaps
    if (report.accessibilityGaps.length > 0) {
      console.log('\n♿ ACCESSIBILITY GAPS:');
      report.accessibilityGaps.forEach(gap => {
        console.log(`- ${gap}`);
      });
    }
    
    // Top recommendations
    console.log('\n💡 TOP RECOMMENDATIONS:');
    report.topRecommendations.forEach((rec, i) => {
      console.log(`${i + 1}. ${rec}`);
    });
    
    // Overall assessment
    console.log('\n' + '='.repeat(80));
    console.log('📝 OVERALL ASSESSMENT:');
    console.log(report.overallAssessment);
    console.log('='.repeat(80) + '\n');
  }
  
  /**
   * Get letter grade for score
   */
  private getGrade(score: number): string {
    if (score >= 90) return '(A)';
    if (score >= 80) return '(B)';
    if (score >= 70) return '(C)';
    if (score >= 60) return '(D)';
    return '(F)';
  }
}