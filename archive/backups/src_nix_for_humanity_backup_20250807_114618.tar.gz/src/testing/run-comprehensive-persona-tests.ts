#!/usr/bin/env ts-node
/**
 * Comprehensive Persona Test Runner CLI
 * Tests all 10 personas with honest feedback about failures
 */

import { PersonaTestRunner } from './persona-test-runner';
import * as fs from 'fs/promises';
import * as path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

// ANSI color codes for terminal output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m'
};

const log = {
  info: (msg: string) => console.log(`${colors.blue}ℹ${colors.reset}  ${msg}`),
  success: (msg: string) => console.log(`${colors.green}✓${colors.reset}  ${msg}`),
  warning: (msg: string) => console.log(`${colors.yellow}⚠${colors.reset}  ${msg}`),
  error: (msg: string) => console.log(`${colors.red}✗${colors.reset}  ${msg}`),
  header: (msg: string) => console.log(`\n${colors.bright}${colors.cyan}${msg}${colors.reset}\n`)
};

/**
 * Main test runner
 */
async function runTests() {
  log.header('🧪 Nix for Humanity - Comprehensive Persona Testing Suite');
  log.info('Starting comprehensive persona testing...');
  log.info('This will provide honest feedback about system performance.\n');
  
  try {
    // Initialize test runner
    const runner = new PersonaTestRunner();
    
    // Run all tests
    const startTime = Date.now();
    const report = await runner.runTests();
    const duration = ((Date.now() - startTime) / 1000).toFixed(1);
    
    log.success(`Testing completed in ${duration} seconds\n`);
    
    // Save report to file
    const reportDir = path.join(process.cwd(), 'test-reports');
    await fs.mkdir(reportDir, { recursive: true });
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const reportPath = path.join(reportDir, `persona-test-report-${timestamp}.json`);
    
    await fs.writeFile(reportPath, JSON.stringify(report, null, 2));
    log.success(`Full report saved to: ${reportPath}`);
    
    // Generate summary
    printSummary(report);
    
    // Generate HTML report if requested
    if (process.argv.includes('--html')) {
      await generateHTMLReport(report, reportDir, timestamp);
    }
    
    // Check if we should fail CI
    if (process.argv.includes('--ci')) {
      const exitCode = determineCIExitCode(report);
      if (exitCode !== 0) {
        log.error(`\nCI FAILED: Critical issues detected`);
        process.exit(exitCode);
      }
    }
    
  } catch (error) {
    log.error(`Test execution failed: ${error}`);
    process.exit(1);
  }
}

/**
 * Print colorful summary to console
 */
function printSummary(report: any) {
  log.header('📊 Test Summary');
  
  // Overall score with color
  const avgScore = report.summary.averageScore;
  let scoreColor = colors.green;
  if (avgScore < 70) scoreColor = colors.red;
  else if (avgScore < 85) scoreColor = colors.yellow;
  
  console.log(`Average Score: ${scoreColor}${avgScore.toFixed(1)}%${colors.reset}\n`);
  
  // Pass/fail breakdown
  console.log(`${colors.green}✓ Passed: ${report.summary.passedPersonas}${colors.reset}`);
  console.log(`${colors.red}✗ Failed: ${report.summary.failedPersonas}${colors.reset}`);
  
  if (report.summary.criticalIssues > 0) {
    console.log(`${colors.bright}${colors.red}⚠️  Critical Issues: ${report.summary.criticalIssues}${colors.reset}`);
  }
  
  // Individual persona results
  log.header('👥 Individual Results');
  
  for (const result of report.personaResults) {
    let icon = '✓';
    let color = colors.green;
    
    if (result.overallScore < 60) {
      icon = '✗';
      color = colors.red;
    } else if (result.overallScore < 80) {
      icon = '~';
      color = colors.yellow;
    }
    
    console.log(`${color}${icon}${colors.reset} ${result.persona.padEnd(30)} ${result.overallScore.toFixed(0)}%`);
    
    if (result.criticalFailures.length > 0) {
      for (const failure of result.criticalFailures) {
        console.log(`  ${colors.red}└─ CRITICAL: ${failure}${colors.reset}`);
      }
    }
  }
  
  // Critical failures summary
  if (report.criticalFailuresSummary.length > 0) {
    log.header('❌ Critical Failures');
    for (const failure of report.criticalFailuresSummary) {
      console.log(`${colors.red}• ${failure}${colors.reset}`);
    }
  }
  
  // Accessibility gaps
  if (report.accessibilityGaps.length > 0) {
    log.header('♿ Accessibility Gaps');
    for (const gap of report.accessibilityGaps) {
      console.log(`${colors.yellow}• ${gap}${colors.reset}`);
    }
  }
  
  // Top recommendations
  log.header('💡 Top Recommendations');
  report.topRecommendations.slice(0, 5).forEach((rec: string, i: number) => {
    console.log(`${i + 1}. ${rec}`);
  });
  
  // Overall assessment
  log.header('📝 Overall Assessment');
  console.log(report.overallAssessment);
}

/**
 * Generate HTML report
 */
async function generateHTMLReport(report: any, reportDir: string, timestamp: string) {
  const htmlPath = path.join(reportDir, `persona-test-report-${timestamp}.html`);
  
  const html = `
<!DOCTYPE html>
<html>
<head>
  <title>Persona Test Report - ${new Date().toLocaleDateString()}</title>
  <style>
    body {
      font-family: -apple-system, system-ui, sans-serif;
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem;
      background: #f8f9fa;
    }
    .header {
      text-align: center;
      margin-bottom: 3rem;
    }
    .summary {
      background: white;
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      margin-bottom: 2rem;
    }
    .score-big {
      font-size: 4rem;
      font-weight: bold;
      text-align: center;
      margin: 1rem 0;
    }
    .score-good { color: #10b981; }
    .score-medium { color: #f59e0b; }
    .score-bad { color: #ef4444; }
    .persona-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 1rem;
      margin-bottom: 2rem;
    }
    .persona-card {
      background: white;
      padding: 1.5rem;
      border-radius: 8px;
      border-left: 4px solid;
    }
    .critical {
      background: #fee;
      padding: 1rem;
      border-radius: 8px;
      margin: 1rem 0;
      border-left: 4px solid #dc2626;
    }
    .recommendation {
      background: #e0f2fe;
      padding: 1rem;
      border-radius: 8px;
      margin: 0.5rem 0;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>Nix for Humanity - Persona Test Report</h1>
    <p>Generated: ${new Date().toLocaleString()}</p>
  </div>
  
  <div class="summary">
    <h2>Overall Summary</h2>
    <div class="score-big ${report.summary.averageScore >= 85 ? 'score-good' : report.summary.averageScore >= 70 ? 'score-medium' : 'score-bad'}">
      ${report.summary.averageScore.toFixed(1)}%
    </div>
    <p style="text-align: center; color: #666;">
      ${report.summary.passedPersonas} passed • ${report.summary.failedPersonas} failed • ${report.summary.criticalIssues} critical issues
    </p>
  </div>
  
  <h2>Individual Persona Results</h2>
  <div class="persona-grid">
    ${report.personaResults.map((r: any) => `
      <div class="persona-card" style="border-color: ${r.overallScore >= 80 ? '#10b981' : r.overallScore >= 60 ? '#f59e0b' : '#ef4444'}">
        <h3>${r.persona}</h3>
        <p style="font-size: 2rem; font-weight: bold; color: ${r.overallScore >= 80 ? '#10b981' : r.overallScore >= 60 ? '#f59e0b' : '#ef4444'}">
          ${r.overallScore.toFixed(0)}%
        </p>
        <p><strong>Strengths:</strong> ${r.strengths.join(', ') || 'None identified'}</p>
        <p><strong>Weaknesses:</strong> ${r.weaknesses.join(', ') || 'None identified'}</p>
        ${r.criticalFailures.length > 0 ? `
          <div class="critical">
            <strong>Critical Failures:</strong>
            <ul>${r.criticalFailures.map((f: string) => `<li>${f}</li>`).join('')}</ul>
          </div>
        ` : ''}
      </div>
    `).join('')}
  </div>
  
  ${report.criticalFailuresSummary.length > 0 ? `
    <div class="critical">
      <h2>All Critical Failures</h2>
      <ul>
        ${report.criticalFailuresSummary.map((f: string) => `<li>${f}</li>`).join('')}
      </ul>
    </div>
  ` : ''}
  
  <h2>Top Recommendations</h2>
  ${report.topRecommendations.map((r: string) => `
    <div class="recommendation">${r}</div>
  `).join('')}
  
  <div class="summary" style="margin-top: 2rem;">
    <h2>Overall Assessment</h2>
    <pre style="white-space: pre-wrap;">${report.overallAssessment}</pre>
  </div>
</body>
</html>
  `;
  
  await fs.writeFile(htmlPath, html);
  log.success(`HTML report saved to: ${htmlPath}`);
  
  // Try to open in browser
  try {
    if (process.platform === 'darwin') {
      await execAsync(`open ${htmlPath}`);
    } else if (process.platform === 'linux') {
      await execAsync(`xdg-open ${htmlPath}`);
    }
  } catch {
    // Ignore errors opening browser
  }
}

/**
 * Determine CI exit code based on results
 */
function determineCIExitCode(report: any): number {
  // Fail if average score below 70%
  if (report.summary.averageScore < 70) {
    return 1;
  }
  
  // Fail if any critical issues
  if (report.summary.criticalIssues > 0) {
    return 2;
  }
  
  // Fail if more than 3 personas failed
  if (report.summary.failedPersonas > 3) {
    return 3;
  }
  
  // Fail if accessibility score for Alex (blind developer) is below 90%
  const alexResult = report.personaResults.find((r: any) => r.persona.includes('Alex'));
  if (alexResult && alexResult.detailedScores.accessibility < 90) {
    return 4;
  }
  
  return 0;
}

// Show help
if (process.argv.includes('--help')) {
  console.log(`
Nix for Humanity - Comprehensive Persona Test Runner

Usage: npm run test:personas [options]

Options:
  --html     Generate HTML report and open in browser
  --ci       Exit with error code if tests fail (for CI/CD)
  --help     Show this help message

Examples:
  npm run test:personas          Run tests and show console output
  npm run test:personas --html   Run tests and generate HTML report
  npm run test:personas --ci     Run tests in CI mode
`);
  process.exit(0);
}

// Run tests
runTests().catch(error => {
  console.error('Fatal error:', error);
  process.exit(1);
});