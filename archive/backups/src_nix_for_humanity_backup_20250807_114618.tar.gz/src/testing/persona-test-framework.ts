/**
 * Persona Testing Framework
 * Honest, comprehensive testing for all 10 core personas
 * Designed to reveal both successes and failures
 */

import { PersonalityAdapter } from '../personality/personality-adapter';
import { AdaptiveUIFramework } from '../adaptive-ui/adaptive-ui-framework';
import { NLPEngine } from '../nlp/nlp-engine';
import { VoiceEmotionIntegration } from '../voice-emotion/voice-emotion-integration';

export interface PersonaTestResult {
  persona: string;
  overallScore: number; // 0-100
  strengths: string[];
  weaknesses: string[];
  criticalFailures: string[];
  recommendations: string[];
  detailedScores: {
    nlpAccuracy: number;
    personalityMatch: number;
    emotionalResponse: number;
    accessibility: number;
    taskCompletion: number;
    frustrationLevel: number;
    timeToSuccess: number;
  };
  realWorldScenarios: ScenarioResult[];
}

export interface ScenarioResult {
  scenario: string;
  success: boolean;
  timeSpent: number;
  errorCount: number;
  frustrationPeaks: number;
  abandonmentRisk: number; // 0-1
  feedback: string;
}

export interface TestPersona {
  id: string;
  name: string;
  age: number;
  background: string;
  technicalLevel: 'none' | 'basic' | 'intermediate' | 'advanced';
  primaryNeeds: string[];
  accessibilityNeeds: string[];
  emotionalProfile: {
    baselineStress: number;
    frustrationTolerance: number;
    confusionThreshold: number;
    excitementResponse: number;
  };
  typicalVocabulary: string[];
  commonMistakes: string[];
  successCriteria: string[];
}

export class PersonaTestFramework {
  private personas: TestPersona[] = [
    {
      id: 'grandma-rose',
      name: 'Grandma Rose (75)',
      age: 75,
      background: 'Retired teacher, wants to video chat with grandkids',
      technicalLevel: 'none',
      primaryNeeds: ['Simple language', 'Voice-first', 'Patient guidance'],
      accessibilityNeeds: ['Large text', 'High contrast', 'Slow pace'],
      emotionalProfile: {
        baselineStress: 0.6,
        frustrationTolerance: 0.3,
        confusionThreshold: 0.4,
        excitementResponse: 0.7
      },
      typicalVocabulary: ['thingy', 'doohickey', 'the computer', 'my screen'],
      commonMistakes: ['install the google', 'make it go', 'fix the internet'],
      successCriteria: [
        'Can install video chat software in <10 minutes',
        'Never sees a terminal command',
        'Feels supported, not patronized'
      ]
    },
    {
      id: 'maya',
      name: 'Maya (16, ADHD)',
      age: 16,
      background: 'High school student, speed reader, easily distracted',
      technicalLevel: 'intermediate',
      primaryNeeds: ['Fast responses', 'Minimal UI', 'No patronizing'],
      accessibilityNeeds: ['Focus mode', 'Distraction-free', 'Quick actions'],
      emotionalProfile: {
        baselineStress: 0.4,
        frustrationTolerance: 0.2,
        confusionThreshold: 0.3,
        excitementResponse: 0.9
      },
      typicalVocabulary: ['quick', 'fast', 'just do it', 'skip', 'whatever'],
      commonMistakes: ['instal', 'firefix', 'idc just do it'],
      successCriteria: [
        'Commands complete in <2 seconds',
        'Can skip all explanations',
        'Maintains flow state'
      ]
    },
    {
      id: 'david',
      name: 'David (42, Tired Parent)',
      age: 42,
      background: 'IT manager, 3 kids, always exhausted',
      technicalLevel: 'advanced',
      primaryNeeds: ['Reliability', 'No surprises', 'Quick fixes'],
      accessibilityNeeds: ['Works at 3am', 'One-handed operation', 'Quiet mode'],
      emotionalProfile: {
        baselineStress: 0.8,
        frustrationTolerance: 0.1,
        confusionThreshold: 0.2,
        excitementResponse: 0.3
      },
      typicalVocabulary: ['just work', 'fix', 'update', 'quick', 'now'],
      commonMistakes: ['updte', 'isntall', 'sys update'],
      successCriteria: [
        'Zero confirmation dialogs at night',
        'Everything works first try',
        'Can operate while holding baby'
      ]
    },
    {
      id: 'dr-sarah',
      name: 'Dr. Sarah (35, Researcher)',
      age: 35,
      background: 'Data scientist, needs reproducible environments',
      technicalLevel: 'advanced',
      primaryNeeds: ['Precision', 'Reproducibility', 'Efficiency'],
      accessibilityNeeds: ['Keyboard-only', 'Scriptable', 'Batch operations'],
      emotionalProfile: {
        baselineStress: 0.3,
        frustrationTolerance: 0.7,
        confusionThreshold: 0.8,
        excitementResponse: 0.5
      },
      typicalVocabulary: ['environment', 'dependencies', 'version', 'config', 'deterministic'],
      commonMistakes: [],
      successCriteria: [
        'Can specify exact versions',
        'All actions are logged',
        'Can export/script everything'
      ]
    },
    {
      id: 'alex',
      name: 'Alex (28, Blind Developer)',
      age: 28,
      background: 'Full-stack developer, screen reader user',
      technicalLevel: 'advanced',
      primaryNeeds: ['100% accessible', 'Keyboard navigation', 'Clear structure'],
      accessibilityNeeds: ['Screen reader support', 'Semantic HTML', 'Audio feedback'],
      emotionalProfile: {
        baselineStress: 0.4,
        frustrationTolerance: 0.5,
        confusionThreshold: 0.6,
        excitementResponse: 0.6
      },
      typicalVocabulary: ['navigate', 'heading', 'list', 'region', 'announce'],
      commonMistakes: [],
      successCriteria: [
        'Every element is reachable',
        'All actions announced',
        'Faster than sighted interfaces'
      ]
    },
    {
      id: 'carlos',
      name: 'Carlos (52, Career Changer)',
      age: 52,
      background: 'Former construction worker learning IT',
      technicalLevel: 'basic',
      primaryNeeds: ['Encouragement', 'Clear progress', 'No shame'],
      accessibilityNeeds: ['Simple terms', 'Visual aids', 'Celebration'],
      emotionalProfile: {
        baselineStress: 0.7,
        frustrationTolerance: 0.4,
        confusionThreshold: 0.5,
        excitementResponse: 0.8
      },
      typicalVocabulary: ['computer stuff', 'the program', 'make it work'],
      commonMistakes: ['crhome', 'fierox', 'install the wifi'],
      successCriteria: [
        'Feels capable, not stupid',
        'Celebrates small wins',
        'Clear learning path'
      ]
    },
    {
      id: 'priya',
      name: 'Priya (34, Single Mom)',
      age: 34,
      background: 'Remote worker, juggles work and childcare',
      technicalLevel: 'intermediate',
      primaryNeeds: ['Speed', 'Interruption recovery', 'Context aware'],
      accessibilityNeeds: ['One-handed mode', 'Voice commands', 'Auto-save'],
      emotionalProfile: {
        baselineStress: 0.7,
        frustrationTolerance: 0.3,
        confusionThreshold: 0.4,
        excitementResponse: 0.5
      },
      typicalVocabulary: ['quick', 'pause', 'continue', 'later', 'now'],
      commonMistakes: ['insatll', 'quikc', 'updaet'],
      successCriteria: [
        'Can pause mid-task',
        'Resumes context perfectly',
        'Works during chaos'
      ]
    },
    {
      id: 'jamie',
      name: 'Jamie (19, Privacy Advocate)',
      age: 19,
      background: 'College student, values privacy and control',
      technicalLevel: 'intermediate',
      primaryNeeds: ['Transparency', 'Control', 'No tracking'],
      accessibilityNeeds: ['Dark mode', 'Minimal permissions', 'Local-only'],
      emotionalProfile: {
        baselineStress: 0.3,
        frustrationTolerance: 0.6,
        confusionThreshold: 0.7,
        excitementResponse: 0.7
      },
      typicalVocabulary: ['privacy', 'local', 'secure', 'open source', 'audit'],
      commonMistakes: [],
      successCriteria: [
        'Can verify no data leaves device',
        'All actions transparent',
        'Can inspect/modify anything'
      ]
    },
    {
      id: 'viktor',
      name: 'Viktor (67, ESL)',
      age: 67,
      background: 'Immigrant, English is third language',
      technicalLevel: 'basic',
      primaryNeeds: ['Clear language', 'Patient pace', 'Multi-lingual'],
      accessibilityNeeds: ['Simple words', 'Visual cues', 'Native language option'],
      emotionalProfile: {
        baselineStress: 0.6,
        frustrationTolerance: 0.5,
        confusionThreshold: 0.6,
        excitementResponse: 0.6
      },
      typicalVocabulary: ['program', 'computer machine', 'install program'],
      commonMistakes: ['instal', 'programm', 'compueter'],
      successCriteria: [
        'Understands despite language barrier',
        'No complex idioms',
        'Patient with mistakes'
      ]
    },
    {
      id: 'luna',
      name: 'Luna (14, Autistic)',
      age: 14,
      background: 'Special interest in Linux, needs predictability',
      technicalLevel: 'advanced',
      primaryNeeds: ['Consistency', 'Predictability', 'Clear patterns'],
      accessibilityNeeds: ['No surprises', 'Explicit confirmations', 'Routine respect'],
      emotionalProfile: {
        baselineStress: 0.5,
        frustrationTolerance: 0.2,
        confusionThreshold: 0.3,
        excitementResponse: 0.8
      },
      typicalVocabulary: ['exactly', 'always', 'never', 'pattern', 'specific'],
      commonMistakes: [],
      successCriteria: [
        'Behavior is 100% predictable',
        'No unexpected changes',
        'Respects routines'
      ]
    }
  ];

  constructor(
    private nlpEngine: NLPEngine,
    private personalityAdapter: PersonalityAdapter,
    private uiFramework: AdaptiveUIFramework,
    private emotionIntegration: VoiceEmotionIntegration
  ) {}

  /**
   * Run comprehensive tests for all personas
   */
  async runAllTests(): Promise<PersonaTestResult[]> {
    const results: PersonaTestResult[] = [];
    
    for (const persona of this.personas) {
      console.log(`\n🧪 Testing ${persona.name}...`);
      const result = await this.testPersona(persona);
      results.push(result);
      
      // Reset system between personas
      await this.resetSystem();
    }
    
    return results;
  }

  /**
   * Test a single persona comprehensively
   */
  private async testPersona(persona: TestPersona): Promise<PersonaTestResult> {
    // Set up persona profile
    await this.setupPersonaProfile(persona);
    
    // Run realistic scenarios
    const scenarios = await this.runPersonaScenarios(persona);
    
    // Calculate detailed scores
    const scores = this.calculateDetailedScores(persona, scenarios);
    
    // Identify strengths and weaknesses
    const analysis = this.analyzeResults(persona, scenarios, scores);
    
    return {
      persona: persona.name,
      overallScore: this.calculateOverallScore(scores),
      strengths: analysis.strengths,
      weaknesses: analysis.weaknesses,
      criticalFailures: analysis.criticalFailures,
      recommendations: analysis.recommendations,
      detailedScores: scores,
      realWorldScenarios: scenarios
    };
  }

  /**
   * Run realistic scenarios for a persona
   */
  private async runPersonaScenarios(persona: TestPersona): Promise<ScenarioResult[]> {
    const scenarios = this.getPersonaScenarios(persona);
    const results: ScenarioResult[] = [];
    
    for (const scenario of scenarios) {
      const result = await this.runScenario(persona, scenario);
      results.push(result);
    }
    
    return results;
  }

  /**
   * Get realistic scenarios for each persona
   */
  private getPersonaScenarios(persona: TestPersona): string[] {
    const scenarioMap: Record<string, string[]> = {
      'grandma-rose': [
        'I want to see my grandchildren on the computer',
        'The internet stopped working',
        'Make the text bigger, I can\'t see it',
        'How do I get my photos from my phone?'
      ],
      'maya': [
        'install discord firefox vscode all at once',
        'make everything faster',
        'turn off all the annoying notifications',
        'just fix whatever is broken idc'
      ],
      'david': [
        'Kids broke the wifi again, fix it',
        'Update everything but don\'t break anything',
        'Need zoom working in 5 minutes',
        'System is slow, make it faster'
      ],
      'dr-sarah': [
        'Set up reproducible Python environment with specific versions',
        'Install R with tidyverse and bioinformatics packages',
        'Create isolated environment for TensorFlow 2.14.0',
        'Export full system configuration for paper'
      ],
      'alex': [
        'Set up development environment with accessible terminal',
        'Install screen reader friendly text editor',
        'Configure system for voice coding',
        'Debug why audio feedback stopped working'
      ],
      'carlos': [
        'Help me install that coding program',
        'I think I broke something',
        'How do I learn to use this?',
        'Make a backup before I mess up again'
      ],
      'priya': [
        'Quick install zoom I have meeting in 2 min',
        'Set up auto-save everywhere',
        'Install kids educational software',
        'Fix printer while on video call'
      ],
      'jamie': [
        'Prove no data leaves my machine',
        'Install privacy-focused browser',
        'Audit what has network access',
        'Set up encrypted communication tools'
      ],
      'viktor': [
        'Install program for write document',
        'Computer is speak English, need Russian',
        'How to make backup of important files',
        'Install video chat for family in homeland'
      ],
      'luna': [
        'Install exactly kernel 6.1.0-13 not any other version',
        'Set up my development environment exactly like yesterday',
        'Why did the terminal color change? Change it back',
        'Create script to install programs in specific order'
      ]
    };
    
    return scenarioMap[persona.id] || [];
  }

  /**
   * Run a single scenario and measure success
   */
  private async runScenario(persona: TestPersona, scenario: string): Promise<ScenarioResult> {
    const startTime = Date.now();
    let errorCount = 0;
    let frustrationPeaks = 0;
    let lastFrustration = 0;
    
    try {
      // Process through NLP
      const intent = await this.nlpEngine.processInput(scenario);
      
      if (!intent || intent.confidence < 0.7) {
        errorCount++;
      }
      
      // Simulate voice emotion
      const emotionalState = this.simulateEmotionalResponse(persona, errorCount);
      
      // Track frustration peaks
      if (emotionalState.frustration > 0.6 && emotionalState.frustration > lastFrustration) {
        frustrationPeaks++;
      }
      lastFrustration = emotionalState.frustration;
      
      // Calculate abandonment risk
      const abandonmentRisk = this.calculateAbandonmentRisk(
        persona,
        errorCount,
        frustrationPeaks,
        (Date.now() - startTime) / 1000
      );
      
      // Determine success
      const success = errorCount === 0 && abandonmentRisk < 0.5;
      
      return {
        scenario,
        success,
        timeSpent: (Date.now() - startTime) / 1000,
        errorCount,
        frustrationPeaks,
        abandonmentRisk,
        feedback: this.generateScenarioFeedback(persona, success, errorCount)
      };
      
    } catch (error) {
      return {
        scenario,
        success: false,
        timeSpent: (Date.now() - startTime) / 1000,
        errorCount: errorCount + 1,
        frustrationPeaks,
        abandonmentRisk: 1.0,
        feedback: `Critical failure: ${error}`
      };
    }
  }

  /**
   * Calculate detailed scores for persona
   */
  private calculateDetailedScores(
    persona: TestPersona,
    scenarios: ScenarioResult[]
  ): PersonaTestResult['detailedScores'] {
    const successRate = scenarios.filter(s => s.success).length / scenarios.length;
    const avgTime = scenarios.reduce((sum, s) => sum + s.timeSpent, 0) / scenarios.length;
    const avgErrors = scenarios.reduce((sum, s) => sum + s.errorCount, 0) / scenarios.length;
    const avgFrustration = scenarios.reduce((sum, s) => sum + s.frustrationPeaks, 0) / scenarios.length;
    
    return {
      nlpAccuracy: Math.max(0, (1 - avgErrors) * 100),
      personalityMatch: this.calculatePersonalityMatch(persona) * 100,
      emotionalResponse: Math.max(0, (1 - avgFrustration / 3) * 100),
      accessibility: this.calculateAccessibilityScore(persona) * 100,
      taskCompletion: successRate * 100,
      frustrationLevel: avgFrustration * 33.33,
      timeToSuccess: Math.max(0, 100 - (avgTime * 10))
    };
  }

  /**
   * Analyze results and provide honest feedback
   */
  private analyzeResults(
    persona: TestPersona,
    scenarios: ScenarioResult[],
    scores: PersonaTestResult['detailedScores']
  ): {
    strengths: string[];
    weaknesses: string[];
    criticalFailures: string[];
    recommendations: string[];
  } {
    const strengths: string[] = [];
    const weaknesses: string[] = [];
    const criticalFailures: string[] = [];
    const recommendations: string[] = [];
    
    // Analyze NLP accuracy
    if (scores.nlpAccuracy > 80) {
      strengths.push('Natural language understanding works well');
    } else if (scores.nlpAccuracy < 60) {
      weaknesses.push(`NLP accuracy too low (${scores.nlpAccuracy.toFixed(0)}%) - many commands misunderstood`);
      recommendations.push('Add more vocabulary patterns for this persona type');
    }
    
    // Analyze personality match
    if (scores.personalityMatch < 70) {
      weaknesses.push('Personality adaptation not matching user needs');
      recommendations.push('Refine personality detection algorithms');
    }
    
    // Analyze emotional response
    if (scores.frustrationLevel > 50) {
      criticalFailures.push(`High frustration levels (${scores.frustrationLevel.toFixed(0)}%) - user likely to abandon`);
      recommendations.push('Simplify interaction flow and add better error recovery');
    }
    
    // Analyze accessibility
    if (persona.accessibilityNeeds.length > 0 && scores.accessibility < 80) {
      criticalFailures.push(`Accessibility needs not met (${scores.accessibility.toFixed(0)}%)`);
      recommendations.push(`Improve: ${persona.accessibilityNeeds.join(', ')}`);
    }
    
    // Analyze task completion
    if (scores.taskCompletion < 70) {
      weaknesses.push(`Low task completion rate (${scores.taskCompletion.toFixed(0)}%)`);
    } else if (scores.taskCompletion > 90) {
      strengths.push('Excellent task completion rate');
    }
    
    // Persona-specific analysis
    this.addPersonaSpecificFeedback(persona, scores, strengths, weaknesses, recommendations);
    
    return { strengths, weaknesses, criticalFailures, recommendations };
  }

  /**
   * Add persona-specific honest feedback
   */
  private addPersonaSpecificFeedback(
    persona: TestPersona,
    scores: PersonaTestResult['detailedScores'],
    strengths: string[],
    weaknesses: string[],
    recommendations: string[]
  ) {
    switch (persona.id) {
      case 'grandma-rose':
        if (scores.timeToSuccess < 70) {
          weaknesses.push('Takes too long for simple tasks - Grandma will get confused');
        }
        if (scores.nlpAccuracy < 80) {
          criticalFailures.push('Cannot understand non-technical vocabulary');
        }
        break;
        
      case 'maya':
        if (scores.timeToSuccess < 90) {
          weaknesses.push('Too slow for ADHD users - Maya will lose focus');
        }
        if (scores.personalityMatch < 80) {
          weaknesses.push('Too much hand-holding irritates power users');
        }
        break;
        
      case 'alex':
        if (scores.accessibility < 95) {
          criticalFailures.push('NOT fully accessible - excluding blind users');
          recommendations.push('Every UI element must have screen reader support');
        }
        break;
        
      case 'luna':
        if (scores.taskCompletion < 100) {
          weaknesses.push('Inconsistent behavior will cause distress');
          recommendations.push('Ensure 100% predictable outcomes');
        }
        break;
    }
  }

  /**
   * Helper methods
   */
  private async setupPersonaProfile(persona: TestPersona) {
    // Configure system for persona
    await this.personalityAdapter.reset();
    await this.uiFramework.reset();
    this.nlpEngine.clearContext();
  }

  private simulateEmotionalResponse(persona: TestPersona, errorCount: number) {
    const frustration = Math.min(1, persona.emotionalProfile.baselineStress + 
                                   (errorCount * 0.2 / persona.emotionalProfile.frustrationTolerance));
    const confusion = errorCount > 0 ? persona.emotionalProfile.confusionThreshold : 0;
    
    return {
      frustration,
      confidence: Math.max(0, 1 - frustration),
      confusion,
      excitement: 0,
      calmness: Math.max(0, 1 - frustration - confusion),
      stress: frustration * 0.8,
      engagement: Math.max(0, 1 - frustration),
      needsHelp: confusion > 0.5 ? 1 : 0,
      certainty: 0.8,
      timestamp: new Date()
    };
  }

  private calculateAbandonmentRisk(
    persona: TestPersona,
    errorCount: number,
    frustrationPeaks: number,
    timeSpent: number
  ): number {
    let risk = 0;
    
    // Error impact
    risk += errorCount * 0.2;
    
    // Frustration impact
    risk += frustrationPeaks * 0.3;
    
    // Time impact (varies by persona)
    if (persona.id === 'maya' && timeSpent > 5) {
      risk += 0.3; // ADHD - quick abandonment
    } else if (timeSpent > 30) {
      risk += 0.2; // General patience limit
    }
    
    // Persona-specific factors
    risk *= (2 - persona.emotionalProfile.frustrationTolerance);
    
    return Math.min(1, risk);
  }

  private calculatePersonalityMatch(persona: TestPersona): number {
    // Simplified - would check actual personality adaptation
    return 0.7 + Math.random() * 0.3;
  }

  private calculateAccessibilityScore(persona: TestPersona): number {
    // Simplified - would check actual accessibility features
    if (persona.id === 'alex') {
      return 0.6; // Be honest - we're not fully accessible yet
    }
    return 0.8 + Math.random() * 0.2;
  }

  private calculateOverallScore(scores: PersonaTestResult['detailedScores']): number {
    const weights = {
      nlpAccuracy: 0.2,
      personalityMatch: 0.15,
      emotionalResponse: 0.15,
      accessibility: 0.2,
      taskCompletion: 0.2,
      frustrationLevel: -0.1,
      timeToSuccess: 0.1
    };
    
    let totalScore = 0;
    for (const [key, weight] of Object.entries(weights)) {
      if (key === 'frustrationLevel') {
        totalScore += (100 - scores[key as keyof typeof scores]) * Math.abs(weight);
      } else {
        totalScore += scores[key as keyof typeof scores] * weight;
      }
    }
    
    return Math.max(0, Math.min(100, totalScore));
  }

  private generateScenarioFeedback(persona: TestPersona, success: boolean, errorCount: number): string {
    if (success) {
      return 'Task completed successfully';
    }
    
    if (errorCount > 2) {
      return `Failed: Too many errors (${errorCount}) - ${persona.name} would have given up`;
    }
    
    return `Struggled but completed - ${persona.name} would be frustrated`;
  }

  private async resetSystem() {
    await this.personalityAdapter.reset();
    await this.uiFramework.reset();
    this.emotionIntegration.reset();
    this.nlpEngine.clearContext();
  }
}