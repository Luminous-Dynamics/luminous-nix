/**
 * Persona Test Dashboard
 * Honest visualization of how well we serve each persona
 */

import React, { useState, useEffect } from 'react';
import { PersonaTestRunner, TestReport } from './persona-test-runner';
import { PersonaTestResult } from './persona-test-framework';

export const PersonaTestDashboard: React.FC = () => {
  const [report, setReport] = useState<TestReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedPersona, setSelectedPersona] = useState<PersonaTestResult | null>(null);
  
  const runTests = async () => {
    setLoading(true);
    try {
      const runner = new PersonaTestRunner();
      const testReport = await runner.runTests();
      setReport(testReport);
    } catch (error) {
      console.error('Test failed:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const getScoreColor = (score: number): string => {
    if (score >= 85) return '#10b981'; // Green
    if (score >= 70) return '#f59e0b'; // Yellow
    if (score >= 55) return '#f97316'; // Orange
    return '#ef4444'; // Red
  };
  
  const getScoreEmoji = (score: number): string => {
    if (score >= 85) return '😊';
    if (score >= 70) return '😐';
    if (score >= 55) return '😟';
    return '😰';
  };
  
  return (
    <div className="persona-test-dashboard">
      <div className="dashboard-header">
        <h1>Persona Testing Dashboard</h1>
        <p className="subtitle">Honest assessment of how well Nix for Humanity serves each user</p>
        
        {!report && (
          <button 
            className="run-tests-btn"
            onClick={runTests}
            disabled={loading}
          >
            {loading ? 'Running Tests...' : 'Run Comprehensive Tests'}
          </button>
        )}
      </div>
      
      {report && (
        <>
          {/* Summary Card */}
          <div className="summary-card">
            <h2>Overall Summary</h2>
            <div className="summary-stats">
              <div className="stat">
                <div className="stat-value" style={{ color: getScoreColor(report.summary.averageScore) }}>
                  {report.summary.averageScore.toFixed(1)}%
                </div>
                <div className="stat-label">Average Score</div>
              </div>
              <div className="stat">
                <div className="stat-value success">{report.summary.passedPersonas}</div>
                <div className="stat-label">Passed</div>
              </div>
              <div className="stat">
                <div className="stat-value danger">{report.summary.failedPersonas}</div>
                <div className="stat-label">Failed</div>
              </div>
              <div className="stat">
                <div className="stat-value warning">{report.summary.criticalIssues}</div>
                <div className="stat-label">Critical Issues</div>
              </div>
            </div>
            
            <div className="assessment-box">
              <h3>Assessment</h3>
              <pre>{report.overallAssessment}</pre>
            </div>
          </div>
          
          {/* Persona Grid */}
          <div className="personas-grid">
            <h2>Individual Persona Results</h2>
            <div className="persona-cards">
              {report.personaResults.map((result) => (
                <div 
                  key={result.persona}
                  className="persona-card"
                  onClick={() => setSelectedPersona(result)}
                  style={{ borderColor: getScoreColor(result.overallScore) }}
                >
                  <div className="persona-header">
                    <h3>{result.persona}</h3>
                    <span className="score-emoji">{getScoreEmoji(result.overallScore)}</span>
                  </div>
                  
                  <div className="score-circle" style={{ borderColor: getScoreColor(result.overallScore) }}>
                    <span className="score-value">{result.overallScore.toFixed(0)}%</span>
                  </div>
                  
                  <div className="mini-scores">
                    <div className="mini-score">
                      <span className="label">NLP</span>
                      <span className="value">{result.detailedScores.nlpAccuracy.toFixed(0)}%</span>
                    </div>
                    <div className="mini-score">
                      <span className="label">Tasks</span>
                      <span className="value">{result.detailedScores.taskCompletion.toFixed(0)}%</span>
                    </div>
                    <div className="mini-score">
                      <span className="label">A11y</span>
                      <span className="value">{result.detailedScores.accessibility.toFixed(0)}%</span>
                    </div>
                  </div>
                  
                  {result.criticalFailures.length > 0 && (
                    <div className="critical-badge">
                      ❌ {result.criticalFailures.length} Critical
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          {/* Critical Issues */}
          {report.criticalFailuresSummary.length > 0 && (
            <div className="critical-issues">
              <h2>❌ Critical Failures</h2>
              <div className="issues-list">
                {report.criticalFailuresSummary.map((issue, i) => (
                  <div key={i} className="issue-item">
                    {issue}
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Accessibility Gaps */}
          {report.accessibilityGaps.length > 0 && (
            <div className="accessibility-gaps">
              <h2>♿ Accessibility Gaps</h2>
              <div className="gaps-list">
                {report.accessibilityGaps.map((gap, i) => (
                  <div key={i} className="gap-item">
                    {gap}
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Recommendations */}
          <div className="recommendations">
            <h2>💡 Top Recommendations</h2>
            <ol className="recommendations-list">
              {report.topRecommendations.map((rec, i) => (
                <li key={i}>{rec}</li>
              ))}
            </ol>
          </div>
        </>
      )}
      
      {/* Persona Detail Modal */}
      {selectedPersona && (
        <div className="modal-overlay" onClick={() => setSelectedPersona(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>{selectedPersona.persona}</h2>
            <button className="close-btn" onClick={() => setSelectedPersona(null)}>×</button>
            
            <div className="detailed-scores">
              <h3>Detailed Scores</h3>
              <div className="score-bars">
                {Object.entries(selectedPersona.detailedScores).map(([key, value]) => (
                  <div key={key} className="score-bar-item">
                    <span className="label">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                    <div className="bar-container">
                      <div 
                        className="bar-fill"
                        style={{ 
                          width: `${Math.abs(value)}%`,
                          backgroundColor: getScoreColor(value)
                        }}
                      />
                    </div>
                    <span className="value">{value.toFixed(0)}%</span>
                  </div>
                ))}
              </div>
            </div>
            
            {selectedPersona.strengths.length > 0 && (
              <div className="section">
                <h3>✅ Strengths</h3>
                <ul>
                  {selectedPersona.strengths.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ul>
              </div>
            )}
            
            {selectedPersona.weaknesses.length > 0 && (
              <div className="section">
                <h3>⚠️ Weaknesses</h3>
                <ul>
                  {selectedPersona.weaknesses.map((w, i) => (
                    <li key={i}>{w}</li>
                  ))}
                </ul>
              </div>
            )}
            
            {selectedPersona.criticalFailures.length > 0 && (
              <div className="section critical">
                <h3>❌ Critical Failures</h3>
                <ul>
                  {selectedPersona.criticalFailures.map((f, i) => (
                    <li key={i}>{f}</li>
                  ))}
                </ul>
              </div>
            )}
            
            {selectedPersona.recommendations.length > 0 && (
              <div className="section">
                <h3>💡 Recommendations</h3>
                <ul>
                  {selectedPersona.recommendations.map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </div>
            )}
            
            <div className="scenarios">
              <h3>Scenario Results</h3>
              {selectedPersona.realWorldScenarios.map((scenario, i) => (
                <div key={i} className="scenario-item">
                  <div className="scenario-header">
                    <span className="scenario-text">"{scenario.scenario}"</span>
                    <span className={`scenario-result ${scenario.success ? 'success' : 'failure'}`}>
                      {scenario.success ? '✅' : '❌'}
                    </span>
                  </div>
                  <div className="scenario-details">
                    <span>Time: {scenario.timeSpent.toFixed(1)}s</span>
                    <span>Errors: {scenario.errorCount}</span>
                    <span>Abandonment Risk: {(scenario.abandonmentRisk * 100).toFixed(0)}%</span>
                  </div>
                  <div className="scenario-feedback">{scenario.feedback}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
      
      <style jsx>{`
        .persona-test-dashboard {
          max-width: 1200px;
          margin: 0 auto;
          padding: 2rem;
          font-family: -apple-system, system-ui, sans-serif;
        }
        
        .dashboard-header {
          text-align: center;
          margin-bottom: 3rem;
        }
        
        .dashboard-header h1 {
          color: #1f2937;
          margin-bottom: 0.5rem;
        }
        
        .subtitle {
          color: #6b7280;
          font-size: 1.125rem;
        }
        
        .run-tests-btn {
          margin-top: 2rem;
          padding: 1rem 2rem;
          font-size: 1.125rem;
          background: #3b82f6;
          color: white;
          border: none;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.2s;
        }
        
        .run-tests-btn:hover:not(:disabled) {
          background: #2563eb;
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }
        
        .run-tests-btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }
        
        .summary-card {
          background: white;
          border-radius: 12px;
          padding: 2rem;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
          margin-bottom: 3rem;
        }
        
        .summary-card h2 {
          margin: 0 0 1.5rem 0;
          color: #1f2937;
        }
        
        .summary-stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 2rem;
          margin-bottom: 2rem;
        }
        
        .stat {
          text-align: center;
        }
        
        .stat-value {
          font-size: 3rem;
          font-weight: bold;
          margin-bottom: 0.5rem;
        }
        
        .stat-value.success {
          color: #10b981;
        }
        
        .stat-value.danger {
          color: #ef4444;
        }
        
        .stat-value.warning {
          color: #f59e0b;
        }
        
        .stat-label {
          color: #6b7280;
          font-size: 0.875rem;
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }
        
        .assessment-box {
          background: #f9fafb;
          border-radius: 8px;
          padding: 1.5rem;
        }
        
        .assessment-box h3 {
          margin: 0 0 1rem 0;
          color: #1f2937;
        }
        
        .assessment-box pre {
          white-space: pre-wrap;
          font-family: inherit;
          margin: 0;
          color: #4b5563;
          line-height: 1.6;
        }
        
        .personas-grid h2 {
          margin: 0 0 1.5rem 0;
          color: #1f2937;
        }
        
        .persona-cards {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
          gap: 1.5rem;
          margin-bottom: 3rem;
        }
        
        .persona-card {
          background: white;
          border-radius: 12px;
          padding: 1.5rem;
          border: 3px solid;
          cursor: pointer;
          transition: all 0.2s;
          position: relative;
        }
        
        .persona-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }
        
        .persona-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1rem;
        }
        
        .persona-header h3 {
          margin: 0;
          font-size: 1rem;
          color: #1f2937;
        }
        
        .score-emoji {
          font-size: 1.5rem;
        }
        
        .score-circle {
          width: 100px;
          height: 100px;
          border-radius: 50%;
          border: 4px solid;
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 1rem auto;
        }
        
        .score-value {
          font-size: 1.5rem;
          font-weight: bold;
        }
        
        .mini-scores {
          display: flex;
          justify-content: space-around;
          margin-top: 1rem;
        }
        
        .mini-score {
          text-align: center;
        }
        
        .mini-score .label {
          display: block;
          font-size: 0.75rem;
          color: #6b7280;
          margin-bottom: 0.25rem;
        }
        
        .mini-score .value {
          font-weight: 600;
          color: #1f2937;
        }
        
        .critical-badge {
          position: absolute;
          top: 0.5rem;
          right: 0.5rem;
          background: #fee;
          color: #dc2626;
          padding: 0.25rem 0.5rem;
          border-radius: 4px;
          font-size: 0.75rem;
          font-weight: 600;
        }
        
        .critical-issues,
        .accessibility-gaps,
        .recommendations {
          background: white;
          border-radius: 12px;
          padding: 2rem;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
          margin-bottom: 2rem;
        }
        
        .critical-issues h2,
        .accessibility-gaps h2,
        .recommendations h2 {
          margin: 0 0 1.5rem 0;
          color: #1f2937;
        }
        
        .issues-list,
        .gaps-list {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }
        
        .issue-item,
        .gap-item {
          padding: 1rem;
          background: #fee;
          color: #dc2626;
          border-radius: 6px;
          border-left: 4px solid #dc2626;
        }
        
        .gap-item {
          background: #fef3c7;
          color: #d97706;
          border-color: #d97706;
        }
        
        .recommendations-list {
          margin: 0;
          padding-left: 1.5rem;
        }
        
        .recommendations-list li {
          margin-bottom: 0.75rem;
          color: #4b5563;
        }
        
        /* Modal */
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 2rem;
        }
        
        .modal-content {
          background: white;
          border-radius: 12px;
          padding: 2rem;
          max-width: 800px;
          max-height: 90vh;
          overflow-y: auto;
          position: relative;
        }
        
        .modal-content h2 {
          margin: 0 0 1.5rem 0;
          color: #1f2937;
        }
        
        .close-btn {
          position: absolute;
          top: 1rem;
          right: 1rem;
          background: none;
          border: none;
          font-size: 2rem;
          color: #6b7280;
          cursor: pointer;
        }
        
        .close-btn:hover {
          color: #1f2937;
        }
        
        .detailed-scores {
          margin-bottom: 2rem;
        }
        
        .detailed-scores h3 {
          margin: 0 0 1rem 0;
          color: #1f2937;
        }
        
        .score-bars {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }
        
        .score-bar-item {
          display: grid;
          grid-template-columns: 150px 1fr 50px;
          align-items: center;
          gap: 1rem;
        }
        
        .score-bar-item .label {
          font-size: 0.875rem;
          color: #4b5563;
          text-transform: capitalize;
        }
        
        .bar-container {
          height: 20px;
          background: #f3f4f6;
          border-radius: 10px;
          overflow: hidden;
        }
        
        .bar-fill {
          height: 100%;
          transition: width 0.5s ease;
        }
        
        .score-bar-item .value {
          font-weight: 600;
          text-align: right;
        }
        
        .section {
          margin-bottom: 2rem;
        }
        
        .section h3 {
          margin: 0 0 0.75rem 0;
          color: #1f2937;
        }
        
        .section ul {
          margin: 0;
          padding-left: 1.5rem;
        }
        
        .section li {
          margin-bottom: 0.5rem;
          color: #4b5563;
        }
        
        .section.critical li {
          color: #dc2626;
        }
        
        .scenarios {
          margin-top: 2rem;
        }
        
        .scenarios h3 {
          margin: 0 0 1rem 0;
          color: #1f2937;
        }
        
        .scenario-item {
          background: #f9fafb;
          border-radius: 8px;
          padding: 1rem;
          margin-bottom: 1rem;
        }
        
        .scenario-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 0.5rem;
        }
        
        .scenario-text {
          flex: 1;
          font-style: italic;
          color: #4b5563;
        }
        
        .scenario-result {
          font-size: 1.25rem;
          margin-left: 1rem;
        }
        
        .scenario-details {
          display: flex;
          gap: 1rem;
          font-size: 0.875rem;
          color: #6b7280;
          margin-bottom: 0.5rem;
        }
        
        .scenario-feedback {
          font-size: 0.875rem;
          color: #4b5563;
          font-style: italic;
        }
      `}</style>
    </div>
  );
};