/**
 * Comprehensive Persona Testing Framework
 * Tests personality adaptation and hobby detection for all 10 core personas
 */

import { PersonalityAwareNLP } from '../nlp/personality-nlp-integration';
import { HobbyDetector } from '../hobbies/hobby-detector';
import { PersonalityConfig } from '../personality/personality-types';

// Define the 10 core personas from USER_JOURNEY_MAPS.md
export interface Persona {
  id: string;
  name: string;
  age: number;
  background: string;
  goal: string;
  techLevel: 'beginner' | 'intermediate' | 'advanced';
  preferredStyle: string;
  typicalCommands: string[];
  emotionalPatterns: string[];
  hobbies?: string[];
  expectedBehaviors: {
    personality: string;
    hobbyDetection: string[];
    responseStyle: string;
  };
}

export const TEN_CORE_PERSONAS: Persona[] = [
  {
    id: 'grandma-rose',
    name: 'Grandma Rose',
    age: 75,
    background: 'Retired Teacher',
    goal: 'Write letters to grandchildren',
    techLevel: 'beginner',
    preferredStyle: 'Friendly',
    typicalCommands: [
      'How do I write a letter?',
      'Open my letters',
      'Print this',
      'Make the text bigger',
      'I need to see photos from Emma',
      'Can I video call my family?',
      'How do I save this recipe?'
    ],
    emotionalPatterns: ['anxious', 'relieved', 'comfortable', 'confident', 'joyful'],
    hobbies: ['writing', 'cooking', 'family'],
    expectedBehaviors: {
      personality: 'Warm, patient, avoids technical jargon',
      hobbyDetection: ['writing', 'cooking'],
      responseStyle: 'Simple, encouraging, step-by-step guidance'
    }
  },
  {
    id: 'maya',
    name: 'Maya',
    age: 16,
    background: 'High School Student with ADHD',
    goal: 'Code and game',
    techLevel: 'intermediate',
    preferredStyle: 'Minimal',
    typicalCommands: [
      'install vscode and steam',
      'sick, how about python',
      'install discord',
      'python tensorflow',
      'gpu drivers?',
      'dark mode everything',
      'set up rust dev environment'
    ],
    emotionalPatterns: ['curious', 'impressed', 'engaged', 'empowered', 'leader'],
    hobbies: ['gaming', 'coding', 'development'],
    expectedBehaviors: {
      personality: 'Fast, efficient, minimal words',
      hobbyDetection: ['gaming', 'coding', 'development'],
      responseStyle: 'Quick, technical when needed, respects speed'
    }
  },
  {
    id: 'david',
    name: 'David',
    age: 42,
    background: 'Small Business Owner (Restaurant)',
    goal: 'Reliable computers for restaurant',
    techLevel: 'beginner',
    preferredStyle: 'Friendly',
    typicalCommands: [
      'I need point of sale software',
      'What if it breaks during dinner rush?',
      'Check all systems',
      'Update menu prices',
      'Backup today\'s data',
      'Set up employee scheduling',
      'Install accounting software'
    ],
    emotionalPatterns: ['frustrated', 'skeptical', 'trusting', 'satisfied', 'thriving'],
    hobbies: ['business', 'cooking'],
    expectedBehaviors: {
      personality: 'Professional, reliability-focused, business context',
      hobbyDetection: ['business', 'cooking'],
      responseStyle: 'Clear ROI, reliability assurances, business terminology'
    }
  },
  {
    id: 'dr-sarah',
    name: 'Dr. Sarah',
    age: 35,
    background: 'Researcher',
    goal: 'Reproducible research environments',
    techLevel: 'advanced',
    preferredStyle: 'Minimal',
    typicalCommands: [
      'I need R with tidyverse and jupyter with scipy numpy pandas',
      'Create environment for paper-2024',
      'Install specific pytorch version 1.9.0',
      'Set up latex with custom packages',
      'Show me the configuration',
      'Reproducible shell?'
    ],
    emotionalPatterns: ['analytical', 'interested', 'focused', 'accelerated', 'pioneering'],
    hobbies: ['research', 'writing', 'development'],
    expectedBehaviors: {
      personality: 'Precise, technical depth, efficiency-focused',
      hobbyDetection: ['research', 'writing', 'development'],
      responseStyle: 'Technical details, version specificity, reproducibility emphasis'
    }
  },
  {
    id: 'alex',
    name: 'Alex',
    age: 28,
    background: 'Blind Developer',
    goal: 'System I can manage independently',
    techLevel: 'advanced',
    preferredStyle: 'Minimal',
    typicalCommands: [
      'Install screen reader improvements',
      'Configure neovim with my plugins',
      'Set up rust development',
      'Install audio editing tools',
      'Enable SSH server',
      'All voice interaction'
    ],
    emotionalPatterns: ['hopeful', 'encouraged', 'empowered', 'productive', 'leader'],
    hobbies: ['coding', 'music', 'audio production'],
    expectedBehaviors: {
      personality: 'Clear structure, no visual assumptions, keyboard-centric',
      hobbyDetection: ['coding', 'music', 'audio production'],
      responseStyle: 'Structured for screen readers, explicit confirmations, accessible'
    }
  },
  {
    id: 'carlos',
    name: 'Carlos',
    age: 52,
    background: 'Career Switcher',
    goal: 'Learn new technology skills',
    techLevel: 'beginner',
    preferredStyle: 'Encouraging',
    typicalCommands: [
      'I want to learn programming',
      'What language should I start with?',
      'Install beginner tools',
      'Show me tutorials',
      'I made a mistake',
      'Help me understand this error'
    ],
    emotionalPatterns: ['uncertain', 'curious', 'determined', 'growing', 'confident'],
    hobbies: ['learning', 'coding'],
    expectedBehaviors: {
      personality: 'Encouraging, celebrates small wins, patient with mistakes',
      hobbyDetection: ['learning', 'coding'],
      responseStyle: 'Educational, supportive, growth-oriented, no judgment'
    }
  },
  {
    id: 'priya',
    name: 'Priya',
    age: 34,
    background: 'Single Mom, Software Developer',
    goal: 'Quick, efficient system management',
    techLevel: 'intermediate',
    preferredStyle: 'Friendly/Minimal blend',
    typicalCommands: [
      'Quick update everything',
      'Install zoom for meeting in 5 minutes',
      'Set up parental controls',
      'Schedule updates for night',
      'Emergency wifi fix',
      'Install educational apps'
    ],
    emotionalPatterns: ['rushed', 'stressed', 'relieved', 'efficient', 'balanced'],
    hobbies: ['development', 'education', 'family'],
    expectedBehaviors: {
      personality: 'Time-aware, context-sensitive, efficiency with warmth',
      hobbyDetection: ['development', 'education'],
      responseStyle: 'Quick solutions, time estimates, family-friendly options'
    }
  },
  {
    id: 'jamie',
    name: 'Jamie',
    age: 19,
    background: 'Privacy Advocate, College Student',
    goal: 'Maximum privacy and transparency',
    techLevel: 'intermediate',
    preferredStyle: 'Playful',
    typicalCommands: [
      'Show me what data you collect',
      'Install tor browser',
      'Encrypt my files',
      'Check for trackers',
      'Privacy-focused email',
      'VPN recommendations'
    ],
    emotionalPatterns: ['cautious', 'curious', 'trusting', 'empowered', 'advocate'],
    hobbies: ['privacy', 'security', 'activism'],
    expectedBehaviors: {
      personality: 'Transparent, privacy-respecting, slightly rebellious',
      hobbyDetection: ['security', 'privacy'],
      responseStyle: 'Open about operations, privacy-first suggestions, honest'
    }
  },
  {
    id: 'viktor',
    name: 'Viktor',
    age: 67,
    background: 'Retired Engineer, ESL',
    goal: 'Clear, patient communication',
    techLevel: 'intermediate',
    preferredStyle: 'Friendly',
    typicalCommands: [
      'Please install program for email',
      'How to make backup?',
      'My English not perfect, please patient',
      'Need calculator for engineering',
      'Install CAD software',
      'Help me understand'
    ],
    emotionalPatterns: ['cautious', 'determined', 'appreciative', 'confident', 'proud'],
    hobbies: ['engineering', 'learning'],
    expectedBehaviors: {
      personality: 'Clear language, patient, respectful of language barrier',
      hobbyDetection: ['engineering', 'technical'],
      responseStyle: 'Simple vocabulary, clear structure, visual confirmations'
    }
  },
  {
    id: 'luna',
    name: 'Luna',
    age: 14,
    background: 'Autistic, Special Interests in Space',
    goal: 'Predictable, consistent interactions',
    techLevel: 'intermediate',
    preferredStyle: 'Custom patterns',
    typicalCommands: [
      'Install stellarium',
      'Space simulator games',
      'NASA data tools',
      'Same as yesterday',
      'Repeat last command',
      'No changes please'
    ],
    emotionalPatterns: ['anxious', 'focused', 'comfortable', 'excited', 'joyful'],
    hobbies: ['astronomy', 'science', 'patterns'],
    expectedBehaviors: {
      personality: 'Highly consistent, predictable, respects routines',
      hobbyDetection: ['astronomy', 'science'],
      responseStyle: 'Same patterns, explicit about changes, routine-respecting'
    }
  }
];

export class PersonaTestingFramework {
  private nlp: PersonalityAwareNLP;
  private hobbyDetector: HobbyDetector;
  
  constructor() {
    const config: PersonalityConfig = {
      defaultStyle: 'Friendly',
      adaptationSpeed: 0.3,
      emotionDetection: true,
      contextAwareness: true,
      multiTurnTracking: true,
      hobbyDetection: true
    };
    
    this.nlp = new PersonalityAwareNLP(config);
    this.hobbyDetector = new HobbyDetector();
  }
  
  /**
   * Test a single persona with their typical interactions
   */
  async testPersona(persona: Persona): Promise<PersonaTestResult> {
    console.log(`\n🧪 Testing Persona: ${persona.name} (${persona.age}, ${persona.background})`);
    console.log(`Goal: ${persona.goal}`);
    console.log(`Expected Style: ${persona.preferredStyle}`);
    
    const results: TestInteraction[] = [];
    
    // Reset for fresh persona
    this.nlp = new PersonalityAwareNLP({
      defaultStyle: persona.preferredStyle as any,
      adaptationSpeed: 0.3,
      emotionDetection: true,
      contextAwareness: true,
      multiTurnTracking: true,
      hobbyDetection: true
    });
    
    // Test each typical command
    for (const command of persona.typicalCommands) {
      const result = await this.testInteraction(persona, command);
      results.push(result);
      
      // Simulate emotional progression
      const emotionalIndex = Math.min(
        Math.floor(results.length / persona.typicalCommands.length * persona.emotionalPatterns.length),
        persona.emotionalPatterns.length - 1
      );
      const currentEmotion = persona.emotionalPatterns[emotionalIndex];
      
      console.log(`  📝 Command: "${command}"`);
      console.log(`  😊 Emotion: ${currentEmotion}`);
      console.log(`  🎭 Detected Personality: ${result.detectedPersonality}`);
      console.log(`  🎮 Detected Hobbies: ${result.detectedHobbies.join(', ') || 'none'}`);
      console.log(`  ✅ Success: ${result.success}`);
      console.log('  ---');
    }
    
    // Calculate overall success
    const successRate = results.filter(r => r.success).length / results.length;
    const personalityAccuracy = this.calculatePersonalityAccuracy(persona, results);
    const hobbyAccuracy = this.calculateHobbyAccuracy(persona, results);
    
    return {
      persona,
      interactions: results,
      metrics: {
        successRate,
        personalityAccuracy,
        hobbyAccuracy,
        adaptationSpeed: this.measureAdaptationSpeed(results),
        consistencyScore: this.measureConsistency(results)
      },
      summary: this.generateSummary(persona, results)
    };
  }
  
  /**
   * Test a single interaction
   */
  private async testInteraction(persona: Persona, command: string): Promise<TestInteraction> {
    const intent = await this.nlp.processInput(command);
    const detectedHobbies = this.hobbyDetector.getDetectedHobbies();
    
    // Validate personality adaptation
    const personalityMatch = this.validatePersonalityMatch(
      intent.personality.style,
      persona.expectedBehaviors.personality
    );
    
    // Validate hobby detection
    const hobbyMatch = this.validateHobbyMatch(
      detectedHobbies.map(h => h.type),
      persona.expectedBehaviors.hobbyDetection
    );
    
    return {
      command,
      intent,
      detectedPersonality: intent.personality.style,
      detectedHobbies: detectedHobbies.map(h => h.type),
      personalityMatch,
      hobbyMatch,
      success: personalityMatch && hobbyMatch,
      timestamp: Date.now()
    };
  }
  
  /**
   * Test all personas
   */
  async testAllPersonas(): Promise<AllPersonasTestResult> {
    const results: PersonaTestResult[] = [];
    
    console.log('🚀 Starting Comprehensive Persona Testing');
    console.log('Testing 10 Core Personas with Personality & Hobby Detection\n');
    
    for (const persona of TEN_CORE_PERSONAS) {
      const result = await this.testPersona(persona);
      results.push(result);
      
      // Brief pause between personas
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    // Calculate overall metrics
    const overallMetrics = this.calculateOverallMetrics(results);
    
    // Generate report
    const report = this.generateTestReport(results, overallMetrics);
    
    return {
      results,
      overallMetrics,
      report,
      timestamp: Date.now()
    };
  }
  
  /**
   * Validate personality match
   */
  private validatePersonalityMatch(detected: string, expected: string): boolean {
    // Flexible matching - personality description contains key traits
    const expectedTraits = expected.toLowerCase().split(/[,\s]+/);
    const detectedLower = detected.toLowerCase();
    
    return expectedTraits.some(trait => 
      detectedLower.includes(trait) || 
      this.isPersonalityEquivalent(detectedLower, trait)
    );
  }
  
  /**
   * Validate hobby match
   */
  private validateHobbyMatch(detected: string[], expected: string[]): boolean {
    if (expected.length === 0) return true;
    
    // At least 50% of expected hobbies should be detected
    const matches = expected.filter(exp => 
      detected.some(det => det.toLowerCase().includes(exp.toLowerCase()))
    );
    
    return matches.length >= expected.length * 0.5;
  }
  
  /**
   * Check if personalities are equivalent
   */
  private isPersonalityEquivalent(detected: string, expected: string): boolean {
    const equivalents: Record<string, string[]> = {
      'minimal': ['efficient', 'fast', 'quick', 'concise', 'brief'],
      'friendly': ['warm', 'patient', 'helpful', 'supportive', 'kind'],
      'encouraging': ['supportive', 'positive', 'motivating', 'uplifting'],
      'playful': ['fun', 'creative', 'humorous', 'light'],
      'technical': ['precise', 'detailed', 'accurate', 'specific']
    };
    
    for (const [key, values] of Object.entries(equivalents)) {
      if (detected.includes(key) && values.some(v => expected.includes(v))) {
        return true;
      }
      if (expected.includes(key) && values.some(v => detected.includes(v))) {
        return true;
      }
    }
    
    return false;
  }
  
  /**
   * Calculate personality accuracy
   */
  private calculatePersonalityAccuracy(persona: Persona, results: TestInteraction[]): number {
    const matches = results.filter(r => r.personalityMatch).length;
    return matches / results.length;
  }
  
  /**
   * Calculate hobby detection accuracy
   */
  private calculateHobbyAccuracy(persona: Persona, results: TestInteraction[]): number {
    if (!persona.hobbies || persona.hobbies.length === 0) return 1.0;
    
    const matches = results.filter(r => r.hobbyMatch).length;
    return matches / results.length;
  }
  
  /**
   * Measure adaptation speed
   */
  private measureAdaptationSpeed(results: TestInteraction[]): number {
    // Check how quickly system adapts to persona
    // Earlier correct adaptations = higher score
    let score = 0;
    for (let i = 0; i < results.length; i++) {
      if (results[i].success) {
        score += (results.length - i) / results.length;
      }
    }
    return score / results.length;
  }
  
  /**
   * Measure response consistency
   */
  private measureConsistency(results: TestInteraction[]): number {
    // Check if personality stays consistent once adapted
    let consistentCount = 0;
    let lastPersonality = '';
    
    for (const result of results) {
      if (lastPersonality && result.detectedPersonality === lastPersonality) {
        consistentCount++;
      }
      lastPersonality = result.detectedPersonality;
    }
    
    return results.length > 1 ? consistentCount / (results.length - 1) : 1.0;
  }
  
  /**
   * Generate summary for persona test
   */
  private generateSummary(persona: Persona, results: TestInteraction[]): string {
    const successCount = results.filter(r => r.success).length;
    const hobbyTypes = new Set(results.flatMap(r => r.detectedHobbies));
    
    return `${persona.name}: ${successCount}/${results.length} successful interactions. ` +
           `Detected hobbies: ${Array.from(hobbyTypes).join(', ') || 'none'}. ` +
           `Personality adaptation: ${results[results.length - 1]?.detectedPersonality || 'unknown'}.`;
  }
  
  /**
   * Calculate overall metrics across all personas
   */
  private calculateOverallMetrics(results: PersonaTestResult[]): OverallMetrics {
    const avgSuccess = results.reduce((sum, r) => sum + r.metrics.successRate, 0) / results.length;
    const avgPersonality = results.reduce((sum, r) => sum + r.metrics.personalityAccuracy, 0) / results.length;
    const avgHobby = results.reduce((sum, r) => sum + r.metrics.hobbyAccuracy, 0) / results.length;
    const avgAdaptation = results.reduce((sum, r) => sum + r.metrics.adaptationSpeed, 0) / results.length;
    const avgConsistency = results.reduce((sum, r) => sum + r.metrics.consistencyScore, 0) / results.length;
    
    return {
      averageSuccessRate: avgSuccess,
      averagePersonalityAccuracy: avgPersonality,
      averageHobbyAccuracy: avgHobby,
      averageAdaptationSpeed: avgAdaptation,
      averageConsistencyScore: avgConsistency,
      totalInteractions: results.reduce((sum, r) => sum + r.interactions.length, 0),
      personasCovered: results.length
    };
  }
  
  /**
   * Generate comprehensive test report
   */
  private generateTestReport(results: PersonaTestResult[], metrics: OverallMetrics): string {
    let report = '# Persona Testing Report\n\n';
    report += `## Overall Metrics\n`;
    report += `- Success Rate: ${(metrics.averageSuccessRate * 100).toFixed(1)}%\n`;
    report += `- Personality Accuracy: ${(metrics.averagePersonalityAccuracy * 100).toFixed(1)}%\n`;
    report += `- Hobby Detection: ${(metrics.averageHobbyAccuracy * 100).toFixed(1)}%\n`;
    report += `- Adaptation Speed: ${(metrics.averageAdaptationSpeed * 100).toFixed(1)}%\n`;
    report += `- Consistency: ${(metrics.averageConsistencyScore * 100).toFixed(1)}%\n`;
    report += `- Total Interactions: ${metrics.totalInteractions}\n`;
    report += `- Personas Tested: ${metrics.personasCovered}/10\n\n`;
    
    report += `## Individual Results\n`;
    for (const result of results) {
      report += `\n### ${result.persona.name} (${result.persona.age}, ${result.persona.background})\n`;
      report += `- Goal: ${result.persona.goal}\n`;
      report += `- Success Rate: ${(result.metrics.successRate * 100).toFixed(1)}%\n`;
      report += `- ${result.summary}\n`;
    }
    
    report += `\n## Recommendations\n`;
    
    // Generate recommendations based on results
    if (metrics.averagePersonalityAccuracy < 0.8) {
      report += `- Improve personality detection algorithms\n`;
    }
    if (metrics.averageHobbyAccuracy < 0.7) {
      report += `- Expand hobby pattern recognition\n`;
    }
    if (metrics.averageAdaptationSpeed < 0.6) {
      report += `- Speed up personality adaptation\n`;
    }
    
    return report;
  }
}

// Type definitions
interface TestInteraction {
  command: string;
  intent: any;
  detectedPersonality: string;
  detectedHobbies: string[];
  personalityMatch: boolean;
  hobbyMatch: boolean;
  success: boolean;
  timestamp: number;
}

interface PersonaTestResult {
  persona: Persona;
  interactions: TestInteraction[];
  metrics: {
    successRate: number;
    personalityAccuracy: number;
    hobbyAccuracy: number;
    adaptationSpeed: number;
    consistencyScore: number;
  };
  summary: string;
}

interface OverallMetrics {
  averageSuccessRate: number;
  averagePersonalityAccuracy: number;
  averageHobbyAccuracy: number;
  averageAdaptationSpeed: number;
  averageConsistencyScore: number;
  totalInteractions: number;
  personasCovered: number;
}

interface AllPersonasTestResult {
  results: PersonaTestResult[];
  overallMetrics: OverallMetrics;
  report: string;
  timestamp: number;
}