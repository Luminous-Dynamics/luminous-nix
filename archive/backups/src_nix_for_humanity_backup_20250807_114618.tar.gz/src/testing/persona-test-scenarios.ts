/**
 * Detailed test scenarios for each persona
 * These represent realistic interaction patterns
 */

export interface TestScenario {
  personaId: string;
  scenarioName: string;
  description: string;
  interactions: {
    input: string;
    expectedIntent: string;
    expectedPersonality: string[];
    expectedHobbies?: string[];
    expectedResponse: string;
  }[];
}

export const PERSONA_TEST_SCENARIOS: TestScenario[] = [
  // Grandma Rose - Warm, patient, non-technical
  {
    personaId: 'grandma-rose',
    scenarioName: 'Morning Letter Writing',
    description: 'Rose wants to write a letter to her grandchildren',
    interactions: [
      {
        input: "I want to write a letter to Emma",
        expectedIntent: 'document.create',
        expectedPersonality: ['friendly', 'warm', 'patient'],
        expectedHobbies: ['writing'],
        expectedResponse: "I'll help you write a letter to Emma! Let me open a word processor for you. Would you like me to set up a nice letter template?"
      },
      {
        input: "How do I make the text bigger? My eyes aren't what they used to be",
        expectedIntent: 'accessibility.font.increase',
        expectedPersonality: ['understanding', 'helpful'],
        expectedResponse: "Of course! I'll make the text larger so it's easier to read. There, I've increased the font size. Is this better for you?"
      },
      {
        input: "Can you save this somewhere I can find it?",
        expectedIntent: 'file.save',
        expectedPersonality: ['organized', 'thoughtful'],
        expectedHobbies: ['writing'],
        expectedResponse: "I'll save your letter in a folder called 'My Letters' on your desktop where it's easy to find. I've named it 'Letter to Emma' with today's date."
      }
    ]
  },
  
  // Maya - Fast, technical, ADHD-friendly
  {
    personaId: 'maya',
    scenarioName: 'Gaming and Coding Setup',
    description: 'Maya setting up her development and gaming environment',
    interactions: [
      {
        input: "install vscode steam discord rust",
        expectedIntent: 'package.install.multiple',
        expectedPersonality: ['minimal', 'efficient'],
        expectedHobbies: ['gaming', 'coding'],
        expectedResponse: "Installing: VS Code, Steam, Discord, Rust. Done in 45s. VS Code has Rust analyzer pre-configured."
      },
      {
        input: "dark mode everything now",
        expectedIntent: 'theme.change',
        expectedPersonality: ['quick', 'responsive'],
        expectedResponse: "Dark mode enabled system-wide. Apps will follow."
      },
      {
        input: "gpu for tensorflow?",
        expectedIntent: 'hardware.query',
        expectedPersonality: ['technical', 'concise'],
        expectedHobbies: ['development', 'ml'],
        expectedResponse: "NVIDIA GPU detected. Installing CUDA 12.1 and cuDNN. TensorFlow GPU ready in 2 min."
      }
    ]
  },
  
  // David - Business owner, reliability focused
  {
    personaId: 'david',
    scenarioName: 'Restaurant System Setup',
    description: 'David needs reliable point-of-sale and backup systems',
    interactions: [
      {
        input: "I need software for my restaurant's cash register",
        expectedIntent: 'business.pos.setup',
        expectedPersonality: ['professional', 'reliable'],
        expectedHobbies: ['business'],
        expectedResponse: "I'll set up a reliable point-of-sale system for your restaurant. Square POS is popular and works offline too. Should I install it?"
      },
      {
        input: "What happens if the internet goes down during dinner rush?",
        expectedIntent: 'reliability.query',
        expectedPersonality: ['reassuring', 'thorough'],
        expectedResponse: "Don't worry - Square POS stores all transactions offline and syncs when internet returns. You won't lose any sales. I'll also set up automatic local backups every hour."
      },
      {
        input: "Can you backup everything automatically?",
        expectedIntent: 'backup.configure',
        expectedPersonality: ['proactive', 'business-minded'],
        expectedHobbies: ['business'],
        expectedResponse: "I'll set up automatic daily backups at 3 AM when you're closed. They'll save to both local storage and cloud. You'll get a summary email each morning confirming the backup succeeded."
      }
    ]
  },
  
  // Dr. Sarah - Researcher, precision and reproducibility
  {
    personaId: 'dr-sarah',
    scenarioName: 'Research Environment Setup',
    description: 'Sarah needs reproducible scientific computing environment',
    interactions: [
      {
        input: "Create isolated environment: R 4.3.1, tidyverse 2.0.0, ggplot2 3.4.4",
        expectedIntent: 'environment.create',
        expectedPersonality: ['precise', 'technical'],
        expectedHobbies: ['research', 'data science'],
        expectedResponse: "Creating reproducible environment 'research-env' with exact versions. Generating lock file for perfect reproduction. Shell activation: `nix-shell research-env`"
      },
      {
        input: "Need LaTeX with bioinformatics packages for Nature submission",
        expectedIntent: 'document.setup',
        expectedPersonality: ['knowledgeable', 'academic'],
        expectedHobbies: ['research', 'writing'],
        expectedResponse: "Installing TeXLive with nature, bioinformatics, and bibliography packages. Template for Nature submissions included. Reproducible build ensures exact formatting."
      },
      {
        input: "Show configuration for peer review reproduction",
        expectedIntent: 'config.display',
        expectedPersonality: ['transparent', 'systematic'],
        expectedResponse: "Generated `reproduction.nix` with all dependencies pinned. Colleagues run: `nix-shell reproduction.nix` for identical environment. SHA256 hashes guarantee exact reproduction."
      }
    ]
  },
  
  // Alex - Blind developer, screen reader optimized
  {
    personaId: 'alex',
    scenarioName: 'Accessible Development Setup',
    description: 'Alex setting up fully accessible coding environment',
    interactions: [
      {
        input: "optimize everything for screen readers",
        expectedIntent: 'accessibility.optimize',
        expectedPersonality: ['thoughtful', 'structured'],
        expectedHobbies: ['coding', 'accessibility'],
        expectedResponse: "Optimizing for screen readers: Enabled semantic navigation. Configured verbose command feedback. Set keyboard-only operation. Disabled animations. Testing with NVDA... All systems accessible."
      },
      {
        input: "install neovim with my screen reader config",
        expectedIntent: 'editor.setup',
        expectedPersonality: ['knowledgeable', 'precise'],
        expectedHobbies: ['coding'],
        expectedResponse: "Installing Neovim with screen reader optimizations. Loading your config from ~/.config/nvim. Enabled: line numbers spoken, syntax described, navigation by semantic blocks. Ready for coding."
      },
      {
        input: "setup audio production tools",
        expectedIntent: 'audio.setup',
        expectedPersonality: ['understanding', 'thorough'],
        expectedHobbies: ['music', 'audio'],
        expectedResponse: "Installing Reaper (fully accessible DAW), Audacity, and JACK audio. Configured hotkeys for screen reader compatibility. Audio interface detected and configured. Want me to test audio routing?"
      }
    ]
  },
  
  // Carlos - Career switcher, learning focused
  {
    personaId: 'carlos',
    scenarioName: 'Learning Programming Journey',
    description: 'Carlos starting his programming education',
    interactions: [
      {
        input: "I want to learn programming but don't know where to start",
        expectedIntent: 'education.programming.start',
        expectedPersonality: ['encouraging', 'supportive'],
        expectedHobbies: ['learning', 'coding'],
        expectedResponse: "That's exciting! Python is great for beginners - it reads almost like English. Shall I set up Python with a friendly learning environment? I'll include interactive tutorials too!"
      },
      {
        input: "I tried to run my code but got an error and I don't understand it",
        expectedIntent: 'error.help',
        expectedPersonality: ['patient', 'educational'],
        expectedResponse: "No worries - errors are how we learn! Can you share the error message? I'll explain what it means in simple terms and help you fix it. Remember, even experienced programmers see errors daily!"
      },
      {
        input: "Am I too old to learn this?",
        expectedIntent: 'encouragement.request',
        expectedPersonality: ['inspiring', 'supportive'],
        expectedHobbies: ['learning'],
        expectedResponse: "Never! Many successful programmers started later in life. You bring valuable life experience that younger learners don't have. Let's take it one step at a time. You're doing great!"
      }
    ]
  },
  
  // Priya - Time-pressed parent developer
  {
    personaId: 'priya',
    scenarioName: 'Quick Work Setup During Naptime',
    description: 'Priya needs fast, efficient setup while kids nap',
    interactions: [
      {
        input: "quick install zoom meeting in 5 mins",
        expectedIntent: 'package.install.urgent',
        expectedPersonality: ['efficient', 'time-aware'],
        expectedHobbies: ['development'],
        expectedResponse: "Installing Zoom priority mode. Ready in 90 seconds. Auto-launching when done. Webcam and mic will be tested automatically."
      },
      {
        input: "schedule all updates for 2am please",
        expectedIntent: 'maintenance.schedule',
        expectedPersonality: ['understanding', 'family-aware'],
        expectedResponse: "Updates scheduled for 2 AM. System will stay quiet during day. If urgent security update appears, I'll ask first."
      },
      {
        input: "need kids educational apps but safe ones",
        expectedIntent: 'software.parental',
        expectedPersonality: ['protective', 'knowledgeable'],
        expectedHobbies: ['education', 'family'],
        expectedResponse: "Installing: GCompris (pre-school), Scratch Jr (coding for kids), Tux Math. All offline-capable, no ads, no in-app purchases. Parental controls enabled."
      }
    ]
  },
  
  // Jamie - Privacy advocate
  {
    personaId: 'jamie',
    scenarioName: 'Privacy-First Setup',
    description: 'Jamie wants maximum privacy and transparency',
    interactions: [
      {
        input: "what data are you collecting about me?",
        expectedIntent: 'privacy.query',
        expectedPersonality: ['transparent', 'honest'],
        expectedHobbies: ['privacy', 'security'],
        expectedResponse: "I collect zero data externally. All learning stays on your device in ~/.local/nix-humanity/. You can view, export, or delete it anytime. No telemetry, no analytics, no cloud sync unless you explicitly enable it."
      },
      {
        input: "install most private browser and email",
        expectedIntent: 'privacy.tools.install',
        expectedPersonality: ['knowledgeable', 'rebellious'],
        expectedHobbies: ['privacy'],
        expectedResponse: "Installing Tor Browser and Thunderbird with Enigmail. Adding ProtonMail bridge. Config includes: no telemetry, encrypted profiles, auto-clear cookies. Your privacy is sacred here."
      },
      {
        input: "show me the source code for your learning algorithm",
        expectedIntent: 'transparency.code',
        expectedPersonality: ['open', 'technical'],
        expectedResponse: "Here's the learning algorithm: [shows code]. It's all local pattern matching - no ML model uploads. The code is MIT licensed. Want me to explain any specific part?"
      }
    ]
  },
  
  // Viktor - ESL, patient communication needed
  {
    personaId: 'viktor',
    scenarioName: 'Clear Communication Setup',
    description: 'Viktor needs clear, simple English communication',
    interactions: [
      {
        input: "Please to install program for calculate engineering",
        expectedIntent: 'engineering.software',
        expectedPersonality: ['patient', 'clear'],
        expectedHobbies: ['engineering'],
        expectedResponse: "I'll install engineering calculator programs for you. Installing: SciDAVis for data, Octave for calculations, FreeCAD for design. I'll use simple English to explain each one."
      },
      {
        input: "I not understand how make backup",
        expectedIntent: 'help.backup',
        expectedPersonality: ['patient', 'visual'],
        expectedResponse: "I'll show you step by step: 1) Click 'Backup' button (I marked it). 2) Choose what to save. 3) Click 'Start'. Backup happens automatically every week too. Want me to show you?"
      },
      {
        input: "My English not perfect, sorry",
        expectedIntent: 'communication.acknowledge',
        expectedPersonality: ['respectful', 'encouraging'],
        expectedResponse: "Your English is fine! I understand you well. I'll use simple words and can repeat anything. Many users speak English as second language. Please ask if anything is unclear."
      }
    ]
  },
  
  // Luna - Autistic, needs consistency
  {
    personaId: 'luna',
    scenarioName: 'Predictable Space Interest Setup',
    description: 'Luna needs consistent, predictable interactions',
    interactions: [
      {
        input: "install stellarium exactly like yesterday",
        expectedIntent: 'package.install.repeat',
        expectedPersonality: ['consistent', 'precise'],
        expectedHobbies: ['astronomy'],
        expectedResponse: "Installing Stellarium exactly as before: version 0.22.2, same settings, same desktop location. No changes to your configuration. It will look exactly the same."
      },
      {
        input: "list all space programs in alphabetical order",
        expectedIntent: 'query.organized',
        expectedPersonality: ['structured', 'predictable'],
        expectedHobbies: ['astronomy', 'space'],
        expectedResponse: "Space programs installed (alphabetical): Celestia, Gpredict, KStars, Stellarium, VirtualMoon. Same order as always. No new programs added without asking you first."
      },
      {
        input: "use the same words as last time",
        expectedIntent: 'communication.consistent',
        expectedPersonality: ['reliable', 'unchanging'],
        expectedResponse: "Understood. I'll use the same phrasing and structure as our previous conversations. Consistency is important. No surprises or changes in how I communicate."
      }
    ]
  }
];

// Helper function to get scenarios for a specific persona
export function getScenariosForPersona(personaId: string): TestScenario[] {
  return PERSONA_TEST_SCENARIOS.filter(s => s.personaId === personaId);
}

// Helper function to validate if response matches expected patterns
export function validateResponse(
  actual: string, 
  expected: string,
  personalityTraits: string[]
): boolean {
  // Check if key concepts are present
  const expectedConcepts = expected.toLowerCase().split(/\s+/)
    .filter(word => word.length > 4); // Key words
  
  const actualLower = actual.toLowerCase();
  const conceptMatches = expectedConcepts.filter(concept => 
    actualLower.includes(concept)
  ).length;
  
  // At least 30% of key concepts should match
  const conceptScore = conceptMatches / expectedConcepts.length;
  
  // Check personality traits in response
  const traitMatches = personalityTraits.filter(trait => {
    // Check if response exhibits the trait
    return evaluatePersonalityTrait(actual, trait);
  }).length;
  
  const traitScore = traitMatches / personalityTraits.length;
  
  // Combined score
  return conceptScore >= 0.3 && traitScore >= 0.5;
}

// Evaluate if response exhibits a personality trait
function evaluatePersonalityTrait(response: string, trait: string): boolean {
  const traitIndicators: Record<string, string[]> = {
    'friendly': ['!', 'happy to', 'glad to', 'help you', 'of course'],
    'warm': ['dear', 'wonderful', 'lovely', 'nice'],
    'patient': ['no worries', 'take your time', 'step by step', "that's okay"],
    'minimal': ['.', ':', '-'], // Short sentences
    'efficient': ['done', 'ready', 'complete', 'sec', 'min'],
    'technical': ['SHA256', 'config', 'version', 'compile', 'binary'],
    'encouraging': ['great', 'excellent', 'doing well', 'can do', '!'],
    'consistent': ['same', 'exactly', 'as before', 'unchanged'],
    'transparent': ['here\'s', 'showing', 'source', 'how it works']
  };
  
  const indicators = traitIndicators[trait] || [];
  return indicators.some(indicator => response.toLowerCase().includes(indicator));
}