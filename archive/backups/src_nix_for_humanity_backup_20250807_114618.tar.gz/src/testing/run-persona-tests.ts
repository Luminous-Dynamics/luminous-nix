#!/usr/bin/env ts-node

/**
 * Run comprehensive persona tests
 * Tests all 10 personas with personality adaptation and hobby detection
 */

import { PersonaTestingFramework } from './persona-testing-framework';
import * as fs from 'fs';
import * as path from 'path';

async function runTests() {
  console.log('🌟 Nix for Humanity - Comprehensive Persona Testing');
  console.log('='.repeat(60));
  console.log('Testing personality adaptation and hobby detection');
  console.log('for all 10 core personas...\n');
  
  const framework = new PersonaTestingFramework();
  
  try {
    // Run all tests
    const startTime = Date.now();
    const results = await framework.testAllPersonas();
    const duration = Date.now() - startTime;
    
    // Display results
    console.log('\n' + '='.repeat(60));
    console.log('📊 Test Results Summary');
    console.log('='.repeat(60));
    
    const metrics = results.overallMetrics;
    console.log(`✅ Overall Success Rate: ${(metrics.averageSuccessRate * 100).toFixed(1)}%`);
    console.log(`🎭 Personality Accuracy: ${(metrics.averagePersonalityAccuracy * 100).toFixed(1)}%`);
    console.log(`🎮 Hobby Detection Rate: ${(metrics.averageHobbyAccuracy * 100).toFixed(1)}%`);
    console.log(`⚡ Adaptation Speed: ${(metrics.averageAdaptationSpeed * 100).toFixed(1)}%`);
    console.log(`🔄 Consistency Score: ${(metrics.averageConsistencyScore * 100).toFixed(1)}%`);
    console.log(`\n📝 Total Interactions Tested: ${metrics.totalInteractions}`);
    console.log(`👥 Personas Covered: ${metrics.personasCovered}/10`);
    console.log(`⏱️  Test Duration: ${(duration / 1000).toFixed(1)}s`);
    
    // Save detailed report
    const reportDir = path.join(__dirname, '../../test-results');
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true });
    }
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const reportPath = path.join(reportDir, `persona-test-report-${timestamp}.md`);
    fs.writeFileSync(reportPath, results.report);
    
    console.log(`\n📄 Detailed report saved to: ${reportPath}`);
    
    // Determine pass/fail
    const PASSING_THRESHOLD = 0.8; // 80% success rate
    if (metrics.averageSuccessRate >= PASSING_THRESHOLD) {
      console.log('\n✅ All tests PASSED! The system successfully adapts to all personas.');
    } else {
      console.log(`\n❌ Tests need improvement. Success rate ${(metrics.averageSuccessRate * 100).toFixed(1)}% is below ${PASSING_THRESHOLD * 100}% threshold.`);
    }
    
    // Show areas for improvement
    if (metrics.averagePersonalityAccuracy < 0.9) {
      console.log('\n💡 Suggestion: Improve personality detection for better adaptation');
    }
    if (metrics.averageHobbyAccuracy < 0.8) {
      console.log('💡 Suggestion: Enhance hobby pattern recognition');
    }
    if (metrics.averageAdaptationSpeed < 0.7) {
      console.log('💡 Suggestion: Speed up initial personality detection');
    }
    
  } catch (error) {
    console.error('\n❌ Error during testing:', error);
    process.exit(1);
  }
}

// Run if executed directly
if (require.main === module) {
  runTests()
    .then(() => {
      console.log('\n✨ Testing complete!');
      process.exit(0);
    })
    .catch(error => {
      console.error('Fatal error:', error);
      process.exit(1);
    });
}

export { runTests };