/**
 * Privacy Transparency Component
 * Clear, honest explanation of all privacy aspects
 */

import React, { useState } from 'react';
import { Shield, Eye, Lock, Database, Cloud, Home, Heart } from 'lucide-react';

interface PrivacySection {
  id: string;
  title: string;
  icon: React.ReactNode;
  description: string;
  details: string[];
  dataCollected: string[];
  dataNotCollected: string[];
  userControl: string[];
}

export const PrivacyTransparency: React.FC<{
  onComplete: (choices: PrivacyChoices) => void;
}> = ({ onComplete }) => {
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const [choices, setChoices] = useState<PrivacyChoices>({
    acceptedSections: [],
    readSections: [],
    questions: []
  });
  
  const privacySections: PrivacySection[] = [
    {
      id: 'voice',
      title: 'Voice & Speech Processing',
      icon: <span className="text-2xl">🎤</span>,
      description: 'How we handle your voice commands',
      details: [
        'Voice is processed locally using Whisper.cpp',
        'No audio is sent to any servers',
        'Temporary audio buffers are deleted immediately',
        'Voice emotion detection happens on-device'
      ],
      dataCollected: [
        'Temporary audio for processing (deleted after)',
        'Detected emotions (frustration, confidence)',
        'Speech patterns for better recognition'
      ],
      dataNotCollected: [
        'Actual voice recordings',
        'Personal identifiers from voice',
        'Conversation history'
      ],
      userControl: [
        'Turn off voice anytime',
        'Clear voice adaptation data',
        'Choose which emotions to detect',
        'Disable voice storage completely'
      ]
    },
    {
      id: 'gestures',
      title: 'Interaction Patterns',
      icon: <span className="text-2xl">👆</span>,
      description: 'How we learn from your mouse/touch patterns',
      details: [
        'Detects hesitation, confusion, confidence',
        'All processing happens locally',
        'Patterns are anonymized',
        'Used only to offer help when needed'
      ],
      dataCollected: [
        'General movement patterns (not coordinates)',
        'Click timing and frequency',
        'Scroll behaviors',
        'Time between actions'
      ],
      dataNotCollected: [
        'What you click on specifically',
        'Text you type',
        'Websites you visit',
        'Personal information'
      ],
      userControl: [
        'Opt-in required before activation',
        'Turn off instantly',
        'Delete all pattern data',
        'Customize sensitivity'
      ]
    },
    {
      id: 'adaptation',
      title: 'Learning & Adaptation',
      icon: <span className="text-2xl">🧠</span>,
      description: 'How the system learns your preferences',
      details: [
        'Remembers your complexity level',
        'Learns your preferred interaction style',
        'Adapts language to your comfort',
        'All learning stays on your device'
      ],
      dataCollected: [
        'Preferred complexity level (0-10)',
        'Successful command patterns',
        'Feature usage frequency',
        'Time of day preferences'
      ],
      dataNotCollected: [
        'Personal data from commands',
        'File contents or names',
        'Network activity',
        'Other application data'
      ],
      userControl: [
        'Reset learning anytime',
        'Export your preferences',
        'Disable adaptation',
        'Manual control only mode'
      ]
    },
    {
      id: 'emotions',
      title: 'Emotional Awareness',
      icon: <span className="text-2xl">💝</span>,
      description: 'How we detect and respond to emotions',
      details: [
        'Detects stress, confusion, confidence',
        'Used to simplify or offer help',
        'Never judges or profiles you',
        'Emotions are not stored long-term'
      ],
      dataCollected: [
        'Current emotional indicators',
        'Stress patterns for adaptation',
        'Success/frustration ratios',
        'Comfort zone boundaries'
      ],
      dataNotCollected: [
        'Emotional history or profiles',
        'Medical or health data',
        'Psychological assessments',
        'Mood tracking over time'
      ],
      userControl: [
        'Disable emotion detection',
        'Choose which emotions to track',
        'Set adaptation sensitivity',
        'Clear emotional data'
      ]
    },
    {
      id: 'storage',
      title: 'Data Storage & Security',
      icon: <span className="text-2xl">🔒</span>,
      description: 'Where your data lives and how it\'s protected',
      details: [
        'Everything stays on YOUR device',
        'No cloud services or accounts',
        'Data encrypted at rest',
        'You own and control everything'
      ],
      dataCollected: [
        'Settings and preferences',
        'Command history (optional)',
        'Learning adaptations',
        'Theme and UI choices'
      ],
      dataNotCollected: [
        'Data is NEVER sent anywhere',
        'No analytics or tracking',
        'No third-party sharing',
        'No advertising profiles'
      ],
      userControl: [
        'Delete everything with one click',
        'Export all your data',
        'Choose what to save',
        'Full transparency'
      ]
    }
  ];
  
  const toggleSection = (sectionId: string) => {
    setExpandedSection(expandedSection === sectionId ? null : sectionId);
    
    // Mark as read
    if (!choices.readSections.includes(sectionId)) {
      setChoices(prev => ({
        ...prev,
        readSections: [...prev.readSections, sectionId]
      }));
    }
  };
  
  const acceptSection = (sectionId: string) => {
    setChoices(prev => ({
      ...prev,
      acceptedSections: prev.acceptedSections.includes(sectionId)
        ? prev.acceptedSections.filter(id => id !== sectionId)
        : [...prev.acceptedSections, sectionId]
    }));
  };
  
  const allSectionsRead = choices.readSections.length === privacySections.length;
  
  return (
    <div className="privacy-transparency max-w-4xl mx-auto">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
          <Shield className="w-8 h-8 text-blue-600" />
        </div>
        <h2 className="text-2xl font-bold mb-2">Your Privacy Matters</h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          We believe in complete transparency. Here's exactly how Nix for Humanity 
          protects your privacy while providing helpful features.
        </p>
      </div>
      
      {/* Key Principles */}
      <div className="grid md:grid-cols-3 gap-4 mb-8">
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <Home className="w-6 h-6 text-green-600 mb-2" />
          <h3 className="font-semibold text-green-900">Local Only</h3>
          <p className="text-sm text-green-800">
            Everything stays on your device. No cloud, no servers, no accounts.
          </p>
        </div>
        
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <Lock className="w-6 h-6 text-blue-600 mb-2" />
          <h3 className="font-semibold text-blue-900">You Control Everything</h3>
          <p className="text-sm text-blue-800">
            Turn features on/off instantly. Delete data anytime. Export what's yours.
          </p>
        </div>
        
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
          <Eye className="w-6 h-6 text-purple-600 mb-2" />
          <h3 className="font-semibold text-purple-900">Full Transparency</h3>
          <p className="text-sm text-purple-800">
            See exactly what we track and why. No hidden behaviors or dark patterns.
          </p>
        </div>
      </div>
      
      {/* Detailed Sections */}
      <div className="space-y-4 mb-8">
        {privacySections.map((section) => (
          <div
            key={section.id}
            className={`
              border rounded-lg transition-all
              ${expandedSection === section.id 
                ? 'border-blue-300 shadow-lg' 
                : 'border-gray-200 hover:border-gray-300'
              }
            `}
          >
            {/* Section Header */}
            <button
              onClick={() => toggleSection(section.id)}
              className="w-full p-4 flex items-center justify-between text-left"
            >
              <div className="flex items-center space-x-3">
                {section.icon}
                <div>
                  <h3 className="font-semibold">{section.title}</h3>
                  <p className="text-sm text-gray-600">{section.description}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                {choices.readSections.includes(section.id) && (
                  <span className="text-green-600 text-sm">✓ Read</span>
                )}
                <span className="text-gray-400">
                  {expandedSection === section.id ? '▼' : '▶'}
                </span>
              </div>
            </button>
            
            {/* Expanded Content */}
            {expandedSection === section.id && (
              <div className="border-t px-4 py-4 space-y-4">
                {/* How it works */}
                <div>
                  <h4 className="font-medium mb-2">How it works:</h4>
                  <ul className="space-y-1">
                    {section.details.map((detail, i) => (
                      <li key={i} className="flex items-start text-sm">
                        <span className="text-blue-600 mr-2">•</span>
                        <span>{detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                {/* What we collect */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="bg-yellow-50 rounded-lg p-3">
                    <h5 className="font-medium text-yellow-900 mb-2">
                      What we track:
                    </h5>
                    <ul className="space-y-1">
                      {section.dataCollected.map((item, i) => (
                        <li key={i} className="text-sm text-yellow-800">
                          • {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="bg-green-50 rounded-lg p-3">
                    <h5 className="font-medium text-green-900 mb-2">
                      What we DON'T track:
                    </h5>
                    <ul className="space-y-1">
                      {section.dataNotCollected.map((item, i) => (
                        <li key={i} className="text-sm text-green-800">
                          • {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                
                {/* User control */}
                <div className="bg-blue-50 rounded-lg p-3">
                  <h5 className="font-medium text-blue-900 mb-2">
                    Your controls:
                  </h5>
                  <ul className="space-y-1">
                    {section.userControl.map((control, i) => (
                      <li key={i} className="text-sm text-blue-800">
                        ✓ {control}
                      </li>
                    ))}
                  </ul>
                </div>
                
                {/* Accept/Decline */}
                <div className="flex items-center justify-between pt-2">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={choices.acceptedSections.includes(section.id)}
                      onChange={() => acceptSection(section.id)}
                      className="mr-3 h-4 w-4 text-blue-600 rounded"
                    />
                    <span className="text-sm font-medium">
                      Enable {section.title.toLowerCase()}
                    </span>
                  </label>
                  
                  <button className="text-sm text-blue-600 hover:text-blue-700">
                    Learn more →
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
      
      {/* Summary */}
      <div className="bg-gray-50 rounded-lg p-6 mb-6">
        <h3 className="font-semibold mb-3">Privacy Summary:</h3>
        <div className="grid md:grid-cols-2 gap-4 text-sm">
          <div>
            <h4 className="font-medium text-green-700 mb-1">✅ We Promise:</h4>
            <ul className="space-y-1 text-gray-600">
              <li>• Never sell or share your data</li>
              <li>• Everything stays on your device</li>
              <li>• You can delete everything anytime</li>
              <li>• No hidden tracking or analytics</li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium text-blue-700 mb-1">🛡️ You Control:</h4>
            <ul className="space-y-1 text-gray-600">
              <li>• Which features to enable</li>
              <li>• What data to keep</li>
              <li>• When to delete data</li>
              <li>• How sensitive adaptation is</li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Actions */}
      <div className="flex justify-between items-center">
        <button
          onClick={() => onComplete({
            ...choices,
            acceptedSections: []
          })}
          className="text-gray-600 hover:text-gray-800"
        >
          Skip for now
        </button>
        
        <button
          onClick={() => onComplete(choices)}
          disabled={!allSectionsRead}
          className={`
            px-6 py-3 rounded-lg font-medium transition-all
            ${allSectionsRead
              ? 'bg-blue-600 hover:bg-blue-700 text-white'
              : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }
          `}
        >
          Continue with selected features
        </button>
      </div>
      
      {/* Trust Badge */}
      <div className="text-center mt-8 text-sm text-gray-500">
        <Heart className="w-4 h-4 inline mr-1 text-red-500" />
        Built with respect for your privacy and autonomy
      </div>
    </div>
  );
};

interface PrivacyChoices {
  acceptedSections: string[];
  readSections: string[];
  questions: string[];
}