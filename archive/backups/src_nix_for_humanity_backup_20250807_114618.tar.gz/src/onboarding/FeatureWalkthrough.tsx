/**
 * Feature Walkthrough Component
 * Optional guided tour of each feature
 */

import React, { useState } from 'react';
import { Play, Pause, SkipForward, Check, Info } from 'lucide-react';
import { SimplifiedInterface } from '../ui/visual-simplification/SimplifiedInterface';
import { VoiceInterface } from '../voice/VoiceInterface';
import { LevelControl } from '../ui/visual-simplification/SimplifiedInterface';
import { ThemeSelector } from '../ui/color-themes/ThemeSelector';

interface Feature {
  id: string;
  name: string;
  description: string;
  duration: string;
  emoji: string;
  enabled: boolean;
  demo: React.ReactNode;
  benefits: string[];
  howToUse: string[];
  tips: string[];
}

export const FeatureWalkthrough: React.FC<{
  enabledFeatures: string[];
  onComplete: (viewedFeatures: string[]) => void;
}> = ({ enabledFeatures, onComplete }) => {
  const [currentFeature, setCurrentFeature] = useState(0);
  const [viewedFeatures, setViewedFeatures] = useState<string[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  
  const features: Feature[] = [
    {
      id: 'voice',
      name: 'Voice Commands',
      description: 'Speak naturally to control NixOS',
      duration: '2 min',
      emoji: '🎤',
      enabled: enabledFeatures.includes('voice'),
      demo: <VoiceDemo />,
      benefits: [
        'Hands-free operation',
        'Natural language understanding',
        'Emotion-aware responses',
        'No memorization needed'
      ],
      howToUse: [
        'Click the microphone button or say "Hey Nix"',
        'Speak your request naturally',
        'Wait for confirmation',
        'Say "no" to cancel or "yes" to confirm'
      ],
      tips: [
        'Speak clearly but naturally',
        'You can interrupt anytime',
        'Try: "Install Firefox" or "Update my system"'
      ]
    },
    {
      id: 'simplification',
      name: 'Adaptive Complexity',
      description: 'Interface that grows with you',
      duration: '1 min',
      emoji: '🎚️',
      enabled: enabledFeatures.includes('adaptation'),
      demo: <SimplificationDemo />,
      benefits: [
        'Never feel overwhelmed',
        'See more as you learn',
        'Automatic or manual control',
        'Perfect for all skill levels'
      ],
      howToUse: [
        'System adapts automatically',
        'Use the slider to manually adjust',
        'Level 0 = Simplest, Level 10 = Everything',
        'Your preference is remembered'
      ],
      tips: [
        'Start simple and let it grow',
        'High stress? It simplifies automatically',
        'Feeling confident? More features appear'
      ]
    },
    {
      id: 'themes',
      name: 'Emotional Color Themes',
      description: 'Colors that match your mood',
      duration: '1 min',
      emoji: '🎨',
      enabled: true, // Always enabled
      demo: <ThemeDemo />,
      benefits: [
        'Reduce eye strain',
        'Match your environment',
        'Emotional comfort',
        'Accessibility options'
      ],
      howToUse: [
        'Choose from preset themes',
        'Themes can change by time of day',
        'Adapt to your emotional state',
        'Full colorblind support'
      ],
      tips: [
        'Try Sanctuary when stressed',
        'Night Owl for evening work',
        'High Contrast for clarity'
      ]
    },
    {
      id: 'gestures',
      name: 'Gesture Recognition',
      description: 'Help when you need it',
      duration: '2 min',
      emoji: '👆',
      enabled: enabledFeatures.includes('gestures'),
      demo: <GestureDemo />,
      benefits: [
        'Automatic help when confused',
        'No need to ask for assistance',
        'Learns your patterns',
        'Completely private'
      ],
      howToUse: [
        'Just use the interface normally',
        'Hesitation is detected and help offered',
        'Confusion triggers simplification',
        'All processing stays local'
      ],
      tips: [
        'You control sensitivity',
        'Turn off anytime in settings',
        'Data never leaves your device'
      ]
    },
    {
      id: 'personality',
      name: 'Adaptive Personality',
      description: 'Responses that match your style',
      duration: '1 min',
      emoji: '💬',
      enabled: true, // Always enabled
      demo: <PersonalityDemo />,
      benefits: [
        'Communication you prefer',
        'From minimal to encouraging',
        'Adapts to your mood',
        'Never condescending'
      ],
      howToUse: [
        'System learns your preference',
        'Changes based on context',
        'You can set manually too',
        'Different for different tasks'
      ],
      tips: [
        'Frustrated? It becomes more patient',
        'Confident? It gets out of your way',
        'Always respectful'
      ]
    }
  ];
  
  // Filter to only enabled features
  const availableFeatures = features.filter(f => f.enabled);
  const currentFeatureData = availableFeatures[currentFeature];
  
  const handleNext = () => {
    if (!viewedFeatures.includes(currentFeatureData.id)) {
      setViewedFeatures([...viewedFeatures, currentFeatureData.id]);
    }
    
    if (currentFeature < availableFeatures.length - 1) {
      setCurrentFeature(currentFeature + 1);
      setIsPlaying(false);
      setShowDetails(false);
    }
  };
  
  const handleSkipAll = () => {
    onComplete(viewedFeatures);
  };
  
  const handleComplete = () => {
    if (!viewedFeatures.includes(currentFeatureData.id)) {
      setViewedFeatures([...viewedFeatures, currentFeatureData.id]);
    }
    onComplete(viewedFeatures);
  };
  
  if (availableFeatures.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600 mb-4">
          No features selected for walkthrough
        </p>
        <button
          onClick={() => onComplete([])}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg"
        >
          Continue
        </button>
      </div>
    );
  }
  
  return (
    <div className="feature-walkthrough max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold">Feature Walkthrough</h2>
          <p className="text-gray-600">
            Learn about your enabled features ({currentFeature + 1} of {availableFeatures.length})
          </p>
        </div>
        
        <button
          onClick={handleSkipAll}
          className="text-gray-600 hover:text-gray-800"
        >
          Skip all →
        </button>
      </div>
      
      {/* Progress */}
      <div className="flex space-x-2 mb-8">
        {availableFeatures.map((feature, index) => (
          <div
            key={feature.id}
            className={`
              flex-1 h-2 rounded-full transition-colors
              ${index < currentFeature ? 'bg-green-500' :
                index === currentFeature ? 'bg-blue-500' :
                'bg-gray-200'}
            `}
          />
        ))}
      </div>
      
      {/* Current Feature */}
      <div className="grid md:grid-cols-2 gap-8">
        {/* Demo Side */}
        <div className="bg-gray-50 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <span className="text-4xl">{currentFeatureData.emoji}</span>
              <div>
                <h3 className="text-xl font-semibold">{currentFeatureData.name}</h3>
                <p className="text-sm text-gray-600">{currentFeatureData.duration}</p>
              </div>
            </div>
            
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-2 bg-white rounded-lg shadow hover:shadow-md transition-shadow"
            >
              {isPlaying ? <Pause size={20} /> : <Play size={20} />}
            </button>
          </div>
          
          <div className="bg-white rounded-lg p-4 min-h-[300px]">
            {isPlaying ? currentFeatureData.demo : (
              <div className="flex items-center justify-center h-full text-gray-400">
                <div className="text-center">
                  <Play size={48} className="mx-auto mb-2" />
                  <p>Click play to see demo</p>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Info Side */}
        <div className="space-y-6">
          <div>
            <h4 className="font-semibold mb-2">{currentFeatureData.description}</h4>
            
            {/* Benefits */}
            <div className="bg-green-50 rounded-lg p-4 mb-4">
              <h5 className="font-medium text-green-900 mb-2">Benefits:</h5>
              <ul className="space-y-1">
                {currentFeatureData.benefits.map((benefit, i) => (
                  <li key={i} className="flex items-start text-sm text-green-800">
                    <Check size={16} className="mr-2 mt-0.5 flex-shrink-0" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            {/* How to Use */}
            <div className="bg-blue-50 rounded-lg p-4 mb-4">
              <h5 className="font-medium text-blue-900 mb-2">How to use:</h5>
              <ol className="space-y-1">
                {currentFeatureData.howToUse.map((step, i) => (
                  <li key={i} className="flex items-start text-sm text-blue-800">
                    <span className="font-medium mr-2">{i + 1}.</span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </div>
            
            {/* Tips */}
            <button
              onClick={() => setShowDetails(!showDetails)}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center"
            >
              <Info size={16} className="mr-1" />
              {showDetails ? 'Hide' : 'Show'} pro tips
            </button>
            
            {showDetails && (
              <div className="mt-2 bg-yellow-50 rounded-lg p-4">
                <h5 className="font-medium text-yellow-900 mb-2">Pro tips:</h5>
                <ul className="space-y-1">
                  {currentFeatureData.tips.map((tip, i) => (
                    <li key={i} className="text-sm text-yellow-800">
                      💡 {tip}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
          
          {/* Actions */}
          <div className="flex justify-between items-center pt-4">
            <div className="text-sm text-gray-600">
              {viewedFeatures.includes(currentFeatureData.id) && (
                <span className="text-green-600">✓ Viewed</span>
              )}
            </div>
            
            <div className="space-x-3">
              {currentFeature === availableFeatures.length - 1 ? (
                <button
                  onClick={handleComplete}
                  className="px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium"
                >
                  Complete Walkthrough
                </button>
              ) : (
                <button
                  onClick={handleNext}
                  className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium flex items-center"
                >
                  Next Feature
                  <SkipForward size={16} className="ml-2" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Demo Components

const VoiceDemo: React.FC = () => (
  <div className="p-4 text-center">
    <div className="mb-4">
      <div className="w-24 h-24 mx-auto bg-blue-100 rounded-full flex items-center justify-center animate-pulse">
        <span className="text-4xl">🎤</span>
      </div>
    </div>
    <p className="text-gray-600 mb-4">Try saying:</p>
    <div className="space-y-2">
      <div className="bg-gray-100 rounded-lg p-2 text-sm">
        "Install Firefox"
      </div>
      <div className="bg-gray-100 rounded-lg p-2 text-sm">
        "Update my system"
      </div>
      <div className="bg-gray-100 rounded-lg p-2 text-sm">
        "What's taking up space?"
      </div>
    </div>
  </div>
);

const SimplificationDemo: React.FC = () => (
  <SimplifiedInterface initialLevel={5}>
    <div className="p-4">
      <h4 className="font-semibold mb-2">Complexity Level Demo</h4>
      <p className="text-sm text-gray-600 mb-4">
        Move the slider to see how the interface adapts
      </p>
      <LevelControl />
      <div className="mt-4 space-y-2">
        <button className="w-full p-2 bg-blue-600 text-white rounded">
          Main Action
        </button>
        <div className="grid grid-cols-2 gap-2">
          <button className="p-2 bg-gray-200 rounded">Option A</button>
          <button className="p-2 bg-gray-200 rounded">Option B</button>
        </div>
      </div>
    </div>
  </SimplifiedInterface>
);

const ThemeDemo: React.FC = () => (
  <div className="p-4">
    <div className="grid grid-cols-2 gap-3">
      {[
        { name: 'Sanctuary', color: '#F7F8FA', emoji: '🌅' },
        { name: 'Night Owl', color: '#121212', emoji: '🌙' },
        { name: 'Ocean', color: '#F0FCFF', emoji: '🌊' },
        { name: 'Focus', color: '#FAFAFA', emoji: '🎯' }
      ].map(theme => (
        <button
          key={theme.name}
          className="p-4 rounded-lg border-2 border-gray-200 hover:border-blue-300 transition-colors"
          style={{ backgroundColor: theme.color }}
        >
          <div className="text-2xl mb-1">{theme.emoji}</div>
          <div className="text-sm font-medium">{theme.name}</div>
        </button>
      ))}
    </div>
  </div>
);

const GestureDemo: React.FC = () => (
  <div className="p-4">
    <div className="bg-gray-100 rounded-lg p-8 relative">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-gray-400">
          <p className="text-center mb-2">Move your mouse here</p>
          <div className="flex justify-center space-x-4">
            <div className="text-center">
              <div className="w-16 h-16 bg-white rounded-lg mb-1"></div>
              <p className="text-xs">Hover</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-white rounded-lg mb-1"></div>
              <p className="text-xs">Click</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Animated cursor */}
      <div className="absolute top-1/2 left-1/2 w-4 h-4 bg-blue-600 rounded-full animate-bounce" />
    </div>
    
    <div className="mt-4 text-center text-sm text-gray-600">
      <p>When you hesitate, we notice and offer help</p>
      <p className="text-xs mt-1">(All processing stays on your device)</p>
    </div>
  </div>
);

const PersonalityDemo: React.FC = () => {
  const [style, setStyle] = useState('friendly');
  
  const responses = {
    minimal: 'Firefox installed.',
    friendly: 'Great! Firefox is now installed and ready to use.',
    encouraging: '🎉 Awesome! You\'ve successfully installed Firefox. You\'re doing great!',
    playful: '🦊 Firefox is ready to browse! The internet awaits your adventure!'
  };
  
  return (
    <div className="p-4">
      <div className="mb-4">
        <p className="text-sm text-gray-600 mb-2">Same action, different responses:</p>
        <div className="bg-blue-50 rounded-lg p-3 min-h-[60px] flex items-center">
          <p className="font-medium">{responses[style as keyof typeof responses]}</p>
        </div>
      </div>
      
      <div className="space-y-2">
        {Object.keys(responses).map(s => (
          <button
            key={s}
            onClick={() => setStyle(s)}
            className={`
              w-full p-2 rounded text-left capitalize
              ${style === s 
                ? 'bg-blue-100 border-blue-300 border' 
                : 'bg-gray-100 hover:bg-gray-200'
              }
            `}
          >
            {s} style
          </button>
        ))}
      </div>
    </div>
  );
};