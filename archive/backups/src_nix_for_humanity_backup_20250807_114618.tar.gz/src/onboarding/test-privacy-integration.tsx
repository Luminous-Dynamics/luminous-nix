/**
 * Test file for Privacy and Feature Integration
 * Tests the complete onboarding flow with privacy transparency
 */

import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { EnhancedOnboarding } from './EnhancedOnboarding';

describe('Privacy-Enhanced Onboarding', () => {
  it('shows privacy transparency after visual preferences', async () => {
    render(<EnhancedOnboarding />);
    
    // Should start with welcome
    expect(screen.getByText('Welcome to Nix for Humanity')).toBeInTheDocument();
    
    // Fill in name and continue
    const nameInput = screen.getByPlaceholderText('Your name or nickname');
    fireEvent.change(nameInput, { target: { value: 'Test User' } });
    fireEvent.click(screen.getByText('Continue'));
    
    // Select comfort level
    await waitFor(() => {
      expect(screen.getByText('How comfortable are you with technology?')).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText("I'm New to This"));
    fireEvent.click(screen.getByText('Continue'));
    
    // Choose visual style
    await waitFor(() => {
      expect(screen.getByText('Choose a look that feels right')).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText('Calm & Clear'));
    fireEvent.click(screen.getByText('Continue'));
    
    // Should now show privacy transparency
    await waitFor(() => {
      expect(screen.getByText('Your Privacy Matters')).toBeInTheDocument();
      expect(screen.getByText('We believe in complete transparency')).toBeInTheDocument();
    });
  });
  
  it('enables features based on privacy choices', async () => {
    render(<EnhancedOnboarding />);
    
    // Navigate to privacy step (simplified)
    // ... navigation code ...
    
    // Expand voice section
    fireEvent.click(screen.getByText('Voice & Speech Processing'));
    
    // Check the enable checkbox
    const voiceCheckbox = screen.getByLabelText('Enable voice & speech processing');
    fireEvent.click(voiceCheckbox);
    
    // Continue
    fireEvent.click(screen.getByText('Continue with selected features'));
    
    // Should eventually reach feature walkthrough
    await waitFor(() => {
      expect(screen.getByText('Feature Walkthrough')).toBeInTheDocument();
    });
    
    // Voice should be in enabled features
    expect(screen.getByText('Voice Commands')).toBeInTheDocument();
  });
  
  it('respects user privacy choices throughout flow', async () => {
    render(<EnhancedOnboarding />);
    
    // Test that declining all privacy features still allows completion
    // Navigate to privacy
    // ... navigation ...
    
    // Click "Skip for now"
    fireEvent.click(screen.getByText('Skip for now'));
    
    // Should continue to next steps
    await waitFor(() => {
      expect(screen.getByText('Try Your First Task')).toBeInTheDocument();
    });
    
    // Feature walkthrough should show no features
    // ... continue to walkthrough ...
    expect(screen.getByText('No features selected for walkthrough')).toBeInTheDocument();
  });
});

describe('Feature Walkthrough Integration', () => {
  it('shows walkthroughs only for enabled features', async () => {
    const enabledFeatures = ['voice', 'adaptation', 'gestures'];
    
    render(
      <FeatureWalkthrough 
        enabledFeatures={enabledFeatures}
        onComplete={(viewed) => console.log('Viewed:', viewed)}
      />
    );
    
    // Should show 3 features
    expect(screen.getByText('1 of 3')).toBeInTheDocument();
    
    // First should be voice
    expect(screen.getByText('Voice Commands')).toBeInTheDocument();
    expect(screen.getByText('Speak naturally to control NixOS')).toBeInTheDocument();
  });
  
  it('tracks viewed features', async () => {
    const onComplete = jest.fn();
    const enabledFeatures = ['voice'];
    
    render(
      <FeatureWalkthrough 
        enabledFeatures={enabledFeatures}
        onComplete={onComplete}
      />
    );
    
    // Play demo
    fireEvent.click(screen.getByLabelText('Play demo'));
    
    // Complete walkthrough
    fireEvent.click(screen.getByText('Complete Walkthrough'));
    
    // Should call onComplete with viewed features
    expect(onComplete).toHaveBeenCalledWith(['voice']);
  });
});

// Integration test for the full flow
describe('Complete Onboarding Flow', () => {
  it('integrates all components smoothly', async () => {
    render(<EnhancedOnboarding />);
    
    // Track the journey
    const steps = [
      'Welcome to Nix for Humanity',
      'How comfortable are you with technology?',
      'Choose a look that feels right',
      'Your Privacy Matters',
      'How Do You Want to Interact?',
      'Would you like adaptive help?',
      'Try Your First Task',
      'Feature Walkthrough'
    ];
    
    // Each step should flow to the next
    for (const step of steps) {
      await waitFor(() => {
        expect(screen.getByText(new RegExp(step, 'i'))).toBeInTheDocument();
      });
      
      // Take appropriate action for each step
      // ... step-specific actions ...
      
      // Continue to next
      const continueButton = screen.queryByText(/continue|next/i);
      if (continueButton) {
        fireEvent.click(continueButton);
      }
    }
    
    // Should complete successfully
    expect(screen.getByText(/complete|finish|done/i)).toBeInTheDocument();
  });
});