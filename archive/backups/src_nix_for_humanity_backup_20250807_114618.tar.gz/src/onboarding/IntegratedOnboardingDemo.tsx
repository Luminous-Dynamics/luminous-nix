/**
 * Integrated Onboarding Demo
 * Shows the complete flow with privacy and feature walkthroughs
 */

import React, { useState } from 'react';
import { EnhancedOnboarding } from './EnhancedOnboarding';

export const IntegratedOnboardingDemo: React.FC = () => {
  const [isComplete, setIsComplete] = useState(false);
  const [userJourney, setUserJourney] = useState<{
    name: string;
    comfortLevel: string;
    theme: string;
    privacyChoices: string[];
    enabledFeatures: string[];
    viewedFeatures: string[];
  } | null>(null);
  
  if (isComplete && userJourney) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="text-center mb-8">
              <div className="text-6xl mb-4">🎉</div>
              <h1 className="text-3xl font-bold text-gray-800 mb-2">
                Welcome to Nix for Humanity, {userJourney.name}!
              </h1>
              <p className="text-lg text-gray-600">
                Your personalized system is ready
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              {/* User Profile */}
              <div className="bg-blue-50 rounded-lg p-6">
                <h2 className="font-semibold text-blue-900 mb-4">Your Profile</h2>
                <dl className="space-y-2">
                  <div>
                    <dt className="text-sm text-blue-700">Comfort Level:</dt>
                    <dd className="font-medium">{userJourney.comfortLevel}</dd>
                  </div>
                  <div>
                    <dt className="text-sm text-blue-700">Theme:</dt>
                    <dd className="font-medium">{userJourney.theme}</dd>
                  </div>
                  <div>
                    <dt className="text-sm text-blue-700">Primary Features:</dt>
                    <dd className="font-medium">
                      {userJourney.enabledFeatures.join(', ') || 'Basic features'}
                    </dd>
                  </div>
                </dl>
              </div>
              
              {/* Privacy Summary */}
              <div className="bg-green-50 rounded-lg p-6">
                <h2 className="font-semibold text-green-900 mb-4">Privacy Settings</h2>
                <ul className="space-y-2">
                  <li className="flex items-center text-sm">
                    <span className="text-green-600 mr-2">✓</span>
                    All data stays local
                  </li>
                  <li className="flex items-center text-sm">
                    <span className="text-green-600 mr-2">✓</span>
                    You control everything
                  </li>
                  {userJourney.privacyChoices.map(choice => (
                    <li key={choice} className="flex items-center text-sm">
                      <span className="text-green-600 mr-2">✓</span>
                      {choice} enabled
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            
            {/* Getting Started */}
            <div className="mt-8 bg-gray-50 rounded-lg p-6">
              <h2 className="font-semibold mb-4">Ready to Get Started?</h2>
              <div className="grid md:grid-cols-3 gap-4">
                <button className="p-4 bg-white rounded-lg border hover:border-blue-300 transition-colors">
                  <div className="text-2xl mb-2">💬</div>
                  <div className="font-medium">Try a Command</div>
                  <div className="text-sm text-gray-600">Say "install firefox"</div>
                </button>
                
                <button className="p-4 bg-white rounded-lg border hover:border-blue-300 transition-colors">
                  <div className="text-2xl mb-2">🎨</div>
                  <div className="font-medium">Customize More</div>
                  <div className="text-sm text-gray-600">Adjust your settings</div>
                </button>
                
                <button className="p-4 bg-white rounded-lg border hover:border-blue-300 transition-colors">
                  <div className="text-2xl mb-2">📚</div>
                  <div className="font-medium">Learn More</div>
                  <div className="text-sm text-gray-600">Explore features</div>
                </button>
              </div>
            </div>
            
            {/* Features Overview */}
            {userJourney.viewedFeatures.length > 0 && (
              <div className="mt-6 text-center">
                <p className="text-sm text-gray-600">
                  You learned about: {userJourney.viewedFeatures.join(', ')}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="integrated-onboarding-demo">
      <EnhancedOnboarding />
    </div>
  );
};

// Story Mode for Development
export const OnboardingStoryMode: React.FC = () => {
  const [currentStory, setCurrentStory] = useState<
    'grandma' | 'maya' | 'david' | 'nervous' | null
  >(null);
  
  const stories = {
    grandma: {
      name: 'Grandma Rose',
      age: 75,
      scenario: 'First time using a computer properly',
      needs: ['Large text', 'Voice commands', 'Simple language', 'Patient guidance'],
      journey: 'Discovers she can video chat with grandkids'
    },
    maya: {
      name: 'Maya',
      age: 16,
      scenario: 'Tech-savvy but new to Linux',
      needs: ['Fast interaction', 'Keyboard shortcuts', 'Minimal hand-holding', 'Dark theme'],
      journey: 'Sets up her dream gaming/coding environment'
    },
    david: {
      name: 'David',
      age: 42,
      scenario: 'Tired parent trying to fix computer',
      needs: ['Quick solutions', 'Clear explanations', 'Stress reduction', 'Time-saving'],
      journey: 'Gets computer running smoothly again'
    },
    nervous: {
      name: 'Sam',
      age: 28,
      scenario: 'Anxious about breaking things',
      needs: ['Reassurance', 'Undo options', 'Safe exploration', 'Clear warnings'],
      journey: 'Gains confidence through gentle guidance'
    }
  };
  
  if (!currentStory) {
    return (
      <div className="min-h-screen bg-gray-50 p-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-center mb-8">
            Experience Onboarding Through Different Eyes
          </h1>
          
          <div className="grid md:grid-cols-2 gap-6">
            {Object.entries(stories).map(([key, story]) => (
              <button
                key={key}
                onClick={() => setCurrentStory(key as any)}
                className="bg-white rounded-lg shadow-lg p-6 text-left hover:shadow-xl transition-shadow"
              >
                <h2 className="text-xl font-semibold mb-2">{story.name}, {story.age}</h2>
                <p className="text-gray-600 mb-4">{story.scenario}</p>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-gray-700">Needs:</p>
                  <ul className="text-sm text-gray-600">
                    {story.needs.map(need => (
                      <li key={need}>• {need}</li>
                    ))}
                  </ul>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }
  
  // Simulate the persona's journey
  return (
    <div className="persona-journey">
      <div className="bg-yellow-50 border-b border-yellow-200 p-4 text-center">
        <p className="text-sm">
          <strong>Experiencing as:</strong> {stories[currentStory].name} - 
          {stories[currentStory].scenario}
        </p>
        <button 
          onClick={() => setCurrentStory(null)}
          className="text-blue-600 hover:text-blue-700 text-sm mt-1"
        >
          ← Choose Different Persona
        </button>
      </div>
      
      <EnhancedOnboarding />
    </div>
  );
};

// Privacy Impact Visualizer
export const PrivacyImpactVisualizer: React.FC = () => {
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([]);
  
  const features = {
    voice: {
      name: 'Voice Commands',
      collects: ['Temporary audio buffers', 'Speech patterns'],
      doesntCollect: ['Actual recordings', 'Voice identity'],
      benefit: 'Natural interaction without typing'
    },
    gestures: {
      name: 'Gesture Recognition',
      collects: ['Movement patterns', 'Click timing'],
      doesntCollect: ['Screen content', 'Specific clicks'],
      benefit: 'Automatic help when confused'
    },
    adaptation: {
      name: 'Learning System',
      collects: ['Command patterns', 'Preferences'],
      doesntCollect: ['Personal data', 'Private content'],
      benefit: 'System that grows with you'
    }
  };
  
  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Privacy Impact Visualizer</h2>
      
      <div className="grid md:grid-cols-3 gap-4 mb-8">
        {Object.entries(features).map(([key, feature]) => (
          <label
            key={key}
            className={`
              p-4 rounded-lg border-2 cursor-pointer transition-all
              ${selectedFeatures.includes(key)
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-gray-300'
              }
            `}
          >
            <input
              type="checkbox"
              checked={selectedFeatures.includes(key)}
              onChange={(e) => {
                if (e.target.checked) {
                  setSelectedFeatures([...selectedFeatures, key]);
                } else {
                  setSelectedFeatures(selectedFeatures.filter(f => f !== key));
                }
              }}
              className="sr-only"
            />
            <h3 className="font-semibold mb-2">{feature.name}</h3>
            <p className="text-sm text-gray-600">{feature.benefit}</p>
          </label>
        ))}
      </div>
      
      {selectedFeatures.length > 0 && (
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="font-semibold mb-4">Your Privacy Impact:</h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-yellow-50 rounded-lg p-4">
              <h4 className="font-medium text-yellow-900 mb-2">What We Track:</h4>
              <ul className="space-y-1 text-sm text-yellow-800">
                {selectedFeatures.flatMap(f => 
                  features[f as keyof typeof features].collects.map(item => (
                    <li key={item}>• {item}</li>
                  ))
                )}
              </ul>
            </div>
            
            <div className="bg-green-50 rounded-lg p-4">
              <h4 className="font-medium text-green-900 mb-2">What We DON'T Track:</h4>
              <ul className="space-y-1 text-sm text-green-800">
                {selectedFeatures.flatMap(f => 
                  features[f as keyof typeof features].doesntCollect.map(item => (
                    <li key={item}>• {item}</li>
                  ))
                )}
              </ul>
            </div>
          </div>
          
          <div className="mt-4 p-4 bg-blue-50 rounded-lg">
            <p className="text-sm text-blue-800">
              <strong>Remember:</strong> All data stays on your device. 
              You can delete everything anytime. No cloud, no tracking, no accounts.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};