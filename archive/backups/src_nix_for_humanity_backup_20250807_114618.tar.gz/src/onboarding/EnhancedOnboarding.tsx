/**
 * Enhanced Onboarding Experience
 * Integrates all features into a smooth, adaptive first experience
 */

import React, { useState, useEffect } from 'react';
import { SimplifiedInterface, useSimplification } from '../ui/visual-simplification/SimplifiedInterface';
import { ThemeEngine } from '../ui/color-themes/theme-engine';
import { VoiceInterface } from '../voice/VoiceInterface';
import { GestureEngine } from '../interaction/gesture-recognition/gesture-engine';
import { PersonalityAdaptationEngine } from '../personality/personality-adaptation-engine';
import { NLPEngine } from '../nlp/nlp-engine';
import { EmotionalState } from '../voice-emotion/types';
import { PrivacyTransparency } from './PrivacyTransparency';
import { FeatureWalkthrough } from './FeatureWalkthrough';

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  component: React.ReactNode;
  minComplexityLevel: number;
  optional: boolean;
}

export const EnhancedOnboarding: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [userProfile, setUserProfile] = useState({
    name: '',
    preferredName: '',
    comfort: 'beginner' as 'beginner' | 'intermediate' | 'advanced',
    primaryGoal: '',
    hasDisabilities: false,
    preferredInput: 'mouse' as 'mouse' | 'voice' | 'keyboard'
  });
  
  const [engines] = useState(() => ({
    theme: new ThemeEngine(),
    gesture: new GestureEngine(),
    personality: new PersonalityAdaptationEngine(),
    nlp: new NLPEngine()
  }));
  
  const [emotionalState, setEmotionalState] = useState<EmotionalState>({
    frustration: 0.1,
    confidence: 0.5,
    confusion: 0.3,
    excitement: 0.4,
    calmness: 0.6,
    stress: 0.2,
    engagement: 0.5,
    needsHelp: 0.3,
    certainty: 0.7,
    timestamp: new Date()
  });
  
  const [privacyChoices, setPrivacyChoices] = useState<any>(null);
  const [enabledFeatures, setEnabledFeatures] = useState<string[]>(['adaptation']); // adaptation always enabled
  
  const { level: complexityLevel } = useSimplification();
  
  // Define onboarding steps
  const steps: OnboardingStep[] = [
    {
      id: 'welcome',
      title: 'Welcome to Nix for Humanity',
      description: 'Let\'s make NixOS work for you',
      component: <WelcomeStep userProfile={userProfile} setUserProfile={setUserProfile} />,
      minComplexityLevel: 0,
      optional: false
    },
    {
      id: 'comfort-check',
      title: 'Your Comfort Level',
      description: 'Help us adapt to your needs',
      component: <ComfortCheckStep userProfile={userProfile} setUserProfile={setUserProfile} />,
      minComplexityLevel: 0,
      optional: false
    },
    {
      id: 'visual-preference',
      title: 'Choose Your Visual Style',
      description: 'Select a color theme that feels right',
      component: <VisualPreferenceStep engine={engines.theme} />,
      minComplexityLevel: 0,
      optional: false
    },
    {
      id: 'privacy-transparency',
      title: 'Your Privacy Matters',
      description: 'Understanding how we protect your data',
      component: <PrivacyTransparency onComplete={(choices) => {
        setPrivacyChoices(choices);
        setEnabledFeatures(choices.acceptedSections);
      }} />,
      minComplexityLevel: 0,
      optional: false
    },
    {
      id: 'input-preference',
      title: 'How Do You Want to Interact?',
      description: 'Choose your preferred input method',
      component: <InputPreferenceStep 
        userProfile={userProfile} 
        setUserProfile={(profile) => {
          setUserProfile(profile);
          if (profile.preferredInput === 'voice') {
            setEnabledFeatures(prev => [...prev, 'voice']);
          }
        }}
      />,
      minComplexityLevel: 2,
      optional: true
    },
    {
      id: 'gesture-opt-in',
      title: 'Adaptive Help',
      description: 'Let us learn when you need assistance',
      component: <GestureOptInStep 
        engine={engines.gesture}
        onDecision={(accepted) => {
          if (accepted) {
            setEnabledFeatures(prev => [...prev, 'gestures']);
          }
        }}
      />,
      minComplexityLevel: 3,
      optional: true
    },
    {
      id: 'first-task',
      title: 'Try Your First Task',
      description: 'Let\'s install something together',
      component: <FirstTaskStep personality={engines.personality} />,
      minComplexityLevel: 0,
      optional: false
    },
    {
      id: 'feature-walkthrough',
      title: 'Explore Your Features',
      description: 'Learn about what you enabled',
      component: <FeatureWalkthrough 
        enabledFeatures={enabledFeatures}
        onComplete={(viewedFeatures) => {
          console.log('User viewed features:', viewedFeatures);
        }}
      />,
      minComplexityLevel: 0,
      optional: true
    }
  ];
  
  // Filter steps based on complexity level
  const availableSteps = steps.filter(step => 
    complexityLevel >= step.minComplexityLevel || !step.optional
  );
  
  const currentStepData = availableSteps[currentStep];
  
  // Detect emotional state changes
  useEffect(() => {
    // Simple heuristic - if user is stuck on a step too long
    const timer = setTimeout(() => {
      setEmotionalState(prev => ({
        ...prev,
        confusion: Math.min(1, prev.confusion + 0.1),
        frustration: Math.min(1, prev.frustration + 0.05),
        confidence: Math.max(0, prev.confidence - 0.05)
      }));
    }, 30000); // 30 seconds
    
    return () => clearTimeout(timer);
  }, [currentStep]);
  
  const handleNext = () => {
    if (currentStep < availableSteps.length - 1) {
      setCurrentStep(currentStep + 1);
      
      // Boost confidence when progressing
      setEmotionalState(prev => ({
        ...prev,
        confidence: Math.min(1, prev.confidence + 0.1),
        confusion: Math.max(0, prev.confusion - 0.1),
        excitement: Math.min(1, prev.excitement + 0.05)
      }));
    }
  };
  
  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };
  
  const handleSkip = () => {
    if (currentStepData.optional) {
      handleNext();
    }
  };
  
  const calculateProgress = () => {
    return ((currentStep + 1) / availableSteps.length) * 100;
  };
  
  return (
    <SimplifiedInterface initialLevel={2} personaId="new-user">
      <div className="enhanced-onboarding min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
        {/* Progress bar */}
        <div className="fixed top-0 left-0 right-0 h-1 bg-gray-200">
          <div 
            className="h-full bg-blue-600 transition-all duration-500"
            style={{ width: `${calculateProgress()}%` }}
          />
        </div>
        
        {/* Main content */}
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">
              {currentStepData.title}
            </h1>
            <p className="text-lg text-gray-600">
              {currentStepData.description}
            </p>
          </div>
          
          {/* Step content */}
          <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8 mb-6">
            {currentStepData.component}
          </div>
          
          {/* Navigation */}
          <div className="flex justify-between items-center">
            <button
              onClick={handleBack}
              disabled={currentStep === 0}
              className={`
                px-6 py-3 rounded-lg font-medium transition-all
                ${currentStep === 0 
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                  : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
                }
              `}
            >
              Back
            </button>
            
            <div className="flex space-x-3">
              {currentStepData.optional && (
                <button
                  onClick={handleSkip}
                  className="px-6 py-3 text-gray-600 hover:text-gray-800"
                >
                  Skip
                </button>
              )}
              
              <button
                onClick={handleNext}
                className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-all transform hover:scale-105"
              >
                {currentStep === availableSteps.length - 1 ? 'Get Started!' : 'Continue'}
              </button>
            </div>
          </div>
          
          {/* Help indicator */}
          {emotionalState.confusion > 0.6 && (
            <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg animate-fade-in">
              <p className="text-yellow-800">
                Need help? Try using voice commands or click the help button anytime!
              </p>
            </div>
          )}
        </div>
      </div>
    </SimplifiedInterface>
  );
};

// Step Components

const WelcomeStep: React.FC<{
  userProfile: any;
  setUserProfile: (update: any) => void;
}> = ({ userProfile, setUserProfile }) => {
  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <div className="text-6xl mb-4">👋</div>
        <h2 className="text-2xl font-semibold mb-2">Hello there!</h2>
        <p className="text-gray-600">
          I'm here to help you use NixOS in a way that feels natural to you.
        </p>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          What should I call you?
        </label>
        <input
          type="text"
          value={userProfile.preferredName}
          onChange={(e) => setUserProfile({ ...userProfile, preferredName: e.target.value })}
          placeholder="Your name or nickname"
          className="w-full px-4 py-3 text-lg border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          autoFocus
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          What brings you to NixOS today?
        </label>
        <textarea
          value={userProfile.primaryGoal}
          onChange={(e) => setUserProfile({ ...userProfile, primaryGoal: e.target.value })}
          placeholder="e.g., I want to install some software, set up my development environment, or just explore..."
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          rows={3}
        />
      </div>
    </div>
  );
};

const ComfortCheckStep: React.FC<{
  userProfile: any;
  setUserProfile: (update: any) => void;
}> = ({ userProfile, setUserProfile }) => {
  const { setLevel } = useSimplification();
  
  const comfortOptions = [
    {
      level: 'beginner',
      emoji: '🌱',
      title: 'I\'m New to This',
      description: 'Keep things simple and guide me through everything',
      complexityLevel: 0
    },
    {
      level: 'intermediate',
      emoji: '🌿',
      title: 'I Know Some Basics',
      description: 'I can handle some technical stuff but appreciate help',
      complexityLevel: 5
    },
    {
      level: 'advanced',
      emoji: '🌲',
      title: 'I\'m Comfortable',
      description: 'Show me everything, I like having full control',
      complexityLevel: 8
    }
  ];
  
  const selectComfort = (option: any) => {
    setUserProfile({ ...userProfile, comfort: option.level });
    setLevel(option.complexityLevel);
  };
  
  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h3 className="text-xl font-semibold mb-2">
          How comfortable are you with technology?
        </h3>
        <p className="text-gray-600">
          This helps me adjust how much information to show you
        </p>
      </div>
      
      <div className="grid gap-4">
        {comfortOptions.map((option) => (
          <button
            key={option.level}
            onClick={() => selectComfort(option)}
            className={`
              p-6 rounded-xl border-2 transition-all text-left
              ${userProfile.comfort === option.level
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
              }
            `}
          >
            <div className="flex items-start">
              <span className="text-3xl mr-4">{option.emoji}</span>
              <div>
                <h4 className="font-semibold text-lg mb-1">{option.title}</h4>
                <p className="text-gray-600">{option.description}</p>
              </div>
            </div>
          </button>
        ))}
      </div>
      
      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <p className="text-sm text-blue-800">
          💡 Don't worry - you can always change this later in settings!
        </p>
      </div>
    </div>
  );
};

const VisualPreferenceStep: React.FC<{ engine: ThemeEngine }> = ({ engine }) => {
  const [selectedTheme, setSelectedTheme] = useState('sanctuary');
  
  const quickThemes = [
    { id: 'sanctuary', name: 'Calm & Clear', emoji: '🌅' },
    { id: 'focus', name: 'High Contrast', emoji: '🎯' },
    { id: 'night-owl', name: 'Dark Mode', emoji: '🌙' },
    { id: 'ocean-breeze', name: 'Fresh & Bright', emoji: '🌊' }
  ];
  
  const selectTheme = (themeId: string) => {
    setSelectedTheme(themeId);
    engine.setTheme(themeId);
  };
  
  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h3 className="text-xl font-semibold mb-2">
          Choose a look that feels right
        </h3>
        <p className="text-gray-600">
          Colors can affect how comfortable you feel using the system
        </p>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        {quickThemes.map((theme) => (
          <button
            key={theme.id}
            onClick={() => selectTheme(theme.id)}
            className={`
              p-6 rounded-xl border-2 transition-all
              ${selectedTheme === theme.id
                ? 'border-blue-500 bg-blue-50 scale-105'
                : 'border-gray-200 hover:border-gray-300'
              }
            `}
          >
            <div className="text-4xl mb-2">{theme.emoji}</div>
            <div className="font-medium">{theme.name}</div>
          </button>
        ))}
      </div>
      
      <div className="text-center">
        <button className="text-blue-600 hover:text-blue-700 text-sm">
          Browse all themes →
        </button>
      </div>
    </div>
  );
};

const InputPreferenceStep: React.FC<{
  userProfile: any;
  setUserProfile: (update: any) => void;
}> = ({ userProfile, setUserProfile }) => {
  const inputMethods = [
    {
      id: 'mouse',
      emoji: '🖱️',
      title: 'Mouse & Keyboard',
      description: 'Traditional point and click'
    },
    {
      id: 'voice',
      emoji: '🎤',
      title: 'Voice Commands',
      description: 'Just speak naturally'
    },
    {
      id: 'keyboard',
      emoji: '⌨️',
      title: 'Keyboard Only',
      description: 'Navigate without a mouse'
    }
  ];
  
  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h3 className="text-xl font-semibold mb-2">
          How do you prefer to interact?
        </h3>
        <p className="text-gray-600">
          You can always use any method, but I'll optimize for your preference
        </p>
      </div>
      
      <div className="grid gap-4">
        {inputMethods.map((method) => (
          <button
            key={method.id}
            onClick={() => setUserProfile({ ...userProfile, preferredInput: method.id })}
            className={`
              p-4 rounded-xl border-2 transition-all flex items-center
              ${userProfile.preferredInput === method.id
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-gray-300'
              }
            `}
          >
            <span className="text-3xl mr-4">{method.emoji}</span>
            <div className="text-left">
              <h4 className="font-semibold">{method.title}</h4>
              <p className="text-sm text-gray-600">{method.description}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

const GestureOptInStep: React.FC<{ 
  engine: GestureEngine;
  onDecision?: (accepted: boolean) => void;
}> = ({ engine, onDecision }) => {
  const [decision, setDecision] = useState<'pending' | 'accepted' | 'declined'>('pending');
  
  const handleAccept = () => {
    engine.enable();
    setDecision('accepted');
    onDecision?.(true);
  };
  
  const handleDecline = () => {
    setDecision('declined');
    onDecision?.(false);
  };
  
  if (decision !== 'pending') {
    return (
      <div className="text-center py-8">
        <div className="text-5xl mb-4">
          {decision === 'accepted' ? '✅' : '👍'}
        </div>
        <h3 className="text-xl font-semibold mb-2">
          {decision === 'accepted' ? 'Adaptive help enabled!' : 'No problem!'}
        </h3>
        <p className="text-gray-600">
          {decision === 'accepted' 
            ? 'I\'ll help when you seem stuck'
            : 'You can always enable this later in settings'
          }
        </p>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <div className="text-5xl mb-4">🤝</div>
        <h3 className="text-xl font-semibold mb-2">
          Would you like adaptive help?
        </h3>
        <p className="text-gray-600">
          I can notice when you might need assistance and offer help
        </p>
      </div>
      
      <div className="bg-blue-50 rounded-lg p-4 space-y-2">
        <h4 className="font-medium text-blue-900">How it works:</h4>
        <ul className="text-sm text-blue-800 space-y-1">
          <li>• I'll notice if you seem to be searching for something</li>
          <li>• All data stays on your device</li>
          <li>• You can turn it off anytime</li>
          <li>• I'll never interrupt when you're in flow</li>
        </ul>
      </div>
      
      <div className="flex space-x-4">
        <button
          onClick={handleDecline}
          className="flex-1 py-3 px-6 bg-gray-200 hover:bg-gray-300 rounded-lg font-medium"
        >
          No Thanks
        </button>
        <button
          onClick={handleAccept}
          className="flex-1 py-3 px-6 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium"
        >
          Yes, Help Me
        </button>
      </div>
    </div>
  );
};

const FirstTaskStep: React.FC<{ personality: PersonalityAdaptationEngine }> = ({ personality }) => {
  const [task, setTask] = useState('');
  const [result, setResult] = useState<string | null>(null);
  
  const suggestions = [
    'Install Firefox',
    'Update my system',
    'Install VS Code',
    'Set up Python'
  ];
  
  const handleTask = () => {
    // Simulate task completion
    setResult(`Great! I'm ${task.toLowerCase() || 'installing Firefox'} for you...`);
    setTimeout(() => {
      setResult(`✅ Success! ${task || 'Firefox'} is ready to use!`);
    }, 2000);
  };
  
  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <div className="text-5xl mb-4">🚀</div>
        <h3 className="text-xl font-semibold mb-2">
          Let's try something together!
        </h3>
        <p className="text-gray-600">
          What would you like to do first?
        </p>
      </div>
      
      <div>
        <input
          type="text"
          value={task}
          onChange={(e) => setTask(e.target.value)}
          placeholder="Tell me what you'd like to do..."
          className="w-full px-4 py-3 text-lg border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          onKeyPress={(e) => e.key === 'Enter' && handleTask()}
        />
      </div>
      
      <div className="flex flex-wrap gap-2">
        {suggestions.map((suggestion) => (
          <button
            key={suggestion}
            onClick={() => setTask(suggestion)}
            className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg text-sm"
          >
            {suggestion}
          </button>
        ))}
      </div>
      
      {task && (
        <button
          onClick={handleTask}
          className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium"
        >
          Do it!
        </button>
      )}
      
      {result && (
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg animate-fade-in">
          <p className="text-green-800">{result}</p>
        </div>
      )}
    </div>
  );
};