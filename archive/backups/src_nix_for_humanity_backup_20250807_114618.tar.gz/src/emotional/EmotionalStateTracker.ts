// Mock EmotionalStateTracker for demo
export interface EmotionalState {
  valence: number; // -1 to 1 (negative to positive)
  arousal: number; // 0 to 1 (calm to excited)
  dominance: number; // 0 to 1 (submissive to dominant)
  confidence: number; // 0 to 1
}

export interface EmotionalMetrics {
  currentState: EmotionalState;
  trend: 'improving' | 'stable' | 'declining';
  stressLevel: number;
  focusLevel: number;
}

export class EmotionalStateTracker {
  private state: EmotionalState = {
    valence: 0.5,
    arousal: 0.3,
    dominance: 0.5,
    confidence: 0.7
  };

  private history: EmotionalState[] = [];

  async initialize() {
    console.log('Emotional State Tracker initialized');
  }

  analyzeTextEmotion(text: string): EmotionalState {
    // Mock emotion detection from text
    const words = text.toLowerCase().split(/\s+/);
    
    // Simple keyword-based emotion detection
    let valence = 0.5;
    let arousal = 0.3;
    
    // Positive words
    if (words.some(w => ['happy', 'great', 'love', 'wonderful', 'excited'].includes(w))) {
      valence = 0.8;
      arousal = 0.6;
    }
    
    // Negative words
    if (words.some(w => ['sad', 'frustrated', 'confused', 'angry', 'worried'].includes(w))) {
      valence = 0.2;
      arousal = 0.7;
    }
    
    // Question words
    if (words.some(w => ['help', 'how', 'what', 'why', 'confused'].includes(w))) {
      arousal = 0.5;
    }
    
    return {
      valence,
      arousal,
      dominance: 0.5,
      confidence: 0.6
    };
  }

  analyzeVoiceEmotion(audioFeatures: any): EmotionalState {
    // Mock voice emotion detection
    return {
      valence: 0.6,
      arousal: 0.4,
      dominance: 0.5,
      confidence: 0.8
    };
  }

  updateState(newState: Partial<EmotionalState>) {
    this.state = { ...this.state, ...newState };
    this.history.push({ ...this.state });
    
    // Keep history limited
    if (this.history.length > 100) {
      this.history.shift();
    }
  }

  getCurrentState(): EmotionalState {
    return this.state;
  }

  getMetrics(): EmotionalMetrics {
    const trend = this.calculateTrend();
    
    return {
      currentState: this.state,
      trend,
      stressLevel: this.calculateStress(),
      focusLevel: this.calculateFocus()
    };
  }

  private calculateTrend(): 'improving' | 'stable' | 'declining' {
    if (this.history.length < 5) return 'stable';
    
    const recent = this.history.slice(-5);
    const avgRecent = recent.reduce((sum, s) => sum + s.valence, 0) / recent.length;
    const avgPrevious = this.history.slice(-10, -5).reduce((sum, s) => sum + s.valence, 0) / 5;
    
    if (avgRecent > avgPrevious + 0.1) return 'improving';
    if (avgRecent < avgPrevious - 0.1) return 'declining';
    return 'stable';
  }

  private calculateStress(): number {
    // High arousal + low valence = stress
    return Math.max(0, this.state.arousal - this.state.valence);
  }

  private calculateFocus(): number {
    // Moderate arousal + positive valence = focus
    const optimalArousal = Math.abs(this.state.arousal - 0.5);
    return this.state.valence * (1 - optimalArousal);
  }

  isUserFrustrated(): boolean {
    return this.state.valence < 0.3 && this.state.arousal > 0.6;
  }

  isUserConfident(): boolean {
    return this.state.confidence > 0.7 && this.state.valence > 0.6;
  }

  isUserLearning(): boolean {
    return this.state.arousal > 0.4 && this.state.arousal < 0.7 && this.state.valence > 0.4;
  }
}