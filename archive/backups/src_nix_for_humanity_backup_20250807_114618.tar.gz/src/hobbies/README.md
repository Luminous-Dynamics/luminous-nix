# 🎨 Hobby Detection System

The hobby detection system recognizes user interests and personalizes the Nix for Humanity experience based on what they love to do.

## Overview

The system detects hobbies through:
- Command patterns (what packages they install)
- Keywords in their queries
- Frequency of domain-specific commands

Currently supported hobbies:
- 🎮 Gaming
- 🎵 Music Production
- 🎨 Digital Art
- ✍️ Writing
- 📸 Photography
- 💻 Programming (bonus)
- 🎬 Video Editing (bonus)

## How It Works

### 1. Detection Process

```typescript
// Every command is processed
hobbyDetector.processCommand("install steam");

// Patterns are analyzed
// - Keywords: "game", "steam", "fps"
// - Packages: "steam", "lutris", "discord"
// - Commands: Matching regex patterns

// Confidence is calculated
// Based on frequency and pattern matches
```

### 2. Response Enrichment

Once hobbies are detected, responses are enriched:

```typescript
// Base response
"Installing Firefox..."

// With gaming hobby detected
"Installing Firefox... steam next?"

// With art hobby + friendly personality
"Installing Firefox! 🎨 Want to set up Krita too?"
```

### 3. Contextual Help

The system provides hobby-specific help:

**Gaming Issues:**
- Performance problems → Suggests gamemode, mangohud
- Controller setup → Points to xboxdrv, ds4drv

**Art Issues:**
- Tablet problems → Wacom configuration help
- Color accuracy → Monitor calibration tools

**Music Issues:**
- Latency problems → JACK configuration
- Plugin needs → Carla for VST hosting

## Privacy First

- All detection happens locally
- No data leaves the system
- User can clear hobby data anytime
- Transparent about what's detected

## Integration with Personality

Hobbies combine with personality for rich responses:

| Personality | Gaming Response | Art Response |
|------------|-----------------|--------------|
| Minimal | "steam next?" | "krita available." |
| Friendly | "🎮 Ready to game?" | "🎨 Let's create!" |
| Encouraging | "Your setup will be awesome!" | "Your art will shine!" |
| Playful | "Game time! 🚀" | "Art party! 🎨" |
| Sacred | "✨ Digital realms await..." | "✨ Creative flow beckons..." |

## Configuration

The system works out of the box, but can be configured:

```typescript
// Adjust detection sensitivity
hobbyDetector.setConfidenceThreshold(0.5); // Default: 0.3

// Disable specific hobbies
hobbyDetector.disableHobby(HobbyType.Sacred);

// Clear all data
hobbyDetector.clearData();
```

## Future Enhancements

Planned improvements:
- More hobbies (cooking, gardening, etc.)
- Workflow detection (game dev, content creation)
- Time-based patterns (evening gaming, weekend art)
- Cross-hobby suggestions (gaming + streaming)

## Examples

### Basic Usage

```javascript
// In PersonalityAwareNLP
const result = await nlp.processInput("install obs-studio");

// result.detectedHobbies might contain:
[
  { type: 'gaming', confidence: 0.8 },
  { type: 'video-editing', confidence: 0.6 }
]
```

### Testing

```bash
npm test -- --grep "Hobby Detection"
```

## Files

- `hobby-detector.ts` - Core detection logic
- `hobby-responses.ts` - Response generation
- `README.md` - This file

## Contributing

To add a new hobby:

1. Add to `HobbyType` enum
2. Add patterns to `hobbyPatterns`
3. Add response templates
4. Add tests
5. Update documentation

Remember: Hobbies should enhance, not overwhelm the experience!