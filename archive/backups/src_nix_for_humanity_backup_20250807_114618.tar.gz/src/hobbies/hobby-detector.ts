/**
 * Hobby Detection System
 * Detects user interests from command patterns and installed packages
 * Enhanced with integral theory awareness for deeper understanding
 */

export interface HobbySignals {
  keywords: string[];
  packages: string[];
  commands: string[];
  frequency: number;
  confidence: number;
}

export interface DetectedHobby {
  type: HobbyType;
  confidence: number;
  signals: HobbySignals;
  suggestedPackages?: string[];
  tips?: string[];
  integralContext?: HobbyIntegralContext;
}

export interface HobbyIntegralContext {
  // How hobby manifests in consciousness (UL)
  consciousnessAspect?: {
    creativityLevel: number;
    flowPotential: number;
    valueAlignment: string[];
  };
  // Observable patterns (UR)
  behaviorPatterns?: {
    practiceFrequency: number;
    skillProgression: number;
  };
  // Community connections (LL)
  communityAspect?: {
    sharedCulture: string[];
    collaborationStyle: string;
  };
  // System requirements (LR)
  systemRequirements?: {
    toolComplexity: number;
    resourceIntensity: number;
  };
}

export enum HobbyType {
  Gaming = 'gaming',
  MusicProduction = 'music-production',
  DigitalArt = 'digital-art',
  Writing = 'writing',
  Photography = 'photography',
  Programming = 'programming',
  VideoEditing = 'video-editing',
  Unknown = 'unknown'
}

export class HobbyDetector {
  private integralProfile?: any; // IntegralProfile type from integral module
  
  private hobbyPatterns = {
    [HobbyType.Gaming]: {
      keywords: ['game', 'steam', 'fps', 'mmo', 'rpg', 'twitch', 'gaming', 'play', 'controller', 'emulator'],
      packages: ['steam', 'lutris', 'wine', 'discord', 'obs-studio', 'mangohud', 'gamemode', 'retroarch'],
      commandPatterns: [/steam/, /lutris/, /wine.*\.exe/, /proton/, /nvidia-settings/],
      suggestedPackages: ['steam', 'discord', 'obs-studio', 'mangohud'],
      tips: [
        'Try gamemode for better performance',
        'MangoHud can show FPS and system stats',
        'Consider ProtonDB for Windows game compatibility'
      ]
    },
    
    [HobbyType.MusicProduction]: {
      keywords: ['music', 'audio', 'daw', 'midi', 'recording', 'mixing', 'production', 'beats', 'synth'],
      packages: ['ardour', 'reaper', 'bitwig-studio', 'jack', 'carla', 'qjackctl', 'audacity', 'lmms'],
      commandPatterns: [/jack/, /ardour/, /reaper/, /carla/, /qjackctl/],
      suggestedPackages: ['ardour', 'qjackctl', 'carla', 'calf'],
      tips: [
        'JACK provides low-latency audio routing',
        'Carla can host Windows VST plugins',
        'Consider realtime kernel for lower latency'
      ]
    },
    
    [HobbyType.DigitalArt]: {
      keywords: ['art', 'draw', 'paint', 'design', 'illustration', 'graphics', 'tablet', 'wacom', 'creative'],
      packages: ['krita', 'gimp', 'inkscape', 'blender', 'mypaint', 'darktable', 'digikam'],
      commandPatterns: [/krita/, /gimp/, /inkscape/, /blender/, /wacom/],
      suggestedPackages: ['krita', 'gimp', 'inkscape', 'blender'],
      tips: [
        'Krita excels at digital painting',
        'Configure pressure sensitivity for tablets',
        'Blender includes powerful 2D animation tools'
      ]
    },
    
    [HobbyType.Writing]: {
      keywords: ['write', 'writing', 'author', 'blog', 'novel', 'markdown', 'notes', 'journal', 'book'],
      packages: ['obsidian', 'typora', 'ghostwriter', 'focuswriter', 'libreoffice', 'latex', 'pandoc'],
      commandPatterns: [/obsidian/, /typora/, /vim.*\.(md|txt)/, /nano.*\.(md|txt)/, /pandoc/],
      suggestedPackages: ['obsidian', 'ghostwriter', 'pandoc', 'texlive'],
      tips: [
        'Obsidian great for interconnected notes',
        'Pandoc converts between document formats',
        'FocusWriter provides distraction-free writing'
      ]
    },
    
    [HobbyType.Photography]: {
      keywords: ['photo', 'photography', 'camera', 'raw', 'editing', 'lightroom', 'pictures', 'shots'],
      packages: ['darktable', 'rawtherapee', 'digikam', 'gimp', 'hugin', 'rapid-photo-downloader'],
      commandPatterns: [/darktable/, /rawtherapee/, /digikam/, /exif/, /dcraw/],
      suggestedPackages: ['darktable', 'digikam', 'hugin', 'rapid-photo-downloader'],
      tips: [
        'Darktable is a Lightroom alternative',
        'DigiKam helps organize large collections',
        'Hugin creates panoramas from multiple photos'
      ]
    }
  };
  
  private commandHistory: string[] = [];
  private detectedHobbies: Map<HobbyType, DetectedHobby> = new Map();
  private readonly maxHistorySize = 100;
  
  constructor() {
    this.loadState();
  }
  
  /**
   * Process a command and update hobby detection
   */
  processCommand(command: string): void {
    // Add to history
    this.commandHistory.push(command.toLowerCase());
    if (this.commandHistory.length > this.maxHistorySize) {
      this.commandHistory.shift();
    }
    
    // Update detection
    this.updateDetection();
    this.saveState();
  }
  
  /**
   * Analyze installed packages for hobby indicators
   */
  analyzeInstalledPackages(packages: string[]): void {
    const normalizedPackages = packages.map(p => p.toLowerCase());
    
    for (const [hobby, pattern] of Object.entries(this.hobbyPatterns)) {
      const matchingPackages = pattern.packages.filter(p => 
        normalizedPackages.some(installed => installed.includes(p))
      );
      
      if (matchingPackages.length > 0) {
        this.updateHobbyConfidence(hobby as HobbyType, {
          packages: matchingPackages,
          confidence: matchingPackages.length / pattern.packages.length
        });
      }
    }
  }
  
  /**
   * Get current detected hobbies sorted by confidence
   */
  getDetectedHobbies(): DetectedHobby[] {
    return Array.from(this.detectedHobbies.values())
      .sort((a, b) => b.confidence - a.confidence)
      .filter(h => h.confidence > 0.3); // Only return hobbies with >30% confidence
  }
  
  /**
   * Get the primary hobby (highest confidence)
   */
  getPrimaryHobby(): DetectedHobby | null {
    const hobbies = this.getDetectedHobbies();
    return hobbies.length > 0 ? hobbies[0] : null;
  }
  
  /**
   * Get package suggestions based on detected hobbies
   */
  getPackageSuggestions(): string[] {
    const suggestions = new Set<string>();
    const hobbies = this.getDetectedHobbies();
    
    for (const hobby of hobbies) {
      if (hobby.suggestedPackages) {
        hobby.suggestedPackages.forEach(pkg => suggestions.add(pkg));
      }
    }
    
    return Array.from(suggestions);
  }
  
  /**
   * Private: Update detection based on command history
   */
  private updateDetection(): void {
    for (const [hobbyType, pattern] of Object.entries(this.hobbyPatterns)) {
      const signals: Partial<HobbySignals> = {
        keywords: [],
        commands: [],
        frequency: 0
      };
      
      // Check command patterns
      for (const cmd of this.commandHistory) {
        // Check keywords
        for (const keyword of pattern.keywords) {
          if (cmd.includes(keyword)) {
            signals.keywords!.push(keyword);
            signals.frequency!++;
          }
        }
        
        // Check command patterns
        for (const cmdPattern of pattern.commandPatterns) {
          if (cmdPattern.test(cmd)) {
            signals.commands!.push(cmd);
            signals.frequency!++;
          }
        }
      }
      
      // Calculate confidence
      if (signals.frequency! > 0) {
        const keywordScore = signals.keywords!.length / pattern.keywords.length;
        const frequencyScore = Math.min(signals.frequency! / 10, 1); // Cap at 10 occurrences
        const confidence = (keywordScore + frequencyScore) / 2;
        
        this.updateHobbyConfidence(hobbyType as HobbyType, {
          ...signals as HobbySignals,
          confidence
        });
      }
    }
  }
  
  /**
   * Private: Update confidence for a specific hobby
   */
  private updateHobbyConfidence(hobby: HobbyType, signals: Partial<HobbySignals>): void {
    const existing = this.detectedHobbies.get(hobby);
    const pattern = this.hobbyPatterns[hobby];
    
    if (existing) {
      // Merge signals
      existing.signals = {
        keywords: [...new Set([...existing.signals.keywords, ...(signals.keywords || [])])],
        packages: [...new Set([...existing.signals.packages, ...(signals.packages || [])])],
        commands: [...new Set([...existing.signals.commands, ...(signals.commands || [])])],
        frequency: existing.signals.frequency + (signals.frequency || 0),
        confidence: Math.max(existing.confidence, signals.confidence || 0)
      };
      existing.confidence = existing.signals.confidence;
    } else if (signals.confidence && signals.confidence > 0) {
      // Create new detection
      this.detectedHobbies.set(hobby, {
        type: hobby,
        confidence: signals.confidence,
        signals: signals as HobbySignals,
        suggestedPackages: pattern.suggestedPackages,
        tips: pattern.tips
      });
    }
  }
  
  /**
   * Private: Save state to localStorage
   */
  private saveState(): void {
    if (typeof window !== 'undefined' && window.localStorage) {
      const state = {
        commandHistory: this.commandHistory,
        detectedHobbies: Array.from(this.detectedHobbies.entries())
      };
      localStorage.setItem('nix-humanity-hobbies', JSON.stringify(state));
    }
  }
  
  /**
   * Private: Load state from localStorage
   */
  private loadState(): void {
    if (typeof window !== 'undefined' && window.localStorage) {
      const saved = localStorage.getItem('nix-humanity-hobbies');
      if (saved) {
        try {
          const state = JSON.parse(saved);
          this.commandHistory = state.commandHistory || [];
          this.detectedHobbies = new Map(state.detectedHobbies || []);
        } catch (e) {
          console.error('Failed to load hobby state:', e);
        }
      }
    }
  }
  
  /**
   * Clear all detection data
   */
  clearData(): void {
    this.commandHistory = [];
    this.detectedHobbies.clear();
    this.saveState();
  }
  
  /**
   * Set integral profile for enhanced detection
   */
  setIntegralProfile(profile: any): void {
    this.integralProfile = profile;
  }
  
  /**
   * Add integral context to detected hobby
   */
  private addIntegralContext(hobby: DetectedHobby): DetectedHobby {
    if (!this.integralProfile) {
      return hobby;
    }
    
    const integralContext: HobbyIntegralContext = {};
    
    // Analyze consciousness aspect (Upper Left)
    if (hobby.type === HobbyType.DigitalArt || hobby.type === HobbyType.MusicProduction) {
      integralContext.consciousnessAspect = {
        creativityLevel: 0.8,
        flowPotential: 0.9,
        valueAlignment: ['self-expression', 'beauty', 'innovation']
      };
    } else if (hobby.type === HobbyType.Programming) {
      integralContext.consciousnessAspect = {
        creativityLevel: 0.7,
        flowPotential: 0.8,
        valueAlignment: ['problem-solving', 'mastery', 'efficiency']
      };
    }
    
    // Analyze behavior patterns (Upper Right)
    integralContext.behaviorPatterns = {
      practiceFrequency: this.calculatePracticeFrequency(hobby),
      skillProgression: this.estimateSkillProgression(hobby)
    };
    
    // Analyze community aspect (Lower Left)
    integralContext.communityAspect = {
      sharedCulture: this.identifySharedCulture(hobby.type),
      collaborationStyle: this.determineCollaborationStyle(hobby.type)
    };
    
    // Analyze system requirements (Lower Right)
    integralContext.systemRequirements = {
      toolComplexity: this.assessToolComplexity(hobby.type),
      resourceIntensity: this.assessResourceIntensity(hobby.type)
    };
    
    return {
      ...hobby,
      integralContext
    };
  }
  
  /**
   * Calculate practice frequency from command history
   */
  private calculatePracticeFrequency(hobby: DetectedHobby): number {
    const relevantCommands = this.commandHistory.filter(cmd => 
      hobby.signals.keywords.some(keyword => cmd.includes(keyword))
    );
    return Math.min(1, relevantCommands.length / 20);
  }
  
  /**
   * Estimate skill progression
   */
  private estimateSkillProgression(hobby: DetectedHobby): number {
    // Simple heuristic based on command complexity
    const advancedIndicators = ['config', 'plugin', 'script', 'compile', 'optimize'];
    const advancedCommands = this.commandHistory.filter(cmd => 
      advancedIndicators.some(indicator => cmd.includes(indicator))
    );
    return Math.min(1, advancedCommands.length / 10);
  }
  
  /**
   * Identify shared culture for hobby
   */
  private identifySharedCulture(hobbyType: HobbyType): string[] {
    const cultures: Record<HobbyType, string[]> = {
      [HobbyType.Gaming]: ['competitive', 'social', 'achievement-oriented'],
      [HobbyType.MusicProduction]: ['creative', 'collaborative', 'expressive'],
      [HobbyType.DigitalArt]: ['aesthetic', 'innovative', 'community-sharing'],
      [HobbyType.Writing]: ['reflective', 'narrative', 'knowledge-sharing'],
      [HobbyType.Photography]: ['observant', 'documentary', 'artistic'],
      [HobbyType.Programming]: ['problem-solving', 'open-source', 'efficiency'],
      [HobbyType.VideoEditing]: ['storytelling', 'technical', 'creative'],
      [HobbyType.Unknown]: ['exploring', 'learning']
    };
    return cultures[hobbyType] || [];
  }
  
  /**
   * Determine collaboration style
   */
  private determineCollaborationStyle(hobbyType: HobbyType): string {
    const styles: Record<HobbyType, string> = {
      [HobbyType.Gaming]: 'team-based',
      [HobbyType.MusicProduction]: 'studio-collaborative',
      [HobbyType.DigitalArt]: 'showcase-and-critique',
      [HobbyType.Writing]: 'peer-review',
      [HobbyType.Photography]: 'exhibition-based',
      [HobbyType.Programming]: 'code-review',
      [HobbyType.VideoEditing]: 'project-based',
      [HobbyType.Unknown]: 'exploratory'
    };
    return styles[hobbyType] || 'independent';
  }
  
  /**
   * Assess tool complexity for hobby
   */
  private assessToolComplexity(hobbyType: HobbyType): number {
    const complexity: Record<HobbyType, number> = {
      [HobbyType.Gaming]: 0.3,
      [HobbyType.MusicProduction]: 0.8,
      [HobbyType.DigitalArt]: 0.6,
      [HobbyType.Writing]: 0.2,
      [HobbyType.Photography]: 0.5,
      [HobbyType.Programming]: 0.9,
      [HobbyType.VideoEditing]: 0.7,
      [HobbyType.Unknown]: 0.5
    };
    return complexity[hobbyType] || 0.5;
  }
  
  /**
   * Assess resource intensity
   */
  private assessResourceIntensity(hobbyType: HobbyType): number {
    const intensity: Record<HobbyType, number> = {
      [HobbyType.Gaming]: 0.7,
      [HobbyType.MusicProduction]: 0.6,
      [HobbyType.DigitalArt]: 0.5,
      [HobbyType.Writing]: 0.1,
      [HobbyType.Photography]: 0.4,
      [HobbyType.Programming]: 0.3,
      [HobbyType.VideoEditing]: 0.8,
      [HobbyType.Unknown]: 0.3
    };
    return intensity[hobbyType] || 0.3;
  }
  
  /**
   * Get hobby tips with integral awareness
   */
  getHobbyTips(hobbyType: HobbyType): string[] {
    const baseTips = this.hobbyPatterns[hobbyType]?.tips || [];
    
    if (this.integralProfile) {
      // Add development-aware tips
      const developmentStage = this.integralProfile.development?.stage;
      if (developmentStage === 'integral' || developmentStage === 'pluralistic') {
        baseTips.push('Consider how this hobby serves your larger purpose');
        baseTips.push('Connect with communities that share your values');
      }
    }
    
    return baseTips;
  }
  
  /**
   * Detect hobby from query with integral enhancement
   */
  detectHobbyFromQuery(query: string): DetectedHobby | null {
    const lowercaseQuery = query.toLowerCase();
    
    for (const [hobbyType, pattern] of Object.entries(this.hobbyPatterns)) {
      const keywordMatches = pattern.keywords.filter(keyword => 
        lowercaseQuery.includes(keyword)
      );
      
      if (keywordMatches.length > 0) {
        const hobby: DetectedHobby = {
          type: hobbyType as HobbyType,
          confidence: keywordMatches.length / pattern.keywords.length,
          signals: {
            keywords: keywordMatches,
            packages: [],
            commands: [query],
            frequency: 1,
            confidence: keywordMatches.length / pattern.keywords.length
          },
          suggestedPackages: pattern.suggestedPackages,
          tips: pattern.tips
        };
        
        // Add integral context if available
        return this.addIntegralContext(hobby);
      }
    }
    
    return null;
  }
  
  /**
   * Add command and process it
   */
  addCommand(command: string): void {
    this.processCommand(command);
  }
  
  /**
   * Update installed packages for detection
   */
  updateInstalledPackages(packages: string[]): void {
    this.analyzeInstalledPackages(packages);
  }
}

// Export singleton instance
export const hobbyDetector = new HobbyDetector();