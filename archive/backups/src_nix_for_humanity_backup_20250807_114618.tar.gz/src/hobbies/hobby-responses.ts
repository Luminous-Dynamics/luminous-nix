/**
 * Hobby-aware response generation
 * Tailors responses based on detected user interests
 */

import { HobbyType, DetectedHobby } from './hobby-detector';

export interface HobbyResponse {
  greeting?: string;
  packageSuggestion?: string;
  contextualHelp?: string;
  communityTip?: string;
}

export class HobbyResponseGenerator {
  
  /**
   * Generate a hobby-aware greeting
   */
  generateGreeting(hobbies: DetectedHobby[]): string {
    if (hobbies.length === 0) {
      return '';
    }
    
    const primary = hobbies[0];
    const greetings: Record<HobbyType, string[]> = {
      [HobbyType.Gaming]: [
        "Ready to game? 🎮",
        "Let's level up your setup!",
        "Time for some epic gaming!"
      ],
      [HobbyType.MusicProduction]: [
        "Ready to make some music? 🎵",
        "Let's get those beats flowing!",
        "Time to create sonic magic!"
      ],
      [HobbyType.DigitalArt]: [
        "Ready to create? 🎨",
        "Let's bring your vision to life!",
        "Time to paint digitally!"
      ],
      [HobbyType.Writing]: [
        "Ready to write? ✍️",
        "Let's capture those thoughts!",
        "Time to craft your story!"
      ],
      [HobbyType.Photography]: [
        "Ready to capture moments? 📸",
        "Let's enhance those photos!",
        "Time to develop your shots!"
      ],
      [HobbyType.Programming]: [
        "Ready to code? 💻",
        "Let's build something awesome!",
        "Time to write elegant solutions!"
      ],
      [HobbyType.VideoEditing]: [
        "Ready to edit? 🎬",
        "Let's cut together something amazing!",
        "Time to tell your visual story!"
      ],
      [HobbyType.Unknown]: []
    };
    
    const hobbyGreetings = greetings[primary.type] || [];
    if (hobbyGreetings.length > 0) {
      const index = Math.floor(Math.random() * hobbyGreetings.length);
      return hobbyGreetings[index];
    }
    
    return '';
  }
  
  /**
   * Generate contextual help based on hobbies
   */
  generateContextualHelp(command: string, hobbies: DetectedHobby[]): string | null {
    if (hobbies.length === 0) return null;
    
    const primary = hobbies[0];
    
    // Gaming-specific help
    if (primary.type === HobbyType.Gaming) {
      if (command.includes('performance') || command.includes('fps')) {
        return "For better gaming performance, try: gamemode, mangohud for FPS overlay, or check your GPU drivers";
      }
      if (command.includes('controller') || command.includes('gamepad')) {
        return "For controller support: install xboxdrv or xpadneo for Xbox controllers, ds4drv for PlayStation";
      }
    }
    
    // Music production help
    if (primary.type === HobbyType.MusicProduction) {
      if (command.includes('latency') || command.includes('delay')) {
        return "For low latency audio: use JACK with qjackctl, consider a realtime kernel, and check your buffer settings";
      }
      if (command.includes('plugin') || command.includes('vst')) {
        return "For plugins: Carla can host Windows VSTs, or try native Linux plugins like Calf, x42, or LSP";
      }
    }
    
    // Art-specific help
    if (primary.type === HobbyType.DigitalArt) {
      if (command.includes('tablet') || command.includes('wacom')) {
        return "For tablet setup: install xf86-input-wacom, use 'xsetwacom' for configuration, KDE has great tablet settings";
      }
      if (command.includes('color') || command.includes('calibration')) {
        return "For color accuracy: use displaycal for monitor calibration, enable color management in your art apps";
      }
    }
    
    // Writing help
    if (primary.type === HobbyType.Writing) {
      if (command.includes('distraction') || command.includes('focus')) {
        return "For focused writing: try FocusWriter for distraction-free mode, or Obsidian's zen mode";
      }
      if (command.includes('format') || command.includes('convert')) {
        return "For document conversion: pandoc is your Swiss army knife - converts between markdown, docx, PDF, and more";
      }
    }
    
    // Photography help
    if (primary.type === HobbyType.Photography) {
      if (command.includes('raw') || command.includes('workflow')) {
        return "For RAW workflow: Darktable for processing, digiKam for organization, rapid-photo-downloader for imports";
      }
      if (command.includes('batch') || command.includes('bulk')) {
        return "For batch processing: Darktable can batch export, ImageMagick for command-line operations";
      }
    }
    
    return null;
  }
  
  /**
   * Generate package suggestions based on hobbies
   */
  generatePackageSuggestion(hobbies: DetectedHobby[]): string | null {
    if (hobbies.length === 0) return null;
    
    const primary = hobbies[0];
    const suggestions: Record<HobbyType, string> = {
      [HobbyType.Gaming]: "steam discord obs-studio gamemode mangohud",
      [HobbyType.MusicProduction]: "ardour qjackctl carla calf lsp-plugins",
      [HobbyType.DigitalArt]: "krita inkscape gimp blender",
      [HobbyType.Writing]: "obsidian ghostwriter pandoc texlive",
      [HobbyType.Photography]: "darktable digikam rapid-photo-downloader hugin",
      [HobbyType.Programming]: "vscode neovim git-lfs docker-compose",
      [HobbyType.VideoEditing]: "kdenlive obs-studio ffmpeg handbrake",
      [HobbyType.Unknown]: ""
    };
    
    const packages = suggestions[primary.type];
    if (packages) {
      return `Based on your interests, you might like: ${packages}`;
    }
    
    return null;
  }
  
  /**
   * Generate community recommendations
   */
  generateCommunityTip(hobbies: DetectedHobby[]): string | null {
    if (hobbies.length === 0) return null;
    
    const primary = hobbies[0];
    const tips: Record<HobbyType, string[]> = {
      [HobbyType.Gaming]: [
        "Check ProtonDB for game compatibility reports",
        "Join r/linux_gaming for tips and troubleshooting",
        "GamingOnLinux.com has great news and guides"
      ],
      [HobbyType.MusicProduction]: [
        "LinuxMusicians forum is super helpful",
        "Check out Unfa's YouTube channel for Linux audio",
        "The Linux Audio Users mailing list is very active"
      ],
      [HobbyType.DigitalArt]: [
        "David Revoy (Pepper&Carrot) has amazing Krita tutorials",
        "r/linuxart showcases great Linux-made art",
        "Krita's forum is very welcoming to beginners"
      ],
      [HobbyType.Writing]: [
        "The Obsidian community has tons of plugins",
        "NaNoWriMo has Linux-friendly writing tools",
        "r/plaintextproject for minimalist writing"
      ],
      [HobbyType.Photography]: [
        "pixls.us is the Linux photography community",
        "Darktable has excellent YouTube tutorials",
        "discuss.pixls.us forum for processing help"
      ],
      [HobbyType.Programming]: [
        "Dev.to has great Linux development articles",
        "r/neovim if you're into terminal editors",
        "Linux kernel docs if you want to go deep"
      ],
      [HobbyType.VideoEditing]: [
        "Kdenlive forums are very helpful",
        "r/OpenSourceVideo for Linux video tips",
        "Blender can do video editing too!"
      ],
      [HobbyType.Unknown]: []
    };
    
    const hobbyTips = tips[primary.type] || [];
    if (hobbyTips.length > 0) {
      const index = Math.floor(Math.random() * hobbyTips.length);
      return `💡 Tip: ${hobbyTips[index]}`;
    }
    
    return null;
  }
  
  /**
   * Generate response enriched with hobby context
   */
  enrichResponse(baseResponse: string, hobbies: DetectedHobby[], command?: string): string {
    const parts: string[] = [baseResponse];
    
    // Add contextual help if relevant
    if (command) {
      const help = this.generateContextualHelp(command, hobbies);
      if (help) {
        parts.push(`\n\n${help}`);
      }
    }
    
    // Occasionally add community tips (30% chance)
    if (Math.random() < 0.3) {
      const tip = this.generateCommunityTip(hobbies);
      if (tip) {
        parts.push(`\n\n${tip}`);
      }
    }
    
    return parts.join('');
  }
  
  /**
   * Generate workflow suggestions for users with multiple hobbies
   */
  generateWorkflowSuggestion(hobbies: DetectedHobby[]): string | null {
    if (hobbies.length < 2) return null;
    
    const combo = `${hobbies[0].type}+${hobbies[1].type}`;
    
    const workflows: Record<string, string> = {
      'gaming+video-editing': "Perfect combo! OBS Studio can record gameplay, then edit in Kdenlive or OpenShot",
      'music-production+video-editing': "Great for music videos! Sync your DAW with Kdenlive using JACK transport",
      'digital-art+writing': "Illustrated stories! Use Krita for art and integrate with Scribus for beautiful layouts",
      'photography+digital-art': "Photo manipulation mastery! Process RAWs in Darktable, then enhance in Krita/GIMP",
      'gaming+programming': "Game dev potential! Check out Godot engine - it's open source and Linux-native",
      'writing+programming': "Technical writing! Use Markdown + Pandoc for beautiful documentation"
    };
    
    return workflows[combo] || null;
  }
  
  /**
   * Get troubleshooting tips based on hobby
   */
  getTroubleshootingTip(error: string, hobbies: DetectedHobby[]): string | null {
    if (hobbies.length === 0) return null;
    
    const primary = hobbies[0];
    
    if (primary.type === HobbyType.Gaming && error.includes('gpu')) {
      return "Gaming GPU issue: Check if you need proprietary drivers (nvidia-driver or amdgpu-pro)";
    }
    
    if (primary.type === HobbyType.MusicProduction && error.includes('audio')) {
      return "Audio issue: Make sure JACK isn't running if using PulseAudio, or vice versa";
    }
    
    if (primary.type === HobbyType.DigitalArt && error.includes('pressure')) {
      return "Tablet pressure issue: Check xsetwacom settings, might need to configure pressure curve";
    }
    
    return null;
  }
}

// Export singleton instance
export const hobbyResponses = new HobbyResponseGenerator();