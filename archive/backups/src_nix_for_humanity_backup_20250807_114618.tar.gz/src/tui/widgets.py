"""
Custom widgets for Nix for Humanity TUI
Beautiful, accessible components for consciousness-first interaction
"""

from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import Static, Button, ProgressBar as TextualProgressBar, Label
from textual.reactive import reactive
from textual.message import Message
from textual import events
from rich.text import Text
from rich.panel import Panel
from rich.syntax import Syntax
from datetime import datetime
from typing import Optional, List, Dict, Any


class AnimatedLogo(Static):
    """Animated Nix for Humanity logo"""
    
    frame = reactive(0)
    
    FRAMES = [
        "🌟 Nix for Humanity",
        "✨ Nix for Humanity", 
        "💫 Nix for Humanity",
        "⭐ Nix for Humanity",
    ]
    
    def on_mount(self) -> None:
        """Start animation when mounted"""
        self.set_interval(0.5, self.animate)
        
    def animate(self) -> None:
        """Animate the logo"""
        self.frame = (self.frame + 1) % len(self.FRAMES)
        
    def render(self) -> str:
        """Render current frame"""
        return f"[bold cyan]{self.FRAMES[self.frame]}[/bold cyan]"


class CommandPreview(Container):
    """Preview of commands that will be executed"""
    
    def __init__(self, commands: List[Dict[str, str]]):
        super().__init__()
        self.commands = commands
        
    def compose(self) -> ComposeResult:
        """Compose the command preview"""
        yield Label("📋 Commands to execute:", classes="preview-title")
        
        for i, cmd in enumerate(self.commands, 1):
            command = cmd.get('command', '')
            description = cmd.get('description', '')
            
            # Syntax highlight the command
            syntax = Syntax(
                command, 
                "bash", 
                theme="monokai", 
                line_numbers=False,
                word_wrap=True
            )
            
            yield Static(
                Panel(
                    syntax,
                    title=f"[cyan]{i}. {description}[/cyan]",
                    border_style="cyan"
                ),
                classes="command-preview-item"
            )
            
        with Horizontal(classes="preview-buttons"):
            yield Button("Execute", variant="success", id="execute-commands")
            yield Button("Cancel", variant="error", id="cancel-commands")


class PersonalitySelector(Container):
    """Widget for selecting response personality"""
    
    personalities = {
        "minimal": "Just the facts",
        "friendly": "Warm and helpful", 
        "encouraging": "Supportive and positive",
        "technical": "Detailed explanations",
        "symbiotic": "Learning together"
    }
    
    selected = reactive("friendly")
    
    def compose(self) -> ComposeResult:
        """Compose the personality selector"""
        yield Label("🎭 Response Style:", classes="selector-title")
        
        for key, description in self.personalities.items():
            is_selected = key == self.selected
            variant = "primary" if is_selected else "default"
            
            yield Button(
                f"{description}",
                variant=variant,
                classes="personality-button",
                id=f"personality-{key}"
            )
            
    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle personality selection"""
        if event.button.id and event.button.id.startswith("personality-"):
            new_personality = event.button.id.replace("personality-", "")
            self.selected = new_personality
            
            # Update button styles
            for key in self.personalities:
                button = self.query_one(f"#personality-{key}", Button)
                button.variant = "primary" if key == new_personality else "default"


class EducationalPanel(Container):
    """Panel showing educational context about operations"""
    
    def __init__(self, education: Dict[str, str]):
        super().__init__()
        self.education = education
        
    def compose(self) -> ComposeResult:
        """Compose the educational panel"""
        yield Static(
            "[bold cyan]📚 Learning Moment[/bold cyan]",
            classes="education-title"
        )
        
        if "what_happened" in self.education:
            yield Static(
                f"[bold]What happened:[/bold] {self.education['what_happened']}",
                classes="education-item"
            )
            
        if "why_it_matters" in self.education:
            yield Static(
                f"[bold]Why it matters:[/bold] {self.education['why_it_matters']}",
                classes="education-item"
            )
            
        if "next_steps" in self.education:
            yield Static(
                f"[bold]Next steps:[/bold] {self.education['next_steps']}",
                classes="education-item"
            )


class GenerationList(Container):
    """Widget showing system generations"""
    
    def __init__(self, generations: List[Dict[str, Any]]):
        super().__init__()
        self.generations = generations
        
    def compose(self) -> ComposeResult:
        """Compose the generation list"""
        yield Label("🕐 System Generations:", classes="list-title")
        
        for gen in self.generations[:10]:  # Show last 10
            number = gen.get("number", "?")
            date = gen.get("date", "Unknown")
            current = gen.get("current", False)
            
            marker = "→ " if current else "  "
            style = "bold green" if current else "dim"
            
            yield Static(
                f"[{style}]{marker}Generation {number} - {date}[/{style}]",
                classes="generation-item"
            )


class SearchResults(Container):
    """Widget showing package search results"""
    
    def __init__(self, query: str, results: List[Dict[str, str]]):
        super().__init__()
        self.query = query
        self.results = results
        
    def compose(self) -> ComposeResult:
        """Compose search results"""
        yield Label(f"🔍 Search results for '{self.query}':", classes="results-title")
        
        if not self.results:
            yield Static("[dim]No packages found[/dim]")
            return
            
        for pkg in self.results[:10]:  # Show first 10
            name = pkg.get("name", "")
            version = pkg.get("version", "")
            description = pkg.get("description", "")[:60] + "..."
            
            yield Static(
                f"[bold cyan]{name}[/bold cyan] [dim]{version}[/dim]\n"
                f"  {description}",
                classes="search-result"
            )


class StatusIndicator(Static):
    """Animated status indicator"""
    
    STATES = {
        "idle": ("🟢", "Ready"),
        "thinking": ("🤔", "Thinking..."),
        "processing": ("⚡", "Processing..."),
        "success": ("✅", "Success!"),
        "error": ("❌", "Error"),
        "learning": ("🧠", "Learning..."),
    }
    
    state = reactive("idle")
    
    def render(self) -> str:
        """Render the status"""
        icon, text = self.STATES.get(self.state, ("❓", "Unknown"))
        return f"{icon} {text}"


class FeatureShowcase(Container):
    """Showcase panel highlighting key features"""
    
    features = [
        ("🚀", "10x Faster", "Native Python-Nix integration"),
        ("🔒", "100% Private", "Everything stays local"),
        ("🧠", "Always Learning", "Adapts to your preferences"),
        ("💬", "Natural Language", "Speak like a human"),
        ("♿", "Accessible", "Works for everyone"),
    ]
    
    def compose(self) -> ComposeResult:
        """Compose the showcase"""
        yield Label("✨ Features:", classes="showcase-title")
        
        for icon, title, description in self.features:
            yield Static(
                f"{icon} [bold]{title}[/bold] - [dim]{description}[/dim]",
                classes="feature-item"
            )


class AdaptiveProgressBar(TextualProgressBar):
    """Progress bar that adapts its style based on operation"""
    
    operation_type = reactive("default")
    
    STYLES = {
        "default": "bar-back-default",
        "update": "bar-back-update",
        "install": "bar-back-install",
        "rollback": "bar-back-rollback",
        "build": "bar-back-build",
    }
    
    def __init__(self, *args, **kwargs):
        self.operation_type = kwargs.pop("operation_type", "default")
        super().__init__(*args, **kwargs)
        
    def render_bar(self) -> str:
        """Render the progress bar with adaptive styling"""
        # This would be enhanced with Textual's styling system
        return super().render()


class ConversationFlow(Container):
    """Enhanced conversation display with flow indicators"""
    
    def __init__(self):
        super().__init__()
        self.messages = []
        
    def add_message(self, text: str, is_user: bool = True, 
                   metadata: Optional[Dict[str, Any]] = None):
        """Add a message with optional metadata"""
        timestamp = datetime.now()
        
        # Create message with flow indicator
        if is_user:
            flow_indicator = "→"
            role_style = "bold blue"
        else:
            flow_indicator = "←"
            role_style = "bold green"
            
        message = {
            "text": text,
            "is_user": is_user,
            "timestamp": timestamp,
            "metadata": metadata or {},
            "flow_indicator": flow_indicator,
            "role_style": role_style
        }
        
        self.messages.append(message)
        self.refresh()
        
    def compose(self) -> ComposeResult:
        """Compose the conversation flow"""
        for msg in self.messages:
            time_str = msg["timestamp"].strftime("%H:%M")
            role = "You" if msg["is_user"] else "Nix"
            
            # Add flow indicator for visual coherence
            yield Static(
                f"[dim]{time_str}[/dim] {msg['flow_indicator']} "
                f"[{msg['role_style']}]{role}:[/{msg['role_style']}] "
                f"{msg['text']}",
                classes="flow-message"
            )