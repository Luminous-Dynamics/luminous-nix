"""
Error Intelligence Widgets for TUI Integration

Provides rich, educational error displays with XAI explanations,
interactive solutions, and persona-aware formatting.
"""

from typing import List, Dict, Any, Optional
from textual.app import ComposeResult
from textual.containers import Container, Vertical, Horizontal, ScrollableContainer
from textual.widgets import Static, Button, Label, ProgressBar, Collapsible
from textual.reactive import reactive
from textual import events
from rich.text import Text
from rich.panel import Panel
from rich.table import Table
from rich.console import Group
from rich.columns import Columns
from rich.align import Align

from ..error_intelligence import (
    AnalyzedError,
    ErrorSolution,
    ErrorSeverity,
    ErrorCategory
)
from ..xai.causal_engine import CausalExplanation, ConfidenceLevel
from ..core.types import PersonalityType


class ErrorIntelligencePanel(Container):
    """
    Main error display panel with full intelligence integration
    """
    
    DEFAULT_CSS = """
    ErrorIntelligencePanel {
        height: auto;
        border: heavy $error;
        background: $surface;
        padding: 1;
        margin: 1;
    }
    
    ErrorIntelligencePanel.warning {
        border: heavy $warning;
    }
    
    ErrorIntelligencePanel.critical {
        border: heavy $error;
        background: $error 10%;
    }
    
    .error-header {
        text-style: bold;
        color: $error;
        margin-bottom: 1;
    }
    
    .error-summary {
        margin-bottom: 1;
        padding: 1;
        background: $panel;
    }
    
    .solution-container {
        margin: 1 0;
    }
    
    .xai-explanation {
        border: solid $primary;
        padding: 1;
        margin: 1 0;
        background: $primary 5%;
    }
    
    .preventive-tips {
        border-top: dashed $surface-lighten-2;
        margin-top: 1;
        padding-top: 1;
    }
    """
    
    def __init__(
        self,
        analyzed_error: AnalyzedError,
        xai_explanation: Optional[CausalExplanation] = None,
        personality: PersonalityType = PersonalityType.FRIENDLY,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.analyzed_error = analyzed_error
        self.xai_explanation = xai_explanation
        self.personality = personality
        self.current_solution_index = 0
        
        # Apply severity styling
        if analyzed_error.severity == ErrorSeverity.WARNING:
            self.add_class("warning")
        elif analyzed_error.severity == ErrorSeverity.CRITICAL:
            self.add_class("critical")
    
    def compose(self) -> ComposeResult:
        """Compose the error intelligence panel"""
        # Error header with icon
        severity_icon = self._get_severity_icon()
        yield Static(
            f"{severity_icon} Error: {self._get_category_description()}",
            classes="error-header"
        )
        
        # Error summary adapted for persona
        summary = self._format_error_summary()
        yield Static(summary, classes="error-summary")
        
        # XAI explanation if available
        if self.xai_explanation:
            yield XAIErrorExplanationWidget(
                self.xai_explanation,
                self.personality
            )
        
        # Solutions section
        if self.analyzed_error.solutions:
            yield Static("💡 Solutions:", classes="solutions-header")
            yield SolutionCarousel(
                self.analyzed_error.solutions,
                self.personality
            )
        
        # Educational content
        if self._should_show_education():
            yield EducationalErrorPanel(
                self.analyzed_error,
                self.personality
            )
        
        # Preventive suggestions
        if self.analyzed_error.preventive_suggestions:
            yield PreventiveTipsWidget(
                self.analyzed_error.preventive_suggestions,
                self.personality
            )
    
    def _get_severity_icon(self) -> str:
        """Get icon based on severity"""
        return {
            ErrorSeverity.INFO: "ℹ️",
            ErrorSeverity.WARNING: "⚠️",
            ErrorSeverity.ERROR: "❌",
            ErrorSeverity.CRITICAL: "🚨"
        }.get(self.analyzed_error.severity, "❓")
    
    def _get_category_description(self) -> str:
        """Get human-friendly category description"""
        descriptions = {
            ErrorCategory.PERMISSION: "Permission Issue",
            ErrorCategory.NOT_FOUND: "Not Found",
            ErrorCategory.NETWORK: "Network Problem",
            ErrorCategory.SYSTEM: "System Issue",
            ErrorCategory.DEPENDENCY: "Missing Dependencies",
            ErrorCategory.CONFIGURATION: "Configuration Error",
            ErrorCategory.USER_INPUT: "Input Error"
        }
        return descriptions.get(self.analyzed_error.category, "Unknown Error")
    
    def _format_error_summary(self) -> str:
        """Format error summary based on persona"""
        error_text = self.analyzed_error.original_error
        
        if self.personality == PersonalityType.GRANDMA_ROSE:
            return f"Oh dear, something went wrong: {error_text}\n\nDon't worry, I'll help you fix it!"
        elif self.personality == PersonalityType.MAYA_ADHD:
            return f"Error: {error_text[:50]}..."
        elif self.personality == PersonalityType.TECHNICAL:
            return f"Error Details:\n{error_text}\n\nCategory: {self.analyzed_error.category.value}"
        else:
            return f"I encountered an issue: {error_text}"
    
    def _should_show_education(self) -> bool:
        """Determine if educational content should be shown"""
        # Don't show for Maya (ADHD) or in minimal mode
        return self.personality not in [
            PersonalityType.MAYA_ADHD,
            PersonalityType.MINIMAL
        ]


class SolutionCarousel(Container):
    """
    Interactive carousel for browsing solutions
    """
    
    DEFAULT_CSS = """
    SolutionCarousel {
        height: auto;
        layout: vertical;
    }
    
    .solution-card {
        border: solid $primary;
        padding: 1;
        margin: 0 0 1 0;
        background: $panel;
    }
    
    .solution-card.selected {
        border: thick $success;
        background: $success 10%;
    }
    
    .solution-title {
        text-style: bold;
        margin-bottom: 1;
    }
    
    .solution-confidence {
        color: $text-muted;
        text-align: right;
    }
    
    .solution-steps {
        margin: 1 0;
        padding-left: 2;
    }
    
    .solution-commands {
        background: $surface;
        border: solid $primary-darken-2;
        padding: 1;
        margin: 1 0;
        font-family: monospace;
    }
    
    .solution-navigation {
        layout: horizontal;
        height: 3;
        align: center middle;
    }
    """
    
    current_index = reactive(0)
    
    def __init__(
        self,
        solutions: List[ErrorSolution],
        personality: PersonalityType = PersonalityType.FRIENDLY,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.solutions = solutions
        self.personality = personality
    
    def compose(self) -> ComposeResult:
        """Compose solution carousel"""
        if not self.solutions:
            yield Static("No solutions available")
            return
        
        # Current solution
        solution = self.solutions[self.current_index]
        
        with Container(classes="solution-card selected"):
            # Title and confidence
            with Horizontal():
                yield Static(solution.title, classes="solution-title")
                yield Static(
                    f"Confidence: {solution.confidence:.0%}",
                    classes="solution-confidence"
                )
            
            # Explanation
            if solution.explanation:
                yield Static(
                    self._format_explanation(solution.explanation),
                    classes="solution-explanation"
                )
            
            # Steps (if not minimal personality)
            if self.personality != PersonalityType.MAYA_ADHD and solution.steps:
                yield Static("Steps:", classes="steps-header")
                steps_list = Vertical(classes="solution-steps")
                for i, step in enumerate(solution.steps, 1):
                    steps_list.compose_add_child(
                        Static(f"{i}. {step}")
                    )
                yield steps_list
            
            # Commands
            if solution.commands:
                yield Static("Commands to run:", classes="commands-header")
                commands_text = "\n".join(f"$ {cmd}" for cmd in solution.commands)
                yield Static(commands_text, classes="solution-commands")
            
            # Warnings
            if solution.warnings:
                for warning in solution.warnings:
                    yield Static(f"⚠️ {warning}", classes="solution-warning")
        
        # Navigation (if multiple solutions)
        if len(self.solutions) > 1:
            with Horizontal(classes="solution-navigation"):
                yield Button(
                    "← Previous",
                    id="prev-solution",
                    disabled=self.current_index == 0
                )
                yield Static(
                    f"Solution {self.current_index + 1} of {len(self.solutions)}",
                    classes="solution-counter"
                )
                yield Button(
                    "Next →",
                    id="next-solution",
                    disabled=self.current_index == len(self.solutions) - 1
                )
        
        # Action buttons
        with Horizontal(classes="solution-actions"):
            yield Button("Try This Solution", variant="primary", id="try-solution")
            yield Button("Copy Commands", id="copy-commands")
            if solution.learn_more_url:
                yield Button("Learn More", id="learn-more")
    
    def _format_explanation(self, explanation: str) -> str:
        """Format explanation for persona"""
        if self.personality == PersonalityType.MAYA_ADHD:
            # Shorten for ADHD
            return explanation[:100] + "..." if len(explanation) > 100 else explanation
        return explanation
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle navigation buttons"""
        if event.button.id == "prev-solution" and self.current_index > 0:
            self.current_index -= 1
            self.refresh()
        elif event.button.id == "next-solution" and self.current_index < len(self.solutions) - 1:
            self.current_index += 1
            self.refresh()
        elif event.button.id == "try-solution":
            self.try_current_solution()
        elif event.button.id == "copy-commands":
            self.copy_solution_commands()
    
    def try_current_solution(self):
        """Attempt to apply the current solution"""
        solution = self.solutions[self.current_index]
        # Emit event for parent to handle
        self.post_message(TrySolutionMessage(solution))
    
    def copy_solution_commands(self):
        """Copy solution commands to clipboard"""
        solution = self.solutions[self.current_index]
        if solution.commands:
            commands = "\n".join(solution.commands)
            # Emit event for clipboard copy
            self.post_message(CopyCommandsMessage(commands))


class XAIErrorExplanationWidget(Container):
    """
    Widget for displaying XAI explanations of why errors occurred
    """
    
    DEFAULT_CSS = """
    XAIErrorExplanationWidget {
        height: auto;
        border: solid $primary;
        background: $primary 5%;
        padding: 1;
        margin: 1 0;
    }
    
    .xai-header {
        text-style: bold;
        color: $primary;
        margin-bottom: 1;
    }
    
    .confidence-bar {
        height: 1;
        margin: 1 0;
    }
    
    .factor-list {
        margin-left: 2;
    }
    
    .factor-item {
        margin-bottom: 0;
    }
    
    .show-details-button {
        margin-top: 1;
        width: auto;
    }
    """
    
    expanded = reactive(False)
    
    def __init__(
        self,
        explanation: CausalExplanation,
        personality: PersonalityType = PersonalityType.FRIENDLY,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.explanation = explanation
        self.personality = personality
    
    def compose(self) -> ComposeResult:
        """Compose XAI explanation"""
        # Header
        yield Static(
            "🤔 Why did this error happen?",
            classes="xai-header"
        )
        
        # Primary reason
        yield Static(
            self._format_primary_reason(),
            classes="primary-reason"
        )
        
        # Confidence indicator
        yield ProgressBar(
            total=100,
            progress=int(self.explanation.confidence_score * 100),
            show_eta=False,
            show_percentage=True
        )
        yield Static(
            f"Analysis confidence: {self._format_confidence()}",
            classes="confidence-text"
        )
        
        # Detailed factors (if expanded or technical persona)
        if self.expanded or self.personality == PersonalityType.TECHNICAL:
            yield Static("Contributing factors:", classes="factors-header")
            factors_list = Vertical(classes="factor-list")
            
            for factor in self.explanation.contributing_factors[:3]:
                factor_text = f"• {factor.description} ({factor.confidence:.0%})"
                factors_list.compose_add_child(
                    Static(factor_text, classes="factor-item")
                )
            
            yield factors_list
        
        # Expand/collapse button (not for Maya)
        if self.personality != PersonalityType.MAYA_ADHD:
            yield Button(
                "Show details" if not self.expanded else "Hide details",
                id="toggle-xai-details",
                classes="show-details-button"
            )
    
    def _format_primary_reason(self) -> str:
        """Format primary reason for persona"""
        reason = self.explanation.primary_reason
        
        if self.personality == PersonalityType.GRANDMA_ROSE:
            return f"Here's what happened in simple terms: {reason}"
        elif self.personality == PersonalityType.MAYA_ADHD:
            # Keep it very short
            return reason[:80] + "..." if len(reason) > 80 else reason
        else:
            return reason
    
    def _format_confidence(self) -> str:
        """Format confidence level"""
        level = self.explanation.confidence
        
        if self.personality == PersonalityType.GRANDMA_ROSE:
            if level == ConfidenceLevel.HIGH:
                return "I'm quite sure about this"
            elif level == ConfidenceLevel.MEDIUM:
                return "I think this is what happened"
            else:
                return "I'm not entirely certain"
        else:
            return f"{level.value} ({self.explanation.confidence_score:.0%})"
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle expand/collapse"""
        if event.button.id == "toggle-xai-details":
            self.expanded = not self.expanded
            self.refresh()


class EducationalErrorPanel(Container):
    """
    Educational content about the error
    """
    
    DEFAULT_CSS = """
    EducationalErrorPanel {
        height: auto;
        border: solid $primary-lighten-2;
        padding: 1;
        margin: 1 0;
        background: $surface;
    }
    
    .education-header {
        text-style: bold;
        color: $primary;
        margin-bottom: 1;
    }
    
    .concept-explanation {
        margin-bottom: 1;
        padding: 1;
        background: $panel;
        border-left: thick $primary;
    }
    """
    
    def __init__(
        self,
        analyzed_error: AnalyzedError,
        personality: PersonalityType = PersonalityType.FRIENDLY,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.analyzed_error = analyzed_error
        self.personality = personality
    
    def compose(self) -> ComposeResult:
        """Compose educational content"""
        yield Static("📚 Understanding this error:", classes="education-header")
        
        # Explain the error category
        category_explanation = self._get_category_education()
        if category_explanation:
            yield Static(
                category_explanation,
                classes="concept-explanation"
            )
        
        # Common causes
        if self.analyzed_error.pattern and self.analyzed_error.pattern.common_causes:
            yield Static("Common causes:", classes="causes-header")
            causes_list = Vertical(classes="causes-list")
            
            for cause in self.analyzed_error.pattern.common_causes[:3]:
                causes_list.compose_add_child(
                    Static(f"• {cause}")
                )
            
            yield causes_list
        
        # NixOS-specific education
        if self.personality != PersonalityType.MAYA_ADHD:
            yield Static(
                self._get_nixos_tip(),
                classes="nixos-tip"
            )
    
    def _get_category_education(self) -> str:
        """Get educational content for error category"""
        education = {
            ErrorCategory.PERMISSION: 
                "Permission errors happen when you try to modify system files without the right privileges. "
                "In NixOS, system-wide changes usually need administrator (sudo) access.",
            
            ErrorCategory.NOT_FOUND:
                "This error means NixOS couldn't find what you asked for. Package names in NixOS "
                "sometimes differ from other systems. Using 'nix search' helps find the right name.",
            
            ErrorCategory.DEPENDENCY:
                "Dependency errors occur when a package needs other packages that aren't available. "
                "NixOS's unique approach ensures all dependencies are explicitly declared.",
            
            ErrorCategory.NETWORK:
                "Network errors can happen when downloading packages or accessing remote resources. "
                "Check your internet connection and any proxy settings."
        }
        
        base_education = education.get(self.analyzed_error.category, "")
        
        # Adapt for persona
        if self.personality == PersonalityType.GRANDMA_ROSE and base_education:
            return f"Let me explain: {base_education}"
        
        return base_education
    
    def _get_nixos_tip(self) -> str:
        """Get a relevant NixOS tip"""
        tips = {
            ErrorCategory.PERMISSION: 
                "💡 Tip: Consider using configuration.nix for system-wide changes instead of imperative commands.",
            
            ErrorCategory.NOT_FOUND:
                "💡 Tip: Enable command-not-found to get package suggestions when commands aren't found.",
            
            ErrorCategory.DEPENDENCY:
                "💡 Tip: Use 'nix-shell' to create isolated environments with all dependencies."
        }
        
        return tips.get(self.analyzed_error.category, 
                        "💡 Tip: NixOS's declarative approach helps prevent many common errors.")


class PreventiveTipsWidget(Container):
    """
    Widget showing how to prevent similar errors
    """
    
    DEFAULT_CSS = """
    PreventiveTipsWidget {
        height: auto;
        border-top: dashed $surface-lighten-2;
        padding-top: 1;
        margin-top: 1;
    }
    
    .preventive-header {
        text-style: bold;
        color: $success;
        margin-bottom: 1;
    }
    
    .tip-item {
        margin-bottom: 0;
        padding-left: 2;
    }
    """
    
    def __init__(
        self,
        suggestions: List[str],
        personality: PersonalityType = PersonalityType.FRIENDLY,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.suggestions = suggestions
        self.personality = personality
    
    def compose(self) -> ComposeResult:
        """Compose preventive tips"""
        # Don't show for Maya (ADHD) - too much info
        if self.personality == PersonalityType.MAYA_ADHD:
            return
        
        header_text = self._get_header_text()
        yield Static(header_text, classes="preventive-header")
        
        # Show limited tips based on persona
        max_tips = 2 if self.personality == PersonalityType.GRANDMA_ROSE else len(self.suggestions)
        
        for tip in self.suggestions[:max_tips]:
            formatted_tip = self._format_tip(tip)
            yield Static(f"• {formatted_tip}", classes="tip-item")
    
    def _get_header_text(self) -> str:
        """Get header text for persona"""
        if self.personality == PersonalityType.GRANDMA_ROSE:
            return "🛡️ How to avoid this next time:"
        elif self.personality == PersonalityType.TECHNICAL:
            return "🛡️ Preventive measures:"
        else:
            return "🛡️ Prevent this error:"
    
    def _format_tip(self, tip: str) -> str:
        """Format tip for persona"""
        if self.personality == PersonalityType.GRANDMA_ROSE:
            # Simplify technical terms
            tip = tip.replace("declarative configuration", "the settings file")
            tip = tip.replace("garbage collection", "cleaning up old files")
        
        return tip


# Custom messages for event handling
class TrySolutionMessage:
    """Message when user wants to try a solution"""
    def __init__(self, solution: ErrorSolution):
        self.solution = solution


class CopyCommandsMessage:
    """Message when user wants to copy commands"""
    def __init__(self, commands: str):
        self.commands = commands