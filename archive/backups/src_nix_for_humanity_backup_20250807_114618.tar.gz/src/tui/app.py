#!/usr/bin/env python3
"""
Nix for Humanity - Unified Beautiful TUI with Textual
A consciousness-first terminal interface for natural NixOS interaction
"""

from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, Vertical, ScrollableContainer
from textual.widgets import Header, Footer, Input, Static, Button, Label
from textual.reactive import reactive
from textual.binding import Binding
from textual.css.query import NoMatches
from textual import events

import asyncio
from datetime import datetime
from typing import List, Optional, Dict, Any
import os
import sys

# Add backend to path
backend_path = os.path.join(os.path.dirname(__file__), '..', '..', 'backend')
sys.path.insert(0, backend_path)

from core.backend import create_backend
from api.schema import Request, Response

# Import our custom widgets
from widgets import (
    AnimatedLogo, ConversationFlow, StatusIndicator,
    PersonalitySelector, CommandPreview, EducationalPanel,
    GenerationList, SearchResults, FeatureShowcase,
    AdaptiveProgressBar
)




class NixForHumanityTUI(App):
    """Unified TUI application with beautiful features"""
    
    # Load our custom CSS
    CSS_PATH = "styles.css"
    
    TITLE = "Nix for Humanity - Natural NixOS Interface"
    SUB_TITLE = "Where consciousness meets computation"
    
    CSS = """
    Screen {
        layout: grid;
        grid-size: 2 3;
        grid-rows: auto 1fr auto;
        grid-columns: 2fr 1fr;
    }
    
    #conversation {
        column-span: 1;
        row-span: 1;
        border: solid $primary;
        padding: 1;
        margin: 0 1 1 1;
        overflow-y: scroll;
    }
    
    #sidebar {
        column-span: 1;
        row-span: 1;
        border: solid $primary;
        padding: 1;
        margin: 0 1 1 0;
    }
    
    #input-area {
        column-span: 2;
        row-span: 1;
        layout: horizontal;
        height: 3;
        margin: 0 1;
    }
    
    #user-input {
        width: 1fr;
        margin-right: 1;
    }
    
    #send-button {
        width: 10;
    }
    
    .status-title {
        text-style: bold;
        margin-bottom: 1;
    }
    
    #progress {
        height: 3;
        margin: 1 0;
    }
    
    ConversationMessage {
        margin-bottom: 1;
    }
    
    .command-button {
        margin: 0 0 1 0;
        width: 100%;
    }
    """
    
    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", priority=True),
        Binding("ctrl+l", "clear", "Clear conversation"),
        Binding("ctrl+d", "toggle_dark", "Toggle dark mode"),
        Binding("f1", "help", "Help"),
        Binding("ctrl+p", "toggle_personality", "Style", key_display="Ctrl+P"),
        Binding("ctrl+s", "toggle_status", "Status", key_display="Ctrl+S"),
        Binding("ctrl+v", "toggle_voice", "Voice", key_display="Ctrl+V"),
        Binding("tab", "focus_next", "Focus next", show=False),
        Binding("shift+tab", "focus_previous", "Focus previous", show=False),
    ]
    
    # App state
    personality = reactive("friendly")
    status_state = reactive("idle")
    show_sidebar = reactive(True)
    native_api_enabled = reactive(False)
    
    def __init__(self):
        super().__init__()
        self.backend = None
        self.conversation_flow = None
        self.status_indicator = None
        self.progress_bar = None
        self.personality_selector = None
        
    def compose(self) -> ComposeResult:
        """Compose the unified beautiful UI"""
        # Header with animated logo
        with Container(id="header-container"):
            yield AnimatedLogo()
            yield StatusIndicator(id="status")
        
        # Main layout
        with Horizontal(id="main-layout"):
            # Conversation area
            with Vertical(id="conversation-area"):
                self.conversation_flow = ConversationFlow()
                yield ScrollableContainer(self.conversation_flow, id="conversation")
                
                # Progress bar
                self.progress_bar = AdaptiveProgressBar(
                    total=100,
                    show_eta=False,
                    id="main-progress"
                )
                yield self.progress_bar
                
                # Input area
                with Horizontal(id="input-container"):
                    yield Input(
                        placeholder="✨ Ask me anything about NixOS...",
                        id="user-input"
                    )
                    yield Button("Send", variant="primary", id="send")
            
            # Sidebar
            with Container(id="sidebar", classes="sidebar-visible" if self.show_sidebar else "sidebar-hidden"):
                # Personality selector
                self.personality_selector = PersonalitySelector()
                yield self.personality_selector
                
                # Quick actions
                yield Container(
                    Static("[bold]Quick Actions[/bold]", classes="section-title"),
                    Button("🎤 Voice Mode", id="quick-voice", classes="quick-action"),
                    Button("🚀 Update System", id="quick-update", classes="quick-action"),
                    Button("🕐 List Generations", id="quick-generations", classes="quick-action"),
                    Button("↩️  Rollback", id="quick-rollback", classes="quick-action"),
                    Button("🔍 Search Packages", id="quick-search", classes="quick-action"),
                    Button("📚 Help", id="quick-help", classes="quick-action"),
                    id="quick-actions"
                )
                
                # System status (compact)
                yield Container(
                    Static("[bold]System Info[/bold]", classes="section-title"),
                    Static("", id="system-info"),
                    id="system-status"
                )
                
                # Feature showcase
                yield FeatureShowcase()
        
        yield Footer()
    
    async def on_mount(self) -> None:
        """Initialize when app is mounted"""
        # Create backend
        self.backend = create_backend(self.update_progress)
        
        # Check for native API
        self.native_api_enabled = os.getenv('NIX_HUMANITY_PYTHON_BACKEND') == 'true'
        
        # Update status
        self.status_indicator = self.query_one("#status", StatusIndicator)
        self.status_indicator.state = "idle"
        
        # Update system info
        await self.update_system_info()
        
        # Show welcome message
        await self.show_welcome()
        
        # Focus input
        self.query_one("#user-input", Input).focus()
    
    async def show_welcome(self):
        """Show beautiful welcome message"""
        welcome = """[bold cyan]Welcome to Nix for Humanity![/bold cyan]

I'm your AI partner for NixOS - here to help you manage your system naturally.

[dim]Some things you can ask me:[/dim]
• "Install firefox" - I'll guide you through package installation
• "Update my system" - I'll help you safely update NixOS
• "What's a generation?" - I'll explain NixOS concepts clearly
• "My wifi isn't working" - I'll help troubleshoot issues

[dim]Tips:[/dim]
• Speak naturally - I understand context and intent
• I'll explain what I'm doing and why
• All operations are safe by default
• Press F1 for help anytime

What would you like to do today?"""
        
        self.conversation_flow.add_message(welcome, is_user=False, metadata={
            "type": "welcome",
            "personality": "friendly"
        })
    
    async def update_system_info(self):
        """Update system information in sidebar"""
        try:
            info = f"""[dim]NixOS:[/dim] 25.11 (Xantusia)
[dim]Generation:[/dim] 42
[dim]Flakes:[/dim] ✅ Enabled
[dim]Native API:[/dim] {'🚀 Active' if self.native_api_enabled else '❌ Disabled'}"""
            
            self.query_one("#system-info").update(info)
        except Exception:
            pass
    
    def update_progress(self, message: str, progress: float):
        """Update progress from backend"""
        self.progress_bar.update(total=100, completed=int(progress * 100))
        
        # Update status
        if progress < 1.0:
            self.status_indicator.state = "processing"
        else:
            self.status_indicator.state = "success"
            # Reset after delay
            self.set_timer(2.0, lambda: setattr(self.status_indicator, 'state', 'idle'))
    
    async def process_query(self, query: str):
        """Process user query through backend"""
        # Update status
        self.status_indicator.state = "thinking"
        
        # Add user message
        self.conversation_flow.add_message(query, is_user=True)
        
        # Scroll to bottom
        conversation_container = self.query_one("#conversation", ScrollableContainer)
        conversation_container.scroll_end()
        
        # Get current personality
        personality = self.personality_selector.selected
        
        # Create request
        request = Request(
            query=query,
            context={
                "personality": personality,
                "execute": False,
                "native_api": self.native_api_enabled,
                "collect_feedback": True
            }
        )
        
        try:
            # Process through backend
            response = await self.backend.process_request(request)
            
            # Format response
            response_text = self._format_response(response)
            
            # Add response
            self.conversation_flow.add_message(
                response_text,
                is_user=False,
                metadata={
                    "intent": response.intent.type if response.intent else None,
                    "success": response.success,
                    "has_education": bool(response.data and response.data.get("education")),
                    "personality": personality
                }
            )
            
            # Show educational panel if available
            if response.data and response.data.get("education"):
                await self.show_education(response.data["education"])
            
            # Show command preview if commands available
            if response.commands and len(response.commands) > 0:
                await self.show_command_preview(response.commands)
            
            self.status_indicator.state = "success"
            
        except Exception as e:
            # Show error
            self.conversation_flow.add_message(
                f"❌ Error: {str(e)}\n\nPlease try rephrasing your request.",
                is_user=False,
                metadata={"type": "error"}
            )
            self.status_indicator.state = "error"
        
        finally:
            # Scroll to bottom
            conversation_container.scroll_end()
            # Reset status after delay
            self.set_timer(2.0, lambda: setattr(self.status_indicator, 'state', 'idle'))
    
    def _format_response(self, response: Response) -> str:
        """Format response with rich text"""
        text = response.explanation or response.text or "I've processed your request."
        
        # Add native API indicator if used
        if self.native_api_enabled:
            text = "🚀 " + text
        
        # Add suggestions
        if response.suggestions:
            text += "\n\n[bold cyan]💡 Suggestions:[/bold cyan]"
            for suggestion in response.suggestions:
                text += f"\n• {suggestion}"
        
        # Add commands preview
        if response.commands:
            text += "\n\n[bold cyan]📋 Commands:[/bold cyan]"
            for cmd in response.commands[:3]:  # Show first 3
                command = cmd.get('command', '')
                text += f"\n`{command}`"
            if len(response.commands) > 3:
                text += f"\n[dim]...and {len(response.commands) - 3} more[/dim]"
        
        return text
    
    async def show_education(self, education: Dict[str, str]):
        """Show educational panel"""
        panel = EducationalPanel(education)
        await self.mount(panel)
        # Auto-remove after 10 seconds
        self.set_timer(10.0, panel.remove)
    
    async def show_command_preview(self, commands: List[Dict[str, str]]):
        """Show command preview panel"""
        preview = CommandPreview(commands)
        await self.mount(preview)
    
    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses"""
        button_id = event.button.id
        
        if button_id == "send":
            await self.send_message()
        elif button_id == "quick-voice":
            await self.activate_voice_interface()
        elif button_id == "quick-update":
            await self.process_query("update my system")
        elif button_id == "quick-generations":
            await self.process_query("list generations")
        elif button_id == "quick-rollback":
            await self.process_query("rollback to previous generation")
        elif button_id == "quick-search":
            await self.process_query("search for development tools")
        elif button_id == "quick-help":
            self.action_help()
        elif button_id == "execute-commands":
            # TODO: Execute commands through backend - integrate with native_nix_backend.py
            # Should use NativeNixBackend for actual command execution
            try:
                from ..voice.pipecat_interface import PipecatVoiceInterface
                self.voice_interface = PipecatVoiceInterface(self.backend)
                await self.voice_interface.start_listening(
                    on_transcript=self._on_voice_transcript,
                    on_response=self._on_voice_response
                )
                self.notify("Voice interface activated! Say something...", severity="information")
            except ImportError:
                self.notify("Voice interface not available - install pipecat for voice features", severity="warning")
            self.notify("Command execution coming soon!", severity="information")
        elif button_id == "cancel-commands":
            # Remove command preview
            try:
                preview = self.query_one(CommandPreview)
                preview.remove()
            except NoMatches:
                pass
    
    async def _on_voice_transcript(self, transcript: str) -> None:
        """Handle voice input transcript from the voice interface."""
        self.notify(f"🎤 Heard: {transcript}", severity="information")
        
        # Add voice transcript as user message in conversation
        self.conversation_flow.add_message(
            f"🎤 {transcript}", 
            is_user=True, 
            metadata={"type": "voice_input", "interface": "voice"}
        )
        
        # Update status to show we're processing voice input
        self.status_indicator.state = "thinking"
        
        # Process the voice command through normal query processing
        await self.process_query(transcript)
    
    async def _on_voice_response(self, response_text: str) -> None:
        """Handle AI response for voice output."""
        self.notify(f"🗣️ Speaking: {response_text[:50]}...", severity="information")
        
        # The voice interface will handle the actual TTS
        # We just need to update the UI to show that voice output is happening
        self.status_indicator.state = "speaking"
        
        # Add visual indicator that voice response is being spoken
        self.conversation_flow.add_message(
            f"🗣️ Speaking: {response_text}",
            is_user=False,
            metadata={"type": "voice_output", "interface": "voice"}
        )
        
        # Scroll to bottom to show the voice response
        conversation_container = self.query_one("#conversation", ScrollableContainer)
        conversation_container.scroll_end()
        
        # Reset status after a brief delay
        self.set_timer(3.0, lambda: setattr(self.status_indicator, 'state', 'idle'))
    
    async def activate_voice_interface(self) -> None:
        """Activate the voice interface for hands-free interaction."""
        try:
            from ..voice.pipecat_interface import PipecatVoiceInterface
            
            # Initialize voice interface if not already done
            if not hasattr(self, 'voice_interface'):
                self.voice_interface = PipecatVoiceInterface(self.backend)
            
            # Initialize voice state tracking
            if not hasattr(self, 'voice_listening'):
                self.voice_listening = False
            
            # Check if already listening
            if getattr(self, 'voice_listening', False):
                # Stop listening
                try:
                    if hasattr(self.voice_interface, 'stop_listening'):
                        await self.voice_interface.stop_listening()
                except Exception as e:
                    self.notify(f"Error stopping voice: {str(e)}", severity="warning")
                
                self.voice_listening = False
                self.notify("🔇 Voice interface deactivated", severity="information")
                
                # Update button to show activation state
                try:
                    voice_button = self.query_one("#quick-voice")
                    voice_button.label = "🎤 Voice Mode"
                except NoMatches:
                    pass  # Button not found, continue gracefully
            else:
                # Start listening
                try:
                    await self.voice_interface.start_listening(
                        on_transcript=self._on_voice_transcript,
                        on_response=self._on_voice_response
                    )
                    self.voice_listening = True
                    self.notify("🎤 Voice interface activated! Speak naturally...", severity="information")
                    
                    # Update button to show active state
                    try:
                        voice_button = self.query_one("#quick-voice")
                        voice_button.label = "🔇 Stop Voice"
                    except NoMatches:
                        pass  # Button not found, continue gracefully
                    
                    # Add helpful instruction to conversation
                    self.conversation_flow.add_message(
                        "🎤 **Voice mode activated!** You can now speak naturally. Say something like:\n"
                        "• \"Install Firefox\"\n"
                        "• \"Update my system\"\n"
                        "• \"What are generations?\"\n\n"
                        "Click the voice button again to stop listening.",
                        is_user=False,
                        metadata={"type": "voice_activation", "interface": "system"}
                    )
                    
                    # Scroll to show the activation message
                    conversation_container = self.query_one("#conversation", ScrollableContainer)
                    conversation_container.scroll_end()
                    
                except Exception as e:
                    self.notify(f"Failed to start voice interface: {str(e)}", severity="error")
                    self.voice_listening = False
                
        except ImportError:
            self.notify("Voice interface not available - install pipecat for voice features", severity="warning")
            # Add informational message to conversation
            self.conversation_flow.add_message(
                "Voice interface requires additional dependencies. To enable voice features:\n"
                "```bash\n"
                "pip install pipecat-ai whisper-ai\n"
                "```\n"
                "For now, you can use the text interface by typing commands below.",
                is_user=False,
                metadata={"type": "voice_unavailable", "interface": "system"}
            )
            # Scroll to show the message
            conversation_container = self.query_one("#conversation", ScrollableContainer)
            conversation_container.scroll_end()
        except Exception as e:
            self.notify(f"Voice interface error: {str(e)}", severity="error")
    
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle enter key in input"""
        await self.send_message()
    
    async def send_message(self):
        """Send the current input as a message"""
        input_widget = self.query_one("#user-input", Input)
        query = input_widget.value.strip()
        
        if query:
            input_widget.value = ""
            await self.process_query(query)
    
    def action_clear(self) -> None:
        """Clear conversation"""
        self.conversation_flow.messages.clear()
        self.conversation_flow.refresh()
        asyncio.create_task(self.show_welcome())
    
    def action_toggle_personality(self) -> None:
        """Show/hide personality selector"""
        sidebar = self.query_one("#sidebar")
        sidebar.toggle_class("sidebar-hidden")
        sidebar.toggle_class("sidebar-visible")
    
    def action_toggle_status(self) -> None:
        """Toggle system status display"""
        # Update system info when toggled
        asyncio.create_task(self.update_system_info())
    
    def action_toggle_voice(self) -> None:
        """Toggle voice interface via keyboard shortcut"""
        asyncio.create_task(self.activate_voice_interface())
    
    def action_help(self) -> None:
        """Show help"""
        help_text = """[bold cyan]Nix for Humanity - Help[/bold cyan]

[bold]Keyboard Shortcuts:[/bold]
• Ctrl+C: Quit application
• Ctrl+L: Clear conversation
• Ctrl+D: Toggle dark/light theme
• Ctrl+P: Show/hide personality selector
• Ctrl+S: Toggle system status
• Ctrl+V: Toggle voice interface
• F1: This help
• Tab/Shift+Tab: Navigate
• Enter: Send message

[bold]Features:[/bold]
• 🚀 10x faster with native Python-Nix integration
• 🧠 Learns from your preferences
• 🔒 100% private - everything stays local
• ♿ Fully accessible interface
• 🎭 Multiple personality styles
• 🎤 Voice interface for hands-free interaction

[bold]Voice Interface:[/bold]
• Press Ctrl+V or click "🎤 Voice Mode" to activate
• Speak naturally - "Install Firefox", "Update system"
• Click again or press Ctrl+V to deactivate
• Requires pipecat-ai: pip install pipecat-ai whisper-ai

[bold]Example Queries:[/bold]
• "install firefox and vscode"
• "update my system safely"
• "explain what generations are"
• "why did my last update fail?"
• "search for python packages"
• "rollback to yesterday"

[bold]Pro Tips:[/bold]
• Enable native API: export NIX_HUMANITY_PYTHON_BACKEND=true
• Speak naturally - I understand context
• Ask follow-up questions
• I'll always explain what I'm doing"""
        
        self.conversation_flow.add_message(help_text, is_user=False, metadata={"type": "help"})


def main():
    """Run the unified beautiful TUI"""
    # Set environment for better performance
    if not os.getenv('NIX_HUMANITY_PYTHON_BACKEND'):
        print("💡 Tip: Enable native API for 10x performance:")
        print("   export NIX_HUMANITY_PYTHON_BACKEND=true")
        print()
    
    app = NixForHumanityTUI()
    app.run()


if __name__ == "__main__":
    main()