import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAccessibility } from '../../hooks/useAccessibility';
import { usePreferredMotion } from '../../hooks/usePreferredMotion';

interface WelcomeStepProps {
  onBegin: () => void;
  isVisible: boolean;
}

export const WelcomeStep: React.FC<WelcomeStepProps> = ({ onBegin, isVisible }) => {
  const [hasInteracted, setHasInteracted] = useState(false);
  const { announceToScreenReader } = useAccessibility();
  const prefersReducedMotion = usePreferredMotion();

  useEffect(() => {
    if (isVisible) {
      announceToScreenReader(
        "Welcome to Nix for Humanity. A gentle dot of light pulses before you. " +
        "Press Enter or click anywhere to begin our conversation."
      );
    }
  }, [isVisible, announceToScreenReader]);

  const handleInteraction = () => {
    if (!hasInteracted) {
      setHasInteracted(true);
      // Small delay for the blessing animation
      setTimeout(onBegin, 800);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleInteraction();
    }
  };

  // Pulsing animation configuration
  const pulseAnimation = prefersReducedMotion ? {} : {
    scale: [1, 1.2, 1],
    opacity: [0.6, 0.9, 0.6],
    transition: {
      duration: 3,
      repeat: Infinity,
      ease: "easeInOut"
    }
  };

  // Blessing animation when clicked
  const blessingAnimation = {
    scale: [1, 20, 30],
    opacity: [0.9, 0.5, 0],
    transition: {
      duration: 0.8,
      ease: "easeOut"
    }
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className="welcome-container"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1 }}
          onClick={handleInteraction}
          onKeyPress={handleKeyPress}
          tabIndex={0}
          role="button"
          aria-label="Begin conversation with Nix for Humanity"
        >
          <div className="welcome-content">
            {/* The pulsing dot of light */}
            <motion.div
              className="light-dot"
              animate={hasInteracted ? blessingAnimation : pulseAnimation}
              aria-hidden="true"
            >
              <div className="light-core" />
              <div className="light-glow" />
            </motion.div>

            {/* Text appears after a moment */}
            <motion.div
              className="welcome-text"
              initial={{ opacity: 0 }}
              animate={{ opacity: hasInteracted ? 0 : 1 }}
              transition={{ delay: 2, duration: 1 }}
            >
              <h1 className="welcome-greeting">Hello.</h1>
              <p className="welcome-introduction">
                I'm your Nix for Humanity partner.
              </p>
              <p className="welcome-instruction">
                <span className="sr-only">Press Enter or click to begin</span>
                <span aria-hidden="true">⏎</span>
              </p>
            </motion.div>
          </div>

          {/* Hidden live region for screen reader announcements */}
          <div 
            className="sr-only" 
            role="status" 
            aria-live="polite" 
            aria-atomic="true"
          >
            {hasInteracted && "Beginning our conversation..."}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

// CSS styles (would typically be in a separate file)
const styles = `
.welcome-container {
  position: fixed;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #0a0a0a;
  cursor: pointer;
  outline: none;
}

.welcome-container:focus-visible {
  outline: 2px solid rgba(100, 150, 255, 0.5);
  outline-offset: -2px;
}

.welcome-content {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3rem;
}

.light-dot {
  position: relative;
  width: 60px;
  height: 60px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.light-core {
  position: absolute;
  width: 20px;
  height: 20px;
  background: radial-gradient(circle, #ffffff 0%, #e0f2ff 50%, #a0c4ff 100%);
  border-radius: 50%;
  box-shadow: 0 0 20px rgba(160, 196, 255, 0.8);
}

.light-glow {
  position: absolute;
  width: 60px;
  height: 60px;
  background: radial-gradient(circle, rgba(160, 196, 255, 0.3) 0%, transparent 70%);
  border-radius: 50%;
  filter: blur(10px);
}

.welcome-text {
  text-align: center;
  color: #e0f2ff;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

.welcome-greeting {
  font-size: 2rem;
  font-weight: 300;
  margin: 0 0 1rem 0;
  letter-spacing: 0.05em;
}

.welcome-introduction {
  font-size: 1.125rem;
  font-weight: 300;
  margin: 0 0 2rem 0;
  opacity: 0.9;
}

.welcome-instruction {
  font-size: 0.875rem;
  opacity: 0.7;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.welcome-instruction span[aria-hidden="true"] {
  font-size: 1.25rem;
  opacity: 0.5;
}

/* Screen reader only content */
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

/* Reduced motion preferences */
@media (prefers-reduced-motion: reduce) {
  .light-dot {
    animation: none !important;
  }
  
  .welcome-text {
    transition: none !important;
  }
}

/* High contrast mode support */
@media (prefers-contrast: high) {
  .welcome-container {
    background: #000;
  }
  
  .light-core {
    background: #fff;
    box-shadow: 0 0 20px #fff;
  }
  
  .welcome-text {
    color: #fff;
  }
}

/* Touch device optimizations */
@media (hover: none) and (pointer: coarse) {
  .welcome-instruction span[aria-hidden="true"] {
    content: "Tap to begin";
  }
}
`;