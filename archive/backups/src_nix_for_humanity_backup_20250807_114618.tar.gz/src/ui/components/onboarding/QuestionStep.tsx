import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAccessibility } from '../../hooks/useAccessibility';
import { usePreferredMotion } from '../../hooks/usePreferredMotion';

interface QuestionOption {
  id: string;
  label: string;
  description?: string;
  example?: string;
}

interface QuestionStepProps {
  question: string;
  options: QuestionOption[];
  onAnswer: (answerId: string) => void;
  isVisible: boolean;
  currentAnswer?: string;
  allowInterruption?: boolean;
  onInterruption?: () => void;
}

export const QuestionStep: React.FC<QuestionStepProps> = ({
  question,
  options,
  onAnswer,
  isVisible,
  currentAnswer,
  allowInterruption = true,
  onInterruption
}) => {
  const [selectedOption, setSelectedOption] = useState<string>(currentAnswer || '');
  const [isTyping, setIsTyping] = useState(true);
  const [displayedText, setDisplayedText] = useState('');
  const { announceToScreenReader } = useAccessibility();
  const prefersReducedMotion = usePreferredMotion();
  const typingIntervalRef = useRef<NodeJS.Timeout>();

  // Handle typing animation
  useEffect(() => {
    if (!isVisible || prefersReducedMotion) {
      setDisplayedText(question);
      setIsTyping(false);
      return;
    }

    // Reset state when question changes
    setDisplayedText('');
    setIsTyping(true);
    
    let charIndex = 0;
    const typeSpeed = 30; // ms per character

    typingIntervalRef.current = setInterval(() => {
      if (charIndex < question.length) {
        setDisplayedText(prev => prev + question[charIndex]);
        charIndex++;
      } else {
        setIsTyping(false);
        clearInterval(typingIntervalRef.current);
      }
    }, typeSpeed);

    return () => {
      if (typingIntervalRef.current) {
        clearInterval(typingIntervalRef.current);
      }
    };
  }, [question, isVisible, prefersReducedMotion]);

  // Announce to screen readers
  useEffect(() => {
    if (isVisible && !isTyping) {
      const fullAnnouncement = `${question}. ${options.length} options available. Use arrow keys to navigate and Enter to select.`;
      announceToScreenReader(fullAnnouncement);
    }
  }, [isVisible, isTyping, question, options.length, announceToScreenReader]);

  const handleOptionSelect = (optionId: string) => {
    setSelectedOption(optionId);
  };

  const handleConfirm = () => {
    if (selectedOption) {
      onAnswer(selectedOption);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const currentIndex = options.findIndex(opt => opt.id === selectedOption);
      let newIndex: number;

      if (e.key === 'ArrowDown') {
        newIndex = currentIndex === -1 ? 0 : (currentIndex + 1) % options.length;
      } else {
        newIndex = currentIndex === -1 ? options.length - 1 : (currentIndex - 1 + options.length) % options.length;
      }

      setSelectedOption(options[newIndex].id);
      announceToScreenReader(options[newIndex].label);
    } else if (e.key === 'Enter' && selectedOption) {
      handleConfirm();
    } else if (e.key === 'Escape' && allowInterruption && onInterruption) {
      onInterruption();
    }
  };

  const handleInterruptClick = () => {
    if (isTyping && allowInterruption) {
      // Stop typing animation
      if (typingIntervalRef.current) {
        clearInterval(typingIntervalRef.current);
      }
      setDisplayedText(question);
      setIsTyping(false);
    }
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className="question-container"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5 }}
          onKeyDown={handleKeyDown}
          onClick={handleInterruptClick}
          role="group"
          aria-label="Calibration question"
        >
          {/* Question Text */}
          <motion.div
            className="question-text"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <h2 className="question-heading">
              {displayedText}
              {isTyping && (
                <span className="typing-cursor" aria-hidden="true">|</span>
              )}
            </h2>
            
            {/* Skip typing hint */}
            {isTyping && allowInterruption && (
                <motion.p
                  className="skip-hint"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 0.5 }}
                  transition={{ delay: 1 }}
                >
                  <span className="sr-only">Press any key to skip typing animation</span>
                  <span aria-hidden="true">↵ skip</span>
                </motion.p>
            )}
          </motion.div>

          {/* Options */}
          {!isTyping && (
            <motion.div
              className="options-container"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              role="radiogroup"
              aria-label="Answer options"
            >
              {options.map((option, index) => (
                <motion.div
                  key={option.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                >
                  <label
                    className={`option-label ${selectedOption === option.id ? 'selected' : ''}`}
                    tabIndex={0}
                    role="radio"
                    aria-checked={selectedOption === option.id}
                    onClick={() => handleOptionSelect(option.id)}
                    onKeyPress={(e) => {
                      if (e.key === ' ' || e.key === 'Enter') {
                        e.preventDefault();
                        handleOptionSelect(option.id);
                      }
                    }}
                  >
                    <div className="option-content">
                      <span className="option-title">{option.label}</span>
                      {option.description && (
                        <span className="option-description">{option.description}</span>
                      )}
                      {option.example && selectedOption === option.id && (
                        <motion.span
                          className="option-example"
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                        >
                          Example: {option.example}
                        </motion.span>
                      )}
                    </div>
                    <div className="option-indicator" aria-hidden="true">
                      {selectedOption === option.id ? '●' : '○'}
                    </div>
                  </label>
                </motion.div>
              ))}
            </motion.div>
          )}

          {/* Continue Button */}
          {!isTyping && selectedOption && (
            <motion.button
              className="continue-button"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              onClick={handleConfirm}
              aria-label="Continue to next question"
            >
              Continue
              <span aria-hidden="true"> →</span>
            </motion.button>
          )}

          {/* Hidden status for screen readers */}
          <div className="sr-only" role="status" aria-live="polite">
            {selectedOption && `Selected: ${options.find(o => o.id === selectedOption)?.label}`}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

// CSS styles
const styles = `
.question-container {
  max-width: 600px;
  margin: 0 auto;
  padding: 2rem;
  cursor: default;
}

.question-text {
  margin-bottom: 2rem;
}

.question-heading {
  font-size: 1.5rem;
  font-weight: 400;
  color: #e0f2ff;
  line-height: 1.6;
  margin: 0;
  position: relative;
}

.typing-cursor {
  animation: blink 1s infinite;
  font-weight: 300;
  color: #a0c4ff;
  margin-left: 2px;
}

@keyframes blink {
  0%, 50% { opacity: 1; }
  51%, 100% { opacity: 0; }
}

.skip-hint {
  margin-top: 1rem;
  font-size: 0.875rem;
  color: rgba(224, 242, 255, 0.5);
  cursor: pointer;
  user-select: none;
}

.options-container {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-bottom: 2rem;
}

.option-label {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 1.5rem;
  background: rgba(160, 196, 255, 0.05);
  border: 1px solid rgba(160, 196, 255, 0.2);
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s ease;
  outline: none;
}

.option-label:hover,
.option-label:focus-visible {
  background: rgba(160, 196, 255, 0.1);
  border-color: rgba(160, 196, 255, 0.4);
  transform: translateX(4px);
}

.option-label.selected {
  background: rgba(160, 196, 255, 0.15);
  border-color: #a0c4ff;
  box-shadow: 0 0 0 2px rgba(160, 196, 255, 0.2);
}

.option-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.option-title {
  font-size: 1.125rem;
  color: #e0f2ff;
}

.option-description {
  font-size: 0.875rem;
  color: rgba(224, 242, 255, 0.7);
}

.option-example {
  font-size: 0.813rem;
  color: rgba(160, 196, 255, 0.8);
  font-style: italic;
  margin-top: 0.5rem;
  overflow: hidden;
}

.option-indicator {
  font-size: 1.25rem;
  color: #a0c4ff;
  margin-left: 1rem;
  flex-shrink: 0;
}

.continue-button {
  background: linear-gradient(135deg, #4a6fa5 0%, #6495ed 100%);
  color: white;
  border: none;
  padding: 0.75rem 2rem;
  border-radius: 24px;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.3s ease;
  outline: none;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin: 0 auto;
}

.continue-button:hover,
.continue-button:focus-visible {
  transform: translateY(-2px);
  box-shadow: 0 4px 20px rgba(100, 149, 237, 0.4);
}

.continue-button:active {
  transform: translateY(0);
}

/* Accessibility improvements */
@media (prefers-reduced-motion: reduce) {
  .option-label,
  .continue-button {
    transition: none !important;
  }
  
  .typing-cursor {
    animation: none;
    opacity: 1;
  }
}

/* High contrast mode */
@media (prefers-contrast: high) {
  .option-label {
    border-width: 2px;
  }
  
  .option-label.selected {
    background: #fff;
    color: #000;
  }
  
  .option-label.selected .option-title,
  .option-label.selected .option-description {
    color: #000;
  }
}

/* Touch-friendly sizing */
@media (hover: none) and (pointer: coarse) {
  .option-label {
    padding: 1.25rem 1.5rem;
    min-height: 60px;
  }
  
  .continue-button {
    padding: 1rem 2.5rem;
    font-size: 1.125rem;
  }
}
`;