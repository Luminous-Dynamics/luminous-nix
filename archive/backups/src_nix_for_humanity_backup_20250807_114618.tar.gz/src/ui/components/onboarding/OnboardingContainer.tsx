import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { WelcomeStep } from './WelcomeStep';
import { QuestionStep } from './QuestionStep';
import { SynthesisStep } from './SynthesisStep';
import { onboardingQuestions, derivePersonalityProfile } from '../../data/onboardingFlow';
import { useAccessibility } from '../../hooks/useAccessibility';
import { useLocalStorage } from '../../hooks/useLocalStorage';

interface OnboardingContainerProps {
  onComplete: (profile: UserProfile) => void;
  onSkip?: () => void;
}

export interface UserProfile {
  primaryStyle: string;
  styleBlend: Array<{ style: string; weight: number }>;
  interactionPreference: string;
  learningStyle: string;
  communicationDensity: string;
  calibrationAnswers: Record<string, string>;
  calibrationDate: string;
  hasCompletedOnboarding: boolean;
}

type OnboardingStep = 'welcome' | 'questions' | 'synthesis' | 'blessing';

export const OnboardingContainer: React.FC<OnboardingContainerProps> = ({
  onComplete,
  onSkip
}) => {
  const [currentStep, setCurrentStep] = useState<OnboardingStep>('welcome');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [derivedProfile, setDerivedProfile] = useState<UserProfile | null>(null);
  const [isInterrupted, setIsInterrupted] = useState(false);
  
  const { announceToScreenReader } = useAccessibility();
  const [storedProfile, setStoredProfile] = useLocalStorage<UserProfile>('nfh-user-profile');

  // Check if user has already completed onboarding
  useEffect(() => {
    if (storedProfile?.hasCompletedOnboarding && onSkip) {
      onSkip();
    }
  }, [storedProfile, onSkip]);

  // Handle welcome completion
  const handleWelcomeComplete = useCallback(() => {
    setCurrentStep('questions');
    announceToScreenReader('Beginning calibration questions. You can interrupt at any time.');
  }, [announceToScreenReader]);

  // Handle question answers
  const handleQuestionAnswer = useCallback((answerId: string) => {
    const currentQuestion = onboardingQuestions[currentQuestionIndex];
    const newAnswers = {
      ...answers,
      [currentQuestion.id]: answerId
    };
    setAnswers(newAnswers);

    // Move to next question or synthesis
    if (currentQuestionIndex < onboardingQuestions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // All questions answered, move to synthesis
      const profile = derivePersonalityProfile(newAnswers);
      const fullProfile: UserProfile = {
        ...profile,
        calibrationAnswers: newAnswers,
        calibrationDate: new Date().toISOString(),
        hasCompletedOnboarding: false // Will be set true after blessing
      };
      setDerivedProfile(fullProfile);
      setCurrentStep('synthesis');
    }
  }, [currentQuestionIndex, answers]);

  // Handle synthesis confirmation
  const handleSynthesisConfirm = useCallback(() => {
    if (derivedProfile) {
      setCurrentStep('blessing');
      // Start blessing animation
      setTimeout(() => {
        const finalProfile = {
          ...derivedProfile,
          hasCompletedOnboarding: true
        };
        setStoredProfile(finalProfile);
        onComplete(finalProfile);
      }, 2000); // 2 second blessing animation
    }
  }, [derivedProfile, setStoredProfile, onComplete]);

  // Handle synthesis adjustment request
  const handleSynthesisAdjust = useCallback(() => {
    // Reset to first question
    setCurrentQuestionIndex(0);
    setCurrentStep('questions');
    announceToScreenReader('Returning to calibration questions for adjustment.');
  }, [announceToScreenReader]);

  // Handle interruption
  const handleInterruption = useCallback(() => {
    setIsInterrupted(true);
    announceToScreenReader(
      'Calibration paused. Would you like to continue with quick setup or resume calibration?'
    );
  }, [announceToScreenReader]);

  // Handle interruption choices
  const handleQuickSetup = useCallback(() => {
    // Use default friendly profile
    const defaultProfile: UserProfile = {
      primaryStyle: 'Friendly',
      styleBlend: [{ style: 'Friendly', weight: 1.0 }],
      interactionPreference: 'conversational',
      learningStyle: 'experiential',
      communicationDensity: 'light',
      calibrationAnswers: {},
      calibrationDate: new Date().toISOString(),
      hasCompletedOnboarding: true
    };
    setStoredProfile(defaultProfile);
    onComplete(defaultProfile);
  }, [setStoredProfile, onComplete]);

  const handleResumeCalibration = useCallback(() => {
    setIsInterrupted(false);
    announceToScreenReader('Resuming calibration.');
  }, [announceToScreenReader]);

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isInterrupted) {
        handleInterruption();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isInterrupted, handleInterruption]);

  return (
    <div className="onboarding-container" role="main" aria-label="Nix for Humanity Onboarding">
      <AnimatePresence mode="wait">
        {/* Welcome Step */}
        {currentStep === 'welcome' && (
          <WelcomeStep
            key="welcome"
            onBegin={handleWelcomeComplete}
            isVisible={true}
          />
        )}

        {/* Question Steps */}
        {currentStep === 'questions' && !isInterrupted && (
          <QuestionStep
            key={`question-${currentQuestionIndex}`}
            question={onboardingQuestions[currentQuestionIndex].question}
            options={onboardingQuestions[currentQuestionIndex].options}
            onAnswer={handleQuestionAnswer}
            isVisible={true}
            currentAnswer={answers[onboardingQuestions[currentQuestionIndex].id]}
            allowInterruption={true}
            onInterruption={handleInterruption}
          />
        )}

        {/* Interruption Dialog */}
        {isInterrupted && (
          <motion.div
            key="interruption"
            className="interruption-dialog"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
          >
            <h2>No worries! How would you like to proceed?</h2>
            <div className="interruption-options">
              <button onClick={handleQuickSetup} className="option-button primary">
                Use friendly defaults
                <span className="option-description">
                  Start with a warm, helpful personality (you can change this anytime)
                </span>
              </button>
              <button onClick={handleResumeCalibration} className="option-button secondary">
                Continue calibration
                <span className="option-description">
                  Just {onboardingQuestions.length - currentQuestionIndex} questions remaining
                </span>
              </button>
            </div>
          </motion.div>
        )}

        {/* Synthesis Step */}
        {currentStep === 'synthesis' && derivedProfile && (
          <SynthesisStep
            key="synthesis"
            profile={derivedProfile}
            onConfirm={handleSynthesisConfirm}
            onAdjust={handleSynthesisAdjust}
            isVisible={true}
          />
        )}

        {/* Blessing Animation */}
        {currentStep === 'blessing' && (
          <motion.div
            key="blessing"
            className="blessing-container"
            initial={{ opacity: 1 }}
            animate={{ opacity: 0 }}
            transition={{ duration: 2, ease: 'easeInOut' }}
          >
            <motion.div
              className="blessing-dot"
              initial={{ scale: 1 }}
              animate={{ scale: 50 }}
              transition={{ duration: 2, ease: 'easeOut' }}
            />
            <motion.h2
              className="blessing-text"
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 1, 1, 0] }}
              transition={{ times: [0, 0.3, 0.7, 1], duration: 2 }}
            >
              Perfect. Let's begin...
            </motion.h2>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Progress Indicator */}
      {currentStep === 'questions' && !isInterrupted && (
        <motion.div
          className="progress-indicator"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <div className="progress-dots">
            {onboardingQuestions.map((_, index) => (
              <div
                key={index}
                className={`progress-dot ${index <= currentQuestionIndex ? 'active' : ''}`}
                aria-label={`Question ${index + 1} of ${onboardingQuestions.length}`}
              />
            ))}
          </div>
          <p className="sr-only">
            Question {currentQuestionIndex + 1} of {onboardingQuestions.length}
          </p>
        </motion.div>
      )}
    </div>
  );
};

// CSS styles
const styles = `
.onboarding-container {
  position: fixed;
  inset: 0;
  background: #0a0a0a;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

/* Interruption Dialog */
.interruption-dialog {
  max-width: 500px;
  padding: 2rem;
  text-align: center;
}

.interruption-dialog h2 {
  color: #e0f2ff;
  font-weight: 400;
  margin-bottom: 2rem;
}

.interruption-options {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.option-button {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding: 1.5rem;
  border: 1px solid rgba(160, 196, 255, 0.3);
  background: rgba(160, 196, 255, 0.05);
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s ease;
  text-align: left;
  gap: 0.5rem;
}

.option-button:hover,
.option-button:focus-visible {
  background: rgba(160, 196, 255, 0.1);
  border-color: rgba(160, 196, 255, 0.5);
  transform: translateY(-2px);
}

.option-button.primary {
  border-color: #4a6fa5;
  background: rgba(74, 111, 165, 0.2);
}

.option-button .option-description {
  font-size: 0.875rem;
  color: rgba(224, 242, 255, 0.7);
  font-weight: 400;
}

/* Blessing Animation */
.blessing-container {
  position: fixed;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #0a0a0a;
}

.blessing-dot {
  position: absolute;
  width: 60px;
  height: 60px;
  background: radial-gradient(circle, #ffffff 0%, #e0f2ff 50%, #a0c4ff 100%);
  border-radius: 50%;
  filter: blur(2px);
}

.blessing-text {
  position: relative;
  z-index: 1;
  color: #e0f2ff;
  font-weight: 300;
  font-size: 1.5rem;
}

/* Progress Indicator */
.progress-indicator {
  position: fixed;
  bottom: 2rem;
  left: 50%;
  transform: translateX(-50%);
}

.progress-dots {
  display: flex;
  gap: 0.5rem;
}

.progress-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: rgba(160, 196, 255, 0.2);
  transition: all 0.3s ease;
}

.progress-dot.active {
  background: #a0c4ff;
  box-shadow: 0 0 10px rgba(160, 196, 255, 0.5);
}

/* Accessibility */
@media (prefers-reduced-motion: reduce) {
  .option-button,
  .progress-dot {
    transition: none !important;
  }
}

/* Mobile optimization */
@media (max-width: 600px) {
  .onboarding-container {
    padding: 1rem;
  }
  
  .interruption-dialog {
    max-width: 100%;
  }
}
`;