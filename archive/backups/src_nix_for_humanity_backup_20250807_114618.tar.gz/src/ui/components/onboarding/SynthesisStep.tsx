import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { UserProfile } from './OnboardingContainer';
import { useAccessibility } from '../../hooks/useAccessibility';

interface SynthesisStepProps {
  profile: UserProfile;
  onConfirm: () => void;
  onAdjust: () => void;
  isVisible: boolean;
}

export const SynthesisStep: React.FC<SynthesisStepProps> = ({
  profile,
  onConfirm,
  onAdjust,
  isVisible
}) => {
  const { announceToScreenReader } = useAccessibility();

  useEffect(() => {
    if (isVisible) {
      announceToScreenReader(
        `Based on your preferences, I'll be ${profile.primaryStyle.toLowerCase()} in my interactions. ` +
        `You prefer ${profile.interactionPreference} communication with ${profile.communicationDensity} feedback. ` +
        `Press Enter to confirm or A to adjust.`
      );
    }
  }, [isVisible, profile, announceToScreenReader]);

  const getPersonalityDescription = (style: string): string => {
    const descriptions: Record<string, string> = {
      Minimal: "I'll be efficient and stay out of your way, providing just what you need.",
      Friendly: "I'll be warm and conversational, like a knowledgeable friend helping out.",
      Encouraging: "I'll celebrate your progress and provide supportive guidance along the way.",
      Playful: "I'll keep things light and fun while we work together.",
      Adaptive: "I'll adjust my style based on what you're doing and how you're feeling."
    };
    return descriptions[style] || descriptions.Friendly;
  };

  const getCommunicationExample = (profile: UserProfile): string => {
    const density = profile.communicationDensity;
    const style = profile.primaryStyle;

    if (density === 'sparse' && style === 'Minimal') {
      return 'firefox → ✓';
    } else if (density === 'light' && style === 'Minimal') {
      return '"Installing firefox... Done."';
    } else if (density === 'rich' && style === 'Friendly') {
      return '"I\'m installing Firefox for you now. This will set up the latest version with privacy protections enabled. Almost done... There we go! Firefox is ready to use."';
    } else if (density === 'expressive' && style === 'Encouraging') {
      return '"Great choice! Installing Firefox for you... 🦊 And we\'re done! You\'ve got a fantastic browser ready to explore the web safely. Well done!"';
    } else {
      return '"Installing Firefox for you... All set!"';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      onConfirm();
    } else if (e.key.toLowerCase() === 'a') {
      onAdjust();
    }
  };

  return (
    <motion.div
      className="synthesis-container"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
      onKeyDown={handleKeyDown}
      tabIndex={0}
      role="region"
      aria-label="Personality synthesis"
    >
      <motion.h2
        className="synthesis-title"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
      >
        Perfect! Here's how I'll interact with you:
      </motion.h2>

      <motion.div
        className="personality-summary"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.4 }}
      >
        <div className="personality-badge">
          <span className="badge-label">Your AI Personality</span>
          <span className="badge-value">{profile.primaryStyle}</span>
        </div>

        <p className="personality-description">
          {getPersonalityDescription(profile.primaryStyle)}
        </p>

        <div className="example-box">
          <span className="example-label">Example response to "install firefox":</span>
          <div className="example-response">
            {getCommunicationExample(profile)}
          </div>
        </div>

        {/* Show style blend if mixed */}
        {profile.styleBlend.length > 1 && (
          <motion.div
            className="style-blend"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
          >
            <span className="blend-label">Personality blend:</span>
            <div className="blend-bars">
              {profile.styleBlend.map(({ style, weight }) => (
                <div key={style} className="blend-item">
                  <span className="blend-style">{style}</span>
                  <div className="blend-bar">
                    <div
                      className="blend-fill"
                      style={{ width: `${weight * 100}%` }}
                    />
                  </div>
                  <span className="blend-percent">{Math.round(weight * 100)}%</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </motion.div>

      <motion.div
        className="synthesis-actions"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
      >
        <button
          className="confirm-button"
          onClick={onConfirm}
          aria-label="Confirm personality settings"
        >
          Sounds perfect!
          <span aria-hidden="true"> ✓</span>
        </button>
        
        <button
          className="adjust-button"
          onClick={onAdjust}
          aria-label="Adjust personality settings"
        >
          Let me adjust this
        </button>
      </motion.div>

      <motion.p
        className="reminder-text"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        You can always change these preferences later by saying "change your personality"
      </motion.p>
    </motion.div>
  );
};

// CSS styles
const styles = `
.synthesis-container {
  max-width: 600px;
  padding: 2rem;
  text-align: center;
  outline: none;
}

.synthesis-title {
  color: #e0f2ff;
  font-size: 1.5rem;
  font-weight: 400;
  margin-bottom: 2rem;
}

.personality-summary {
  background: rgba(160, 196, 255, 0.05);
  border: 1px solid rgba(160, 196, 255, 0.2);
  border-radius: 16px;
  padding: 2rem;
  margin-bottom: 2rem;
}

.personality-badge {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
}

.badge-label {
  font-size: 0.875rem;
  color: rgba(224, 242, 255, 0.7);
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.badge-value {
  font-size: 2rem;
  font-weight: 300;
  color: #a0c4ff;
  background: linear-gradient(135deg, #4a6fa5, #6495ed);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.personality-description {
  color: #e0f2ff;
  line-height: 1.6;
  margin-bottom: 1.5rem;
}

.example-box {
  background: rgba(0, 0, 0, 0.3);
  border: 1px solid rgba(160, 196, 255, 0.1);
  border-radius: 8px;
  padding: 1rem;
  text-align: left;
}

.example-label {
  display: block;
  font-size: 0.813rem;
  color: rgba(224, 242, 255, 0.6);
  margin-bottom: 0.5rem;
}

.example-response {
  font-family: 'Courier New', monospace;
  color: #a0c4ff;
  font-size: 0.875rem;
  white-space: pre-wrap;
}

.style-blend {
  margin-top: 1.5rem;
  padding-top: 1.5rem;
  border-top: 1px solid rgba(160, 196, 255, 0.1);
}

.blend-label {
  display: block;
  font-size: 0.875rem;
  color: rgba(224, 242, 255, 0.7);
  margin-bottom: 1rem;
}

.blend-bars {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.blend-item {
  display: grid;
  grid-template-columns: 100px 1fr 50px;
  align-items: center;
  gap: 1rem;
}

.blend-style {
  font-size: 0.875rem;
  color: #e0f2ff;
  text-align: right;
}

.blend-bar {
  height: 8px;
  background: rgba(160, 196, 255, 0.1);
  border-radius: 4px;
  overflow: hidden;
}

.blend-fill {
  height: 100%;
  background: linear-gradient(90deg, #4a6fa5, #6495ed);
  border-radius: 4px;
  transition: width 0.3s ease;
}

.blend-percent {
  font-size: 0.813rem;
  color: rgba(224, 242, 255, 0.6);
}

.synthesis-actions {
  display: flex;
  gap: 1rem;
  justify-content: center;
  margin-bottom: 1.5rem;
}

.confirm-button,
.adjust-button {
  padding: 0.75rem 2rem;
  border-radius: 24px;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.2s ease;
  border: 1px solid transparent;
  outline: none;
}

.confirm-button {
  background: linear-gradient(135deg, #4a6fa5, #6495ed);
  color: white;
  border: none;
}

.confirm-button:hover,
.confirm-button:focus-visible {
  transform: translateY(-2px);
  box-shadow: 0 4px 20px rgba(100, 149, 237, 0.4);
}

.adjust-button {
  background: transparent;
  color: #a0c4ff;
  border-color: rgba(160, 196, 255, 0.3);
}

.adjust-button:hover,
.adjust-button:focus-visible {
  background: rgba(160, 196, 255, 0.1);
  border-color: rgba(160, 196, 255, 0.5);
}

.reminder-text {
  font-size: 0.875rem;
  color: rgba(224, 242, 255, 0.5);
  font-style: italic;
}

/* Mobile optimization */
@media (max-width: 600px) {
  .synthesis-container {
    padding: 1rem;
  }
  
  .synthesis-actions {
    flex-direction: column;
  }
  
  .confirm-button,
  .adjust-button {
    width: 100%;
  }
}
`;