import React, { useState } from 'react';
import { OnboardingContainer, UserProfile } from './components/onboarding/OnboardingContainer';
import { useLocalStorage } from './hooks/useLocalStorage';

function App() {
  const [userProfile, setUserProfile] = useLocalStorage<UserProfile>('nfh-user-profile');
  const [showOnboarding, setShowOnboarding] = useState(!userProfile?.hasCompletedOnboarding);

  const handleOnboardingComplete = (profile: UserProfile) => {
    setUserProfile(profile);
    setShowOnboarding(false);
    console.log('User profile calibrated:', profile);
    
    // Here you would initialize your NLP system with the user's preferences
    // initializeNLP(profile);
  };

  const handleOnboardingSkip = () => {
    setShowOnboarding(false);
  };

  if (showOnboarding) {
    return (
      <OnboardingContainer
        onComplete={handleOnboardingComplete}
        onSkip={handleOnboardingSkip}
      />
    );
  }

  // Main app content
  return (
    <div className="app">
      <h1>Nix for Humanity</h1>
      {userProfile && (
        <div className="profile-info">
          <h2>Your Profile</h2>
          <p>Primary Style: {userProfile.primaryStyle}</p>
          <p>Interaction Preference: {userProfile.interactionPreference}</p>
          <p>Learning Style: {userProfile.learningStyle}</p>
          <p>Communication Density: {userProfile.communicationDensity}</p>
          
          <button onClick={() => setShowOnboarding(true)}>
            Recalibrate Personality
          </button>
        </div>
      )}
      
      <div className="main-interface">
        {/* Your main NLP interface goes here */}
        <p>Main conversational interface would go here...</p>
      </div>
    </div>
  );
}

export default App;

// Basic styles for the demo
const styles = `
.app {
  min-height: 100vh;
  background: #0a0a0a;
  color: #e0f2ff;
  padding: 2rem;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

.profile-info {
  background: rgba(160, 196, 255, 0.05);
  border: 1px solid rgba(160, 196, 255, 0.2);
  border-radius: 8px;
  padding: 1.5rem;
  margin-bottom: 2rem;
}

.profile-info h2 {
  margin-top: 0;
  color: #a0c4ff;
}

.profile-info button {
  margin-top: 1rem;
  padding: 0.5rem 1rem;
  background: transparent;
  border: 1px solid rgba(160, 196, 255, 0.3);
  color: #a0c4ff;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.profile-info button:hover {
  background: rgba(160, 196, 255, 0.1);
  border-color: rgba(160, 196, 255, 0.5);
}

.main-interface {
  background: rgba(160, 196, 255, 0.02);
  border: 1px solid rgba(160, 196, 255, 0.1);
  border-radius: 8px;
  padding: 2rem;
  min-height: 400px;
}
`;