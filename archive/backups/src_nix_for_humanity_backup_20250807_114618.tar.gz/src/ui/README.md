# 🎨 Nix for Humanity - Onboarding UI

This is the Integral Onboarding Experience UI for Nix for Humanity - a 4-question calibration conversation that replaces continuous psycho-spiritual tracking.

## 🚀 Quick Start

```bash
# Run the development server
./run-dev.sh

# Or manually:
npm install
npm run dev
```

Then open http://localhost:5173 in your browser.

## 🏗️ Architecture

### Components
- **WelcomeStep**: Pulsing dot welcome screen with blessing animation
- **QuestionStep**: Reusable question component with typing animation
- **OnboardingContainer**: Main orchestrator managing the flow
- **SynthesisStep**: Profile summary and confirmation

### Data Flow
1. Welcome → 4 Questions → Synthesis → Blessing → Main App
2. Stores profile in localStorage for privacy
3. Derives personality blend from answers

### Key Features
- ✨ Typing animation with interruption support
- ♿ Full accessibility (ARIA, keyboard nav, screen readers)
- 🎯 Respects prefers-reduced-motion
- 💾 Local-first data storage
- 🎨 Beautiful animations with Framer Motion

## 📁 File Structure

```
src/ui/
├── components/
│   └── onboarding/
│       ├── WelcomeStep.tsx      # Welcome screen
│       ├── QuestionStep.tsx     # Question component
│       ├── OnboardingContainer.tsx # Main orchestrator
│       └── SynthesisStep.tsx   # Profile summary
├── data/
│   └── onboardingFlow.ts        # Questions & logic
├── hooks/
│   ├── useLocalStorage.ts       # localStorage hook
│   ├── useAccessibility.ts     # Accessibility hook
│   └── usePreferredMotion.ts   # Motion preference
├── styles/
│   └── global.css               # All styles
├── App.tsx                      # Main app
├── index.tsx                    # Entry point
└── index.html                   # HTML template
```

## 🎯 Personality System

The onboarding derives one of 5 personality styles:
- **Minimal**: Clean, efficient, technical
- **Friendly**: Warm, helpful, conversational  
- **Encouraging**: Supportive, celebrates progress
- **Playful**: Light humor, engaging
- **Sacred** (optional): Mindful, mantras

Blends are created when multiple styles are indicated.

## 🧪 Testing

```bash
# Run tests (when implemented)
npm test

# Type checking
npm run type-check

# Linting
npm run lint
```

## 🔧 Configuration

The app uses Vite for fast development:
- Hot Module Replacement (HMR)
- TypeScript support
- React Fast Refresh
- Path aliases (@components, @hooks, etc.)

## 📝 Development Notes

1. **Accessibility First**: Every component must be keyboard navigable and screen reader friendly
2. **Progressive Enhancement**: Works without JS (shows message), enhances with JS
3. **Privacy First**: All data stays in browser localStorage
4. **Responsive**: Works on all screen sizes
5. **Performance**: Lazy load heavy components

## 🌊 We Flow!

This onboarding experience embodies the vision of technology that adapts to users, not the other way around. The interface learns YOUR communication style through a simple, respectful conversation.

---

Built with 💜 by Luminous-Dynamics