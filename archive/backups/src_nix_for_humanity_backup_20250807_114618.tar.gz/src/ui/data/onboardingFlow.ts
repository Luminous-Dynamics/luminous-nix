export interface OnboardingQuestion {
  id: string;
  question: string;
  options: Array<{
    id: string;
    label: string;
    description?: string;
    example?: string;
    // Maps to personality preferences
    implications: {
      personalityStyle?: string;
      interactionPreference?: string;
      learningStyle?: string;
      communicationDensity?: string;
    };
  }>;
}

export const onboardingQuestions: OnboardingQuestion[] = [
  {
    id: 'interaction-style',
    question: "How do you prefer to interact with technology?",
    options: [
      {
        id: 'conversational',
        label: 'Natural conversation',
        description: 'Chat like with a helpful friend',
        example: '"Hey, can you help me install a browser?"',
        implications: {
          personalityStyle: 'Friendly',
          interactionPreference: 'conversational'
        }
      },
      {
        id: 'efficient',
        label: 'Quick and efficient',
        description: 'Just the essentials, please',
        example: '"install firefox"',
        implications: {
          personalityStyle: 'Minimal',
          interactionPreference: 'command-like'
        }
      },
      {
        id: 'guided',
        label: 'Step-by-step guidance',
        description: 'Walk me through everything',
        example: '"I\'m new to this, can you guide me?"',
        implications: {
          personalityStyle: 'Encouraging',
          interactionPreference: 'tutorial'
        }
      },
      {
        id: 'flexible',
        label: 'It depends on my mood',
        description: 'Sometimes chatty, sometimes brief',
        implications: {
          personalityStyle: 'Adaptive',
          interactionPreference: 'mixed'
        }
      }
    ]
  },
  {
    id: 'learning-preference',
    question: "When learning something new, you prefer to...",
    options: [
      {
        id: 'doing',
        label: 'Jump in and try it',
        description: 'Learn by doing',
        implications: {
          learningStyle: 'experiential',
          personalityStyle: 'Minimal'
        }
      },
      {
        id: 'understanding',
        label: 'Understand the why first',
        description: 'Context helps me learn',
        implications: {
          learningStyle: 'conceptual',
          personalityStyle: 'Friendly'
        }
      },
      {
        id: 'examples',
        label: 'See examples and patterns',
        description: 'Show me how others do it',
        implications: {
          learningStyle: 'observational',
          personalityStyle: 'Encouraging'
        }
      },
      {
        id: 'structured',
        label: 'Follow a structured path',
        description: 'Step-by-step is best',
        implications: {
          learningStyle: 'sequential',
          personalityStyle: 'Encouraging'
        }
      }
    ]
  },
  {
    id: 'feedback-style',
    question: "How much feedback do you like when things are working?",
    options: [
      {
        id: 'minimal',
        label: 'Minimal - assume success',
        description: 'Only tell me if something goes wrong',
        implications: {
          communicationDensity: 'sparse',
          personalityStyle: 'Minimal'
        }
      },
      {
        id: 'confirmations',
        label: 'Brief confirmations',
        description: 'Quick "done" or checkmark is enough',
        implications: {
          communicationDensity: 'light',
          personalityStyle: 'Minimal'
        }
      },
      {
        id: 'detailed',
        label: 'Detailed updates',
        description: 'Tell me what\'s happening and why',
        implications: {
          communicationDensity: 'rich',
          personalityStyle: 'Friendly'
        }
      },
      {
        id: 'celebratory',
        label: 'Celebrate successes!',
        description: 'I like encouragement and recognition',
        implications: {
          communicationDensity: 'expressive',
          personalityStyle: 'Encouraging'
        }
      }
    ]
  },
  {
    id: 'personality-preference',
    question: "If your computer had a personality, it would be...",
    options: [
      {
        id: 'butler',
        label: 'A efficient butler',
        description: 'Professional, precise, and unobtrusive',
        implications: {
          personalityStyle: 'Minimal',
          interactionPreference: 'formal'
        }
      },
      {
        id: 'friend',
        label: 'A knowledgeable friend',
        description: 'Warm, helpful, and conversational',
        implications: {
          personalityStyle: 'Friendly',
          interactionPreference: 'casual'
        }
      },
      {
        id: 'mentor',
        label: 'An encouraging mentor',
        description: 'Supportive, patient, and celebrates growth',
        implications: {
          personalityStyle: 'Encouraging',
          interactionPreference: 'supportive'
        }
      },
      {
        id: 'companion',
        label: 'A playful companion',
        description: 'Light-hearted and makes computing fun',
        implications: {
          personalityStyle: 'Playful',
          interactionPreference: 'playful'
        }
      }
    ]
  }
];

// Helper function to derive personality profile from answers
export function derivePersonalityProfile(answers: Record<string, string>) {
  const implications = {
    personalityStyle: [] as string[],
    interactionPreference: [] as string[],
    learningStyle: [] as string[],
    communicationDensity: [] as string[]
  };

  // Collect all implications from answers
  onboardingQuestions.forEach(question => {
    const answerId = answers[question.id];
    const selectedOption = question.options.find(opt => opt.id === answerId);
    
    if (selectedOption?.implications) {
      Object.entries(selectedOption.implications).forEach(([key, value]) => {
        if (value && key in implications) {
          implications[key as keyof typeof implications].push(value);
        }
      });
    }
  });

  // Determine primary personality style (most common)
  const styleCounts = implications.personalityStyle.reduce((acc, style) => {
    acc[style] = (acc[style] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const primaryStyle = Object.entries(styleCounts)
    .sort(([, a], [, b]) => b - a)[0]?.[0] || 'Friendly';

  // Create weighted blend if multiple styles selected
  const styleWeights = Object.entries(styleCounts).map(([style, count]) => ({
    style,
    weight: count / implications.personalityStyle.length
  }));

  return {
    primaryStyle,
    styleBlend: styleWeights,
    interactionPreference: mostCommon(implications.interactionPreference) || 'conversational',
    learningStyle: mostCommon(implications.learningStyle) || 'experiential',
    communicationDensity: mostCommon(implications.communicationDensity) || 'light',
    rawImplications: implications
  };
}

function mostCommon<T>(arr: T[]): T | undefined {
  if (arr.length === 0) return undefined;
  
  const counts = arr.reduce((acc, item) => {
    const key = String(item);
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return Object.entries(counts)
    .sort(([, a], [, b]) => b - a)[0]?.[0] as T;
}