/**
 * Personality Demo Component for Nix for Humanity
 * 
 * Demonstrates the adaptive personality system in action
 */

import React, { useState, useEffect } from 'react';
import { PersonalizedNixInterface, PersonalityConfig } from '../personality/personality-integration';
import { PersonalityStyle } from '../personality/personality-styles';

export const PersonalityDemo: React.FC = () => {
  const [interface, setInterface] = useState<PersonalizedNixInterface | null>(null);
  const [currentStyle, setCurrentStyle] = useState<PersonalityStyle>(PersonalityStyle.Friendly);
  const [command, setCommand] = useState('');
  const [response, setResponse] = useState<any>(null);
  const [history, setHistory] = useState<Array<{command: string, response: any}>>([]);
  const [loading, setLoading] = useState(false);
  
  useEffect(() => {
    // Initialize the personalized interface
    const config: PersonalityConfig = {
      enabled: true,
      defaultStyle: PersonalityStyle.Friendly,
      learningEnabled: true,
      adaptationSpeed: 0.7
    };
    
    const nixInterface = new PersonalizedNixInterface(config);
    setInterface(nixInterface);
  }, []);
  
  const handleCommand = async () => {
    if (!interface || !command.trim()) return;
    
    setLoading(true);
    try {
      const result = await interface.processCommand({
        input: command,
        dryRun: true // For demo purposes
      });
      
      setResponse(result);
      setHistory(prev => [...prev, { command, response: result }]);
      setCommand('');
      
      // Update current style display
      const info = interface.getPersonalityInfo();
      setCurrentStyle(info.currentStyle);
    } catch (error) {
      console.error('Command failed:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleStyleChange = (style: PersonalityStyle) => {
    if (interface) {
      interface.setPersonalityStyle(style);
      setCurrentStyle(style);
    }
  };
  
  const getStyleEmoji = (style: PersonalityStyle) => {
    const emojis = {
      [PersonalityStyle.Minimal]: '🤖',
      [PersonalityStyle.Friendly]: '😊',
      [PersonalityStyle.Encouraging]: '🌟',
      [PersonalityStyle.Playful]: '🎮',
      [PersonalityStyle.Sacred]: '🕉️'
    };
    return emojis[style] || '😊';
  };
  
  return (
    <div className="personality-demo" style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
      <h1>Nix for Humanity - Personality Demo</h1>
      
      {/* Personality Style Selector */}
      <div className="style-selector" style={{ marginBottom: '20px' }}>
        <h3>Choose Your Personality Style:</h3>
        <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
          {Object.values(PersonalityStyle).map(style => (
            <button
              key={style}
              onClick={() => handleStyleChange(style)}
              style={{
                padding: '10px 20px',
                border: currentStyle === style ? '2px solid #007bff' : '1px solid #ccc',
                borderRadius: '5px',
                background: currentStyle === style ? '#e7f3ff' : 'white',
                cursor: 'pointer',
                transition: 'all 0.3s'
              }}
            >
              {getStyleEmoji(style)} {style.charAt(0).toUpperCase() + style.slice(1)}
            </button>
          ))}
        </div>
      </div>
      
      {/* Command Input */}
      <div className="command-input" style={{ marginBottom: '20px' }}>
        <h3>Try Natural Language Commands:</h3>
        <div style={{ display: 'flex', gap: '10px' }}>
          <input
            type="text"
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleCommand()}
            placeholder="e.g., 'install firefox' or 'i need a text editor'"
            style={{
              flex: 1,
              padding: '10px',
              fontSize: '16px',
              borderRadius: '5px',
              border: '1px solid #ccc'
            }}
          />
          <button
            onClick={handleCommand}
            disabled={loading || !command.trim()}
            style={{
              padding: '10px 20px',
              fontSize: '16px',
              borderRadius: '5px',
              background: '#007bff',
              color: 'white',
              border: 'none',
              cursor: loading ? 'wait' : 'pointer',
              opacity: loading || !command.trim() ? 0.6 : 1
            }}
          >
            {loading ? 'Processing...' : 'Send'}
          </button>
        </div>
        
        {/* Example Commands */}
        <div style={{ marginTop: '10px', fontSize: '14px', color: '#666' }}>
          <strong>Try these:</strong>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginTop: '5px' }}>
            {[
              'install emacs',
              'help me set up python',
              'my wifi isn\'t working',
              'update everything',
              'what text editors are available?'
            ].map(example => (
              <button
                key={example}
                onClick={() => setCommand(example)}
                style={{
                  padding: '5px 10px',
                  fontSize: '12px',
                  background: '#f0f0f0',
                  border: '1px solid #ddd',
                  borderRadius: '3px',
                  cursor: 'pointer'
                }}
              >
                {example}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      {/* Current Response */}
      {response && (
        <div className="current-response" style={{
          marginBottom: '20px',
          padding: '15px',
          background: '#f8f9fa',
          borderRadius: '5px',
          border: '1px solid #dee2e6'
        }}>
          <h3>Response ({response.personality.style}):</h3>
          <p style={{ fontSize: '18px', marginBottom: '10px' }}>{response.message}</p>
          
          {response.suggestions && response.suggestions.length > 0 && (
            <div>
              <strong>Suggestions:</strong>
              <ul style={{ marginTop: '5px' }}>
                {response.suggestions.map((suggestion, idx) => (
                  <li key={idx}>{suggestion}</li>
                ))}
              </ul>
            </div>
          )}
          
          {response.command && (
            <div style={{ marginTop: '10px', fontSize: '14px', color: '#666' }}>
              <strong>Command that would run:</strong> <code>{response.command}</code>
            </div>
          )}
          
          <div style={{ marginTop: '10px', fontSize: '12px', color: '#999' }}>
            Confidence: {Math.round(response.personality.confidence * 100)}%
          </div>
        </div>
      )}
      
      {/* Interaction History */}
      {history.length > 0 && (
        <div className="history" style={{ marginTop: '30px' }}>
          <h3>Conversation History:</h3>
          <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
            {history.map((item, idx) => (
              <div key={idx} style={{
                marginBottom: '15px',
                padding: '10px',
                background: idx % 2 === 0 ? '#f8f9fa' : 'white',
                borderRadius: '5px'
              }}>
                <div style={{ fontWeight: 'bold', marginBottom: '5px' }}>
                  You: {item.command}
                </div>
                <div>
                  {getStyleEmoji(item.response.personality.style)} System ({item.response.personality.style}): {item.response.message}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Personality Info */}
      {interface && (
        <div className="personality-info" style={{
          marginTop: '30px',
          padding: '15px',
          background: '#e9ecef',
          borderRadius: '5px'
        }}>
          <h3>Personality Learning Status:</h3>
          <p>The system is learning your preferences based on:</p>
          <ul>
            <li>Your command patterns</li>
            <li>Response timing</li>
            <li>Language style</li>
            <li>Emotional indicators</li>
          </ul>
          <p style={{ marginTop: '10px', fontSize: '14px', color: '#666' }}>
            After several interactions, the system will adapt to your preferred communication style automatically.
          </p>
        </div>
      )}
    </div>
  );
};