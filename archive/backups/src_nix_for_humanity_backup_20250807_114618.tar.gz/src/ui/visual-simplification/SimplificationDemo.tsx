/**
 * Visual Simplification Demo
 * Demonstrates progressive complexity adaptation
 */

import React, { useState, useEffect } from 'react';
import {
  SimplifiedInterface,
  ConditionalComplexity,
  SimplifiedText,
  AdaptiveButton,
  LevelControl,
  useSimplification
} from './SimplifiedInterface';
import { EmotionalState } from '../../voice-emotion/types';

// Demo component showing a typical NixOS interface
const NixOSInterface: React.FC = () => {
  const { level } = useSimplification();
  const [selectedPackage, setSelectedPackage] = useState<string>('');
  const [showAdvanced, setShowAdvanced] = useState(false);
  
  // Simulated packages - filtered based on complexity level
  const allPackages = [
    { name: 'firefox', description: 'Web browser', category: 'essential' },
    { name: 'vscode', description: 'Code editor', category: 'essential' },
    { name: 'discord', description: 'Chat app', category: 'essential' },
    { name: 'git', description: 'Version control', category: 'developer' },
    { name: 'nodejs', description: 'JavaScript runtime', category: 'developer' },
    { name: 'docker', description: 'Container platform', category: 'advanced' },
    { name: 'kubernetes', description: 'Container orchestration', category: 'advanced' },
    { name: 'neovim', description: 'Text editor', category: 'advanced' }
  ];
  
  const getVisiblePackages = () => {
    if (level <= 2) return allPackages.filter(p => p.category === 'essential');
    if (level <= 5) return allPackages.filter(p => p.category !== 'advanced');
    return allPackages;
  };
  
  return (
    <div className="nixos-interface p-4 max-w-4xl mx-auto">
      {/* Header - always visible but adapts */}
      <header className="mb-6">
        <h1 className="text-2xl font-bold mb-2">
          <SimplifiedText>NixOS Package Manager</SimplifiedText>
        </h1>
        
        <ConditionalComplexity minLevel={3}>
          <p className="text-gray-600">
            <SimplifiedText>
              Manage your system packages declaratively
            </SimplifiedText>
          </p>
        </ConditionalComplexity>
      </header>
      
      {/* Main interface */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Package selection */}
        <div className="bg-white rounded-lg shadow p-4">
          <h2 className="text-lg font-semibold mb-3">
            <SimplifiedText>Available Packages</SimplifiedText>
          </h2>
          
          <div className="space-y-2">
            {getVisiblePackages().map(pkg => (
              <button
                key={pkg.name}
                onClick={() => setSelectedPackage(pkg.name)}
                className={`
                  w-full text-left p-3 rounded border transition-colors
                  ${selectedPackage === pkg.name
                    ? 'bg-blue-50 border-blue-300'
                    : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                  }
                `}
              >
                <div className="font-medium">{pkg.name}</div>
                <ConditionalComplexity minLevel={2}>
                  <div className="text-sm text-gray-600">{pkg.description}</div>
                </ConditionalComplexity>
              </button>
            ))}
          </div>
          
          <ConditionalComplexity minLevel={7}>
            <button
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="mt-3 text-sm text-blue-600 hover:underline"
            >
              {showAdvanced ? 'Hide' : 'Show'} advanced options
            </button>
          </ConditionalComplexity>
        </div>
        
        {/* Actions panel */}
        <div className="bg-white rounded-lg shadow p-4">
          <h2 className="text-lg font-semibold mb-3">
            <SimplifiedText>Actions</SimplifiedText>
          </h2>
          
          {selectedPackage ? (
            <div className="space-y-3">
              <p className="text-gray-700">
                Selected: <strong>{selectedPackage}</strong>
              </p>
              
              <AdaptiveButton onClick={() => console.log('Install', selectedPackage)} primary>
                <SimplifiedText>Install Package</SimplifiedText>
              </AdaptiveButton>
              
              <ConditionalComplexity minLevel={3}>
                <AdaptiveButton onClick={() => console.log('Info', selectedPackage)}>
                  <SimplifiedText>Package Information</SimplifiedText>
                </AdaptiveButton>
              </ConditionalComplexity>
              
              <ConditionalComplexity minLevel={5}>
                <AdaptiveButton onClick={() => console.log('Update', selectedPackage)}>
                  Update if Installed
                </AdaptiveButton>
              </ConditionalComplexity>
              
              <ConditionalComplexity minLevel={7} elementId="advanced-actions">
                {showAdvanced && (
                  <div className="mt-4 p-3 bg-gray-50 rounded">
                    <h3 className="font-medium mb-2">Advanced Options</h3>
                    <div className="space-y-2 text-sm">
                      <label className="flex items-center">
                        <input type="checkbox" className="mr-2" />
                        Install with dependencies
                      </label>
                      <label className="flex items-center">
                        <input type="checkbox" className="mr-2" />
                        Build from source
                      </label>
                      <label className="flex items-center">
                        <input type="checkbox" className="mr-2" />
                        Enable experimental features
                      </label>
                    </div>
                  </div>
                )}
              </ConditionalComplexity>
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8">
              <SimplifiedText>Select a package to see actions</SimplifiedText>
            </p>
          )}
        </div>
      </div>
      
      {/* System status - only at higher levels */}
      <ConditionalComplexity minLevel={4}>
        <div className="mt-6 bg-gray-50 rounded-lg p-4">
          <h3 className="font-semibold mb-2">System Status</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Installed:</span>
              <strong className="ml-1">47 packages</strong>
            </div>
            <div>
              <span className="text-gray-600">Updates:</span>
              <strong className="ml-1 text-green-600">3 available</strong>
            </div>
            <ConditionalComplexity minLevel={6}>
              <div>
                <span className="text-gray-600">Space used:</span>
                <strong className="ml-1">2.4 GB</strong>
              </div>
              <div>
                <span className="text-gray-600">Last update:</span>
                <strong className="ml-1">2 days ago</strong>
              </div>
            </ConditionalComplexity>
          </div>
        </div>
      </ConditionalComplexity>
    </div>
  );
};

// Demo controls for testing
const DemoControls: React.FC<{
  onEmotionSimulate: (emotion: Partial<EmotionalState>) => void;
}> = ({ onEmotionSimulate }) => {
  return (
    <div className="demo-controls fixed top-4 right-4 bg-white shadow-lg rounded-lg p-4 max-w-xs">
      <h3 className="font-semibold mb-3">Simulate Emotions</h3>
      <div className="space-y-2">
        <button
          onClick={() => onEmotionSimulate({ frustration: 0.8, confidence: 0.2 })}
          className="w-full text-left px-3 py-2 bg-red-50 hover:bg-red-100 rounded"
        >
          😤 High Frustration
        </button>
        <button
          onClick={() => onEmotionSimulate({ confusion: 0.8, confidence: 0.3 })}
          className="w-full text-left px-3 py-2 bg-yellow-50 hover:bg-yellow-100 rounded"
        >
          😕 High Confusion
        </button>
        <button
          onClick={() => onEmotionSimulate({ confidence: 0.9, frustration: 0.1 })}
          className="w-full text-left px-3 py-2 bg-green-50 hover:bg-green-100 rounded"
        >
          😎 High Confidence
        </button>
        <button
          onClick={() => onEmotionSimulate({ stress: 0.8, needsHelp: 0.9 })}
          className="w-full text-left px-3 py-2 bg-purple-50 hover:bg-purple-100 rounded"
        >
          😰 High Stress
        </button>
      </div>
    </div>
  );
};

// Main demo component
export const SimplificationDemo: React.FC = () => {
  const [personaId, setPersonaId] = useState<string>('general');
  const [showEmotionControl, setShowEmotionControl] = useState(true);
  
  const personas = [
    { id: 'grandma-rose', name: 'Grandma Rose', level: 0 },
    { id: 'maya', name: 'Maya (Teen)', level: 7 },
    { id: 'david', name: 'David (Tired)', level: 3 },
    { id: 'alex', name: 'Alex (Blind)', level: 5 },
    { id: 'viktor', name: 'Viktor (ESL)', level: 2 },
    { id: 'general', name: 'General User', level: 5 }
  ];
  
  const handleEmotionSimulate = (emotion: Partial<EmotionalState>) => {
    console.log('Simulated emotion:', emotion);
    // In a real app, this would trigger the simplification engine
  };
  
  return (
    <div className="simplification-demo min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow mb-6">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold">Progressive Visual Simplification Demo</h1>
          <p className="text-gray-600">
            Watch the interface adapt to complexity levels and emotional states
          </p>
        </div>
      </div>
      
      {/* Persona selector */}
      <div className="max-w-6xl mx-auto px-4 mb-6">
        <div className="bg-white rounded-lg shadow p-4">
          <h2 className="font-semibold mb-3">Select Persona</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {personas.map(persona => (
              <button
                key={persona.id}
                onClick={() => setPersonaId(persona.id)}
                className={`
                  p-3 rounded border transition-all
                  ${personaId === persona.id
                    ? 'bg-blue-50 border-blue-300'
                    : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                  }
                `}
              >
                <div className="font-medium">{persona.name}</div>
                <div className="text-sm text-gray-600">Level {persona.level}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
      
      {/* Main interface with simplification */}
      <SimplifiedInterface
        initialLevel={personas.find(p => p.id === personaId)?.level || 5}
        personaId={personaId}
      >
        <NixOSInterface />
        
        {/* Controls */}
        <LevelControl />
        {showEmotionControl && <DemoControls onEmotionSimulate={handleEmotionSimulate} />}
      </SimplifiedInterface>
      
      {/* Info panel */}
      <div className="max-w-6xl mx-auto px-4 mt-8 pb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">How It Works</h2>
          <div className="grid md:grid-cols-2 gap-6 text-sm">
            <div>
              <h3 className="font-medium mb-2">🎚️ Complexity Levels (0-10)</h3>
              <ul className="space-y-1 text-gray-600">
                <li><strong>Level 0-2:</strong> Ultra minimal, huge text, single focus</li>
                <li><strong>Level 3-4:</strong> Simple, reduced options, clear actions</li>
                <li><strong>Level 5-6:</strong> Balanced, standard interface</li>
                <li><strong>Level 7-8:</strong> Advanced, all features visible</li>
                <li><strong>Level 9-10:</strong> Expert, maximum density</li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-2">🎭 Emotional Triggers</h3>
              <ul className="space-y-1 text-gray-600">
                <li><strong>Frustration:</strong> Simplifies by 2 levels</li>
                <li><strong>Confusion:</strong> Reduces options, increases spacing</li>
                <li><strong>Confidence:</strong> Gradually adds features</li>
                <li><strong>Stress:</strong> Maintains current level</li>
                <li><strong>Success:</strong> Offers more capabilities</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};