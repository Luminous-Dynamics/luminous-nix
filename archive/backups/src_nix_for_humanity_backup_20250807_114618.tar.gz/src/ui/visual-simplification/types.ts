/**
 * Progressive Visual Simplification Types
 * Defines the structure for adaptive complexity reduction
 */

export interface SimplificationLevel {
  level: number; // 0-10 (0 = maximum simplicity, 10 = full complexity)
  name: string;
  description: string;
  characteristics: SimplificationCharacteristics;
}

export interface SimplificationCharacteristics {
  // Visual density
  elementCount: 'minimal' | 'reduced' | 'moderate' | 'full';
  spacing: 'generous' | 'comfortable' | 'standard' | 'compact';
  
  // Typography
  fontSizeMultiplier: number; // 1.0 - 2.0
  lineHeightMultiplier: number; // 1.0 - 2.0
  contrastLevel: 'maximum' | 'high' | 'standard';
  
  // Color & decoration
  colorComplexity: 'monochrome' | 'limited' | 'moderate' | 'full';
  animationsEnabled: boolean;
  decorativeElements: boolean;
  
  // Information architecture
  navigationDepth: number; // Max levels shown
  optionsPerGroup: number; // Max items in any menu/list
  progressIndicators: 'none' | 'simple' | 'detailed';
  
  // Cognitive load
  simultaneousTasks: number; // 1-5
  autoAdvance: boolean;
  confirmations: 'all' | 'critical' | 'minimal';
}

export interface SimplificationTrigger {
  type: 'emotion' | 'error' | 'time' | 'interaction' | 'explicit';
  threshold: number;
  direction: 'simplify' | 'complexify';
  magnitude: number; // How many levels to adjust
}

export interface UserComplexityProfile {
  // Current state
  currentLevel: number;
  preferredLevel: number;
  minLevel: number; // Never go simpler
  maxLevel: number; // Never go more complex
  
  // Adaptation history
  levelHistory: LevelChange[];
  
  // Triggers
  simplificationTriggers: SimplificationTrigger[];
  complexificationTriggers: SimplificationTrigger[];
  
  // Preferences
  autoAdapt: boolean;
  adaptationSpeed: 'instant' | 'fast' | 'gradual' | 'slow';
  notifyOnChange: boolean;
}

export interface LevelChange {
  timestamp: Date;
  fromLevel: number;
  toLevel: number;
  trigger: SimplificationTrigger;
  success: boolean;
}

export interface ElementVisibility {
  id: string;
  minLevel: number; // Minimum level where this appears
  priority: 'essential' | 'important' | 'helpful' | 'optional';
  category: 'navigation' | 'content' | 'action' | 'feedback' | 'decoration';
  dependencies?: string[]; // Other elements that must be visible
}

export interface SimplificationRule {
  id: string;
  name: string;
  description: string;
  condition: SimplificationCondition;
  action: SimplificationAction;
  priority: number; // Higher = apply first
}

export interface SimplificationCondition {
  type: 'threshold' | 'pattern' | 'composite';
  
  // For threshold conditions
  metric?: 'frustration' | 'confusion' | 'errors' | 'time' | 'clicks';
  operator?: '>' | '<' | '>=' | '<=' | '==';
  value?: number;
  
  // For pattern conditions
  pattern?: string; // Regex or specific pattern
  
  // For composite conditions
  conditions?: SimplificationCondition[];
  logic?: 'AND' | 'OR';
}

export interface SimplificationAction {
  type: 'adjust-level' | 'hide-element' | 'simplify-text' | 'reduce-options' | 'increase-spacing';
  
  // For level adjustment
  levelDelta?: number;
  targetLevel?: number;
  
  // For element changes
  elementIds?: string[];
  
  // For text simplification
  textSimplification?: 'plain' | 'guided' | 'minimal';
  
  // For option reduction
  maxOptions?: number;
  groupingStrategy?: 'category' | 'frequency' | 'alphabetical';
}

export interface AnimationProfile {
  level: number;
  transitions: {
    duration: number; // ms
    easing: string;
    properties: string[]; // Which properties to animate
  };
  microAnimations: boolean; // Hover effects, etc
  loadingAnimations: boolean;
  successAnimations: boolean;
}

export interface TextComplexity {
  level: number;
  vocabulary: 'basic' | 'intermediate' | 'advanced';
  sentenceLength: 'short' | 'medium' | 'long';
  technicalTerms: 'avoid' | 'explain' | 'use-freely';
  instructions: 'step-by-step' | 'concise' | 'minimal';
}