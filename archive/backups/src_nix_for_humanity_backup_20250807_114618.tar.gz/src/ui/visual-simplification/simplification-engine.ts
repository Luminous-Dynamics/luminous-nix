/**
 * Progressive Visual Simplification Engine
 * Dynamically adjusts interface complexity based on user needs
 */

import { EventEmitter } from 'events';
import {
  SimplificationLevel,
  SimplificationTrigger,
  UserComplexityProfile,
  ElementVisibility,
  SimplificationRule,
  SimplificationCondition,
  SimplificationAction,
  LevelChange
} from './types';
import { EmotionalState } from '../../voice-emotion/types';

export class SimplificationEngine extends EventEmitter {
  private currentProfile: UserComplexityProfile;
  private levels: SimplificationLevel[];
  private rules: SimplificationRule[];
  private elementRegistry: Map<string, ElementVisibility>;
  private metrics: SimplificationMetrics;
  
  constructor() {
    super();
    
    this.levels = this.initializeLevels();
    this.rules = this.initializeRules();
    this.elementRegistry = new Map();
    this.metrics = {
      errorCount: 0,
      confusionEvents: 0,
      frustrationPeaks: 0,
      taskCompletionTime: [],
      clicksPerTask: []
    };
    
    this.currentProfile = {
      currentLevel: 5, // Start at medium complexity
      preferredLevel: 5,
      minLevel: 0,
      maxLevel: 10,
      levelHistory: [],
      simplificationTriggers: this.getDefaultSimplificationTriggers(),
      complexificationTriggers: this.getDefaultComplexificationTriggers(),
      autoAdapt: true,
      adaptationSpeed: 'gradual',
      notifyOnChange: true
    };
  }
  
  /**
   * Initialize complexity levels
   */
  private initializeLevels(): SimplificationLevel[] {
    return [
      {
        level: 0,
        name: 'Ultra Minimal',
        description: 'Single task focus with maximum clarity',
        characteristics: {
          elementCount: 'minimal',
          spacing: 'generous',
          fontSizeMultiplier: 2.0,
          lineHeightMultiplier: 2.0,
          contrastLevel: 'maximum',
          colorComplexity: 'monochrome',
          animationsEnabled: false,
          decorativeElements: false,
          navigationDepth: 1,
          optionsPerGroup: 3,
          progressIndicators: 'none',
          simultaneousTasks: 1,
          autoAdvance: true,
          confirmations: 'all'
        }
      },
      {
        level: 2,
        name: 'Simple',
        description: 'Clean interface with essential elements',
        characteristics: {
          elementCount: 'reduced',
          spacing: 'generous',
          fontSizeMultiplier: 1.5,
          lineHeightMultiplier: 1.75,
          contrastLevel: 'maximum',
          colorComplexity: 'limited',
          animationsEnabled: false,
          decorativeElements: false,
          navigationDepth: 2,
          optionsPerGroup: 5,
          progressIndicators: 'simple',
          simultaneousTasks: 1,
          autoAdvance: true,
          confirmations: 'critical'
        }
      },
      {
        level: 5,
        name: 'Balanced',
        description: 'Standard interface with good usability',
        characteristics: {
          elementCount: 'moderate',
          spacing: 'comfortable',
          fontSizeMultiplier: 1.2,
          lineHeightMultiplier: 1.5,
          contrastLevel: 'high',
          colorComplexity: 'moderate',
          animationsEnabled: true,
          decorativeElements: true,
          navigationDepth: 3,
          optionsPerGroup: 10,
          progressIndicators: 'detailed',
          simultaneousTasks: 3,
          autoAdvance: false,
          confirmations: 'critical'
        }
      },
      {
        level: 8,
        name: 'Advanced',
        description: 'Full featured interface for power users',
        characteristics: {
          elementCount: 'full',
          spacing: 'standard',
          fontSizeMultiplier: 1.0,
          lineHeightMultiplier: 1.4,
          contrastLevel: 'standard',
          colorComplexity: 'full',
          animationsEnabled: true,
          decorativeElements: true,
          navigationDepth: 5,
          optionsPerGroup: 20,
          progressIndicators: 'detailed',
          simultaneousTasks: 5,
          autoAdvance: false,
          confirmations: 'minimal'
        }
      },
      {
        level: 10,
        name: 'Expert',
        description: 'Maximum density and features',
        characteristics: {
          elementCount: 'full',
          spacing: 'compact',
          fontSizeMultiplier: 1.0,
          lineHeightMultiplier: 1.3,
          contrastLevel: 'standard',
          colorComplexity: 'full',
          animationsEnabled: true,
          decorativeElements: true,
          navigationDepth: 10,
          optionsPerGroup: 50,
          progressIndicators: 'detailed',
          simultaneousTasks: 5,
          autoAdvance: false,
          confirmations: 'minimal'
        }
      }
    ];
  }
  
  /**
   * Initialize simplification rules
   */
  private initializeRules(): SimplificationRule[] {
    return [
      {
        id: 'high-frustration',
        name: 'High Frustration Response',
        description: 'Simplify when user shows high frustration',
        condition: {
          type: 'threshold',
          metric: 'frustration',
          operator: '>',
          value: 0.7
        },
        action: {
          type: 'adjust-level',
          levelDelta: -2
        },
        priority: 100
      },
      {
        id: 'repeated-errors',
        name: 'Error Pattern Response',
        description: 'Simplify after multiple errors',
        condition: {
          type: 'threshold',
          metric: 'errors',
          operator: '>=',
          value: 3
        },
        action: {
          type: 'adjust-level',
          levelDelta: -1
        },
        priority: 90
      },
      {
        id: 'confusion-detected',
        name: 'Confusion Response',
        description: 'Reduce complexity when confused',
        condition: {
          type: 'threshold',
          metric: 'confusion',
          operator: '>',
          value: 0.6
        },
        action: {
          type: 'adjust-level',
          levelDelta: -1
        },
        priority: 80
      },
      {
        id: 'task-success',
        name: 'Success Recognition',
        description: 'Gradually increase complexity on success',
        condition: {
          type: 'pattern',
          pattern: 'consecutive-success-3'
        },
        action: {
          type: 'adjust-level',
          levelDelta: 1
        },
        priority: 50
      },
      {
        id: 'overwhelm-prevention',
        name: 'Overwhelm Prevention',
        description: 'Hide non-essential elements when overwhelmed',
        condition: {
          type: 'composite',
          conditions: [
            { type: 'threshold', metric: 'confusion', operator: '>', value: 0.5 },
            { type: 'threshold', metric: 'clicks', operator: '>', value: 10 }
          ],
          logic: 'AND'
        },
        action: {
          type: 'hide-element',
          elementIds: ['advanced-options', 'secondary-nav', 'decorative-elements']
        },
        priority: 70
      }
    ];
  }
  
  /**
   * Get default simplification triggers
   */
  private getDefaultSimplificationTriggers(): SimplificationTrigger[] {
    return [
      {
        type: 'emotion',
        threshold: 0.7, // High frustration
        direction: 'simplify',
        magnitude: 2
      },
      {
        type: 'error',
        threshold: 3, // 3 errors in a row
        direction: 'simplify',
        magnitude: 1
      },
      {
        type: 'time',
        threshold: 120, // 2 minutes on same task
        direction: 'simplify',
        magnitude: 1
      }
    ];
  }
  
  /**
   * Get default complexification triggers
   */
  private getDefaultComplexificationTriggers(): SimplificationTrigger[] {
    return [
      {
        type: 'interaction',
        threshold: 10, // 10 successful actions
        direction: 'complexify',
        magnitude: 1
      },
      {
        type: 'time',
        threshold: 300, // 5 minutes of smooth usage
        direction: 'complexify',
        magnitude: 1
      }
    ];
  }
  
  /**
   * Process emotional state and adjust complexity
   */
  async processEmotionalState(state: EmotionalState): Promise<void> {
    if (!this.currentProfile.autoAdapt) return;
    
    // Check frustration
    if (state.frustration > 0.7) {
      this.metrics.frustrationPeaks++;
      await this.adjustComplexity(-2, {
        type: 'emotion',
        threshold: state.frustration,
        direction: 'simplify',
        magnitude: 2
      });
    }
    
    // Check confusion
    if (state.confusion > 0.6) {
      this.metrics.confusionEvents++;
      await this.adjustComplexity(-1, {
        type: 'emotion',
        threshold: state.confusion,
        direction: 'simplify',
        magnitude: 1
      });
    }
    
    // Check confidence (allows complexification)
    if (state.confidence > 0.8 && state.frustration < 0.2) {
      // User is confident and not frustrated
      const lastChange = this.getLastLevelChange();
      const timeSinceChange = Date.now() - (lastChange?.timestamp.getTime() || 0);
      
      if (timeSinceChange > 300000) { // 5 minutes
        await this.adjustComplexity(1, {
          type: 'emotion',
          threshold: state.confidence,
          direction: 'complexify',
          magnitude: 1
        });
      }
    }
  }
  
  /**
   * Process user interaction and adjust complexity
   */
  async processInteraction(interaction: UserInteraction): Promise<void> {
    // Track metrics
    if (interaction.type === 'error') {
      this.metrics.errorCount++;
    }
    
    if (interaction.type === 'task-complete') {
      this.metrics.taskCompletionTime.push(interaction.duration || 0);
      this.metrics.clicksPerTask.push(interaction.clickCount || 0);
    }
    
    // Apply rules
    for (const rule of this.rules.sort((a, b) => b.priority - a.priority)) {
      if (this.evaluateCondition(rule.condition)) {
        await this.applyAction(rule.action);
        break; // Only apply highest priority matching rule
      }
    }
  }
  
  /**
   * Manually adjust complexity level
   */
  async setComplexityLevel(level: number): Promise<void> {
    const clampedLevel = Math.max(
      this.currentProfile.minLevel,
      Math.min(this.currentProfile.maxLevel, level)
    );
    
    if (clampedLevel === this.currentProfile.currentLevel) {
      return;
    }
    
    const change: LevelChange = {
      timestamp: new Date(),
      fromLevel: this.currentProfile.currentLevel,
      toLevel: clampedLevel,
      trigger: {
        type: 'explicit',
        threshold: 0,
        direction: clampedLevel > this.currentProfile.currentLevel ? 'complexify' : 'simplify',
        magnitude: Math.abs(clampedLevel - this.currentProfile.currentLevel)
      },
      success: true
    };
    
    this.currentProfile.currentLevel = clampedLevel;
    this.currentProfile.levelHistory.push(change);
    
    // Emit change event
    this.emit('level-changed', {
      newLevel: clampedLevel,
      characteristics: this.getCurrentCharacteristics()
    });
    
    if (this.currentProfile.notifyOnChange) {
      this.emit('notify-user', {
        message: `Interface adjusted to ${this.getLevelName(clampedLevel)} mode`,
        type: 'info'
      });
    }
  }
  
  /**
   * Adjust complexity by delta
   */
  private async adjustComplexity(delta: number, trigger: SimplificationTrigger): Promise<void> {
    const newLevel = this.currentProfile.currentLevel + delta;
    await this.setComplexityLevel(newLevel);
  }
  
  /**
   * Evaluate a simplification condition
   */
  private evaluateCondition(condition: SimplificationCondition): boolean {
    switch (condition.type) {
      case 'threshold':
        return this.evaluateThresholdCondition(condition);
      
      case 'pattern':
        return this.evaluatePatternCondition(condition);
      
      case 'composite':
        return this.evaluateCompositeCondition(condition);
      
      default:
        return false;
    }
  }
  
  /**
   * Evaluate threshold condition
   */
  private evaluateThresholdCondition(condition: SimplificationCondition): boolean {
    const value = this.getMetricValue(condition.metric!);
    
    switch (condition.operator) {
      case '>': return value > condition.value!;
      case '<': return value < condition.value!;
      case '>=': return value >= condition.value!;
      case '<=': return value <= condition.value!;
      case '==': return value === condition.value!;
      default: return false;
    }
  }
  
  /**
   * Get metric value
   */
  private getMetricValue(metric: string): number {
    switch (metric) {
      case 'frustration': return 0; // Would come from emotion state
      case 'confusion': return 0; // Would come from emotion state
      case 'errors': return this.metrics.errorCount;
      case 'time': return Date.now(); // Would track task time
      case 'clicks': return this.metrics.clicksPerTask[this.metrics.clicksPerTask.length - 1] || 0;
      default: return 0;
    }
  }
  
  /**
   * Evaluate pattern condition
   */
  private evaluatePatternCondition(condition: SimplificationCondition): boolean {
    // Pattern matching logic
    if (condition.pattern === 'consecutive-success-3') {
      // Check last 3 task completions
      const recentTasks = this.metrics.taskCompletionTime.slice(-3);
      return recentTasks.length === 3 && recentTasks.every(time => time < 60000); // All under 1 minute
    }
    
    return false;
  }
  
  /**
   * Evaluate composite condition
   */
  private evaluateCompositeCondition(condition: SimplificationCondition): boolean {
    if (!condition.conditions) return false;
    
    const results = condition.conditions.map(c => this.evaluateCondition(c));
    
    if (condition.logic === 'AND') {
      return results.every(r => r);
    } else {
      return results.some(r => r);
    }
  }
  
  /**
   * Apply simplification action
   */
  private async applyAction(action: SimplificationAction): Promise<void> {
    switch (action.type) {
      case 'adjust-level':
        if (action.levelDelta) {
          await this.adjustComplexity(action.levelDelta, {
            type: 'interaction',
            threshold: 0,
            direction: action.levelDelta > 0 ? 'complexify' : 'simplify',
            magnitude: Math.abs(action.levelDelta)
          });
        } else if (action.targetLevel !== undefined) {
          await this.setComplexityLevel(action.targetLevel);
        }
        break;
      
      case 'hide-element':
        if (action.elementIds) {
          this.emit('hide-elements', action.elementIds);
        }
        break;
      
      case 'simplify-text':
        this.emit('simplify-text', action.textSimplification);
        break;
      
      case 'reduce-options':
        this.emit('reduce-options', {
          maxOptions: action.maxOptions,
          strategy: action.groupingStrategy
        });
        break;
      
      case 'increase-spacing':
        this.emit('increase-spacing');
        break;
    }
  }
  
  /**
   * Get current characteristics
   */
  getCurrentCharacteristics() {
    const level = this.levels.find(l => l.level === this.currentProfile.currentLevel);
    if (level) return level.characteristics;
    
    // Interpolate between levels
    const lower = this.levels.filter(l => l.level < this.currentProfile.currentLevel).pop();
    const upper = this.levels.find(l => l.level > this.currentProfile.currentLevel);
    
    if (!lower || !upper) {
      return this.levels[Math.floor(this.levels.length / 2)].characteristics;
    }
    
    // Simple interpolation (in practice, this would be more sophisticated)
    return lower.characteristics;
  }
  
  /**
   * Get level name
   */
  private getLevelName(level: number): string {
    const levelDef = this.levels.find(l => l.level === level);
    return levelDef?.name || `Level ${level}`;
  }
  
  /**
   * Get last level change
   */
  private getLastLevelChange(): LevelChange | undefined {
    return this.currentProfile.levelHistory[this.currentProfile.levelHistory.length - 1];
  }
  
  /**
   * Register UI element with visibility rules
   */
  registerElement(element: ElementVisibility): void {
    this.elementRegistry.set(element.id, element);
    this.updateElementVisibility();
  }
  
  /**
   * Update visibility of all registered elements
   */
  private updateElementVisibility(): void {
    const currentLevel = this.currentProfile.currentLevel;
    const visibleElements: string[] = [];
    const hiddenElements: string[] = [];
    
    for (const [id, element] of this.elementRegistry) {
      if (currentLevel >= element.minLevel) {
        // Check dependencies
        const depsVisible = !element.dependencies || 
          element.dependencies.every(dep => visibleElements.includes(dep));
        
        if (depsVisible) {
          visibleElements.push(id);
        } else {
          hiddenElements.push(id);
        }
      } else {
        hiddenElements.push(id);
      }
    }
    
    this.emit('visibility-update', { visible: visibleElements, hidden: hiddenElements });
  }
  
  /**
   * Get recommended level for persona
   */
  getRecommendedLevelForPersona(personaId: string): number {
    const personaLevels: Record<string, number> = {
      'grandma-rose': 0,
      'maya': 7,
      'david': 3,
      'alex': 5,
      'sam': 8,
      'jordan': 10,
      'viktor': 2,
      'lisa': 4,
      'morgan': 1,
      'taylor': 6
    };
    
    return personaLevels[personaId] ?? 5;
  }
  
  /**
   * Export current profile
   */
  exportProfile(): UserComplexityProfile {
    return JSON.parse(JSON.stringify(this.currentProfile));
  }
  
  /**
   * Import profile
   */
  importProfile(profile: UserComplexityProfile): void {
    this.currentProfile = profile;
    this.updateElementVisibility();
    this.emit('profile-imported', profile);
  }
}

interface SimplificationMetrics {
  errorCount: number;
  confusionEvents: number;
  frustrationPeaks: number;
  taskCompletionTime: number[];
  clicksPerTask: number[];
}

interface UserInteraction {
  type: 'click' | 'error' | 'task-complete' | 'help-request';
  timestamp: Date;
  duration?: number;
  clickCount?: number;
  success?: boolean;
}