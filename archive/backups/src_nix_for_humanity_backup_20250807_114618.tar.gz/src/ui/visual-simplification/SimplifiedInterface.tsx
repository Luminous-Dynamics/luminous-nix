/**
 * Simplified Interface Component
 * Applies progressive visual simplification based on complexity level
 */

import React, { useState, useEffect, useContext, createContext } from 'react';
import { SimplificationEngine } from './simplification-engine';
import { SimplificationLevel, ElementVisibility } from './types';
import { EmotionalState } from '../../voice-emotion/types';

// Context for simplification state
interface SimplificationContextType {
  level: number;
  characteristics: any;
  isVisible: (elementId: string) => boolean;
  registerElement: (element: ElementVisibility) => void;
  setLevel: (level: number) => void;
}

const SimplificationContext = createContext<SimplificationContextType>({
  level: 5,
  characteristics: {},
  isVisible: () => true,
  registerElement: () => {},
  setLevel: () => {}
});

export const useSimplification = () => useContext(SimplificationContext);

interface SimplifiedInterfaceProps {
  children: React.ReactNode;
  initialLevel?: number;
  personaId?: string;
  onLevelChange?: (level: number) => void;
}

export const SimplifiedInterface: React.FC<SimplifiedInterfaceProps> = ({
  children,
  initialLevel = 5,
  personaId,
  onLevelChange
}) => {
  const [engine] = useState(() => new SimplificationEngine());
  const [level, setLevel] = useState(initialLevel);
  const [characteristics, setCharacteristics] = useState<any>({});
  const [visibleElements, setVisibleElements] = useState<Set<string>>(new Set());
  
  useEffect(() => {
    // Set initial level based on persona
    if (personaId) {
      const recommendedLevel = engine.getRecommendedLevelForPersona(personaId);
      engine.setComplexityLevel(recommendedLevel);
    } else {
      engine.setComplexityLevel(initialLevel);
    }
    
    // Listen for level changes
    engine.on('level-changed', (data: any) => {
      setLevel(data.newLevel);
      setCharacteristics(data.characteristics);
      if (onLevelChange) {
        onLevelChange(data.newLevel);
      }
    });
    
    // Listen for visibility updates
    engine.on('visibility-update', (data: any) => {
      setVisibleElements(new Set(data.visible));
    });
    
    // Initial characteristics
    setCharacteristics(engine.getCurrentCharacteristics());
  }, [engine, initialLevel, personaId, onLevelChange]);
  
  const isVisible = (elementId: string): boolean => {
    return visibleElements.has(elementId);
  };
  
  const registerElement = (element: ElementVisibility): void => {
    engine.registerElement(element);
  };
  
  const setManualLevel = (newLevel: number): void => {
    engine.setComplexityLevel(newLevel);
  };
  
  // Apply CSS variables based on characteristics
  useEffect(() => {
    const root = document.documentElement;
    
    // Typography
    root.style.setProperty('--font-size-multiplier', characteristics.fontSizeMultiplier?.toString() || '1');
    root.style.setProperty('--line-height-multiplier', characteristics.lineHeightMultiplier?.toString() || '1.5');
    
    // Spacing
    const spacingMap = {
      generous: '2',
      comfortable: '1.5',
      standard: '1',
      compact: '0.75'
    };
    root.style.setProperty('--spacing-multiplier', spacingMap[characteristics.spacing] || '1');
    
    // Colors
    if (characteristics.colorComplexity === 'monochrome') {
      root.style.setProperty('--color-primary', '#1f2937');
      root.style.setProperty('--color-secondary', '#6b7280');
      root.style.setProperty('--color-accent', '#374151');
    }
    
    // Animations
    root.style.setProperty('--animation-duration', characteristics.animationsEnabled ? '300ms' : '0ms');
    
    // Contrast
    if (characteristics.contrastLevel === 'maximum') {
      root.classList.add('high-contrast');
    } else {
      root.classList.remove('high-contrast');
    }
  }, [characteristics]);
  
  return (
    <SimplificationContext.Provider value={{
      level,
      characteristics,
      isVisible,
      registerElement,
      setLevel: setManualLevel
    }}>
      <div className={`simplified-interface level-${level}`}>
        <style jsx global>{`
          /* Base simplification styles */
          .simplified-interface {
            --font-size-base: calc(1rem * var(--font-size-multiplier, 1));
            --line-height-base: calc(1.5 * var(--line-height-multiplier, 1));
            --spacing-base: calc(1rem * var(--spacing-multiplier, 1));
            --animation-duration: 300ms;
          }
          
          /* Apply to all text */
          .simplified-interface * {
            font-size: var(--font-size-base);
            line-height: var(--line-height-base);
            transition: all var(--animation-duration) ease-in-out;
          }
          
          /* Spacing adjustments */
          .simplified-interface .p-1 { padding: calc(0.25rem * var(--spacing-multiplier)); }
          .simplified-interface .p-2 { padding: calc(0.5rem * var(--spacing-multiplier)); }
          .simplified-interface .p-3 { padding: calc(0.75rem * var(--spacing-multiplier)); }
          .simplified-interface .p-4 { padding: calc(1rem * var(--spacing-multiplier)); }
          .simplified-interface .p-6 { padding: calc(1.5rem * var(--spacing-multiplier)); }
          .simplified-interface .p-8 { padding: calc(2rem * var(--spacing-multiplier)); }
          
          /* Similar for margins */
          .simplified-interface .m-1 { margin: calc(0.25rem * var(--spacing-multiplier)); }
          .simplified-interface .m-2 { margin: calc(0.5rem * var(--spacing-multiplier)); }
          .simplified-interface .m-3 { margin: calc(0.75rem * var(--spacing-multiplier)); }
          .simplified-interface .m-4 { margin: calc(1rem * var(--spacing-multiplier)); }
          .simplified-interface .m-6 { margin: calc(1.5rem * var(--spacing-multiplier)); }
          .simplified-interface .m-8 { margin: calc(2rem * var(--spacing-multiplier)); }
          
          /* High contrast mode */
          .high-contrast {
            --color-text: #000000;
            --color-background: #ffffff;
            --color-border: #000000;
          }
          
          .high-contrast * {
            color: var(--color-text) !important;
            background-color: var(--color-background) !important;
            border-color: var(--color-border) !important;
          }
          
          /* Level-specific styles */
          .level-0 button {
            padding: 1rem 2rem !important;
            font-size: 1.5rem !important;
            font-weight: bold !important;
          }
          
          .level-0 input {
            padding: 1rem !important;
            font-size: 1.5rem !important;
            border: 3px solid #000 !important;
          }
          
          /* Hide decorative elements at low levels */
          .level-0 .decorative,
          .level-0 .icon-only,
          .level-1 .decorative,
          .level-2 .decorative {
            display: none !important;
          }
          
          /* Simplify navigation at low levels */
          .level-0 nav ul ul,
          .level-1 nav ul ul ul {
            display: none !important;
          }
          
          /* Remove animations at low levels */
          .level-0 *,
          .level-1 *,
          .level-2 * {
            animation: none !important;
            transition: none !important;
          }
        `}</style>
        
        {children}
      </div>
    </SimplificationContext.Provider>
  );
};

// HOC for conditional rendering based on complexity level
interface ConditionalComplexityProps {
  minLevel?: number;
  maxLevel?: number;
  elementId?: string;
  priority?: 'essential' | 'important' | 'helpful' | 'optional';
  children: React.ReactNode;
}

export const ConditionalComplexity: React.FC<ConditionalComplexityProps> = ({
  minLevel = 0,
  maxLevel = 10,
  elementId,
  priority = 'optional',
  children
}) => {
  const { level, isVisible, registerElement } = useSimplification();
  
  useEffect(() => {
    if (elementId) {
      registerElement({
        id: elementId,
        minLevel,
        priority,
        category: 'content'
      });
    }
  }, [elementId, minLevel, priority, registerElement]);
  
  // Check if should be visible
  if (elementId && !isVisible(elementId)) {
    return null;
  }
  
  if (level < minLevel || level > maxLevel) {
    return null;
  }
  
  return <>{children}</>;
};

// Simplified text component that adjusts vocabulary
interface SimplifiedTextProps {
  children: string;
  className?: string;
}

export const SimplifiedText: React.FC<SimplifiedTextProps> = ({ children, className }) => {
  const { level, characteristics } = useSimplification();
  
  const simplifyText = (text: string): string => {
    if (level >= 5) return text; // No simplification needed
    
    // Simple vocabulary replacements for low levels
    const replacements: Record<string, string> = {
      'configure': 'set up',
      'initialize': 'start',
      'terminate': 'stop',
      'execute': 'run',
      'navigate': 'go to',
      'authenticate': 'sign in',
      'repository': 'storage',
      'parameter': 'setting',
      'dependency': 'needed program',
      'compilation': 'building',
      'integration': 'connection'
    };
    
    let simplified = text;
    for (const [complex, simple] of Object.entries(replacements)) {
      const regex = new RegExp(`\\b${complex}\\b`, 'gi');
      simplified = simplified.replace(regex, simple);
    }
    
    return simplified;
  };
  
  return (
    <span className={className}>
      {simplifyText(children)}
    </span>
  );
};

// Adaptive button that changes based on complexity
interface AdaptiveButtonProps {
  onClick: () => void;
  primary?: boolean;
  children: React.ReactNode;
  className?: string;
}

export const AdaptiveButton: React.FC<AdaptiveButtonProps> = ({
  onClick,
  primary = false,
  children,
  className = ''
}) => {
  const { level, characteristics } = useSimplification();
  
  const getButtonClass = () => {
    const baseClass = 'adaptive-button';
    const levelClass = `level-${level}`;
    const primaryClass = primary ? 'primary' : 'secondary';
    
    // Add size classes based on level
    let sizeClass = '';
    if (level <= 2) {
      sizeClass = 'text-xl px-8 py-4';
    } else if (level <= 5) {
      sizeClass = 'text-lg px-6 py-3';
    } else {
      sizeClass = 'text-base px-4 py-2';
    }
    
    return `${baseClass} ${levelClass} ${primaryClass} ${sizeClass} ${className}`;
  };
  
  return (
    <button
      onClick={onClick}
      className={getButtonClass()}
      style={{
        borderRadius: level <= 2 ? '12px' : '6px',
        fontWeight: level <= 2 ? 'bold' : 'medium'
      }}
    >
      {children}
    </button>
  );
};

// Level control widget for testing
export const LevelControl: React.FC = () => {
  const { level, setLevel } = useSimplification();
  
  return (
    <div className="level-control fixed bottom-4 right-4 bg-white shadow-lg rounded-lg p-4">
      <h3 className="text-sm font-semibold mb-2">Complexity Level</h3>
      <input
        type="range"
        min="0"
        max="10"
        value={level}
        onChange={(e) => setLevel(parseInt(e.target.value))}
        className="w-full"
      />
      <div className="flex justify-between text-xs mt-1">
        <span>Simple</span>
        <span>{level}</span>
        <span>Complex</span>
      </div>
    </div>
  );
};