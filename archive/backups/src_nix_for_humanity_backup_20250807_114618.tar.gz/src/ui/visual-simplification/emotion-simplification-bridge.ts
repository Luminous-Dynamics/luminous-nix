/**
 * Emotion-Simplification Bridge
 * Connects emotional state detection to visual complexity adaptation
 */

import { SimplificationEngine } from './simplification-engine';
import { EmotionalState } from '../../voice-emotion/types';
import { VoiceEmotionDetector } from '../../voice-emotion/emotion-detector';

export class EmotionSimplificationBridge {
  private simplificationEngine: SimplificationEngine;
  private emotionDetector: VoiceEmotionDetector;
  private emotionHistory: EmotionalState[] = [];
  private adaptationSensitivity: number = 0.7; // 0-1, higher = more sensitive
  
  constructor(
    simplificationEngine: SimplificationEngine,
    emotionDetector: VoiceEmotionDetector
  ) {
    this.simplificationEngine = simplificationEngine;
    this.emotionDetector = emotionDetector;
    
    this.setupEventHandlers();
  }
  
  /**
   * Set up event handlers to bridge emotion and simplification
   */
  private setupEventHandlers(): void {
    // Listen for emotion updates
    this.emotionDetector.on('emotion-detected', async (state: EmotionalState) => {
      await this.processEmotionalState(state);
    });
    
    // Listen for simplification changes
    this.simplificationEngine.on('level-changed', (data: any) => {
      this.handleSimplificationChange(data);
    });
  }
  
  /**
   * Process emotional state and trigger simplification if needed
   */
  private async processEmotionalState(state: EmotionalState): Promise<void> {
    // Add to history
    this.emotionHistory.push(state);
    if (this.emotionHistory.length > 10) {
      this.emotionHistory.shift(); // Keep last 10 states
    }
    
    // Calculate emotional trends
    const trends = this.calculateEmotionalTrends();
    
    // Make simplification decisions based on trends
    if (trends.risingFrustration && state.frustration > 0.6) {
      // User is getting increasingly frustrated
      await this.simplificationEngine.processEmotionalState({
        ...state,
        frustration: state.frustration * 1.2 // Amplify to trigger simplification
      });
      
      this.emitInsight({
        type: 'frustration-rising',
        message: 'Simplifying interface due to rising frustration',
        confidence: trends.frustrationTrendConfidence
      });
    }
    
    if (trends.persistentConfusion && state.confusion > 0.5) {
      // User has been confused for a while
      await this.simplificationEngine.processEmotionalState({
        ...state,
        confusion: state.confusion * 1.3 // Amplify to trigger help
      });
      
      this.emitInsight({
        type: 'persistent-confusion',
        message: 'Reducing complexity to address confusion',
        confidence: trends.confusionPersistenceScore
      });
    }
    
    if (trends.increasingConfidence && state.confidence > 0.7) {
      // User is gaining confidence - maybe ready for more
      const currentProfile = this.simplificationEngine.exportProfile();
      
      if (currentProfile.currentLevel < currentProfile.preferredLevel) {
        await this.simplificationEngine.processEmotionalState(state);
        
        this.emitInsight({
          type: 'confidence-building',
          message: 'User showing increased confidence',
          confidence: trends.confidenceTrendScore
        });
      }
    }
    
    // Check for emotional volatility
    if (trends.emotionalVolatility > 0.7) {
      // High volatility - maintain current level
      this.emitInsight({
        type: 'high-volatility',
        message: 'Emotional state unstable - maintaining current complexity',
        confidence: trends.emotionalVolatility
      });
    }
  }
  
  /**
   * Calculate emotional trends from history
   */
  private calculateEmotionalTrends() {
    if (this.emotionHistory.length < 3) {
      return {
        risingFrustration: false,
        persistentConfusion: false,
        increasingConfidence: false,
        emotionalVolatility: 0,
        frustrationTrendConfidence: 0,
        confusionPersistenceScore: 0,
        confidenceTrendScore: 0
      };
    }
    
    const recent = this.emotionHistory.slice(-5);
    
    // Calculate frustration trend
    const frustrationValues = recent.map(e => e.frustration);
    const frustrationTrend = this.calculateTrend(frustrationValues);
    
    // Calculate confusion persistence
    const confusionValues = recent.map(e => e.confusion);
    const avgConfusion = confusionValues.reduce((a, b) => a + b, 0) / confusionValues.length;
    const confusionPersistence = confusionValues.filter(v => v > 0.5).length / confusionValues.length;
    
    // Calculate confidence trend
    const confidenceValues = recent.map(e => e.confidence);
    const confidenceTrend = this.calculateTrend(confidenceValues);
    
    // Calculate emotional volatility
    const volatility = this.calculateVolatility(recent);
    
    return {
      risingFrustration: frustrationTrend > 0.1,
      persistentConfusion: confusionPersistence > 0.6,
      increasingConfidence: confidenceTrend > 0.1,
      emotionalVolatility: volatility,
      frustrationTrendConfidence: Math.abs(frustrationTrend),
      confusionPersistenceScore: confusionPersistence,
      confidenceTrendScore: Math.abs(confidenceTrend)
    };
  }
  
  /**
   * Calculate trend (positive = increasing, negative = decreasing)
   */
  private calculateTrend(values: number[]): number {
    if (values.length < 2) return 0;
    
    let sum = 0;
    for (let i = 1; i < values.length; i++) {
      sum += (values[i] - values[i - 1]);
    }
    
    return sum / (values.length - 1);
  }
  
  /**
   * Calculate emotional volatility (0-1)
   */
  private calculateVolatility(states: EmotionalState[]): number {
    if (states.length < 2) return 0;
    
    let totalChange = 0;
    
    for (let i = 1; i < states.length; i++) {
      const prev = states[i - 1];
      const curr = states[i];
      
      totalChange += Math.abs(curr.frustration - prev.frustration);
      totalChange += Math.abs(curr.confusion - prev.confusion);
      totalChange += Math.abs(curr.confidence - prev.confidence);
      totalChange += Math.abs(curr.excitement - prev.excitement);
    }
    
    // Normalize by number of emotions and transitions
    return Math.min(1, totalChange / ((states.length - 1) * 4));
  }
  
  /**
   * Handle simplification level changes
   */
  private handleSimplificationChange(data: any): void {
    // Log the change with emotional context
    const currentEmotion = this.emotionHistory[this.emotionHistory.length - 1];
    
    if (currentEmotion) {
      console.log('Simplification changed:', {
        newLevel: data.newLevel,
        emotionalContext: {
          frustration: currentEmotion.frustration,
          confusion: currentEmotion.confusion,
          confidence: currentEmotion.confidence
        }
      });
    }
  }
  
  /**
   * Get adaptation recommendations based on current state
   */
  getAdaptationRecommendations(): AdaptationRecommendation[] {
    const recommendations: AdaptationRecommendation[] = [];
    const currentProfile = this.simplificationEngine.exportProfile();
    const currentEmotion = this.emotionHistory[this.emotionHistory.length - 1];
    
    if (!currentEmotion) return recommendations;
    
    // High frustration + complex interface
    if (currentEmotion.frustration > 0.7 && currentProfile.currentLevel > 5) {
      recommendations.push({
        priority: 'high',
        action: 'simplify',
        reason: 'High frustration detected with complex interface',
        targetLevel: Math.max(0, currentProfile.currentLevel - 3)
      });
    }
    
    // Confusion + many options
    if (currentEmotion.confusion > 0.6 && currentProfile.currentLevel > 3) {
      recommendations.push({
        priority: 'medium',
        action: 'reduce-options',
        reason: 'Confusion detected - too many choices',
        targetLevel: Math.max(0, currentProfile.currentLevel - 2)
      });
    }
    
    // High confidence + simple interface
    if (currentEmotion.confidence > 0.8 && currentProfile.currentLevel < 5) {
      recommendations.push({
        priority: 'low',
        action: 'complexify',
        reason: 'User showing high confidence - can handle more',
        targetLevel: Math.min(10, currentProfile.currentLevel + 1)
      });
    }
    
    // Stress + any level
    if (currentEmotion.stress > 0.7) {
      recommendations.push({
        priority: 'high',
        action: 'maintain',
        reason: 'High stress detected - avoid changes',
        targetLevel: currentProfile.currentLevel
      });
    }
    
    return recommendations;
  }
  
  /**
   * Set adaptation sensitivity
   */
  setAdaptationSensitivity(sensitivity: number): void {
    this.adaptationSensitivity = Math.max(0, Math.min(1, sensitivity));
  }
  
  /**
   * Emit insight about adaptation
   */
  private emitInsight(insight: AdaptationInsight): void {
    console.log('Adaptation Insight:', insight);
    // Could emit to analytics or UI
  }
  
  /**
   * Get emotional stability score
   */
  getEmotionalStabilityScore(): number {
    if (this.emotionHistory.length < 3) return 1; // Assume stable if no history
    
    const volatility = this.calculateVolatility(this.emotionHistory);
    return 1 - volatility; // Higher score = more stable
  }
  
  /**
   * Reset emotion history
   */
  reset(): void {
    this.emotionHistory = [];
  }
}

interface AdaptationRecommendation {
  priority: 'high' | 'medium' | 'low';
  action: 'simplify' | 'complexify' | 'maintain' | 'reduce-options';
  reason: string;
  targetLevel: number;
}

interface AdaptationInsight {
  type: string;
  message: string;
  confidence: number;
}