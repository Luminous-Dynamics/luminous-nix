/**
 * Color Theme Types
 * Defines color themes as emotional sanctuaries
 */

export interface ColorTheme {
  id: string;
  name: string;
  description: string;
  emotional: EmotionalQualities;
  colors: ThemeColors;
  accessibility: AccessibilityFeatures;
  recommended: RecommendationCriteria;
}

export interface EmotionalQualities {
  // Primary emotional qualities (0-1)
  calming: number;
  energizing: number;
  focusing: number;
  comforting: number;
  
  // Secondary qualities
  playful: number;
  serious: number;
  warm: number;
  cool: number;
}

export interface ThemeColors {
  // Core colors
  primary: string;
  secondary: string;
  accent: string;
  
  // Backgrounds
  background: string;
  surface: string;
  elevated: string;
  
  // Text
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  
  // Semantic colors
  success: string;
  warning: string;
  error: string;
  info: string;
  
  // Interactive states
  hover: string;
  active: string;
  disabled: string;
  
  // Borders and dividers
  border: string;
  divider: string;
  
  // Shadows (can be transparent)
  shadowLight: string;
  shadowMedium: string;
  shadowDark: string;
}

export interface AccessibilityFeatures {
  contrastRatio: {
    normal: number; // WCAG AA = 4.5:1
    large: number;  // WCAG AA = 3:1
  };
  colorBlindSafe: {
    protanopia: boolean;
    deuteranopia: boolean;
    tritanopia: boolean;
  };
  reducedMotion: boolean;
  highContrast: boolean;
}

export interface RecommendationCriteria {
  timeOfDay?: {
    morning?: number;   // 6-12
    afternoon?: number; // 12-18
    evening?: number;   // 18-22
    night?: number;     // 22-6
  };
  emotions?: {
    frustration?: number;
    stress?: number;
    fatigue?: number;
    excitement?: number;
  };
  tasks?: string[]; // 'reading', 'coding', 'browsing', 'creating'
  personas?: string[]; // persona IDs this theme suits
}

export interface ColorPreferences {
  // User settings
  currentTheme: string;
  favoriteThemes: string[];
  autoSwitch: boolean;
  
  // Auto-switching rules
  schedule?: ThemeSchedule[];
  emotionResponsive: boolean;
  
  // Accessibility
  colorBlindMode?: 'none' | 'protanopia' | 'deuteranopia' | 'tritanopia';
  contrastPreference: 'standard' | 'increased' | 'maximum';
  
  // Customization
  allowCustomization: boolean;
  customThemes: ColorTheme[];
}

export interface ThemeSchedule {
  themeId: string;
  startTime: string; // "HH:MM"
  endTime: string;   // "HH:MM"
  days?: number[];   // 0-6, Sunday-Saturday
}

export interface ThemeTransition {
  duration: number; // milliseconds
  easing: 'linear' | 'ease' | 'ease-in' | 'ease-out' | 'ease-in-out';
  properties: string[]; // which CSS properties to animate
}

// Predefined theme categories
export type ThemeCategory = 
  | 'sanctuary'    // Calming, protective
  | 'focus'        // High contrast, minimal distraction
  | 'energy'       // Bright, motivating
  | 'comfort'      // Warm, familiar
  | 'night'        // Dark, easy on eyes
  | 'accessible'   // Maximum accessibility
  | 'playful'      // Fun, creative
  | 'professional' // Serious, businesslike

export interface ColorAdjustment {
  brightness: number;    // -100 to 100
  contrast: number;      // -100 to 100
  saturation: number;    // -100 to 100
  hue: number;          // -180 to 180
  temperature: number;   // -100 (cool) to 100 (warm)
}

export interface ColorPsychology {
  color: string;
  associations: string[];
  emotionalImpact: {
    positive: string[];
    negative: string[];
  };
  bestFor: string[];
  avoidFor: string[];
}