/**
 * Color Theme Demo
 * Interactive demonstration of the color theme system
 */

import React, { useState, useEffect } from 'react';
import { ThemeEngine } from './theme-engine';
import { ThemeSelector } from './ThemeSelector';
import { ColorTheme } from './types';
import { EmotionalState } from '../../voice-emotion/types';

// Demo application showing themes in action
const DemoApp: React.FC<{ theme: ColorTheme }> = ({ theme }) => {
  return (
    <div className="demo-app p-6 rounded-lg shadow-lg transition-colors duration-300"
         style={{ 
           backgroundColor: theme.colors.surface,
           color: theme.colors.textPrimary
         }}>
      <h3 className="text-xl font-bold mb-4" style={{ color: theme.colors.primary }}>
        NixOS Control Panel
      </h3>
      
      <div className="grid md:grid-cols-2 gap-4">
        {/* Status card */}
        <div className="p-4 rounded" style={{ 
          backgroundColor: theme.colors.elevated,
          borderColor: theme.colors.border,
          borderWidth: '1px',
          borderStyle: 'solid'
        }}>
          <h4 className="font-semibold mb-2" style={{ color: theme.colors.textPrimary }}>
            System Status
          </h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span style={{ color: theme.colors.textSecondary }}>Status:</span>
              <span style={{ color: theme.colors.success }}>● Online</span>
            </div>
            <div className="flex justify-between">
              <span style={{ color: theme.colors.textSecondary }}>Updates:</span>
              <span style={{ color: theme.colors.warning }}>3 available</span>
            </div>
            <div className="flex justify-between">
              <span style={{ color: theme.colors.textSecondary }}>Last backup:</span>
              <span style={{ color: theme.colors.info }}>2 hours ago</span>
            </div>
          </div>
        </div>
        
        {/* Actions card */}
        <div className="p-4 rounded" style={{ 
          backgroundColor: theme.colors.elevated,
          borderColor: theme.colors.border,
          borderWidth: '1px',
          borderStyle: 'solid'
        }}>
          <h4 className="font-semibold mb-2" style={{ color: theme.colors.textPrimary }}>
            Quick Actions
          </h4>
          <div className="space-y-2">
            <button 
              className="w-full px-4 py-2 rounded transition-colors"
              style={{ 
                backgroundColor: theme.colors.primary,
                color: theme.colors.background
              }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.primary}
            >
              Update System
            </button>
            <button 
              className="w-full px-4 py-2 rounded transition-colors"
              style={{ 
                backgroundColor: theme.colors.secondary,
                color: theme.colors.background
              }}
            >
              Install Package
            </button>
          </div>
        </div>
      </div>
      
      {/* Message examples */}
      <div className="mt-4 space-y-2">
        <div className="p-3 rounded flex items-center" style={{ 
          backgroundColor: theme.colors.success,
          color: theme.colors.background
        }}>
          <span className="mr-2">✓</span>
          Firefox installed successfully
        </div>
        
        <div className="p-3 rounded flex items-center" style={{ 
          backgroundColor: theme.colors.error,
          color: theme.colors.background
        }}>
          <span className="mr-2">✗</span>
          Connection timeout - please check your network
        </div>
      </div>
      
      {/* Form elements */}
      <div className="mt-4 p-4 rounded" style={{ 
        backgroundColor: theme.colors.background,
        borderColor: theme.colors.divider,
        borderWidth: '1px',
        borderStyle: 'solid'
      }}>
        <input
          type="text"
          placeholder="Search packages..."
          className="w-full px-3 py-2 rounded"
          style={{
            backgroundColor: theme.colors.surface,
            borderColor: theme.colors.border,
            color: theme.colors.textPrimary,
            borderWidth: '1px',
            borderStyle: 'solid'
          }}
        />
      </div>
    </div>
  );
};

// Emotion simulator
const EmotionSimulator: React.FC<{
  onEmotionChange: (emotion: Partial<EmotionalState>) => void;
}> = ({ onEmotionChange }) => {
  const emotions = [
    { 
      name: 'Calm & Focused', 
      emoji: '😌', 
      state: { frustration: 0.1, stress: 0.1, confidence: 0.8, calmness: 0.9 } 
    },
    { 
      name: 'Frustrated', 
      emoji: '😤', 
      state: { frustration: 0.8, stress: 0.7, confidence: 0.3, calmness: 0.2 } 
    },
    { 
      name: 'Stressed', 
      emoji: '😰', 
      state: { frustration: 0.5, stress: 0.9, confidence: 0.2, calmness: 0.1 } 
    },
    { 
      name: 'Confused', 
      emoji: '😕', 
      state: { confusion: 0.8, confidence: 0.2, needsHelp: 0.9, calmness: 0.3 } 
    },
    { 
      name: 'Energized', 
      emoji: '⚡', 
      state: { excitement: 0.9, confidence: 0.8, engagement: 0.9, calmness: 0.4 } 
    },
    { 
      name: 'Tired', 
      emoji: '😴', 
      state: { fatigue: 0.8, engagement: 0.2, needsHelp: 0.6, calmness: 0.6 } 
    }
  ];
  
  return (
    <div className="emotion-simulator p-4 bg-white rounded-lg shadow">
      <h3 className="font-semibold mb-3">Simulate Emotional State</h3>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
        {emotions.map(emotion => (
          <button
            key={emotion.name}
            onClick={() => onEmotionChange(emotion.state)}
            className="p-3 rounded border hover:bg-gray-50 transition-colors"
          >
            <div className="text-2xl mb-1">{emotion.emoji}</div>
            <div className="text-sm">{emotion.name}</div>
          </button>
        ))}
      </div>
    </div>
  );
};

// Main demo component
export const ThemeDemo: React.FC = () => {
  const [engine] = useState(() => new ThemeEngine());
  const [currentTheme, setCurrentTheme] = useState<ColorTheme | null>(null);
  const [emotionTriggered, setEmotionTriggered] = useState<string | null>(null);
  
  useEffect(() => {
    // Load initial theme
    engine.loadPreferences();
    setCurrentTheme(engine.getCurrentTheme());
    
    // Listen for emotion-triggered changes
    engine.on('emotion-triggered-change', (data: any) => {
      setEmotionTriggered(data.reason);
      setTimeout(() => setEmotionTriggered(null), 5000);
    });
  }, [engine]);
  
  const handleEmotionChange = (emotion: Partial<EmotionalState>) => {
    // Simulate full emotional state
    const fullState: EmotionalState = {
      frustration: 0,
      confidence: 0.5,
      confusion: 0,
      excitement: 0.5,
      calmness: 0.5,
      stress: 0,
      engagement: 0.5,
      needsHelp: 0,
      certainty: 0.8,
      timestamp: new Date(),
      ...emotion
    };
    
    engine.processEmotionalState(fullState);
  };
  
  return (
    <div className="theme-demo min-h-screen transition-colors duration-300" 
         style={{ backgroundColor: currentTheme?.colors.background || '#ffffff' }}>
      <div className="max-w-6xl mx-auto p-6">
        <h1 className="text-3xl font-bold mb-2">Color Themes Demo</h1>
        <p className="text-gray-600 mb-8">
          Experience how color themes create emotional sanctuaries
        </p>
        
        {/* Emotion-triggered notification */}
        {emotionTriggered && (
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg animate-pulse">
            <p className="text-blue-800">
              🎨 {emotionTriggered}
            </p>
          </div>
        )}
        
        {/* Demo application */}
        {currentTheme && (
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">Live Preview</h2>
            <DemoApp theme={currentTheme} />
          </div>
        )}
        
        {/* Emotion simulator */}
        <div className="mb-8">
          <EmotionSimulator onEmotionChange={handleEmotionChange} />
        </div>
        
        {/* Theme selector */}
        <div className="mb-8">
          <ThemeSelector 
            engine={engine} 
            onThemeChange={setCurrentTheme}
          />
        </div>
        
        {/* Benefits showcase */}
        <div className="grid md:grid-cols-3 gap-6 mt-12">
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="font-semibold mb-3">🌈 Emotional Impact</h3>
            <ul className="text-sm space-y-2 text-gray-600">
              <li>• Calming themes reduce stress</li>
              <li>• Energizing themes boost motivation</li>
              <li>• Focus themes enhance concentration</li>
              <li>• Comfort themes provide familiarity</li>
            </ul>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="font-semibold mb-3">♿ Accessibility First</h3>
            <ul className="text-sm space-y-2 text-gray-600">
              <li>• WCAG AAA contrast ratios</li>
              <li>• Colorblind safe options</li>
              <li>• Reduced motion support</li>
              <li>• High contrast modes</li>
            </ul>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="font-semibold mb-3">🎯 Smart Adaptation</h3>
            <ul className="text-sm space-y-2 text-gray-600">
              <li>• Time-based switching</li>
              <li>• Emotion-responsive themes</li>
              <li>• Task-specific optimization</li>
              <li>• Persona recommendations</li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* CSS for theme transitions */}
      <style jsx global>{`
        .theme-transitioning * {
          transition: background-color 300ms ease-in-out,
                      color 300ms ease-in-out,
                      border-color 300ms ease-in-out !important;
        }
        
        .reduced-motion * {
          animation: none !important;
          transition: none !important;
        }
        
        .high-contrast img {
          filter: contrast(1.5);
        }
      `}</style>
    </div>
  );
};