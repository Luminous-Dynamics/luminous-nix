/**
 * Color Theme Engine
 * Manages theme selection, application, and transitions
 */

import { EventEmitter } from 'events';
import { ColorTheme, ColorPreferences, ThemeSchedule, ColorAdjustment } from './types';
import { predefinedThemes } from './theme-definitions';
import { EmotionalState } from '../../voice-emotion/types';

export class ThemeEngine extends EventEmitter {
  private currentTheme: ColorTheme;
  private preferences: ColorPreferences;
  private themes: Map<string, ColorTheme>;
  private transitionTimeout?: NodeJS.Timeout;
  
  constructor() {
    super();
    
    // Initialize with default theme
    this.themes = new Map();
    predefinedThemes.forEach(theme => {
      this.themes.set(theme.id, theme);
    });
    
    this.currentTheme = this.themes.get('sanctuary')!;
    
    this.preferences = {
      currentTheme: 'sanctuary',
      favoriteThemes: [],
      autoSwitch: false,
      emotionResponsive: true,
      contrastPreference: 'standard',
      allowCustomization: true,
      customThemes: []
    };
    
    this.initializeScheduler();
  }
  
  /**
   * Get current theme
   */
  getCurrentTheme(): ColorTheme {
    return this.currentTheme;
  }
  
  /**
   * Set theme by ID
   */
  async setTheme(themeId: string, transition: boolean = true): Promise<void> {
    const theme = this.themes.get(themeId);
    if (!theme) {
      throw new Error(`Theme '${themeId}' not found`);
    }
    
    if (theme.id === this.currentTheme.id) {
      return; // Already using this theme
    }
    
    const previousTheme = this.currentTheme;
    this.currentTheme = theme;
    this.preferences.currentTheme = themeId;
    
    // Apply theme
    await this.applyTheme(theme, transition);
    
    // Emit change event
    this.emit('theme-changed', {
      previous: previousTheme,
      current: theme,
      trigger: 'manual'
    });
    
    // Save preference
    this.savePreferences();
  }
  
  /**
   * Apply theme to DOM
   */
  private async applyTheme(theme: ColorTheme, transition: boolean): Promise<void> {
    const root = document.documentElement;
    
    // Apply transition class if needed
    if (transition) {
      root.classList.add('theme-transitioning');
    }
    
    // Apply color adjustments based on preferences
    const adjustedColors = this.applyColorAdjustments(theme.colors);
    
    // Set CSS variables
    root.style.setProperty('--color-primary', adjustedColors.primary);
    root.style.setProperty('--color-secondary', adjustedColors.secondary);
    root.style.setProperty('--color-accent', adjustedColors.accent);
    
    root.style.setProperty('--color-background', adjustedColors.background);
    root.style.setProperty('--color-surface', adjustedColors.surface);
    root.style.setProperty('--color-elevated', adjustedColors.elevated);
    
    root.style.setProperty('--color-text-primary', adjustedColors.textPrimary);
    root.style.setProperty('--color-text-secondary', adjustedColors.textSecondary);
    root.style.setProperty('--color-text-muted', adjustedColors.textMuted);
    
    root.style.setProperty('--color-success', adjustedColors.success);
    root.style.setProperty('--color-warning', adjustedColors.warning);
    root.style.setProperty('--color-error', adjustedColors.error);
    root.style.setProperty('--color-info', adjustedColors.info);
    
    root.style.setProperty('--color-hover', adjustedColors.hover);
    root.style.setProperty('--color-active', adjustedColors.active);
    root.style.setProperty('--color-disabled', adjustedColors.disabled);
    
    root.style.setProperty('--color-border', adjustedColors.border);
    root.style.setProperty('--color-divider', adjustedColors.divider);
    
    root.style.setProperty('--shadow-light', adjustedColors.shadowLight);
    root.style.setProperty('--shadow-medium', adjustedColors.shadowMedium);
    root.style.setProperty('--shadow-dark', adjustedColors.shadowDark);
    
    // Apply theme class
    root.className = root.className.replace(/theme-[\w-]+/g, '');
    root.classList.add(`theme-${theme.id}`);
    
    // Apply accessibility classes
    if (theme.accessibility.highContrast) {
      root.classList.add('high-contrast');
    } else {
      root.classList.remove('high-contrast');
    }
    
    if (theme.accessibility.reducedMotion) {
      root.classList.add('reduced-motion');
    } else {
      root.classList.remove('reduced-motion');
    }
    
    // Remove transition class after animation
    if (transition) {
      setTimeout(() => {
        root.classList.remove('theme-transitioning');
      }, 300);
    }
  }
  
  /**
   * Apply color adjustments for accessibility
   */
  private applyColorAdjustments(colors: any): any {
    const adjusted = { ...colors };
    
    // Apply contrast adjustments
    if (this.preferences.contrastPreference === 'increased') {
      // Darken dark colors, lighten light colors
      adjusted.textPrimary = this.adjustContrast(adjusted.textPrimary, 1.2);
      adjusted.textSecondary = this.adjustContrast(adjusted.textSecondary, 1.15);
      adjusted.background = this.adjustContrast(adjusted.background, 0.95);
    } else if (this.preferences.contrastPreference === 'maximum') {
      // Use maximum contrast colors
      adjusted.textPrimary = '#000000';
      adjusted.textSecondary = '#000000';
      adjusted.background = '#FFFFFF';
      adjusted.surface = '#FFFFFF';
    }
    
    // Apply colorblind adjustments
    if (this.preferences.colorBlindMode && this.preferences.colorBlindMode !== 'none') {
      adjusted.success = this.colorBlindAdjust(adjusted.success, this.preferences.colorBlindMode);
      adjusted.error = this.colorBlindAdjust(adjusted.error, this.preferences.colorBlindMode);
      adjusted.warning = this.colorBlindAdjust(adjusted.warning, this.preferences.colorBlindMode);
    }
    
    return adjusted;
  }
  
  /**
   * Adjust contrast of a color
   */
  private adjustContrast(color: string, factor: number): string {
    // Simple contrast adjustment (in practice, use a proper color library)
    const rgb = this.hexToRgb(color);
    if (!rgb) return color;
    
    const adjusted = {
      r: Math.round(Math.min(255, rgb.r * factor)),
      g: Math.round(Math.min(255, rgb.g * factor)),
      b: Math.round(Math.min(255, rgb.b * factor))
    };
    
    return this.rgbToHex(adjusted);
  }
  
  /**
   * Adjust colors for colorblind users
   */
  private colorBlindAdjust(color: string, mode: string): string {
    // Simplified colorblind adjustment
    // In practice, use proper color transformation matrices
    const adjustments: Record<string, Record<string, string>> = {
      protanopia: {
        '#00C853': '#0066CC', // Green → Blue
        '#FF5252': '#FF9800', // Red → Orange
      },
      deuteranopia: {
        '#00C853': '#0066CC', // Green → Blue
        '#FF5252': '#FF9800', // Red → Orange
      },
      tritanopia: {
        '#448AFF': '#00ACC1', // Blue → Cyan
        '#FFD600': '#FF6B00', // Yellow → Orange
      }
    };
    
    return adjustments[mode]?.[color] || color;
  }
  
  /**
   * Get theme recommendation based on context
   */
  getRecommendedTheme(context: ThemeContext): ColorTheme | null {
    const hour = new Date().getHours();
    const timeOfDay = this.getTimeOfDay(hour);
    
    let bestTheme: ColorTheme | null = null;
    let bestScore = 0;
    
    for (const theme of this.themes.values()) {
      let score = 0;
      
      // Time of day score
      if (theme.recommended.timeOfDay?.[timeOfDay]) {
        score += theme.recommended.timeOfDay[timeOfDay] * 0.3;
      }
      
      // Emotional state score
      if (context.emotionalState) {
        const emotionScore = this.calculateEmotionScore(theme, context.emotionalState);
        score += emotionScore * 0.4;
      }
      
      // Task score
      if (context.currentTask && theme.recommended.tasks?.includes(context.currentTask)) {
        score += 0.2;
      }
      
      // Persona score
      if (context.personaId && theme.recommended.personas?.includes(context.personaId)) {
        score += 0.1;
      }
      
      if (score > bestScore) {
        bestScore = score;
        bestTheme = theme;
      }
    }
    
    return bestTheme;
  }
  
  /**
   * Calculate emotion score for theme
   */
  private calculateEmotionScore(theme: ColorTheme, emotion: EmotionalState): number {
    let score = 0;
    
    if (emotion.frustration > 0.6 && theme.emotional.calming > 0.7) {
      score += 0.3;
    }
    
    if (emotion.stress > 0.6 && theme.emotional.comforting > 0.7) {
      score += 0.3;
    }
    
    if (emotion.confidence > 0.7 && theme.emotional.energizing > 0.6) {
      score += 0.2;
    }
    
    if (emotion.needsHelp > 0.6 && theme.emotional.focusing > 0.7) {
      score += 0.2;
    }
    
    return Math.min(1, score);
  }
  
  /**
   * Process emotional state for theme adaptation
   */
  async processEmotionalState(state: EmotionalState): Promise<void> {
    if (!this.preferences.emotionResponsive) return;
    
    const context: ThemeContext = {
      emotionalState: state,
      personaId: undefined, // Would be provided by system
      currentTask: undefined // Would be detected
    };
    
    const recommended = this.getRecommendedTheme(context);
    
    if (recommended && recommended.id !== this.currentTheme.id) {
      // Check if the emotion is strong enough to warrant a change
      const shouldChange = 
        state.frustration > 0.8 ||
        state.stress > 0.8 ||
        (state.needsHelp > 0.7 && this.currentTheme.emotional.calming < 0.5);
      
      if (shouldChange) {
        await this.setTheme(recommended.id, true);
        
        this.emit('emotion-triggered-change', {
          emotion: state,
          newTheme: recommended,
          reason: this.getChangeReason(state)
        });
      }
    }
  }
  
  /**
   * Get reason for theme change
   */
  private getChangeReason(emotion: EmotionalState): string {
    if (emotion.frustration > 0.8) {
      return 'High frustration detected - switching to calming theme';
    }
    if (emotion.stress > 0.8) {
      return 'High stress detected - switching to comforting theme';
    }
    if (emotion.needsHelp > 0.7) {
      return 'User needs help - switching to focus theme';
    }
    return 'Emotional state change';
  }
  
  /**
   * Initialize scheduled theme switching
   */
  private initializeScheduler(): void {
    // Check schedule every minute
    setInterval(() => {
      if (this.preferences.autoSwitch && this.preferences.schedule) {
        this.checkSchedule();
      }
    }, 60000);
  }
  
  /**
   * Check if scheduled theme change is needed
   */
  private checkSchedule(): void {
    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    const currentDay = now.getDay();
    
    for (const schedule of this.preferences.schedule || []) {
      // Check if current day matches (if specified)
      if (schedule.days && !schedule.days.includes(currentDay)) {
        continue;
      }
      
      // Check if current time is within schedule
      if (currentTime >= schedule.startTime && currentTime < schedule.endTime) {
        if (this.currentTheme.id !== schedule.themeId) {
          this.setTheme(schedule.themeId, true);
        }
        break;
      }
    }
  }
  
  /**
   * Get time of day category
   */
  private getTimeOfDay(hour: number): 'morning' | 'afternoon' | 'evening' | 'night' {
    if (hour >= 6 && hour < 12) return 'morning';
    if (hour >= 12 && hour < 18) return 'afternoon';
    if (hour >= 18 && hour < 22) return 'evening';
    return 'night';
  }
  
  /**
   * Add custom theme
   */
  addCustomTheme(theme: ColorTheme): void {
    this.themes.set(theme.id, theme);
    this.preferences.customThemes.push(theme);
    this.savePreferences();
    
    this.emit('theme-added', theme);
  }
  
  /**
   * Toggle favorite theme
   */
  toggleFavorite(themeId: string): void {
    const index = this.preferences.favoriteThemes.indexOf(themeId);
    
    if (index === -1) {
      this.preferences.favoriteThemes.push(themeId);
    } else {
      this.preferences.favoriteThemes.splice(index, 1);
    }
    
    this.savePreferences();
    this.emit('favorites-updated', this.preferences.favoriteThemes);
  }
  
  /**
   * Get all available themes
   */
  getAllThemes(): ColorTheme[] {
    return Array.from(this.themes.values());
  }
  
  /**
   * Get favorite themes
   */
  getFavoriteThemes(): ColorTheme[] {
    return this.preferences.favoriteThemes
      .map(id => this.themes.get(id))
      .filter(theme => theme !== undefined) as ColorTheme[];
  }
  
  /**
   * Update preferences
   */
  updatePreferences(updates: Partial<ColorPreferences>): void {
    this.preferences = { ...this.preferences, ...updates };
    this.savePreferences();
    
    // Re-apply current theme if contrast preference changed
    if (updates.contrastPreference || updates.colorBlindMode) {
      this.applyTheme(this.currentTheme, false);
    }
  }
  
  /**
   * Save preferences to storage
   */
  private savePreferences(): void {
    // In a real app, save to localStorage or backend
    localStorage.setItem('nix-humanity-theme-preferences', JSON.stringify(this.preferences));
  }
  
  /**
   * Load preferences from storage
   */
  loadPreferences(): void {
    const saved = localStorage.getItem('nix-humanity-theme-preferences');
    if (saved) {
      try {
        this.preferences = JSON.parse(saved);
        
        // Load custom themes
        this.preferences.customThemes.forEach(theme => {
          this.themes.set(theme.id, theme);
        });
        
        // Apply saved theme
        if (this.themes.has(this.preferences.currentTheme)) {
          this.setTheme(this.preferences.currentTheme, false);
        }
      } catch (error) {
        console.error('Failed to load theme preferences:', error);
      }
    }
  }
  
  /**
   * Helper: Convert hex to RGB
   */
  private hexToRgb(hex: string): { r: number; g: number; b: number } | null {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  }
  
  /**
   * Helper: Convert RGB to hex
   */
  private rgbToHex(rgb: { r: number; g: number; b: number }): string {
    return '#' + [rgb.r, rgb.g, rgb.b]
      .map(x => x.toString(16).padStart(2, '0'))
      .join('');
  }
}

interface ThemeContext {
  emotionalState?: EmotionalState;
  personaId?: string;
  currentTask?: string;
}