/**
 * Predefined Color Themes
 * Each theme is carefully crafted as an emotional sanctuary
 */

import { ColorTheme } from './types';

export const predefinedThemes: ColorTheme[] = [
  {
    id: 'sanctuary',
    name: 'Sanctuary',
    description: 'Soft, calming colors that create a peaceful digital space',
    emotional: {
      calming: 0.9,
      energizing: 0.2,
      focusing: 0.6,
      comforting: 0.8,
      playful: 0.2,
      serious: 0.5,
      warm: 0.6,
      cool: 0.4
    },
    colors: {
      primary: '#6B7EB8',      // Soft lavender blue
      secondary: '#9CA8C9',    // Gentle gray blue
      accent: '#8B9DC3',       // Muted periwinkle
      
      background: '#F7F8FA',   // Almost white with hint of blue
      surface: '#FFFFFF',      // Pure white
      elevated: '#FEFEFF',     // Slightly elevated white
      
      textPrimary: '#2C3E50',  // Soft dark blue gray
      textSecondary: '#546E7A', // Medium blue gray
      textMuted: '#90A4AE',    // Light blue gray
      
      success: '#7CB342',      // Gentle green
      warning: '#FFA726',      // Soft orange
      error: '#EF5350',        // Muted red
      info: '#42A5F5',         // Sky blue
      
      hover: '#E8EAF6',        // Light lavender
      active: '#C5CAE9',       // Medium lavender
      disabled: '#E0E0E0',     // Light gray
      
      border: '#E1E4E8',       // Very light gray
      divider: '#ECEFF1',      // Almost invisible gray
      
      shadowLight: 'rgba(0, 0, 0, 0.05)',
      shadowMedium: 'rgba(0, 0, 0, 0.1)',
      shadowDark: 'rgba(0, 0, 0, 0.15)'
    },
    accessibility: {
      contrastRatio: {
        normal: 7.5,
        large: 5.2
      },
      colorBlindSafe: {
        protanopia: true,
        deuteranopia: true,
        tritanopia: true
      },
      reducedMotion: false,
      highContrast: false
    },
    recommended: {
      timeOfDay: {
        morning: 0.8,
        afternoon: 0.9,
        evening: 0.7,
        night: 0.5
      },
      emotions: {
        frustration: 0.9,
        stress: 0.8,
        fatigue: 0.7,
        excitement: 0.4
      },
      tasks: ['reading', 'learning', 'browsing'],
      personas: ['grandma-rose', 'david', 'viktor']
    }
  },
  
  {
    id: 'focus',
    name: 'Focus',
    description: 'High contrast theme for deep concentration and clarity',
    emotional: {
      calming: 0.4,
      energizing: 0.6,
      focusing: 1.0,
      comforting: 0.3,
      playful: 0.1,
      serious: 0.9,
      warm: 0.2,
      cool: 0.8
    },
    colors: {
      primary: '#1976D2',      // Strong blue
      secondary: '#424242',    // Dark gray
      accent: '#0D47A1',       // Deep blue
      
      background: '#FAFAFA',   // Off white
      surface: '#FFFFFF',      // Pure white
      elevated: '#FFFFFF',     // Pure white
      
      textPrimary: '#000000',  // Pure black
      textSecondary: '#424242', // Dark gray
      textMuted: '#757575',    // Medium gray
      
      success: '#2E7D32',      // Dark green
      warning: '#F57C00',      // Dark orange
      error: '#C62828',        // Dark red
      info: '#0277BD',         // Dark blue
      
      hover: '#F5F5F5',        // Light gray
      active: '#E0E0E0',       // Medium gray
      disabled: '#BDBDBD',     // Gray
      
      border: '#212121',       // Near black
      divider: '#424242',      // Dark gray
      
      shadowLight: 'rgba(0, 0, 0, 0.12)',
      shadowMedium: 'rgba(0, 0, 0, 0.24)',
      shadowDark: 'rgba(0, 0, 0, 0.36)'
    },
    accessibility: {
      contrastRatio: {
        normal: 21,
        large: 21
      },
      colorBlindSafe: {
        protanopia: true,
        deuteranopia: true,
        tritanopia: true
      },
      reducedMotion: true,
      highContrast: true
    },
    recommended: {
      timeOfDay: {
        morning: 0.9,
        afternoon: 1.0,
        evening: 0.6,
        night: 0.3
      },
      emotions: {
        frustration: 0.3,
        stress: 0.4,
        fatigue: 0.2,
        excitement: 0.8
      },
      tasks: ['coding', 'writing', 'studying'],
      personas: ['alex', 'sam', 'jordan']
    }
  },
  
  {
    id: 'night-owl',
    name: 'Night Owl',
    description: 'Easy on the eyes for late night sessions',
    emotional: {
      calming: 0.8,
      energizing: 0.2,
      focusing: 0.7,
      comforting: 0.7,
      playful: 0.3,
      serious: 0.6,
      warm: 0.7,
      cool: 0.3
    },
    colors: {
      primary: '#BB86FC',      // Purple
      secondary: '#03DAC6',    // Teal
      accent: '#CF6679',       // Pink
      
      background: '#121212',   // Near black
      surface: '#1E1E1E',      // Dark gray
      elevated: '#2C2C2C',     // Lighter dark gray
      
      textPrimary: '#E1E1E1',  // Light gray
      textSecondary: '#AAAAAA', // Medium gray
      textMuted: '#717171',    // Dark gray
      
      success: '#4CAF50',      // Green
      warning: '#FB8C00',      // Orange
      error: '#F44336',        // Red
      info: '#2196F3',         // Blue
      
      hover: '#2A2A2A',        // Slightly lighter
      active: '#3C3C3C',       // More lighter
      disabled: '#404040',     // Gray
      
      border: '#333333',       // Dark gray
      divider: '#2A2A2A',      // Darker gray
      
      shadowLight: 'rgba(0, 0, 0, 0.4)',
      shadowMedium: 'rgba(0, 0, 0, 0.6)',
      shadowDark: 'rgba(0, 0, 0, 0.8)'
    },
    accessibility: {
      contrastRatio: {
        normal: 7.1,
        large: 4.6
      },
      colorBlindSafe: {
        protanopia: false,
        deuteranopia: true,
        tritanopia: true
      },
      reducedMotion: false,
      highContrast: false
    },
    recommended: {
      timeOfDay: {
        morning: 0.1,
        afternoon: 0.3,
        evening: 0.8,
        night: 1.0
      },
      emotions: {
        frustration: 0.5,
        stress: 0.6,
        fatigue: 0.8,
        excitement: 0.6
      },
      tasks: ['browsing', 'entertainment', 'coding'],
      personas: ['maya', 'taylor', 'jordan']
    }
  },
  
  {
    id: 'warm-comfort',
    name: 'Warm Comfort',
    description: 'Cozy and familiar like a warm hug',
    emotional: {
      calming: 0.7,
      energizing: 0.4,
      focusing: 0.5,
      comforting: 1.0,
      playful: 0.4,
      serious: 0.3,
      warm: 1.0,
      cool: 0.0
    },
    colors: {
      primary: '#8D6E63',      // Warm brown
      secondary: '#D7CCC8',    // Light brown
      accent: '#FF7043',       // Warm orange
      
      background: '#FFF8F3',   // Warm off-white
      surface: '#FFFFFF',      // White
      elevated: '#FFFBF7',     // Slightly warm white
      
      textPrimary: '#3E2723',  // Dark brown
      textSecondary: '#5D4037', // Medium brown
      textMuted: '#795548',    // Light brown
      
      success: '#689F38',      // Olive green
      warning: '#FFA000',      // Amber
      error: '#D32F2F',        // Warm red
      info: '#5C6BC0',         // Soft indigo
      
      hover: '#FFECDF',        // Light peach
      active: '#FFD7C4',       // Peach
      disabled: '#D7CCC8',     // Light brown
      
      border: '#BCAAA4',       // Light brown
      divider: '#D7CCC8',      // Very light brown
      
      shadowLight: 'rgba(121, 85, 72, 0.1)',
      shadowMedium: 'rgba(121, 85, 72, 0.2)',
      shadowDark: 'rgba(121, 85, 72, 0.3)'
    },
    accessibility: {
      contrastRatio: {
        normal: 7.8,
        large: 5.5
      },
      colorBlindSafe: {
        protanopia: true,
        deuteranopia: true,
        tritanopia: false
      },
      reducedMotion: false,
      highContrast: false
    },
    recommended: {
      timeOfDay: {
        morning: 0.9,
        afternoon: 0.7,
        evening: 0.9,
        night: 0.6
      },
      emotions: {
        frustration: 0.7,
        stress: 0.8,
        fatigue: 0.9,
        excitement: 0.5
      },
      tasks: ['reading', 'casual browsing', 'learning'],
      personas: ['grandma-rose', 'david', 'lisa']
    }
  },
  
  {
    id: 'high-contrast',
    name: 'Maximum Contrast',
    description: 'Ultimate clarity for visual accessibility',
    emotional: {
      calming: 0.3,
      energizing: 0.5,
      focusing: 0.9,
      comforting: 0.2,
      playful: 0.0,
      serious: 1.0,
      warm: 0.1,
      cool: 0.9
    },
    colors: {
      primary: '#000000',      // Black
      secondary: '#FFFFFF',    // White
      accent: '#0000FF',       // Pure blue
      
      background: '#FFFFFF',   // Pure white
      surface: '#FFFFFF',      // Pure white
      elevated: '#FFFFFF',     // Pure white
      
      textPrimary: '#000000',  // Pure black
      textSecondary: '#000000', // Pure black
      textMuted: '#444444',    // Dark gray
      
      success: '#008000',      // Pure green
      warning: '#FFA500',      // Orange
      error: '#FF0000',        // Pure red
      info: '#0000FF',         // Pure blue
      
      hover: '#000000',        // Black
      active: '#0000FF',       // Blue
      disabled: '#808080',     // Gray
      
      border: '#000000',       // Black
      divider: '#000000',      // Black
      
      shadowLight: 'none',
      shadowMedium: 'none',
      shadowDark: 'none'
    },
    accessibility: {
      contrastRatio: {
        normal: 21,
        large: 21
      },
      colorBlindSafe: {
        protanopia: false,
        deuteranopia: false,
        tritanopia: false
      },
      reducedMotion: true,
      highContrast: true
    },
    recommended: {
      timeOfDay: {
        morning: 0.7,
        afternoon: 0.8,
        evening: 0.5,
        night: 0.3
      },
      emotions: {
        frustration: 0.4,
        stress: 0.3,
        fatigue: 0.2,
        excitement: 0.6
      },
      tasks: ['critical reading', 'data entry', 'forms'],
      personas: ['alex', 'morgan', 'grandma-rose']
    }
  },
  
  {
    id: 'ocean-breeze',
    name: 'Ocean Breeze',
    description: 'Fresh and energizing like a day at the beach',
    emotional: {
      calming: 0.6,
      energizing: 0.8,
      focusing: 0.6,
      comforting: 0.5,
      playful: 0.7,
      serious: 0.3,
      warm: 0.3,
      cool: 0.7
    },
    colors: {
      primary: '#00ACC1',      // Cyan
      secondary: '#26C6DA',    // Light cyan
      accent: '#00838F',       // Dark cyan
      
      background: '#F0FCFF',   // Very light cyan
      surface: '#FFFFFF',      // White
      elevated: '#F8FDFF',     // Slightly blue white
      
      textPrimary: '#006064',  // Dark cyan
      textSecondary: '#00838F', // Medium cyan
      textMuted: '#4DD0E1',    // Light cyan
      
      success: '#00C853',      // Bright green
      warning: '#FFD600',      // Bright yellow
      error: '#FF5252',        // Bright red
      info: '#448AFF',         // Bright blue
      
      hover: '#B2EBF2',        // Light cyan
      active: '#4DD0E1',       // Medium cyan
      disabled: '#B0BEC5',     // Blue gray
      
      border: '#B2EBF2',       // Light cyan
      divider: '#E0F7FA',      // Very light cyan
      
      shadowLight: 'rgba(0, 172, 193, 0.1)',
      shadowMedium: 'rgba(0, 172, 193, 0.2)',
      shadowDark: 'rgba(0, 172, 193, 0.3)'
    },
    accessibility: {
      contrastRatio: {
        normal: 7.2,
        large: 5.1
      },
      colorBlindSafe: {
        protanopia: true,
        deuteranopia: true,
        tritanopia: false
      },
      reducedMotion: false,
      highContrast: false
    },
    recommended: {
      timeOfDay: {
        morning: 1.0,
        afternoon: 0.8,
        evening: 0.4,
        night: 0.2
      },
      emotions: {
        frustration: 0.3,
        stress: 0.4,
        fatigue: 0.2,
        excitement: 0.9
      },
      tasks: ['creative work', 'brainstorming', 'casual use'],
      personas: ['maya', 'lisa', 'taylor']
    }
  }
];