/**
 * Theme Selector Component
 * Beautiful interface for choosing color themes
 */

import React, { useState, useEffect } from 'react';
import { ThemeEngine } from './theme-engine';
import { ColorTheme, ColorPreferences } from './types';

interface ThemeSelectorProps {
  engine: ThemeEngine;
  onThemeChange?: (theme: ColorTheme) => void;
}

export const ThemeSelector: React.FC<ThemeSelectorProps> = ({ engine, onThemeChange }) => {
  const [themes, setThemes] = useState<ColorTheme[]>([]);
  const [currentTheme, setCurrentTheme] = useState<ColorTheme | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [preferences, setPreferences] = useState<Partial<ColorPreferences>>({});
  
  useEffect(() => {
    // Load themes
    setThemes(engine.getAllThemes());
    setCurrentTheme(engine.getCurrentTheme());
    
    // Listen for changes
    engine.on('theme-changed', (data: any) => {
      setCurrentTheme(data.current);
      if (onThemeChange) {
        onThemeChange(data.current);
      }
    });
    
    engine.on('favorites-updated', (favs: string[]) => {
      setFavorites(favs);
    });
    
    // Load preferences
    engine.loadPreferences();
  }, [engine, onThemeChange]);
  
  const selectTheme = (themeId: string) => {
    engine.setTheme(themeId);
  };
  
  const toggleFavorite = (themeId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    engine.toggleFavorite(themeId);
  };
  
  const updatePreference = (key: string, value: any) => {
    const updates = { [key]: value };
    setPreferences(prev => ({ ...prev, ...updates }));
    engine.updatePreferences(updates);
  };
  
  const getThemePreview = (theme: ColorTheme) => {
    return (
      <div className="theme-preview flex h-full">
        <div 
          className="flex-1" 
          style={{ backgroundColor: theme.colors.background }}
        >
          <div className="p-2">
            <div 
              className="h-2 w-3/4 rounded"
              style={{ backgroundColor: theme.colors.primary }}
            />
            <div 
              className="h-2 w-1/2 rounded mt-1"
              style={{ backgroundColor: theme.colors.secondary }}
            />
          </div>
        </div>
        <div 
          className="flex-1" 
          style={{ backgroundColor: theme.colors.surface }}
        >
          <div className="p-2">
            <div 
              className="h-2 w-full rounded"
              style={{ backgroundColor: theme.colors.textPrimary }}
            />
            <div 
              className="h-2 w-2/3 rounded mt-1"
              style={{ backgroundColor: theme.colors.textSecondary }}
            />
          </div>
        </div>
      </div>
    );
  };
  
  const getEmotionalBadge = (theme: ColorTheme) => {
    const { emotional } = theme;
    
    if (emotional.calming > 0.8) return '😌 Calming';
    if (emotional.energizing > 0.8) return '⚡ Energizing';
    if (emotional.focusing > 0.8) return '🎯 Focusing';
    if (emotional.comforting > 0.8) return '🤗 Comforting';
    if (emotional.playful > 0.8) return '🎨 Playful';
    
    return '✨ Balanced';
  };
  
  return (
    <div className="theme-selector max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6">Choose Your Color Sanctuary</h2>
      
      {/* Current theme info */}
      {currentTheme && (
        <div className="mb-6 p-4 rounded-lg border" style={{
          backgroundColor: currentTheme.colors.surface,
          borderColor: currentTheme.colors.border
        }}>
          <p className="text-sm opacity-75 mb-1">Current Theme</p>
          <h3 className="text-xl font-semibold">{currentTheme.name}</h3>
          <p className="text-sm mt-1">{currentTheme.description}</p>
        </div>
      )}
      
      {/* Theme grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {themes.map(theme => (
          <button
            key={theme.id}
            onClick={() => selectTheme(theme.id)}
            className={`
              theme-card relative overflow-hidden rounded-lg border-2 transition-all
              ${currentTheme?.id === theme.id 
                ? 'ring-2 ring-offset-2' 
                : 'hover:shadow-lg'
              }
            `}
            style={{
              borderColor: currentTheme?.id === theme.id 
                ? theme.colors.primary 
                : theme.colors.border
            }}
          >
            {/* Preview */}
            <div className="h-24">
              {getThemePreview(theme)}
            </div>
            
            {/* Info */}
            <div className="p-4 text-left">
              <div className="flex items-start justify-between mb-1">
                <h3 className="font-semibold">{theme.name}</h3>
                <button
                  onClick={(e) => toggleFavorite(theme.id, e)}
                  className="ml-2 text-xl hover:scale-110 transition-transform"
                  aria-label={`${favorites.includes(theme.id) ? 'Remove from' : 'Add to'} favorites`}
                >
                  {favorites.includes(theme.id) ? '❤️' : '🤍'}
                </button>
              </div>
              
              <p className="text-sm text-gray-600 mb-2">
                {theme.description}
              </p>
              
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium px-2 py-1 bg-gray-100 rounded">
                  {getEmotionalBadge(theme)}
                </span>
                
                {/* Accessibility indicators */}
                <div className="flex gap-1">
                  {theme.accessibility.highContrast && (
                    <span className="text-xs" title="High contrast">👁️</span>
                  )}
                  {theme.accessibility.colorBlindSafe.protanopia && (
                    <span className="text-xs" title="Colorblind safe">🎨</span>
                  )}
                  {theme.accessibility.reducedMotion && (
                    <span className="text-xs" title="Reduced motion">🚫</span>
                  )}
                </div>
              </div>
            </div>
          </button>
        ))}
      </div>
      
      {/* Advanced settings */}
      <div className="border-t pt-6">
        <button
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="flex items-center text-sm font-medium mb-4 hover:text-blue-600"
        >
          <span className="mr-2">{showAdvanced ? '▼' : '▶'}</span>
          Advanced Theme Settings
        </button>
        
        {showAdvanced && (
          <div className="space-y-4 bg-gray-50 rounded-lg p-4">
            {/* Auto-switching */}
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={preferences.autoSwitch || false}
                onChange={(e) => updatePreference('autoSwitch', e.target.checked)}
                className="mr-3"
              />
              <span>Automatically switch themes based on time of day</span>
            </label>
            
            {/* Emotion responsive */}
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={preferences.emotionResponsive !== false}
                onChange={(e) => updatePreference('emotionResponsive', e.target.checked)}
                className="mr-3"
              />
              <span>Adapt theme based on emotional state</span>
            </label>
            
            {/* Contrast preference */}
            <div>
              <label className="block text-sm font-medium mb-2">
                Contrast Preference
              </label>
              <select
                value={preferences.contrastPreference || 'standard'}
                onChange={(e) => updatePreference('contrastPreference', e.target.value)}
                className="w-full px-3 py-2 border rounded"
              >
                <option value="standard">Standard</option>
                <option value="increased">Increased</option>
                <option value="maximum">Maximum</option>
              </select>
            </div>
            
            {/* Colorblind mode */}
            <div>
              <label className="block text-sm font-medium mb-2">
                Colorblind Adjustment
              </label>
              <select
                value={preferences.colorBlindMode || 'none'}
                onChange={(e) => updatePreference('colorBlindMode', e.target.value)}
                className="w-full px-3 py-2 border rounded"
              >
                <option value="none">None</option>
                <option value="protanopia">Protanopia (Red-blind)</option>
                <option value="deuteranopia">Deuteranopia (Green-blind)</option>
                <option value="tritanopia">Tritanopia (Blue-blind)</option>
              </select>
            </div>
            
            {/* Theme schedule */}
            {preferences.autoSwitch && (
              <div className="mt-4 p-3 bg-white rounded">
                <h4 className="font-medium mb-2">Theme Schedule</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Morning (6AM-12PM)</span>
                    <span className="font-medium">Ocean Breeze</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Afternoon (12PM-6PM)</span>
                    <span className="font-medium">Focus</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Evening (6PM-10PM)</span>
                    <span className="font-medium">Warm Comfort</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Night (10PM-6AM)</span>
                    <span className="font-medium">Night Owl</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Tips */}
      <div className="mt-8 p-4 bg-blue-50 rounded-lg">
        <h3 className="font-medium mb-2">✨ Theme Tips</h3>
        <ul className="text-sm space-y-1">
          <li>• Themes can automatically adapt to your emotional state</li>
          <li>• Try "Sanctuary" when feeling stressed or overwhelmed</li>
          <li>• Use "Focus" for deep work and concentration</li>
          <li>• "Night Owl" reduces blue light for evening use</li>
          <li>• All themes meet WCAG accessibility standards</li>
        </ul>
      </div>
    </div>
  );
};