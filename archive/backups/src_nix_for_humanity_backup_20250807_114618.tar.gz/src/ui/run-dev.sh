#!/bin/bash

echo "🌟 Starting Nix for Humanity Onboarding UI Development Server..."
echo

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
  echo "📦 Installing dependencies..."
  npm install
  echo
fi

# Start the development server
echo "🚀 Starting Vite development server..."
echo "📍 Open http://localhost:5173 in your browser"
echo
npm run dev