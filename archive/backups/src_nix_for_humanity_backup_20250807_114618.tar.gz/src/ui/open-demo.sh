#!/bin/bash

echo "🌟 Opening Nix for Humanity Onboarding Demo..."
echo

# Get the full path to the HTML file
DEMO_FILE="$(pwd)/onboarding-demo.html"

echo "📍 Demo file: $DEMO_FILE"
echo

# Try different ways to open the file
if command -v xdg-open > /dev/null; then
    echo "Opening with xdg-open..."
    xdg-open "$DEMO_FILE"
elif command -v open > /dev/null; then
    echo "Opening with open..."
    open "$DEMO_FILE"
elif command -v firefox > /dev/null; then
    echo "Opening with Firefox..."
    firefox "$DEMO_FILE"
elif command -v chromium > /dev/null; then
    echo "Opening with Chromium..."
    chromium "$DEMO_FILE"
else
    echo "❌ No browser found. Please open this file manually:"
    echo "   $DEMO_FILE"
fi

echo
echo "✨ The demo should now be open in your browser!"
echo "🔄 To reset and try again, clear your browser's localStorage."