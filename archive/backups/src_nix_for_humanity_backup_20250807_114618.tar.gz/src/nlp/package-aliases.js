/**
 * Package Name Intelligence
 * Maps common names to actual NixOS package names
 */

class PackageAliases {
  constructor() {
    // Common package aliases
    this.aliases = {
      // Browsers
      'chrome': { 
        correct: 'google-chrome', 
        alternatives: ['chromium', 'ungoogled-chromium'],
        category: 'browser'
      },
      'firefox': {
        correct: 'firefox',
        alternatives: ['firefox-esr', 'firefox-bin', 'firefox-wayland'],
        category: 'browser'
      },
      
      // Editors
      'code': {
        correct: 'vscode',
        alternatives: ['vscodium', 'code-server'],
        category: 'editor'
      },
      'vscode': {
        correct: 'vscode',
        alternatives: ['vscodium', 'code-server'],
        category: 'editor'
      },
      'sublime': {
        correct: 'sublime4',
        alternatives: ['sublime3', 'sublime-merge'],
        category: 'editor'
      },
      
      // Development
      'python': {
        correct: 'python3',
        alternatives: ['python311', 'python312', 'python310', 'python3Full'],
        category: 'language'
      },
      'python3': {
        correct: 'python311',  // Current stable
        alternatives: ['python312', 'python310', 'python39'],
        category: 'language'
      },
      'node': {
        correct: 'nodejs',
        alternatives: ['nodejs_20', 'nodejs_18', 'nodejs-slim'],
        category: 'language'
      },
      'nodejs': {
        correct: 'nodejs_20',  // Current LTS
        alternatives: ['nodejs_18', 'nodejs_21', 'nodejs-slim'],
        category: 'language'
      },
      'java': {
        correct: 'jdk',
        alternatives: ['jdk17', 'jdk11', 'jdk8', 'openjdk'],
        category: 'language'
      },
      
      // Databases
      'postgres': {
        correct: 'postgresql',
        alternatives: ['postgresql_15', 'postgresql_14', 'postgresql_13'],
        category: 'database'
      },
      'mysql': {
        correct: 'mysql80',
        alternatives: ['mariadb', 'mysql57'],
        category: 'database'
      },
      'mongo': {
        correct: 'mongodb',
        alternatives: ['mongodb-4_4', 'mongodb-5_0'],
        category: 'database'
      },
      
      // Containers
      'docker': {
        correct: 'docker',
        alternatives: ['podman', 'docker-compose'],
        category: 'container'
      },
      
      // Communication
      'slack': {
        correct: 'slack',
        alternatives: ['signal-desktop', 'discord', 'teams'],
        category: 'communication'
      },
      'zoom': {
        correct: 'zoom-us',
        alternatives: ['teams', 'jitsi-meet'],
        category: 'communication'
      },
      
      // System tools
      'htop': {
        correct: 'htop',
        alternatives: ['btop', 'gtop', 'bottom'],
        category: 'monitoring'
      },
      'neofetch': {
        correct: 'neofetch',
        alternatives: ['fastfetch', 'screenfetch'],
        category: 'system-info'
      },
      
      // Media
      'vlc': {
        correct: 'vlc',
        alternatives: ['mpv', 'mplayer'],
        category: 'media-player'
      },
      'spotify': {
        correct: 'spotify',
        alternatives: ['spotify-tui', 'ncspot'],
        category: 'music'
      }
    };

    // Category mappings for "install a [category]"
    this.categories = {
      'browser': ['firefox', 'chromium', 'brave', 'vivaldi'],
      'web browser': ['firefox', 'chromium', 'brave', 'vivaldi'],
      'editor': ['vim', 'neovim', 'emacs', 'nano', 'vscode'],
      'text editor': ['vim', 'neovim', 'emacs', 'nano', 'vscode'],
      'ide': ['vscode', 'idea-ultimate', 'eclipse', 'netbeans'],
      'terminal': ['alacritty', 'kitty', 'wezterm', 'foot'],
      'shell': ['zsh', 'fish', 'bash', 'nushell'],
      'music player': ['spotify', 'rhythmbox', 'clementine', 'mpd'],
      'video player': ['vlc', 'mpv', 'mplayer', 'celluloid'],
      'image editor': ['gimp', 'krita', 'inkscape', 'darktable'],
      'database': ['postgresql', 'mysql80', 'mongodb', 'redis'],
      'programming language': ['python3', 'nodejs', 'rustc', 'go', 'gcc']
    };

    // Build reverse lookup for package to category
    this.packageToCategory = {};
    for (const [category, packages] of Object.entries(this.categories)) {
      for (const pkg of packages) {
        this.packageToCategory[pkg] = category;
      }
    }
  }

  /**
   * Check if input has a known alias
   */
  checkAlias(packageName) {
    const normalized = packageName.toLowerCase().trim();
    
    if (this.aliases[normalized]) {
      return {
        isAlias: true,
        correct: this.aliases[normalized].correct,
        alternatives: this.aliases[normalized].alternatives,
        category: this.aliases[normalized].category
      };
    }
    
    return null;
  }

  /**
   * Resolve package name to correct NixOS name
   */
  resolvePackageName(input) {
    const normalized = input.toLowerCase().trim();
    
    // Check direct aliases
    const alias = this.checkAlias(normalized);
    if (alias) {
      return {
        resolved: alias.correct,
        confidence: 0.95,
        alternatives: alias.alternatives,
        reason: `"${input}" typically refers to ${alias.correct} in NixOS`
      };
    }
    
    // Check if it's already a valid package name
    if (this.isLikelyValidPackage(normalized)) {
      return {
        resolved: normalized,
        confidence: 0.8,
        reason: 'Appears to be a valid package name'
      };
    }
    
    // Try fuzzy matching against known packages
    const fuzzyMatch = this.fuzzyMatchPackage(normalized);
    if (fuzzyMatch) {
      return {
        resolved: fuzzyMatch.package,
        confidence: fuzzyMatch.confidence,
        alternatives: fuzzyMatch.alternatives,
        reason: fuzzyMatch.reason
      };
    }
    
    return {
      resolved: normalized,
      confidence: 0.3,
      reason: 'Unknown package, will try as-is'
    };
  }

  /**
   * Handle category requests like "install a browser"
   */
  resolveCategoryRequest(input) {
    const normalized = input.toLowerCase();
    
    for (const [category, packages] of Object.entries(this.categories)) {
      if (normalized.includes(category)) {
        return {
          isCategory: true,
          category: category,
          suggestions: packages.slice(0, 5),
          message: `Here are some ${category} options:`,
          fullList: packages
        };
      }
    }
    
    return null;
  }

  /**
   * Get package suggestions based on intent
   */
  getPackageSuggestions(intent, context = {}) {
    const suggestions = [];
    
    if (intent === 'development') {
      suggestions.push(...[
        { package: 'git', reason: 'Version control' },
        { package: 'vscode', reason: 'Popular editor' },
        { package: 'nodejs', reason: 'JavaScript runtime' },
        { package: 'python3', reason: 'Python programming' }
      ]);
    }
    
    if (intent === 'new-user') {
      suggestions.push(...[
        { package: 'firefox', reason: 'Web browser' },
        { package: 'thunderbird', reason: 'Email client' },
        { package: 'libreoffice', reason: 'Office suite' },
        { package: 'vlc', reason: 'Media player' }
      ]);
    }
    
    if (context.previousError && context.previousError.includes('not found')) {
      // Suggest based on what they might have meant
      const pkg = this.extractPackageFromError(context.previousError);
      const alias = this.checkAlias(pkg);
      if (alias) {
        suggestions.push({
          package: alias.correct,
          reason: `Did you mean ${alias.correct}?`,
          alternatives: alias.alternatives
        });
      }
    }
    
    return suggestions;
  }

  /**
   * Check if a package name looks valid
   */
  isLikelyValidPackage(name) {
    // NixOS packages typically use lowercase, hyphens, numbers
    return /^[a-z0-9][a-z0-9-_]*[a-z0-9]$/.test(name) && 
           name.length > 1 && 
           name.length < 50;
  }

  /**
   * Fuzzy match against known packages
   */
  fuzzyMatchPackage(input) {
    // Simple fuzzy matching against our alias keys
    const allPackages = Object.keys(this.aliases);
    
    for (const pkg of allPackages) {
      if (pkg.includes(input) || input.includes(pkg)) {
        const alias = this.aliases[pkg];
        return {
          package: alias.correct,
          confidence: 0.7,
          alternatives: alias.alternatives,
          reason: `Partial match with ${pkg}`
        };
      }
    }
    
    return null;
  }

  /**
   * Extract package name from error message
   */
  extractPackageFromError(error) {
    const patterns = [
      /attribute ['"]?(\w+)['"]? missing/,
      /package ['"]?(\w+)['"]? not found/,
      /unknown package ['"]?(\w+)['"]?/
    ];
    
    for (const pattern of patterns) {
      const match = error.match(pattern);
      if (match) {
        return match[1];
      }
    }
    
    return null;
  }

  /**
   * Get version recommendations
   */
  getVersionRecommendation(packageBase) {
    const versionedPackages = {
      'python': { 
        stable: 'python311', 
        latest: 'python312',
        lts: 'python310'
      },
      'nodejs': {
        stable: 'nodejs_20',
        latest: 'nodejs_21',
        lts: 'nodejs_18'
      },
      'postgresql': {
        stable: 'postgresql_15',
        latest: 'postgresql_16',
        lts: 'postgresql_14'
      }
    };
    
    return versionedPackages[packageBase] || null;
  }
}

module.exports = PackageAliases;