/**
 * Fuzzy Matching for Typo Tolerance
 * Handles common misspellings and typos
 */

class FuzzyMatcher {
  constructor() {
    // Common commands and their variations
    this.commands = {
      'install': ['instal', 'instll', 'intall', 'insatll', 'isntall'],
      'remove': ['remov', 'rmove', 'reomve', 'uninstal'],
      'update': ['updat', 'updae', 'upgarde', 'upgade'],
      'search': ['serach', 'seach', 'sarch', 'searh'],
      'system': ['systm', 'sytem', 'ssytem', 'sysem'],
      'firefox': ['firfox', 'firefx', 'fireox', 'friefox'],
      'chrome': ['chorme', 'chrme', 'crome', 'chrom'],
      'wifi': ['wfi', 'wify', 'wi-fi', 'wii-fi'],
      'running': ['runing', 'runnign', 'runinng', 'runnin']
    };

    // Build reverse lookup
    this.typoMap = new Map();
    for (const [correct, typos] of Object.entries(this.commands)) {
      for (const typo of typos) {
        this.typoMap.set(typo, correct);
      }
    }
  }

  /**
   * Calculate Levenshtein distance between two strings
   */
  levenshteinDistance(str1, str2) {
    const m = str1.length;
    const n = str2.length;
    const dp = Array(m + 1).fill(null).map(() => Array(n + 1).fill(0));

    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;

    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        if (str1[i - 1] === str2[j - 1]) {
          dp[i][j] = dp[i - 1][j - 1];
        } else {
          dp[i][j] = Math.min(
            dp[i - 1][j] + 1,    // deletion
            dp[i][j - 1] + 1,    // insertion
            dp[i - 1][j - 1] + 1 // substitution
          );
        }
      }
    }

    return dp[m][n];
  }

  /**
   * Find the closest matching word
   */
  findClosestWord(word, candidates, threshold = 2) {
    word = word.toLowerCase();
    
    // Check direct typo map first
    if (this.typoMap.has(word)) {
      return {
        word: this.typoMap.get(word),
        distance: 1,
        confidence: 0.9
      };
    }

    // Find closest match using Levenshtein distance
    let bestMatch = null;
    let minDistance = Infinity;

    for (const candidate of candidates) {
      const distance = this.levenshteinDistance(word, candidate.toLowerCase());
      if (distance < minDistance && distance <= threshold) {
        minDistance = distance;
        bestMatch = candidate;
      }
    }

    if (bestMatch) {
      return {
        word: bestMatch,
        distance: minDistance,
        confidence: 1 - (minDistance / Math.max(word.length, bestMatch.length))
      };
    }

    return null;
  }

  /**
   * Correct typos in the input string
   */
  correctTypos(input) {
    const words = input.toLowerCase().split(/\s+/);
    const corrected = [];
    let corrections = [];

    // Common command words to check against
    const commandWords = [
      'install', 'remove', 'uninstall', 'update', 'upgrade',
      'search', 'find', 'list', 'show', 'start', 'stop',
      'enable', 'disable', 'status', 'running', 'system',
      'wifi', 'internet', 'network', 'firefox', 'chrome'
    ];

    for (const word of words) {
      // Skip short words (likely articles)
      if (word.length <= 2) {
        corrected.push(word);
        continue;
      }

      const match = this.findClosestWord(word, commandWords);
      if (match && match.confidence > 0.7) {
        corrected.push(match.word);
        if (match.distance > 0) {
          corrections.push({ from: word, to: match.word });
        }
      } else {
        corrected.push(word);
      }
    }

    return {
      corrected: corrected.join(' '),
      corrections: corrections,
      hadCorrections: corrections.length > 0
    };
  }

  /**
   * Suggest corrections for failed commands
   */
  suggestCorrection(input, error) {
    const result = this.correctTypos(input);
    
    if (result.hadCorrections) {
      const correctionText = result.corrections
        .map(c => `"${c.from}" → "${c.to}"`)
        .join(', ');
      
      return {
        suggestion: `Did you mean: "${result.corrected}"?`,
        corrections: correctionText,
        correctedInput: result.corrected
      };
    }

    // If no typos found, try other suggestions
    if (error && error.includes('not found')) {
      return this.suggestAlternativePackage(input);
    }

    return null;
  }

  /**
   * Suggest alternative package names
   */
  suggestAlternativePackage(input) {
    const packageAliases = {
      'chrome': 'google-chrome or chromium',
      'code': 'vscode or vscodium',
      'docker': 'docker or podman',
      'node': 'nodejs or nodejs_20',
      'python': 'python3 or python311'
    };

    for (const [alias, suggestion] of Object.entries(packageAliases)) {
      if (input.includes(alias)) {
        return {
          suggestion: `Package not found. Try: ${suggestion}`,
          alternatives: suggestion.split(' or ')
        };
      }
    }

    return null;
  }
}

module.exports = FuzzyMatcher;