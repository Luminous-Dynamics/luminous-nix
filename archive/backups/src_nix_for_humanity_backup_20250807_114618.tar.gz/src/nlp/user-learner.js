/**
 * User Learning System
 * Learns and adapts to individual user preferences
 */

const fs = require('fs').promises;
const path = require('path');
const os = require('os');

class UserLearner {
  constructor() {
    this.dataDir = path.join(os.homedir(), '.nix-humanity');
    this.dataFile = path.join(this.dataDir, 'user-patterns.json');
    
    // User patterns to track
    this.patterns = {
      packagePreferences: new Map(),      // firefox vs firefox-esr
      installationMethods: new Map(),     // nix-env vs configuration.nix
      commonCommands: [],                 // Frequently used commands
      vocabulary: new Map(),              // User's way of saying things
      schedule: {                         // When they do certain tasks
        updates: [],
        maintenance: []
      },
      corrections: new Map(),             // Learn from corrections
      sessionPatterns: {                  // How they work
        averageSessionLength: 0,
        commonWorkflows: []
      }
    };
    
    this.initialized = false;
  }

  /**
   * Initialize the learning system
   */
  async initialize() {
    try {
      // Create data directory if it doesn't exist
      await fs.mkdir(this.dataDir, { recursive: true });
      
      // Load existing patterns
      await this.loadPatterns();
      
      this.initialized = true;
    } catch (error) {
      console.error('Failed to initialize user learner:', error);
      // Continue without persistence
      this.initialized = true;
    }
  }

  /**
   * Load saved patterns
   */
  async loadPatterns() {
    try {
      const data = await fs.readFile(this.dataFile, 'utf8');
      const saved = JSON.parse(data);
      
      // Restore patterns
      this.patterns.packagePreferences = new Map(saved.packagePreferences || []);
      this.patterns.installationMethods = new Map(saved.installationMethods || []);
      this.patterns.commonCommands = saved.commonCommands || [];
      this.patterns.vocabulary = new Map(saved.vocabulary || []);
      this.patterns.schedule = saved.schedule || { updates: [], maintenance: [] };
      this.patterns.corrections = new Map(saved.corrections || []);
      this.patterns.sessionPatterns = saved.sessionPatterns || {
        averageSessionLength: 0,
        commonWorkflows: []
      };
    } catch (error) {
      // File doesn't exist yet, start fresh
    }
  }

  /**
   * Save patterns to disk
   */
  async savePatterns() {
    if (!this.initialized) return;
    
    try {
      const data = {
        packagePreferences: Array.from(this.patterns.packagePreferences),
        installationMethods: Array.from(this.patterns.installationMethods),
        commonCommands: this.patterns.commonCommands.slice(-100), // Keep last 100
        vocabulary: Array.from(this.patterns.vocabulary),
        schedule: this.patterns.schedule,
        corrections: Array.from(this.patterns.corrections),
        sessionPatterns: this.patterns.sessionPatterns,
        lastUpdated: new Date().toISOString()
      };
      
      await fs.writeFile(this.dataFile, JSON.stringify(data, null, 2));
    } catch (error) {
      console.error('Failed to save user patterns:', error);
    }
  }

  /**
   * Learn from a successful interaction
   */
  async learnFromInteraction(interaction) {
    const { input, intent, result, timestamp = Date.now() } = interaction;
    
    // Learn package preferences
    if (intent.includes('package.install') && result.success) {
      this.learnPackagePreference(result.package, timestamp);
    }
    
    // Learn vocabulary
    this.learnVocabulary(input, intent);
    
    // Learn command patterns
    this.learnCommandPattern(input, intent, timestamp);
    
    // Learn schedule patterns
    this.learnSchedulePattern(intent, timestamp);
    
    // Save periodically
    if (Math.random() < 0.1) { // 10% chance to save
      await this.savePatterns();
    }
  }

  /**
   * Learn from corrections
   */
  async learnFromCorrection(original, corrected, accepted) {
    const key = original.toLowerCase();
    const current = this.patterns.corrections.get(key) || {
      corrections: [],
      accepted: 0,
      rejected: 0
    };
    
    current.corrections.push({
      corrected,
      accepted,
      timestamp: Date.now()
    });
    
    if (accepted) {
      current.accepted++;
    } else {
      current.rejected++;
    }
    
    this.patterns.corrections.set(key, current);
    
    // If user consistently accepts a correction, add to vocabulary
    if (current.accepted > 2 && current.accepted > current.rejected * 2) {
      this.patterns.vocabulary.set(original, corrected);
    }
    
    await this.savePatterns();
  }

  /**
   * Learn package preferences
   */
  learnPackagePreference(packageName, timestamp) {
    const baseName = this.getBasePackageName(packageName);
    const current = this.patterns.packagePreferences.get(baseName) || {
      variants: {},
      lastUsed: null
    };
    
    // Track which variant they use
    current.variants[packageName] = (current.variants[packageName] || 0) + 1;
    current.lastUsed = packageName;
    current.lastTimestamp = timestamp;
    
    this.patterns.packagePreferences.set(baseName, current);
  }

  /**
   * Learn vocabulary patterns
   */
  learnVocabulary(input, intent) {
    const words = input.toLowerCase().split(/\s+/);
    
    // Learn action words
    if (intent.includes('install')) {
      const installWords = ['install', 'add', 'get', 'setup'];
      const usedWord = words.find(w => 
        ['install', 'add', 'get', 'setup', 'grab', 'need', 'want'].includes(w)
      );
      
      if (usedWord && !installWords.includes(usedWord)) {
        this.patterns.vocabulary.set(usedWord, 'install');
      }
    }
  }

  /**
   * Learn command patterns
   */
  learnCommandPattern(input, intent, timestamp) {
    // Track frequently used commands
    this.patterns.commonCommands.push({
      input,
      intent,
      timestamp,
      dayOfWeek: new Date(timestamp).getDay(),
      hourOfDay: new Date(timestamp).getHours()
    });
    
    // Keep only recent commands
    if (this.patterns.commonCommands.length > 200) {
      this.patterns.commonCommands = this.patterns.commonCommands.slice(-100);
    }
  }

  /**
   * Learn schedule patterns
   */
  learnSchedulePattern(intent, timestamp) {
    const date = new Date(timestamp);
    const pattern = {
      intent,
      dayOfWeek: date.getDay(),
      hourOfDay: date.getHours(),
      timestamp
    };
    
    if (intent.includes('update')) {
      this.patterns.schedule.updates.push(pattern);
      // Keep last 20 updates
      if (this.patterns.schedule.updates.length > 20) {
        this.patterns.schedule.updates.shift();
      }
    }
    
    if (intent.includes('gc') || intent.includes('clean')) {
      this.patterns.schedule.maintenance.push(pattern);
      // Keep last 20 maintenance tasks
      if (this.patterns.schedule.maintenance.length > 20) {
        this.patterns.schedule.maintenance.shift();
      }
    }
  }

  /**
   * Get user preferences for a package
   */
  getPackagePreference(packageName) {
    const baseName = this.getBasePackageName(packageName);
    const pref = this.patterns.packagePreferences.get(baseName);
    
    if (!pref) return null;
    
    // Find most used variant
    const variants = Object.entries(pref.variants);
    if (variants.length === 0) return null;
    
    const mostUsed = variants.reduce((a, b) => a[1] > b[1] ? a : b);
    
    return {
      preferred: mostUsed[0],
      confidence: mostUsed[1] / variants.reduce((sum, [_, count]) => sum + count, 0),
      lastUsed: pref.lastUsed,
      allVariants: Object.keys(pref.variants)
    };
  }

  /**
   * Get vocabulary preference
   */
  getVocabularyPreference(word) {
    return this.patterns.vocabulary.get(word.toLowerCase());
  }

  /**
   * Predict next action based on patterns
   */
  predictNextAction() {
    const now = new Date();
    const currentHour = now.getHours();
    const currentDay = now.getDay();
    
    // Check if it's typical update time
    const updateTimes = this.patterns.schedule.updates
      .filter(u => Math.abs(u.hourOfDay - currentHour) <= 1 && u.dayOfWeek === currentDay);
    
    if (updateTimes.length >= 3) {
      return {
        suggestion: 'Based on your patterns, you usually update your system around this time.',
        action: 'update system',
        confidence: updateTimes.length / this.patterns.schedule.updates.length
      };
    }
    
    // Check common workflows
    const recentCommands = this.patterns.commonCommands.slice(-5);
    const workflow = this.detectWorkflow(recentCommands);
    
    if (workflow) {
      return {
        suggestion: `Continue with your ${workflow.name} workflow?`,
        action: workflow.nextAction,
        confidence: workflow.confidence
      };
    }
    
    return null;
  }

  /**
   * Get personalized suggestions
   */
  getPersonalizedSuggestions(context) {
    const suggestions = [];
    
    // Suggest based on time patterns
    const timeSuggestion = this.predictNextAction();
    if (timeSuggestion && timeSuggestion.confidence > 0.7) {
      suggestions.push(timeSuggestion);
    }
    
    // Suggest frequently used commands
    const frequent = this.getMostFrequentCommands(5);
    if (frequent.length > 0) {
      suggestions.push({
        suggestion: 'Your frequently used commands:',
        actions: frequent,
        type: 'frequent'
      });
    }
    
    // Suggest based on vocabulary
    if (context.input) {
      const corrected = this.applyCorrectionLearning(context.input);
      if (corrected !== context.input) {
        suggestions.push({
          suggestion: `Did you mean: "${corrected}"?`,
          action: corrected,
          type: 'correction'
        });
      }
    }
    
    return suggestions;
  }

  /**
   * Apply learned corrections
   */
  applyCorrectionLearning(input) {
    const words = input.split(/\s+/);
    const corrected = words.map(word => {
      const correction = this.patterns.corrections.get(word.toLowerCase());
      if (correction && correction.accepted > correction.rejected) {
        // Use the most recent accepted correction
        const accepted = correction.corrections
          .filter(c => c.accepted)
          .pop();
        return accepted ? accepted.corrected : word;
      }
      return this.patterns.vocabulary.get(word.toLowerCase()) || word;
    });
    
    return corrected.join(' ');
  }

  /**
   * Helper methods
   */
  getBasePackageName(packageName) {
    // Extract base name (e.g., "firefox" from "firefox-esr")
    return packageName.split(/[-_]/)[0];
  }

  getMostFrequentCommands(limit = 5) {
    const frequency = {};
    
    for (const cmd of this.patterns.commonCommands) {
      const key = cmd.intent;
      frequency[key] = (frequency[key] || 0) + 1;
    }
    
    return Object.entries(frequency)
      .sort(([, a], [, b]) => b - a)
      .slice(0, limit)
      .map(([intent, count]) => ({
        intent,
        count,
        percentage: count / this.patterns.commonCommands.length
      }));
  }

  detectWorkflow(recentCommands) {
    // Detect common workflows
    const workflows = {
      'development-setup': ['package.search', 'package.install', 'service.start'],
      'system-maintenance': ['system.update', 'system.gc', 'package.list'],
      'troubleshooting': ['service.status', 'service.restart', 'system.info']
    };
    
    for (const [name, pattern] of Object.entries(workflows)) {
      const recentIntents = recentCommands.map(c => c.intent);
      let matches = 0;
      
      for (let i = 0; i < Math.min(pattern.length, recentIntents.length); i++) {
        if (pattern[i] === recentIntents[i]) {
          matches++;
        }
      }
      
      if (matches >= 2 && matches < pattern.length) {
        return {
          name,
          nextAction: pattern[matches],
          confidence: matches / pattern.length
        };
      }
    }
    
    return null;
  }

  /**
   * Export user data (for privacy)
   */
  async exportUserData() {
    return {
      patterns: this.patterns,
      dataLocation: this.dataFile,
      exportDate: new Date().toISOString()
    };
  }

  /**
   * Clear all learned data
   */
  async clearAllData() {
    this.patterns = {
      packagePreferences: new Map(),
      installationMethods: new Map(),
      commonCommands: [],
      vocabulary: new Map(),
      schedule: { updates: [], maintenance: [] },
      corrections: new Map(),
      sessionPatterns: { averageSessionLength: 0, commonWorkflows: [] }
    };
    
    try {
      await fs.unlink(this.dataFile);
    } catch (error) {
      // File might not exist
    }
  }
}

module.exports = UserLearner;