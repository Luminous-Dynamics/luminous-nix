/**
 * Enhanced NLP Engine - Integrating All Improvements
 * Combines all NLP capabilities into one powerful engine
 */

const { patterns, matchPattern } = require('./quick-start-patterns');
const FuzzyMatcher = require('./fuzzy-matcher');
const ContextTracker = require('./context-tracker');
const ErrorRecovery = require('./error-recovery');
const PackageAliases = require('./package-aliases');
const UserLearner = require('./user-learner');

class EnhancedNLPEngine {
  constructor() {
    // Initialize all components
    this.fuzzyMatcher = new FuzzyMatcher();
    this.contextTracker = new ContextTracker();
    this.packageAliases = new PackageAliases();
    this.userLearner = new UserLearner();
    this.errorRecovery = new ErrorRecovery(this.fuzzyMatcher, this.packageAliases);
    
    // Initialize async components
    this.initialized = false;
    this.initPromise = this.initialize();
  }

  async initialize() {
    await this.userLearner.initialize();
    this.initialized = true;
  }

  async ensureInitialized() {
    if (!this.initialized) {
      await this.initPromise;
    }
  }

  /**
   * Process natural language input with all enhancements
   */
  async processInput(input) {
    await this.ensureInitialized();
    
    // 1. Check context for references like "it", "that", "the first one"
    const contextResolution = this.contextTracker.resolveReference(input);
    let processedInput = input;
    
    if (contextResolution) {
      processedInput = contextResolution.resolved;
      console.log(`🔄 Resolved reference: "${input}" → "${processedInput}"`);
    }
    
    // 2. Apply user's learned vocabulary preferences
    processedInput = this.userLearner.applyCorrectionLearning(processedInput);
    
    // 3. Correct typos using fuzzy matching
    const typoCorrection = this.fuzzyMatcher.correctTypos(processedInput);
    if (typoCorrection.hadCorrections) {
      console.log(`✏️  Corrected typos: ${typoCorrection.corrections.map(c => `"${c.from}" → "${c.to}"`).join(', ')}`);
      processedInput = typoCorrection.corrected;
    }
    
    // 4. Try pattern matching
    let result = matchPattern(processedInput);
    
    // 5. If no match, check for category requests
    if (!result) {
      const categoryResult = this.packageAliases.resolveCategoryRequest(processedInput);
      if (categoryResult) {
        return {
          type: 'category_request',
          ...categoryResult
        };
      }
    }
    
    // 6. Enhance result with package resolution
    if (result && result.entities && result.entities.package) {
      const packageResolution = this.packageAliases.resolvePackageName(result.entities.package);
      
      // Check user preferences
      const userPref = this.userLearner.getPackagePreference(packageResolution.resolved);
      if (userPref && userPref.confidence > 0.7) {
        packageResolution.resolved = userPref.preferred;
        packageResolution.reason = 'Based on your preferences';
      }
      
      result.entities.package = packageResolution.resolved;
      result.packageInfo = packageResolution;
    }
    
    // 7. Get personalized suggestions
    const suggestions = this.userLearner.getPersonalizedSuggestions({
      input: processedInput,
      intent: result?.intent
    });
    
    if (suggestions.length > 0) {
      result = result || {};
      result.suggestions = suggestions;
    }
    
    return {
      original: input,
      processed: processedInput,
      result: result,
      hadCorrections: typoCorrection.hadCorrections || contextResolution !== null,
      contextSuggestions: this.contextTracker.getSuggestions()
    };
  }

  /**
   * Handle command execution result
   */
  async handleExecutionResult(input, intent, result) {
    // Track in context
    this.contextTracker.addInteraction(input, intent, result);
    
    // Learn from successful interactions
    if (result.success) {
      await this.userLearner.learnFromInteraction({
        input,
        intent,
        result,
        timestamp: Date.now()
      });
    } else {
      // Enhanced error recovery
      const errorAnalysis = await this.errorRecovery.analyzeError(
        result.error || result.message,
        input,
        intent
      );
      
      return {
        ...result,
        errorAnalysis,
        recovery: this.generateRecoverySuggestions(errorAnalysis)
      };
    }
    
    return result;
  }

  /**
   * Generate recovery suggestions based on error analysis
   */
  generateRecoverySuggestions(errorAnalysis) {
    const suggestions = [];
    
    switch (errorAnalysis.type) {
      case 'typo_correction':
        suggestions.push({
          action: 'retry',
          command: errorAnalysis.correctedInput,
          message: 'Let me try that with the corrected spelling'
        });
        break;
        
      case 'package_alias':
        suggestions.push({
          action: 'install',
          package: errorAnalysis.suggestion.split('"')[3], // Extract from "Try: "install package""
          message: `Installing ${errorAnalysis.alternatives[0]} instead`
        });
        break;
        
      case 'similar_packages':
        errorAnalysis.suggestions.forEach(pkg => {
          suggestions.push({
            action: 'search_install',
            package: pkg,
            message: `Search for ${pkg} and install if it matches`
          });
        });
        break;
        
      case 'permission_error':
        suggestions.push({
          action: 'elevate',
          message: 'Retrying with elevated permissions'
        });
        break;
        
      case 'network_error':
        suggestions.push({
          action: 'diagnose_network',
          message: 'Let me check your network connection'
        });
        break;
    }
    
    return suggestions;
  }

  /**
   * Handle user feedback on corrections
   */
  async handleCorrectionFeedback(original, corrected, accepted) {
    await this.userLearner.learnFromCorrection(original, corrected, accepted);
  }

  /**
   * Get current context state
   */
  getContextState() {
    return {
      history: this.contextTracker.history,
      lastSearch: this.contextTracker.lastSearchResults,
      suggestions: this.contextTracker.getSuggestions(),
      userPreferences: {
        commonCommands: this.userLearner.getMostFrequentCommands(5),
        nextAction: this.userLearner.predictNextAction()
      }
    };
  }

  /**
   * Export user data for privacy
   */
  async exportUserData() {
    return await this.userLearner.exportUserData();
  }

  /**
   * Clear all learned data
   */
  async clearUserData() {
    await this.userLearner.clearAllData();
    this.contextTracker.resetContext();
  }
}

module.exports = EnhancedNLPEngine;