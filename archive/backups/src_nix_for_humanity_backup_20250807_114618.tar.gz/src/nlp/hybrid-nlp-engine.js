/**
 * Hybrid NLP Engine for Nix for Humanity
 * Combines rules, statistics, and learning for optimal performance
 */

class HybridNLPEngine {
  constructor() {
    // Layer 1: Rule-based patterns (immediate)
    this.rules = new RuleEngine();
    
    // Layer 2: Statistical matching (quick to add)
    this.fuzzy = new FuzzyMatcher();
    
    // Layer 3: User learning (gradual improvement)
    this.learner = new UserLearner();
    
    // Context tracking
    this.context = new ContextTracker();
  }

  async understand(input) {
    // 1. Check learned patterns first (fastest)
    const learned = this.learner.recall(input);
    if (learned && learned.confidence > 0.9) {
      return learned;
    }
    
    // 2. Try rule-based matching (reliable)
    const ruleMatch = this.rules.match(input);
    if (ruleMatch && ruleMatch.confidence > 0.8) {
      this.learner.observe(input, ruleMatch); // Learn for next time
      return ruleMatch;
    }
    
    // 3. Fall back to fuzzy matching (flexible)
    const fuzzyMatch = await this.fuzzy.findBest(input);
    if (fuzzyMatch && fuzzyMatch.score > 0.7) {
      // Ask for confirmation on fuzzy matches
      fuzzyMatch.needsConfirmation = true;
      return fuzzyMatch;
    }
    
    // 4. Use context to guess
    const contextGuess = this.context.predictFromHistory(input);
    if (contextGuess) {
      contextGuess.confidence = 0.5;
      contextGuess.needsConfirmation = true;
      return contextGuess;
    }
    
    // 5. Admit we don't understand
    return {
      intent: 'unknown',
      confidence: 0,
      suggestions: this.getSuggestions(input)
    };
  }
}

// Layer 1: Rule Engine (Start Here!)
class RuleEngine {
  constructor() {
    this.patterns = {
      // Package Management
      install: {
        patterns: [
          /^(?:install|add|get|setup|download)\s+(.+)$/i,
          /^i (?:need|want|require)\s+(?:to install\s+)?(.+)$/i,
          /^(?:can you |please )?(?:install|add|get)\s+(.+?)(?:\s+for me)?$/i,
          /^(.+)\s+(?:is missing|not installed|isn't installed)$/i
        ],
        handler: 'package.install'
      },
      
      // System Management  
      update: {
        patterns: [
          /^(?:update|upgrade)(?:\s+(?:my\s+)?system)?$/i,
          /^(?:run|do)\s+(?:system\s+)?updates?$/i,
          /^keep (?:everything|system) (?:updated?|current)$/i
        ],
        handler: 'system.update'
      },
      
      // Network
      wifi: {
        patterns: [
          /^(?:connect to |fix |setup |configure )?wifi$/i,
          /^(?:my )?(?:wifi|internet|network)\s+(?:is not|isn't|stopped)?\s*working$/i,
          /^(?:no|lost)\s+(?:internet|wifi|connection)$/i
        ],
        handler: 'network.wifi'
      },
      
      // Services
      service: {
        patterns: [
          /^(?:start|stop|restart|check)\s+(.+?)(?:\s+service)?$/i,
          /^is\s+(.+?)\s+running\??$/i,
          /^(?:enable|disable)\s+(.+?)(?:\s+service)?$/i
        ],
        handler: 'service.manage'
      }
    };
  }
  
  match(input) {
    const normalized = input.toLowerCase().trim();
    
    for (const [intent, config] of Object.entries(this.patterns)) {
      for (const pattern of config.patterns) {
        const match = normalized.match(pattern);
        if (match) {
          return {
            intent: config.handler,
            confidence: 0.95,
            entities: this.extractEntities(match, intent),
            original: input
          };
        }
      }
    }
    
    return null;
  }
  
  extractEntities(match, intent) {
    // Smart entity extraction based on intent
    switch(intent) {
      case 'install':
      case 'remove':
        return { package: this.normalizePackageName(match[1]) };
      
      case 'service':
        return { service: match[1], action: match[0].split(' ')[0] };
        
      default:
        return {};
    }
  }
  
  normalizePackageName(raw) {
    // Common normalizations
    const aliases = {
      'fire fox': 'firefox',
      'vs code': 'vscode',
      'visual studio code': 'vscode',
      'chrome': 'google-chrome'
    };
    
    const normalized = raw.toLowerCase().trim();
    return aliases[normalized] || normalized;
  }
}

// Layer 2: Fuzzy Matcher (Add Week 3)
class FuzzyMatcher {
  constructor() {
    // Use a lightweight fuzzy matching library
    this.commands = [
      { intent: 'install', variations: ['install', 'add', 'get', 'download'] },
      { intent: 'remove', variations: ['remove', 'uninstall', 'delete'] },
      // ... more commands
    ];
  }
  
  async findBest(input) {
    // Implement fuzzy matching
    // Returns closest match with confidence score
  }
}

// Layer 3: User Learner (Add Month 2)
class UserLearner {
  constructor() {
    this.memory = new Map();
  }
  
  observe(input, result) {
    // Learn user's patterns
    const pattern = this.extractPattern(input);
    this.memory.set(pattern, result);
  }
  
  recall(input) {
    const pattern = this.extractPattern(input);
    return this.memory.get(pattern);
  }
}

// Context Tracking (Important!)
class ContextTracker {
  constructor() {
    this.history = [];
    this.lastCommand = null;
  }
  
  track(intent, result) {
    this.history.push({ intent, result, time: Date.now() });
    this.lastCommand = intent;
  }
  
  predictFromHistory(input) {
    // If user says "do it again" or "the same"
    if (/^(?:do it |the same|again|repeat)/.test(input)) {
      return this.lastCommand;
    }
    
    // If user references "that" or "it"
    if (/\b(?:that|it)\b/.test(input) && this.lastCommand) {
      // Try to apply new action to last entity
      return this.inferFromContext(input);
    }
    
    return null;
  }
}

module.exports = HybridNLPEngine;