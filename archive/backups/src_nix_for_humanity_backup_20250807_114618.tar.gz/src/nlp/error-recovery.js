/**
 * Enhanced Error Recovery with Specific Suggestions
 * Provides helpful, context-aware error messages
 */

class ErrorRecovery {
  constructor(fuzzyMatcher, packageAliases) {
    this.fuzzyMatcher = fuzzyMatcher;
    this.packageAliases = packageAliases;
    
    // Common error patterns and solutions
    this.errorPatterns = {
      'attribute .* missing': {
        type: 'package_not_found',
        handler: this.handlePackageNotFound.bind(this)
      },
      'collision between': {
        type: 'package_conflict',
        handler: this.handlePackageConflict.bind(this)
      },
      'permission denied': {
        type: 'permission_error',
        handler: this.handlePermissionError.bind(this)
      },
      'no such file or directory': {
        type: 'file_not_found',
        handler: this.handleFileNotFound.bind(this)
      },
      'command not found': {
        type: 'command_not_found',
        handler: this.handleCommandNotFound.bind(this)
      },
      'network': {
        type: 'network_error',
        handler: this.handleNetworkError.bind(this)
      },
      'failed to start': {
        type: 'service_failed',
        handler: this.handleServiceFailed.bind(this)
      }
    };
  }

  /**
   * Analyze error and provide helpful recovery suggestions
   */
  async analyzeError(error, originalInput, intent) {
    // First, try fuzzy matching for typos
    const fuzzyResult = this.fuzzyMatcher.suggestCorrection(originalInput, error);
    if (fuzzyResult) {
      return {
        type: 'typo_correction',
        message: fuzzyResult.suggestion,
        suggestion: `Try: "${fuzzyResult.correctedInput}"`,
        confidence: 0.9
      };
    }

    // Then check error patterns
    for (const [pattern, config] of Object.entries(this.errorPatterns)) {
      if (new RegExp(pattern, 'i').test(error)) {
        return await config.handler(error, originalInput, intent);
      }
    }

    // Generic error handling
    return this.handleGenericError(error, originalInput, intent);
  }

  /**
   * Handle package not found errors
   */
  async handlePackageNotFound(error, input, intent) {
    // Extract the package name that wasn't found
    const match = error.match(/attribute ['"]?(\w+)['"]? missing/i);
    const packageName = match ? match[1] : this.extractPackageFromInput(input);

    // Check if it's a known alias
    const alias = this.packageAliases.checkAlias(packageName);
    if (alias) {
      return {
        type: 'package_alias',
        message: `"${packageName}" isn't the exact package name.`,
        suggestion: `Try: "install ${alias.correct}"`,
        alternatives: alias.alternatives,
        confidence: 0.95
      };
    }

    // Search for similar packages
    const similar = await this.searchSimilarPackages(packageName);
    if (similar.length > 0) {
      return {
        type: 'similar_packages',
        message: `Couldn't find "${packageName}", but found similar packages:`,
        suggestions: similar.slice(0, 5),
        hint: 'Say "search [package]" to find the exact name',
        confidence: 0.8
      };
    }

    return {
      type: 'package_not_found',
      message: `Package "${packageName}" not found in nixpkgs.`,
      suggestion: 'Try searching first: "search [package type]"',
      hint: 'Package names in NixOS are sometimes different than expected',
      confidence: 0.7
    };
  }

  /**
   * Handle package conflict errors
   */
  handlePackageConflict(error, input, intent) {
    const packages = this.extractConflictingPackages(error);
    
    return {
      type: 'package_conflict',
      message: 'Multiple packages are trying to install the same file.',
      suggestion: 'You may need to choose one or use an overlay',
      conflicting: packages,
      solutions: [
        `Remove one: "remove ${packages[0]}"`,
        'Use nix-shell for temporary access',
        'Create a custom overlay (advanced)'
      ],
      confidence: 0.9
    };
  }

  /**
   * Handle permission errors
   */
  handlePermissionError(error, input, intent) {
    const needsSudo = intent.includes('system') || intent.includes('service');
    
    return {
      type: 'permission_error',
      message: needsSudo ? 
        'This operation requires administrator privileges.' :
        'You don\'t have permission to do this.',
      suggestion: needsSudo ?
        'I\'ll handle the permissions for you' :
        'Try with your user packages instead',
      solutions: [
        needsSudo ? 'Using sudo automatically...' : 'Use home-manager for user packages',
        'Check file ownership',
        'Verify your user groups'
      ],
      confidence: 0.95
    };
  }

  /**
   * Handle file not found errors
   */
  handleFileNotFound(error, input, intent) {
    return {
      type: 'file_not_found',
      message: 'The required file or directory doesn\'t exist.',
      suggestion: 'Let me check what\'s missing...',
      solutions: [
        'Creating missing directories',
        'Checking configuration paths',
        'Verifying service setup'
      ],
      confidence: 0.85
    };
  }

  /**
   * Handle command not found errors
   */
  handleCommandNotFound(error, input, intent) {
    const command = this.extractCommand(error);
    
    return {
      type: 'command_not_found',
      message: `The command "${command}" isn't available.`,
      suggestion: `Would you like me to install it?`,
      package: this.guessPackageForCommand(command),
      confidence: 0.8
    };
  }

  /**
   * Handle network errors
   */
  handleNetworkError(error, input, intent) {
    return {
      type: 'network_error',
      message: 'There seems to be a network issue.',
      suggestion: 'Let me help you troubleshoot',
      solutions: [
        'Check internet connection: "test network"',
        'Try using a different channel',
        'Use cached packages if available',
        'Check DNS settings'
      ],
      confidence: 0.85
    };
  }

  /**
   * Handle service failed to start
   */
  handleServiceFailed(error, input, intent) {
    const service = this.extractServiceName(error) || this.extractServiceFromInput(input);
    
    return {
      type: 'service_failed',
      message: `The service "${service}" failed to start.`,
      suggestion: 'Let me check the logs',
      diagnostic: `Checking: journalctl -u ${service}`,
      solutions: [
        'Check service configuration',
        'Verify dependencies are running',
        'Look for port conflicts',
        'Check service permissions'
      ],
      confidence: 0.9
    };
  }

  /**
   * Handle generic errors
   */
  handleGenericError(error, input, intent) {
    // Try to be helpful even with unknown errors
    const suggestions = [];
    
    if (intent.includes('package')) {
      suggestions.push('Try searching for the package first');
      suggestions.push('Check if the package name is correct');
    }
    
    if (intent.includes('service')) {
      suggestions.push('Check if the service is installed');
      suggestions.push('Verify the service name');
    }
    
    return {
      type: 'generic_error',
      message: 'Something went wrong with that command.',
      error: this.sanitizeError(error),
      suggestions: suggestions.length > 0 ? suggestions : [
        'Try rephrasing your request',
        'Use "help" to see examples',
        'Check the system logs'
      ],
      confidence: 0.5
    };
  }

  /**
   * Helper methods
   */
  extractPackageFromInput(input) {
    const words = input.split(/\s+/);
    // Look for package name after install/remove/search
    const actionIndex = words.findIndex(w => 
      ['install', 'remove', 'search', 'add', 'get'].includes(w.toLowerCase())
    );
    return actionIndex >= 0 && actionIndex < words.length - 1 ? 
      words[actionIndex + 1] : words[words.length - 1];
  }

  async searchSimilarPackages(packageName) {
    // In real implementation, this would search nixpkgs
    // For now, return common similar packages
    const similarPackages = {
      'firefox': ['firefox-esr', 'firefox-bin', 'firefox-wayland'],
      'chrome': ['google-chrome', 'chromium', 'ungoogled-chromium'],
      'python': ['python3', 'python311', 'python312', 'python3Full'],
      'node': ['nodejs', 'nodejs_20', 'nodejs_18', 'nodejs-slim'],
      'code': ['vscode', 'vscodium', 'code-server']
    };
    
    return similarPackages[packageName.toLowerCase()] || [];
  }

  extractConflictingPackages(error) {
    // Extract package names from collision error
    const matches = error.match(/collision between [`']([^`']+)[`'] and [`']([^`']+)[`']/);
    return matches ? [matches[1], matches[2]] : ['package1', 'package2'];
  }

  extractCommand(error) {
    const match = error.match(/command not found: (\w+)/);
    return match ? match[1] : 'unknown';
  }

  guessPackageForCommand(command) {
    const commandToPackage = {
      'git': 'git',
      'make': 'gnumake',
      'gcc': 'gcc',
      'python': 'python3',
      'node': 'nodejs',
      'npm': 'nodejs',
      'cargo': 'cargo',
      'rustc': 'rustc'
    };
    
    return commandToPackage[command] || command;
  }

  extractServiceName(error) {
    const match = error.match(/(?:service|unit) ['"]?(\S+?)['"]? failed/i);
    return match ? match[1] : null;
  }

  extractServiceFromInput(input) {
    const words = input.split(/\s+/);
    const serviceIndex = words.findIndex(w => 
      ['start', 'stop', 'restart', 'enable', 'disable'].includes(w.toLowerCase())
    );
    return serviceIndex >= 0 && serviceIndex < words.length - 1 ? 
      words[serviceIndex + 1] : null;
  }

  sanitizeError(error) {
    // Remove file paths and sensitive information
    return error
      .replace(/\/nix\/store\/[^\s]+/g, '/nix/store/...')
      .replace(/\/home\/\w+/g, '~')
      .substring(0, 200);
  }
}

module.exports = ErrorRecovery;