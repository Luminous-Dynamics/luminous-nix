/**
 * Personality-Aware NLP Integration
 * 
 * Integrates the personality system with the NLP intent engine
 * to provide personalized natural language processing
 */

import { PersonalityAdapter, PersonalityStyle, PERSONALITY_PRESETS } from '../personality/personality-styles';
import { PersonalizedNixInterface } from '../personality/personality-integration';
import { hobbyDetector, HobbyType, DetectedHobby } from '../hobbies/hobby-detector';
import { hobbyResponses } from '../hobbies/hobby-responses';

interface IntentResult {
  action: string;
  command: string;
  package?: string;
  confidence: number;
  originalInput: string;
}

interface PersonalizedIntent extends IntentResult {
  personalizedResponse: string;
  suggestions: string[];
  emotionalContext: {
    detectedEmotion: string;
    confidenceAdjustment: number;
  };
  detectedHobbies?: DetectedHobby[];
}

export class PersonalityAwareNLP {
  private personalityAdapter: PersonalityAdapter;
  private intentPatterns: Map<string, RegExp[]>;
  private domainVocabulary: Map<string, Map<string, string>>;
  
  constructor(initialStyle: PersonalityStyle = PersonalityStyle.Friendly) {
    this.personalityAdapter = new PersonalityAdapter(initialStyle);
    this.initializeIntentPatterns();
    this.initializeDomainVocabulary();
  }
  
  /**
   * Initialize intent patterns with personality variations
   */
  private initializeIntentPatterns() {
    this.intentPatterns = new Map([
      ['install', [
        // Technical/Minimal patterns
        /^install\s+(.+)$/i,
        /^apt-get\s+install\s+(.+)$/i,
        /^nix-env\s+-iA\s+(.+)$/i,
        
        // Friendly patterns
        /^(?:could\s+you\s+)?(?:please\s+)?install\s+(.+)(?:\s+for\s+me)?$/i,
        /^i(?:'d)?\s+like\s+(?:to\s+)?(?:have|get)\s+(.+)$/i,
        
        // Encouraging patterns
        /^let'?s\s+(?:try\s+)?install(?:ing)?\s+(.+)$/i,
        /^i'?m\s+ready\s+to\s+install\s+(.+)$/i,
        
        // Playful patterns
        /^grab\s+(?:me\s+)?(.+)$/i,
        /^hook\s+me\s+up\s+with\s+(.+)$/i,
        /^let'?s\s+get\s+(.+)\s+going$/i,
        
        // Sacred patterns
        /^manifest\s+(.+)$/i,
        /^bring\s+(.+)\s+into\s+being$/i,
        /^invoke\s+the\s+essence\s+of\s+(.+)$/i
      ]],
      
      ['search', [
        // Technical
        /^search\s+(.+)$/i,
        /^find\s+(.+)$/i,
        /^nix\s+search\s+(.+)$/i,
        
        // Friendly
        /^(?:can\s+you\s+)?(?:help\s+me\s+)?(?:find|search\s+for)\s+(.+)$/i,
        /^what'?s?\s+available\s+for\s+(.+)$/i,
        /^show\s+me\s+(.+)\s+(?:options|packages)$/i,
        
        // Encouraging
        /^let'?s\s+(?:explore|discover)\s+(.+)$/i,
        /^help\s+me\s+find\s+the\s+(?:right|best)\s+(.+)$/i,
        
        // Playful
        /^hunt\s+(?:down\s+)?(.+)$/i,
        /^what'?s?\s+out\s+there\s+for\s+(.+)$/i,
        
        // Sacred
        /^seek\s+(.+)$/i,
        /^divine\s+the\s+presence\s+of\s+(.+)$/i
      ]],
      
      ['update', [
        // Technical
        /^update(?:\s+all)?$/i,
        /^upgrade\s+system$/i,
        /^nix-channel\s+--update$/i,
        
        // Friendly
        /^(?:could\s+you\s+)?(?:please\s+)?update\s+(?:everything|my\s+system)$/i,
        /^time\s+to\s+update$/i,
        /^keep\s+(?:me|everything)\s+(?:current|up\s+to\s+date)$/i,
        
        // Encouraging
        /^let'?s\s+get\s+(?:everything\s+)?updated$/i,
        /^ready\s+to\s+update\s+(?:my\s+)?system$/i,
        
        // Playful
        /^freshen\s+(?:things\s+)?up$/i,
        /^time\s+for\s+some\s+updates$/i,
        
        // Sacred
        /^renew\s+the\s+system$/i,
        /^refresh\s+the\s+digital\s+essence$/i
      ]]
    ]);
  }
  
  /**
   * Initialize domain-specific vocabulary adaptations
   */
  private initializeDomainVocabulary() {
    this.domainVocabulary = new Map([
      ['medical', new Map([
        ['install', 'deploy'],
        ['update', 'upgrade protocol'],
        ['error', 'adverse event'],
        ['system', 'environment'],
        ['package', 'module']
      ])],
      
      ['academic', new Map([
        ['install', 'configure'],
        ['search', 'query repository'],
        ['update', 'synchronize'],
        ['help', 'consult documentation'],
        ['package', 'library']
      ])],
      
      ['developer', new Map([
        ['install', 'install'],
        ['update', 'upgrade'],
        ['package', 'package'],
        ['error', 'exception'],
        ['system', 'environment']
      ])],
      
      ['business', new Map([
        ['install', 'provision'],
        ['update', 'upgrade deployment'],
        ['error', 'incident'],
        ['system', 'infrastructure'],
        ['package', 'solution']
      ])]
    ]);
  }
  
  /**
   * Process input with personality awareness
   */
  async processInput(input: string): Promise<PersonalizedIntent> {
    // Update hobby detection with this command
    hobbyDetector.processCommand(input);
    
    // Get detected hobbies
    const detectedHobbies = hobbyDetector.getDetectedHobbies();
    
    // Detect emotional context
    const emotionalContext = this.detectEmotionalContext(input);
    
    // Detect domain if possible
    const domain = this.detectDomain(input);
    
    // Extract intent with personality awareness
    const intent = await this.extractIntent(input, emotionalContext);
    
    // Generate personalized response
    let personalizedResponse = this.generatePersonalizedResponse(
      intent,
      emotionalContext,
      domain
    );
    
    // Enrich response with hobby context
    personalizedResponse = hobbyResponses.enrichResponse(
      personalizedResponse,
      detectedHobbies,
      input
    );
    
    // Generate contextual suggestions
    const suggestions = this.generateSuggestions(intent, emotionalContext);
    
    // Add hobby-based suggestions
    const packageSuggestion = hobbyResponses.generatePackageSuggestion(detectedHobbies);
    if (packageSuggestion) {
      suggestions.push(packageSuggestion);
    }
    
    // Learn from interaction
    this.personalityAdapter.learnFromInteraction({
      userInput: input,
      responseAccepted: true,
      emotionalState: emotionalContext.detectedEmotion as any,
      interactionSpeed: 'normal'
    });
    
    return {
      ...intent,
      personalizedResponse,
      suggestions,
      emotionalContext,
      detectedHobbies
    };
  }
  
  /**
   * Detect emotional context from input
   */
  private detectEmotionalContext(input: string): {
    detectedEmotion: string;
    confidenceAdjustment: number;
  } {
    const lowerInput = input.toLowerCase();
    
    // Frustration indicators
    if (lowerInput.includes('!') ||
        lowerInput.includes('not working') ||
        lowerInput.includes('broken') ||
        lowerInput.includes('stuck') ||
        lowerInput.includes('help')) {
      return {
        detectedEmotion: 'frustrated',
        confidenceAdjustment: -0.1
      };
    }
    
    // Confidence indicators
    if (lowerInput.match(/^[a-z-]+\s+[a-z-]+$/)) {
      return {
        detectedEmotion: 'confident',
        confidenceAdjustment: 0.1
      };
    }
    
    // Happiness indicators
    if (lowerInput.includes('thanks') ||
        lowerInput.includes('great') ||
        lowerInput.includes('awesome') ||
        lowerInput.includes('😊')) {
      return {
        detectedEmotion: 'happy',
        confidenceAdjustment: 0.05
      };
    }
    
    // Uncertainty indicators
    if (lowerInput.includes('?') ||
        lowerInput.includes('maybe') ||
        lowerInput.includes('not sure') ||
        lowerInput.includes('think')) {
      return {
        detectedEmotion: 'uncertain',
        confidenceAdjustment: -0.05
      };
    }
    
    return {
      detectedEmotion: 'neutral',
      confidenceAdjustment: 0
    };
  }
  
  /**
   * Detect user's domain based on vocabulary
   */
  private detectDomain(input: string): string | null {
    const domainIndicators = {
      medical: ['patient', 'protocol', 'clinical', 'diagnosis', 'treatment'],
      academic: ['research', 'paper', 'thesis', 'study', 'analysis'],
      developer: ['git', 'docker', 'npm', 'debug', 'compile'],
      business: ['deploy', 'production', 'stakeholder', 'roi', 'kpi']
    };
    
    for (const [domain, indicators] of Object.entries(domainIndicators)) {
      if (indicators.some(indicator => input.toLowerCase().includes(indicator))) {
        return domain;
      }
    }
    
    return null;
  }
  
  /**
   * Extract intent considering personality patterns
   */
  private async extractIntent(
    input: string,
    emotionalContext: { detectedEmotion: string; confidenceAdjustment: number }
  ): Promise<IntentResult> {
    const normalizedInput = input.toLowerCase().trim();
    
    // Try each intent category
    for (const [action, patterns] of this.intentPatterns.entries()) {
      for (const pattern of patterns) {
        const match = normalizedInput.match(pattern);
        if (match) {
          return {
            action,
            command: this.getCommandForAction(action),
            package: match[1]?.trim(),
            confidence: Math.min(0.95 + emotionalContext.confidenceAdjustment, 1.0),
            originalInput: input
          };
        }
      }
    }
    
    // Fallback to basic intent recognition
    return {
      action: 'unknown',
      command: '',
      confidence: 0.3,
      originalInput: input
    };
  }
  
  /**
   * Generate personalized response based on intent and context
   */
  private generatePersonalizedResponse(
    intent: IntentResult,
    emotionalContext: { detectedEmotion: string; confidenceAdjustment: number },
    domain: string | null
  ): string {
    const currentStyle = this.personalityAdapter.getCurrentStyle();
    const traits = PERSONALITY_PRESETS[currentStyle];
    
    // Base response
    let response = '';
    
    if (intent.action === 'install' && intent.package) {
      response = this.personalityAdapter.getResponse('thinking');
      
      // Add domain-specific vocabulary
      if (domain && this.domainVocabulary.has(domain)) {
        const vocab = this.domainVocabulary.get(domain)!;
        const action = vocab.get('install') || 'install';
        response += ` Preparing to ${action} ${intent.package}...`;
      } else {
        response += ` Installing ${intent.package}...`;
      }
      
      // Add personality flair
      if (traits.encouragement > 0.7) {
        response += " This is going to be great!";
      } else if (traits.playfulness > 0.7) {
        response += " Let's do this! 🚀";
      } else if (traits.spirituality > 0.7) {
        response += " ✨ Manifesting digital reality...";
      }
    } else if (intent.action === 'search' && intent.package) {
      response = `Searching for ${intent.package} packages...`;
      
      if (emotionalContext.detectedEmotion === 'frustrated') {
        response = "I'll help you find what you need. " + response;
      }
    } else if (intent.action === 'unknown') {
      response = this.personalityAdapter.getResponse('error', {
        error: "I didn't quite understand that"
      });
      
      if (emotionalContext.detectedEmotion === 'frustrated') {
        response += " Let me help you with some examples.";
      }
    }
    
    return response;
  }
  
  /**
   * Generate contextual suggestions
   */
  private generateSuggestions(
    intent: IntentResult,
    emotionalContext: { detectedEmotion: string; confidenceAdjustment: number }
  ): string[] {
    const suggestions: string[] = [];
    const currentStyle = this.personalityAdapter.getCurrentStyle();
    const traits = PERSONALITY_PRESETS[currentStyle];
    
    if (intent.action === 'unknown') {
      // Provide helpful suggestions based on personality
      if (traits.verbosity > 0.7) {
        suggestions.push(
          "Try: 'install firefox' to add software",
          "Try: 'search python' to find packages",
          "Try: 'update system' to get latest versions"
        );
      } else {
        suggestions.push("install [package]", "search [term]", "update");
      }
    } else if (intent.action === 'install') {
      if (traits.encouragement > 0.5) {
        suggestions.push("Great choice! After this, you might want to explore related packages.");
      }
      if (emotionalContext.detectedEmotion === 'uncertain') {
        suggestions.push("Not sure? Try 'search' first to see options.");
      }
    }
    
    return suggestions;
  }
  
  /**
   * Get command for action
   */
  private getCommandForAction(action: string): string {
    const commandMap: Record<string, string> = {
      'install': 'nix-env -iA',
      'search': 'nix search',
      'update': 'nix-channel --update',
      'remove': 'nix-env -e',
      'list': 'nix-env -q'
    };
    
    return commandMap[action] || '';
  }
  
  /**
   * Set personality style
   */
  setPersonalityStyle(style: PersonalityStyle): void {
    this.personalityAdapter.setStyle(style);
  }
  
  /**
   * Get current personality info
   */
  getPersonalityInfo() {
    return {
      currentStyle: this.personalityAdapter.getCurrentStyle(),
      traits: this.personalityAdapter.getTraits()
    };
  }
  
  /**
   * Enable/disable learning
   */
  setLearningEnabled(enabled: boolean): void {
    this.personalityAdapter.setLearningEnabled(enabled);
  }
}