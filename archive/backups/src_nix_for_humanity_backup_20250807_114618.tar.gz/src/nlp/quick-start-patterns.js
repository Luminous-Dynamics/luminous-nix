/**
 * Quick Start NLP Patterns
 * Get 50 commands working in 2 days
 */

const patterns = {
  // Package Management (Priority 1)
  // NOTE: Order matters! More specific patterns first
  'package.remove': [
    /^(?:remove|uninstall)\s+(.+)$/i,
    /^get\s+rid\s+of\s+(.+)$/i,
    /^delete\s+(.+)$/i
  ],
  
  'package.install': [
    /^install\s+(.+)$/i,
    /^add\s+(.+)$/i,
    /^i need\s+(.+)$/i,
    /^get (?:me )?(.+)$/i,
    /^(.+) is missing$/i
  ],
  
  'package.search': [
    /^search (?:for )?(.+)$/i,
    /^find\s+(.+)$/i,
    /^what (?:is|are) (.+)$/i,
    /^show (?:me )?(.+) packages$/i
  ],
  
  // System (Priority 2)
  'system.update': [
    /^update(?:\s+system)?$/i,
    /^upgrade(?:\s+everything)?$/i,
    /^run updates$/i
  ],
  
  'system.info': [
    /^system info$/i,
    /^what version(?:\s+am i running)?$/i,
    /^show system$/i
  ],
  
  // Network (Priority 3)
  'network.wifi': [
    /^wifi(?:\s+not working)?$/i,
    /^connect (?:to )?wifi$/i,
    /^internet(?:\s+not working)?$/i,
    /^fix (?:my )?(?:wifi|internet|network)$/i
  ],
  
  // Services (Priority 4)
  'service.start': [
    /^start\s+(.+?)(?:\s+service)?$/i,
    /^enable\s+(.+)$/i
  ],
  
  'service.stop': [
    /^stop\s+(.+?)(?:\s+service)?$/i,
    /^disable\s+(.+)$/i
  ],
  
  'service.status': [
    /^(?:is|check if)\s+(.+)\s+(?:is )?running$/i,
    /^status (?:of )?(.+)$/i
  ]
};

// Helper functions
function extractPackageName(text) {
  // Remove common words
  return text
    .replace(/^(a|an|the|some)\s+/i, '')
    .replace(/\s+(package|program|app|application|software)$/i, '')
    .trim();
}

// Simple matcher
function matchPattern(input) {
  const normalized = input.toLowerCase().trim();
  
  for (const [intent, patternList] of Object.entries(patterns)) {
    for (const pattern of patternList) {
      const match = normalized.match(pattern);
      if (match) {
        return {
          intent,
          confidence: 0.95,
          entities: extractEntities(intent, match),
          raw: input
        };
      }
    }
  }
  
  return null;
}

function extractEntities(intent, match) {
  const [action, domain] = intent.split('.');
  
  switch(domain) {
    case 'install':
    case 'remove':
    case 'search':
      return { package: extractPackageName(match[1] || '') };
      
    case 'start':
    case 'stop':
    case 'status':
      return { service: match[1] };
      
    default:
      return {};
  }
}

module.exports = { matchPattern, patterns };