/**
 * Context Tracking for Conversational Commands
 * Maintains conversation state for natural interactions
 */

class ContextTracker {
  constructor() {
    this.history = [];
    this.maxHistory = 10;
    this.lastSearchResults = null;
    this.lastPackageInstalled = null;
    this.lastError = null;
    this.conversationMode = false;
  }

  /**
   * Add an interaction to history
   */
  addInteraction(input, intent, result) {
    const interaction = {
      timestamp: Date.now(),
      input,
      intent,
      result,
      entities: this.extractEntities(intent, result)
    };

    this.history.unshift(interaction);
    if (this.history.length > this.maxHistory) {
      this.history.pop();
    }

    // Update context based on interaction
    this.updateContext(interaction);
  }

  /**
   * Update context based on interaction
   */
  updateContext(interaction) {
    switch (interaction.intent) {
      case 'package.search':
        if (interaction.result.success && interaction.result.packages) {
          this.lastSearchResults = interaction.result.packages;
          this.conversationMode = true;
        }
        break;
      
      case 'package.install':
        if (interaction.result.success) {
          this.lastPackageInstalled = interaction.entities.package;
        }
        break;
      
      case 'error':
        this.lastError = interaction.result;
        break;
    }
  }

  /**
   * Extract entities from interaction
   */
  extractEntities(intent, result) {
    const entities = {};
    
    if (intent.includes('package')) {
      entities.package = result.package || this.extractPackageFromCommand(result.command);
    }
    
    if (intent.includes('service')) {
      entities.service = result.service || this.extractServiceFromCommand(result.command);
    }
    
    return entities;
  }

  /**
   * Resolve contextual references
   */
  resolveReference(input) {
    const normalized = input.toLowerCase().trim();
    
    // Handle "it", "that", "this"
    if (/\b(it|that|this)\b/.test(normalized)) {
      // If we just searched, "it" likely refers to a search result
      if (this.lastSearchResults && this.conversationMode) {
        return this.resolveSearchReference(normalized);
      }
      
      // If we just installed something, "it" refers to that package
      if (this.lastPackageInstalled) {
        return {
          resolved: normalized.replace(/\b(it|that|this)\b/, this.lastPackageInstalled),
          reference: this.lastPackageInstalled,
          confidence: 0.9
        };
      }
    }
    
    // Handle "the first one", "the second one", etc.
    if (/the (first|second|third|last) (?:one|option)/.test(normalized)) {
      return this.resolveOrdinalReference(normalized);
    }
    
    // Handle "the same"
    if (/the same/.test(normalized)) {
      return this.resolveSameReference(normalized);
    }
    
    // Handle "again"
    if (/again/.test(normalized)) {
      return this.resolveAgainReference(normalized);
    }
    
    return null;
  }

  /**
   * Resolve references to search results
   */
  resolveSearchReference(input) {
    if (!this.lastSearchResults || this.lastSearchResults.length === 0) {
      return null;
    }
    
    // Default to first result for "it"
    if (/\b(it|that)\b/.test(input) && !/(first|second|third)/.test(input)) {
      return {
        resolved: input.replace(/\b(it|that)\b/, this.lastSearchResults[0]),
        reference: this.lastSearchResults[0],
        confidence: 0.8
      };
    }
    
    return null;
  }

  /**
   * Resolve ordinal references (first, second, etc.)
   */
  resolveOrdinalReference(input) {
    if (!this.lastSearchResults || this.lastSearchResults.length === 0) {
      return null;
    }
    
    const ordinals = {
      'first': 0,
      'second': 1,
      'third': 2,
      'fourth': 3,
      'fifth': 4,
      'last': -1
    };
    
    for (const [ordinal, index] of Object.entries(ordinals)) {
      if (input.includes(ordinal)) {
        const actualIndex = index === -1 ? this.lastSearchResults.length - 1 : index;
        
        if (actualIndex < this.lastSearchResults.length) {
          const package = this.lastSearchResults[actualIndex];
          return {
            resolved: input.replace(/the \w+ (?:one|option)/, package),
            reference: package,
            confidence: 0.95
          };
        }
      }
    }
    
    return null;
  }

  /**
   * Resolve "the same" reference
   */
  resolveSameReference(input) {
    if (this.history.length > 0) {
      const lastAction = this.history[0];
      if (lastAction.entities.package) {
        return {
          resolved: input.replace(/the same/, lastAction.entities.package),
          reference: lastAction.entities.package,
          confidence: 0.9
        };
      }
    }
    return null;
  }

  /**
   * Resolve "again" reference
   */
  resolveAgainReference(input) {
    if (this.history.length > 0) {
      const lastAction = this.history[0];
      return {
        resolved: lastAction.input,
        reference: lastAction.input,
        confidence: 0.95,
        isRepeat: true
      };
    }
    return null;
  }

  /**
   * Get conversation suggestions
   */
  getSuggestions() {
    const suggestions = [];
    
    if (this.lastSearchResults && this.lastSearchResults.length > 0) {
      suggestions.push('You can say "install the first one" or "tell me more about the second one"');
    }
    
    if (this.lastPackageInstalled) {
      suggestions.push(`You can say "remove it" to uninstall ${this.lastPackageInstalled}`);
    }
    
    if (this.lastError) {
      suggestions.push('You can say "try again" or ask "why did that fail?"');
    }
    
    return suggestions;
  }

  /**
   * Reset conversation context
   */
  resetContext() {
    this.lastSearchResults = null;
    this.conversationMode = false;
  }

  /**
   * Helper methods
   */
  extractPackageFromCommand(command) {
    const match = command.match(/nixos\.(\w+)/);
    return match ? match[1] : null;
  }

  extractServiceFromCommand(command) {
    const match = command.match(/systemctl \w+ (\w+)/);
    return match ? match[1] : null;
  }
}

module.exports = ContextTracker;