# 🖥️ Nix for Humanity TUI

A beautiful terminal user interface for natural language NixOS management, powered by Textual.

## Features

- 💬 **Natural conversation interface** - Chat with your system like a friend
- 🎨 **Beautiful terminal UI** - Rich colors, borders, and formatting
- ⌨️ **Full keyboard navigation** - Accessible and efficient
- 🧠 **Multiple personality styles** - Adapt to your communication preference
- 📝 **Command preview** - See what will run before executing
- 🔒 **Safe by default** - Always preview commands before running
- 🤝 **Symbiotic learning** - Help the system improve with feedback
- 🌊 **Real-time status** - Always know what's happening

## Quick Start

```bash
# From the project root
./bin/nix-tui

# Or run directly
python3 -m nix_for_humanity.tui.app
```

## Keyboard Shortcuts

- **Ctrl+P** - Toggle personality style
- **Ctrl+H** - Show help screen
- **Ctrl+C** - Clear chat history
- **Ctrl+Q** - Quit application
- **Tab** - Navigate between elements
- **Enter** - Send message

## Personality Styles

Cycle through with Ctrl+P:

1. **Minimal** - Just the facts, no fluff
2. **Friendly** - Warm and helpful (default)
3. **Encouraging** - Great for beginners
4. **Technical** - Detailed explanations
5. **Symbiotic** - Learning mode with feedback

## Usage Examples

### Installing Software
```
You: install firefox
System: I'll help you install Firefox! [Shows command preview]
[Execute button] [Cancel button]
```

### System Updates
```
You: update my system
System: Let me check for updates... [Shows update command]
```

### Getting Help
```
You: help
System: [Shows available commands and tips]
```

### Learning Together (Symbiotic Mode)
```
You: search for editors
System: [Shows results]
[Was this helpful?] [👍] [👎] [✏️ Explain]
```

## Architecture

The TUI is a lightweight frontend that communicates with the headless core engine:

```
┌─────────────────────┐
│   Textual TUI       │
│  (User Interface)   │
├─────────────────────┤
│   Plan/Execute      │
│   Separation        │
├─────────────────────┤
│  Headless Core      │
│   (Intelligence)    │
└─────────────────────┘
```

## Development

### Running in Development Mode

```bash
# Install dependencies
pip install textual

# Run with debug console
textual run --dev src/nix_for_humanity/tui/app.py
```

### Architecture Highlights

- **Plan/Execute Separation** - Core creates plans, TUI shows them, user approves
- **Type-Safe Communication** - All messages use dataclasses
- **Event-Driven Design** - Reactive UI updates
- **Accessibility First** - Screen reader friendly

### Key Components

- `ChatMessage` - Displays user/assistant messages
- `CommandPreview` - Shows commands with syntax highlighting
- `HelpScreen` - Comprehensive help documentation
- `NixHumanityApp` - Main application class

## Customization

### Custom Styles

Edit the CSS in `app.py` to customize appearance:

```python
CSS = """
Screen {
    background: $surface;
}
# ... customize colors, borders, spacing
"""
```

### Adding Features

1. New keyboard shortcuts: Add to `BINDINGS`
2. New screens: Inherit from `Screen`
3. New widgets: Inherit from `Static` or other Textual widgets

## Troubleshooting

### TUI Won't Start
- Check Textual is installed: `pip install textual`
- Verify terminal supports colors: `echo $TERM`
- Try a different terminal emulator

### Display Issues
- Ensure terminal is at least 80x24
- Check locale supports UTF-8: `locale`
- Try without custom fonts

### Performance
- Close other applications
- Use a GPU-accelerated terminal
- Reduce terminal transparency

## Future Features

- [ ] Syntax highlighting for Nix code
- [ ] Multi-tab support
- [ ] Command history browser
- [ ] Theme customization
- [ ] Export conversation logs
- [ ] Voice input integration

## Contributing

The TUI follows the same standards as the core project:
- TypeScript/Python for new code
- Test with all 10 personas in mind
- Maintain accessibility standards
- Keep it simple and beautiful

---

*"A beautiful interface is not about decoration, but about clarity of communication."*