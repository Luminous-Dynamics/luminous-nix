# Frontend Adapters
"""
Adapters for different frontends to use the headless core
"""