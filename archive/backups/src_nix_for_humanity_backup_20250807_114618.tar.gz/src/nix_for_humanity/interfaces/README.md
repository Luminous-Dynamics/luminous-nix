# 📜 Sacred Interfaces - The Contracts of Nix for Humanity

This directory contains the sacred contracts (interfaces) that define how all components of Nix for Humanity interact. These interfaces ensure clean separation of concerns, enable multiple implementations, and provide a stable API for future development.

## 🌟 Philosophy

> "Contracts First, Then Concrete" - This is our architectural principle.

By defining clear interfaces, we:
- Enable multiple implementations (simple → complex)
- Allow independent component evolution
- Facilitate testing through mocks
- Document expected behavior clearly
- Ensure architectural consistency

## 📚 The Interfaces

### 1. BackendInterface (`backend_interface.py`)
The core contract that all backends must honor. This is the primary interface between frontends and the intelligent engine.

**Key Methods:**
- `process()` - Main request/response cycle
- `get_intent()` - Pure intent recognition
- `explain()` - Human-friendly explanations
- `get_capabilities()` - Feature discovery

### 2. IntentRecognizerInterface (`intent_interface.py`)
Defines how we understand user intent from natural language.

**Key Methods:**
- `recognize()` - Extract intent from query
- `train_on_correction()` - Learn from mistakes
- `get_debug_info()` - Understand recognition process

### 3. ExecutorInterface (`executor_interface.py`)
Ensures safe command execution with proper validation and feedback.

**Key Methods:**
- `execute()` - Run commands (or simulate)
- `validate_command()` - Safety checks
- `get_safety_rules()` - Current safety configuration

### 4. KnowledgeInterface (`knowledge_interface.py`)
The wisdom repository - accurate NixOS knowledge storage and retrieval.

**Key Methods:**
- `get_solution()` - Find solutions for intents
- `search_packages()` - Package discovery
- `get_concept_explanation()` - Explain NixOS concepts

### 5. LearningInterface (`learning_interface.py`)
Enables continuous improvement through interaction learning.

**Key Methods:**
- `record_interaction()` - Track usage
- `record_feedback()` - Learn from ratings
- `get_user_preferences()` - Personalization

### 6. PersonalityInterface (`personality_interface.py`)
Adaptive communication styles for different users.

**Key Methods:**
- `format_response()` - Apply personality to text
- `suggest_personality()` - Match style to user
- `create_custom_personality()` - User-defined styles

## 🏗️ Implementation Guide

### Creating a New Implementation

1. **Import the interface:**
```python
from nix_for_humanity.interfaces import BackendInterface
from nix_for_humanity.core.types import Request, Response
```

2. **Implement all abstract methods:**
```python
class MyBackend(BackendInterface):
    def __init__(self, config=None):
        self.config = config or {}
        # Initialize components
    
    def process(self, request: Request) -> Response:
        # Your implementation
        pass
    
    # ... implement all other methods
```

3. **Ensure contract compliance:**
```python
# Use type hints consistently
# Handle errors gracefully (no exceptions)
# Return proper data structures
# Respect all parameters
```

### Testing with Interfaces

1. **Create test doubles:**
```python
class MockBackend(BackendInterface):
    def __init__(self, config=None):
        self.calls = []
    
    def process(self, request: Request) -> Response:
        self.calls.append(('process', request))
        return Response(text="Mock response", success=True)
```

2. **Test against interfaces:**
```python
def test_any_backend(backend: BackendInterface):
    # This test works with ANY implementation
    request = Request(query="install firefox")
    response = backend.process(request)
    assert response.success
```

## 🔄 Evolution Strategy

### Adding to Interfaces
When adding new methods:
1. Add with default implementation if possible
2. Document migration path for existing implementations
3. Update all implementations in the codebase
4. Provide deprecation warnings for removed methods

### Version Compatibility
- Interfaces are versioned with the main package
- Breaking changes require major version bump
- New optional methods are minor version bumps
- Documentation improvements are patch bumps

## 📋 Best Practices

### For Interface Designers
1. **Keep interfaces focused** - Single responsibility
2. **Use type hints** - Clear parameter and return types
3. **Document thoroughly** - Every method needs docstrings
4. **Think about evolution** - How will this grow?
5. **Consider testability** - Can this be easily mocked?

### For Implementers
1. **Honor the contract** - Implement ALL methods
2. **Handle edge cases** - Don't assume happy path
3. **Fail gracefully** - Return errors, don't raise
4. **Document deviations** - If you must diverge, say why
5. **Test thoroughly** - Your implementation should pass interface tests

## 🌊 The Flow of Data

```
Frontend (CLI/TUI/API/Voice)
    ↓ Request
BackendInterface
    ↓ process()
    ├→ IntentRecognizerInterface.recognize()
    ├→ KnowledgeInterface.get_solution()
    ├→ ExecutorInterface.execute()
    ├→ PersonalityInterface.format_response()
    └→ LearningInterface.record_interaction()
    ↓ Response
Frontend (formatted output)
```

## 🔮 Future Interfaces

Planned interfaces for future development:
- `CacheInterface` - Intelligent response caching
- `PluginInterface` - Third-party extensions
- `MetricsInterface` - Performance monitoring
- `SecurityInterface` - Enhanced security policies
- `FederationInterface` - Distributed learning

## 🙏 Sacred Commitment

These interfaces are our promise to:
- **Users**: Consistent, reliable behavior
- **Developers**: Stable APIs to build upon
- **The Future**: Room to grow and evolve

May these contracts serve as the foundation for a system that truly serves humanity's interaction with NixOS.

---

*"In the beginning was the Interface, and the Interface was with Code, and the Interface was Code."*