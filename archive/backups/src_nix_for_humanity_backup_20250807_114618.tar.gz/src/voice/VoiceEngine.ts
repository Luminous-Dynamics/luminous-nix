// Mock VoiceEngine for demo
export interface VoiceConfig {
  language: string;
  sampleRate: number;
  enableEmotionDetection: boolean;
  enableNoiseCancellation: boolean;
}

export interface VoiceEmotionFeatures {
  pitch: number;
  energy: number;
  speechRate: number;
  pauseFrequency: number;
}

export class VoiceEngine {
  private isListening = false;
  private config: VoiceConfig = {
    language: 'en-US',
    sampleRate: 16000,
    enableEmotionDetection: true,
    enableNoiseCancellation: true
  };

  async initialize() {
    console.log('Voice Engine initialized');
  }

  async startListening(onTranscript: (text: string) => void, onEmotion?: (features: VoiceEmotionFeatures) => void) {
    this.isListening = true;
    console.log('Voice listening started');
    
    // Mock voice input
    setTimeout(() => {
      if (this.isListening) {
        onTranscript("Install Firefox please");
        if (onEmotion) {
          onEmotion({
            pitch: 200,
            energy: 0.7,
            speechRate: 150,
            pauseFrequency: 0.3
          });
        }
      }
    }, 2000);
  }

  async stopListening() {
    this.isListening = false;
    console.log('Voice listening stopped');
  }

  async speak(text: string, emotion?: 'neutral' | 'friendly' | 'encouraging') {
    console.log(`Speaking with ${emotion || 'neutral'} emotion: ${text}`);
    
    // Mock speech synthesis
    return new Promise<void>((resolve) => {
      setTimeout(() => {
        resolve();
      }, text.length * 50); // Simulate speaking time
    });
  }

  detectEmotionFromVoice(audioData: ArrayBuffer): VoiceEmotionFeatures {
    // Mock emotion detection from voice
    return {
      pitch: 180 + Math.random() * 40,
      energy: 0.5 + Math.random() * 0.5,
      speechRate: 140 + Math.random() * 40,
      pauseFrequency: 0.2 + Math.random() * 0.3
    };
  }

  setLanguage(language: string) {
    this.config.language = language;
  }

  enableEmotionDetection(enable: boolean) {
    this.config.enableEmotionDetection = enable;
  }

  calibrateUserVoice(samples: ArrayBuffer[]): void {
    console.log('Calibrating user voice profile from', samples.length, 'samples');
  }

  getNoiseLevel(): number {
    // Mock ambient noise level (0-1)
    return 0.3;
  }

  isVoiceDetected(): boolean {
    // Mock voice activity detection
    return this.isListening && Math.random() > 0.3;
  }
}