/**
 * Voice Integration Demo
 * Shows how voice interaction works with personality adaptation
 */

import React, { useState } from 'react';
import { VoiceInterface } from './VoiceInterface';
import { CommandResult } from '../types';
import { PersonalityStyle } from '../personality/types';

export const VoiceDemo: React.FC = () => {
  const [results, setResults] = useState<CommandResult[]>([]);
  const [personalityStyle, setPersonalityStyle] = useState<PersonalityStyle>('friendly');
  const [selectedPersona, setSelectedPersona] = useState('general');
  
  const personas = [
    { id: 'grandma-rose', name: 'Grandma Rose (75)', description: 'Voice-first, patient' },
    { id: 'maya', name: 'Maya (16)', description: 'Fast, minimal distractions' },
    { id: 'david', name: 'David (42)', description: 'Tired parent, needs simplicity' },
    { id: 'alex', name: 'Alex (28)', description: 'Blind developer, efficient' },
    { id: 'viktor', name: 'Viktor (67)', description: 'ESL, needs clarity' },
    { id: 'general', name: 'General User', description: 'Adaptive to anyone' }
  ];
  
  const handleCommand = (result: CommandResult) => {
    setResults(prev => [...prev, {
      ...result,
      timestamp: new Date()
    }]);
  };
  
  const getPersonaPrompt = (personaId: string): string => {
    switch (personaId) {
      case 'grandma-rose':
        return "Try saying: 'I need that program for video calls with my grandkids'";
      case 'maya':
        return "Try saying: 'install discord'";
      case 'david':
        return "Try saying: 'my computer is running slow'";
      case 'alex':
        return "Try saying: 'set up python development environment'";
      case 'viktor':
        return "Try saying: 'how I make wifi work?'";
      default:
        return "Try saying: 'install firefox' or 'update my system'";
    }
  };
  
  return (
    <div className="voice-demo min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto p-6">
        <h1 className="text-3xl font-bold mb-2">Voice Integration Demo</h1>
        <p className="text-gray-600 mb-8">
          Natural voice conversations with Nix for Humanity - adapted to YOUR way of speaking!
        </p>
        
        {/* Persona Selection */}
        <div className="mb-8 bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Select Test Persona</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {personas.map(persona => (
              <button
                key={persona.id}
                onClick={() => setSelectedPersona(persona.id)}
                className={`
                  p-3 rounded-lg border-2 transition-all
                  ${selectedPersona === persona.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                  }
                `}
              >
                <div className="font-medium">{persona.name}</div>
                <div className="text-sm text-gray-600">{persona.description}</div>
              </button>
            ))}
          </div>
          
          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
            <p className="text-sm font-medium text-blue-900">
              {getPersonaPrompt(selectedPersona)}
            </p>
          </div>
        </div>
        
        {/* Voice Interface */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <VoiceInterface
            onCommand={handleCommand}
            personalityStyle={personalityStyle}
          />
        </div>
        
        {/* Results History */}
        {results.length > 0 && (
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">Command History</h2>
            <div className="space-y-3">
              {results.slice().reverse().map((result, index) => (
                <div
                  key={index}
                  className={`
                    p-4 rounded-lg border
                    ${result.success 
                      ? 'bg-green-50 border-green-200' 
                      : 'bg-red-50 border-red-200'
                    }
                  `}
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className={`
                      inline-flex items-center px-2 py-1 rounded text-xs font-medium
                      ${result.success 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                      }
                    `}>
                      {result.success ? 'Success' : 'Failed'}
                    </span>
                    <span className="text-xs text-gray-500">
                      {new Date(result.timestamp!).toLocaleTimeString()}
                    </span>
                  </div>
                  
                  <p className="font-medium mb-1">{result.command}</p>
                  <p className="text-sm text-gray-700">{result.response}</p>
                  
                  {result.output && (
                    <pre className="mt-2 p-2 bg-gray-100 rounded text-xs overflow-x-auto">
                      {result.output}
                    </pre>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Features Showcase */}
        <div className="mt-8 grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="font-semibold mb-3">🎯 Voice Features</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>✓ Natural conversation - no robotic commands</li>
              <li>✓ Emotion detection adapts responses</li>
              <li>✓ Corrections: "No, I meant Firefox"</li>
              <li>✓ Confirmations for important actions</li>
              <li>✓ Learns your speaking patterns</li>
              <li>✓ Handles accents and dialects</li>
            </ul>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="font-semibold mb-3">🌈 Accessibility</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>✓ Works with screen readers</li>
              <li>✓ Visual waveform feedback</li>
              <li>✓ Emotion indicators</li>
              <li>✓ Clear confirmations</li>
              <li>✓ No time pressure</li>
              <li>✓ Patient with repetition</li>
            </ul>
          </div>
        </div>
        
        {/* Technical Details */}
        <details className="mt-8 bg-white rounded-lg shadow p-6">
          <summary className="font-semibold cursor-pointer">Technical Implementation</summary>
          <div className="mt-4 space-y-3 text-sm text-gray-600">
            <p>
              <strong>Speech Recognition:</strong> Whisper.cpp for accurate, local transcription
            </p>
            <p>
              <strong>Emotion Detection:</strong> Prosody analysis (pitch, tempo, energy)
            </p>
            <p>
              <strong>Natural Language:</strong> Hybrid NLP with context awareness
            </p>
            <p>
              <strong>Personality:</strong> Adapts based on user patterns and preferences
            </p>
            <p>
              <strong>Privacy:</strong> Everything runs locally - no cloud services
            </p>
          </div>
        </details>
      </div>
    </div>
  );
};