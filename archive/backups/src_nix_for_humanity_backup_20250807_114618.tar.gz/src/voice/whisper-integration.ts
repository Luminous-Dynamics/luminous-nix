/**
 * Whisper.cpp Integration for Voice-to-Text
 * Enables natural voice conversations with Nix for Humanity
 */

import { EventEmitter } from 'events';
import { spawn, ChildProcess } from 'child_process';
import { EmotionalState } from '../voice-emotion/types';
import { VoiceEmotionDetector } from '../voice-emotion/emotion-detector';

export interface WhisperConfig {
  modelPath: string;
  language?: string;
  threads?: number;
  samplingRate?: number;
  vadThreshold?: number;
  audioContext?: 'command' | 'dictation' | 'conversation';
}

export interface TranscriptionResult {
  text: string;
  confidence: number;
  timestamp: Date;
  duration: number;
  language?: string;
  segments?: TranscriptionSegment[];
}

export interface TranscriptionSegment {
  text: string;
  start: number;
  end: number;
  confidence: number;
}

export class WhisperIntegration extends EventEmitter {
  private config: WhisperConfig;
  private whisperProcess?: ChildProcess;
  private emotionDetector: VoiceEmotionDetector;
  private isListening: boolean = false;
  private audioBuffer: Float32Array[] = [];
  private silenceTimeout?: NodeJS.Timeout;
  
  constructor(config: WhisperConfig) {
    super();
    this.config = {
      language: 'en',
      threads: 4,
      samplingRate: 16000,
      vadThreshold: 0.6,
      audioContext: 'conversation',
      ...config
    };
    
    this.emotionDetector = new VoiceEmotionDetector();
  }
  
  /**
   * Start listening for voice input
   */
  async startListening(): Promise<void> {
    if (this.isListening) {
      throw new Error('Already listening');
    }
    
    this.isListening = true;
    this.emit('listening-started');
    
    // Initialize Whisper process
    await this.initializeWhisper();
    
    // Start audio capture
    await this.startAudioCapture();
  }
  
  /**
   * Stop listening
   */
  async stopListening(): Promise<void> {
    if (!this.isListening) {
      return;
    }
    
    this.isListening = false;
    this.emit('listening-stopped');
    
    // Clean up resources
    if (this.whisperProcess) {
      this.whisperProcess.kill();
      this.whisperProcess = undefined;
    }
    
    if (this.silenceTimeout) {
      clearTimeout(this.silenceTimeout);
      this.silenceTimeout = undefined;
    }
    
    this.audioBuffer = [];
  }
  
  /**
   * Initialize Whisper.cpp process
   */
  private async initializeWhisper(): Promise<void> {
    const args = [
      '-m', this.config.modelPath,
      '-l', this.config.language!,
      '-t', this.config.threads!.toString(),
      '--step', '0', // Process in real-time
      '--length', '30000', // Max 30 seconds per segment
      '-vth', this.config.vadThreshold!.toString(),
    ];
    
    // Add context-specific parameters
    switch (this.config.audioContext) {
      case 'command':
        args.push('--max-tokens', '32'); // Short commands
        args.push('--beam-size', '2'); // Faster for commands
        break;
      case 'dictation':
        args.push('--max-tokens', '448'); // Longer form
        args.push('--best-of', '3'); // Higher accuracy
        break;
      case 'conversation':
        args.push('--max-tokens', '224'); // Natural conversation
        args.push('--entropy-thold', '2.4'); // Better for varied speech
        break;
    }
    
    // Spawn Whisper process
    this.whisperProcess = spawn('whisper-cpp', args, {
      stdio: ['pipe', 'pipe', 'pipe']
    });
    
    // Handle Whisper output
    this.whisperProcess.stdout?.on('data', (data) => {
      this.handleWhisperOutput(data.toString());
    });
    
    this.whisperProcess.stderr?.on('data', (data) => {
      console.error('Whisper error:', data.toString());
    });
    
    this.whisperProcess.on('error', (error) => {
      this.emit('error', new Error(`Whisper process error: ${error.message}`));
    });
    
    this.whisperProcess.on('exit', (code) => {
      if (code !== 0 && this.isListening) {
        this.emit('error', new Error(`Whisper process exited with code ${code}`));
      }
    });
  }
  
  /**
   * Start capturing audio from microphone
   */
  private async startAudioCapture(): Promise<void> {
    // In a real implementation, this would use WebAudio API or native audio capture
    // For now, we'll simulate with a placeholder
    
    // Simulate audio chunks arriving
    const simulateAudioChunk = () => {
      if (!this.isListening) return;
      
      // Generate simulated audio data
      const chunkSize = 1024;
      const audioChunk = new Float32Array(chunkSize);
      
      // Add to buffer for processing
      this.audioBuffer.push(audioChunk);
      
      // Process buffer if we have enough data
      if (this.audioBuffer.length >= 16) { // ~1 second at 16kHz
        this.processAudioBuffer();
      }
      
      // Continue capturing
      setTimeout(simulateAudioChunk, 64); // ~16ms chunks
    };
    
    simulateAudioChunk();
  }
  
  /**
   * Process accumulated audio buffer
   */
  private async processAudioBuffer(): Promise<void> {
    if (this.audioBuffer.length === 0) return;
    
    // Combine audio chunks
    const totalLength = this.audioBuffer.reduce((sum, chunk) => sum + chunk.length, 0);
    const combinedAudio = new Float32Array(totalLength);
    let offset = 0;
    
    for (const chunk of this.audioBuffer) {
      combinedAudio.set(chunk, offset);
      offset += chunk.length;
    }
    
    // Clear buffer
    this.audioBuffer = [];
    
    // Detect voice activity
    const hasVoice = this.detectVoiceActivity(combinedAudio);
    
    if (hasVoice) {
      // Reset silence timeout
      if (this.silenceTimeout) {
        clearTimeout(this.silenceTimeout);
      }
      
      // Send to Whisper for transcription
      if (this.whisperProcess && this.whisperProcess.stdin) {
        const pcmData = this.convertToPCM16(combinedAudio);
        this.whisperProcess.stdin.write(pcmData);
      }
      
      // Analyze emotion
      const emotion = await this.analyzeEmotion(combinedAudio);
      this.emit('emotion-detected', emotion);
      
      // Set silence timeout
      this.silenceTimeout = setTimeout(() => {
        this.handleSilence();
      }, 1500); // 1.5 seconds of silence ends utterance
    }
  }
  
  /**
   * Simple voice activity detection
   */
  private detectVoiceActivity(audio: Float32Array): boolean {
    // Calculate RMS energy
    let sum = 0;
    for (let i = 0; i < audio.length; i++) {
      sum += audio[i] * audio[i];
    }
    const rms = Math.sqrt(sum / audio.length);
    
    // Simple threshold (in practice, this would be more sophisticated)
    return rms > 0.01;
  }
  
  /**
   * Convert float32 audio to PCM16 for Whisper
   */
  private convertToPCM16(float32Audio: Float32Array): Buffer {
    const pcm16 = new Int16Array(float32Audio.length);
    
    for (let i = 0; i < float32Audio.length; i++) {
      const sample = Math.max(-1, Math.min(1, float32Audio[i]));
      pcm16[i] = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
    }
    
    return Buffer.from(pcm16.buffer);
  }
  
  /**
   * Analyze emotion from audio
   */
  private async analyzeEmotion(audio: Float32Array): Promise<EmotionalState> {
    const segment = {
      audio,
      sampleRate: this.config.samplingRate!,
      timestamp: new Date(),
      duration: audio.length / this.config.samplingRate!
    };
    
    return await this.emotionDetector.detectEmotion(segment);
  }
  
  /**
   * Handle Whisper transcription output
   */
  private handleWhisperOutput(output: string): void {
    try {
      // Parse Whisper output (format depends on Whisper.cpp version)
      const lines = output.trim().split('\n');
      
      for (const line of lines) {
        if (line.includes('[') && line.includes(']')) {
          // Extract timestamp and text
          const match = line.match(/\[(\d+\.\d+)\s*-->\s*(\d+\.\d+)\]\s*(.+)/);
          if (match) {
            const [, start, end, text] = match;
            
            const result: TranscriptionResult = {
              text: text.trim(),
              confidence: 0.9, // Whisper doesn't provide confidence scores
              timestamp: new Date(),
              duration: parseFloat(end) - parseFloat(start),
              segments: [{
                text: text.trim(),
                start: parseFloat(start),
                end: parseFloat(end),
                confidence: 0.9
              }]
            };
            
            this.emit('transcription', result);
          }
        }
      }
    } catch (error) {
      console.error('Error parsing Whisper output:', error);
    }
  }
  
  /**
   * Handle silence (end of utterance)
   */
  private handleSilence(): void {
    this.emit('silence-detected');
    
    // Flush any remaining audio
    if (this.audioBuffer.length > 0) {
      this.processAudioBuffer();
    }
  }
  
  /**
   * Transcribe a pre-recorded audio file
   */
  async transcribeFile(audioPath: string): Promise<TranscriptionResult> {
    return new Promise((resolve, reject) => {
      const args = [
        '-m', this.config.modelPath,
        '-l', this.config.language!,
        '-f', audioPath,
        '--output-json'
      ];
      
      const process = spawn('whisper-cpp', args);
      let output = '';
      
      process.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      process.on('exit', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(output);
            resolve({
              text: result.text,
              confidence: 0.9,
              timestamp: new Date(),
              duration: result.duration || 0,
              segments: result.segments
            });
          } catch (error) {
            reject(new Error(`Failed to parse transcription: ${error}`));
          }
        } else {
          reject(new Error(`Whisper process exited with code ${code}`));
        }
      });
      
      process.on('error', reject);
    });
  }
}