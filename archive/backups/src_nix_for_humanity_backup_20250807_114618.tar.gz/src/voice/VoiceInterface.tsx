/**
 * Voice Interface Component
 * Provides natural voice interaction for Nix for Humanity
 */

import React, { useState, useEffect, useRef } from 'react';
import { VoiceToNLPPipeline } from './voice-to-nlp-pipeline';
import { EmotionalState } from '../voice-emotion/types';
import { CommandResult } from '../types';

interface VoiceInterfaceProps {
  whisperModelPath?: string;
  onCommand?: (result: CommandResult) => void;
  personalityStyle?: string;
}

interface VoiceState {
  isListening: boolean;
  isProcessing: boolean;
  transcription: string;
  partialTranscription: string;
  emotion?: EmotionalState;
  error?: string;
  confirmationPending?: {
    message: string;
    command: any;
  };
}

export const VoiceInterface: React.FC<VoiceInterfaceProps> = ({
  whisperModelPath = '/models/whisper-base.bin',
  onCommand,
  personalityStyle = 'friendly'
}) => {
  const [state, setState] = useState<VoiceState>({
    isListening: false,
    isProcessing: false,
    transcription: '',
    partialTranscription: ''
  });
  
  const pipelineRef = useRef<VoiceToNLPPipeline | null>(null);
  const audioVisualizerRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();
  
  useEffect(() => {
    // Initialize voice pipeline
    const pipeline = new VoiceToNLPPipeline({
      modelPath: whisperModelPath,
      language: 'en',
      audioContext: 'conversation'
    });
    
    // Set up event handlers
    pipeline.on('ready', (message: string) => {
      setState(prev => ({ ...prev, error: undefined }));
    });
    
    pipeline.on('partial-transcription', (text: string) => {
      setState(prev => ({ ...prev, partialTranscription: text }));
    });
    
    pipeline.on('command-result', (result: CommandResult) => {
      setState(prev => ({
        ...prev,
        isProcessing: false,
        transcription: prev.partialTranscription,
        partialTranscription: ''
      }));
      
      if (onCommand) {
        onCommand(result);
      }
    });
    
    pipeline.on('emotion-detected', (emotion: EmotionalState) => {
      setState(prev => ({ ...prev, emotion }));
    });
    
    pipeline.on('confirmation-needed', (data: any) => {
      setState(prev => ({
        ...prev,
        confirmationPending: {
          message: data.message,
          command: data.command
        }
      }));
    });
    
    pipeline.on('error', (error: any) => {
      setState(prev => ({
        ...prev,
        error: error.response || error.message,
        isProcessing: false
      }));
    });
    
    pipelineRef.current = pipeline;
    
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      pipeline.stopListening();
    };
  }, [whisperModelPath, onCommand]);
  
  const toggleListening = async () => {
    if (!pipelineRef.current) return;
    
    if (state.isListening) {
      await pipelineRef.current.stopListening();
      setState(prev => ({ ...prev, isListening: false }));
    } else {
      try {
        await pipelineRef.current.startListening();
        setState(prev => ({ ...prev, isListening: true, error: undefined }));
        startAudioVisualization();
      } catch (error) {
        setState(prev => ({ 
          ...prev, 
          error: `Failed to start listening: ${error}` 
        }));
      }
    }
  };
  
  const handleConfirmation = (confirmed: boolean) => {
    if (!pipelineRef.current || !state.confirmationPending) return;
    
    // Send confirmation response
    const response = confirmed ? 'yes' : 'no';
    // This would be handled by the pipeline
    
    setState(prev => ({ ...prev, confirmationPending: undefined }));
  };
  
  const startAudioVisualization = () => {
    if (!audioVisualizerRef.current) return;
    
    const canvas = audioVisualizerRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Draw waveform visualization
      ctx.strokeStyle = state.isListening ? '#10b981' : '#6b7280';
      ctx.lineWidth = 2;
      ctx.beginPath();
      
      const centerY = canvas.height / 2;
      const amplitude = state.isListening ? 30 : 5;
      
      for (let x = 0; x < canvas.width; x++) {
        const y = centerY + Math.sin((x * 0.02) + (Date.now() * 0.002)) * amplitude;
        if (x === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      
      ctx.stroke();
      
      animationFrameRef.current = requestAnimationFrame(draw);
    };
    
    draw();
  };
  
  const getEmotionEmoji = (emotion?: EmotionalState): string => {
    if (!emotion) return '😊';
    
    const { frustration, confidence, confusion, excitement, calmness } = emotion;
    
    if (frustration > 0.7) return '😤';
    if (confusion > 0.7) return '😕';
    if (excitement > 0.7) return '😃';
    if (confidence > 0.7) return '😎';
    if (calmness > 0.7) return '😌';
    
    return '😊';
  };
  
  const getEmotionColor = (emotion?: EmotionalState): string => {
    if (!emotion) return 'bg-gray-100';
    
    const { frustration, confidence, confusion, excitement, stress } = emotion;
    
    if (frustration > 0.7 || stress > 0.7) return 'bg-red-100';
    if (confusion > 0.7) return 'bg-yellow-100';
    if (excitement > 0.7 || confidence > 0.7) return 'bg-green-100';
    
    return 'bg-blue-100';
  };
  
  return (
    <div className="voice-interface p-6 max-w-2xl mx-auto">
      {/* Voice Button */}
      <div className="text-center mb-8">
        <button
          onClick={toggleListening}
          className={`
            voice-button relative w-32 h-32 rounded-full transition-all duration-300
            ${state.isListening 
              ? 'bg-green-500 hover:bg-green-600 scale-110 animate-pulse' 
              : 'bg-gray-700 hover:bg-gray-600'
            }
            shadow-lg hover:shadow-xl
          `}
          aria-label={state.isListening ? 'Stop listening' : 'Start listening'}
        >
          <div className="absolute inset-0 flex items-center justify-center">
            {state.isListening ? (
              <svg className="w-16 h-16 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 14a2 2 0 01-2-2V6a2 2 0 114 0v6a2 2 0 01-2 2z"/>
                <path d="M12 18a6 6 0 006-6h-2a4 4 0 11-8 0H6a6 6 0 006 6z"/>
              </svg>
            ) : (
              <svg className="w-16 h-16 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 14a2 2 0 002-2V6a2 2 0 10-4 0v6a2 2 0 002 2z"/>
                <path d="M12 18a6 6 0 01-6-6h2a4 4 0 108 0h2a6 6 0 01-6 6z"/>
                <line x1="12" y1="18" x2="12" y2="22" stroke="currentColor" strokeWidth="2"/>
                <line x1="8" y1="22" x2="16" y2="22" stroke="currentColor" strokeWidth="2"/>
              </svg>
            )}
          </div>
          
          {/* Ripple effect when listening */}
          {state.isListening && (
            <>
              <div className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-25"></div>
              <div className="absolute inset-0 rounded-full bg-green-400 animate-ping animation-delay-200 opacity-25"></div>
            </>
          )}
        </button>
        
        <p className="mt-4 text-sm text-gray-600">
          {state.isListening ? 'Listening... Speak naturally!' : 'Click to start voice input'}
        </p>
      </div>
      
      {/* Audio Visualizer */}
      <div className="mb-6">
        <canvas
          ref={audioVisualizerRef}
          width={600}
          height={100}
          className="w-full h-24 bg-gray-50 rounded-lg"
        />
      </div>
      
      {/* Transcription Display */}
      {(state.transcription || state.partialTranscription) && (
        <div className={`mb-6 p-4 rounded-lg ${getEmotionColor(state.emotion)}`}>
          <div className="flex items-start space-x-3">
            <span className="text-2xl">{getEmotionEmoji(state.emotion)}</span>
            <div className="flex-1">
              <p className="text-sm text-gray-600 mb-1">You said:</p>
              <p className="text-lg">
                {state.transcription}
                {state.partialTranscription && (
                  <span className="text-gray-400 italic"> {state.partialTranscription}</span>
                )}
              </p>
            </div>
          </div>
          
          {/* Emotion indicators */}
          {state.emotion && (
            <div className="mt-3 flex items-center space-x-4 text-xs text-gray-600">
              {state.emotion.frustration > 0.5 && (
                <span>Frustration detected</span>
              )}
              {state.emotion.confusion > 0.5 && (
                <span>Seems confusing</span>
              )}
              {state.emotion.needsHelp > 0.7 && (
                <span>Let me help more</span>
              )}
            </div>
          )}
        </div>
      )}
      
      {/* Confirmation Dialog */}
      {state.confirmationPending && (
        <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="mb-3">{state.confirmationPending.message}</p>
          <div className="flex space-x-3">
            <button
              onClick={() => handleConfirmation(true)}
              className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
            >
              Yes, do it
            </button>
            <button
              onClick={() => handleConfirmation(false)}
              className="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700"
            >
              No, cancel
            </button>
          </div>
        </div>
      )}
      
      {/* Error Display */}
      {state.error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          <p className="font-medium">Oops!</p>
          <p>{state.error}</p>
        </div>
      )}
      
      {/* Voice Tips */}
      <div className="mt-8 p-4 bg-gray-50 rounded-lg">
        <h3 className="font-medium mb-2">Voice Tips:</h3>
        <ul className="text-sm text-gray-600 space-y-1">
          <li>• Speak naturally - no need for robot talk!</li>
          <li>• Say "no wait" or "I meant" to correct</li>
          <li>• Pause when you're done speaking</li>
          <li>• I'll understand "um" and "uh" just fine</li>
          <li>• Try: "Install Firefox" or "Update my system"</li>
        </ul>
      </div>
      
      {/* Accessibility */}
      <div className="sr-only" aria-live="polite" aria-atomic="true">
        {state.isListening && 'Voice recognition active'}
        {state.transcription && `You said: ${state.transcription}`}
        {state.error && `Error: ${state.error}`}
      </div>
    </div>
  );
};