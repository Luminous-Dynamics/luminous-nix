/**
 * Voice to NLP Pipeline
 * Connects Whisper transcription to natural language processing
 * Maintains conversation context and handles voice-specific challenges
 */

import { EventEmitter } from 'events';
import { WhisperIntegration, TranscriptionResult } from './whisper-integration';
import { NLPEngine } from '../nlp/nlp-engine';
import { PersonalityAdaptationEngine } from '../personality/personality-adaptation-engine';
import { EmotionalState } from '../voice-emotion/types';
import { CommandResult } from '../types';

export interface VoiceContext {
  // Current conversation state
  isListening: boolean;
  lastTranscription?: TranscriptionResult;
  lastEmotion?: EmotionalState;
  conversationHistory: ConversationTurn[];
  
  // Voice-specific context
  speakingSpeed: 'slow' | 'normal' | 'fast';
  accentConfidence: number;
  backgroundNoise: 'quiet' | 'moderate' | 'noisy';
  
  // User preferences learned
  preferredWakeWord?: string;
  typicalPhrases: string[];
  voiceProfile?: VoiceProfile;
}

export interface ConversationTurn {
  timestamp: Date;
  userInput: string;
  systemResponse: string;
  emotion?: EmotionalState;
  success: boolean;
}

export interface VoiceProfile {
  // Acoustic characteristics
  pitchRange: { min: number; max: number };
  typicalVolume: number;
  speechRate: number;
  
  // Linguistic patterns
  fillerWords: string[]; // "um", "uh", "like"
  commonMispronunciations: Map<string, string>;
  dialectVariations: Map<string, string>;
}

export class VoiceToNLPPipeline extends EventEmitter {
  private whisper: WhisperIntegration;
  private nlp: NLPEngine;
  private personality: PersonalityAdaptationEngine;
  private context: VoiceContext;
  
  // Voice-specific processing
  private pendingUtterance: string = '';
  private correctionBuffer: string[] = [];
  private confirmationPending: boolean = false;
  
  constructor(whisperConfig: any) {
    super();
    
    this.whisper = new WhisperIntegration(whisperConfig);
    this.nlp = new NLPEngine();
    this.personality = new PersonalityAdaptationEngine();
    
    this.context = {
      isListening: false,
      conversationHistory: [],
      speakingSpeed: 'normal',
      accentConfidence: 1.0,
      backgroundNoise: 'quiet',
      typicalPhrases: []
    };
    
    this.setupEventHandlers();
  }
  
  /**
   * Set up event handlers for the pipeline
   */
  private setupEventHandlers(): void {
    // Handle transcription results
    this.whisper.on('transcription', async (result: TranscriptionResult) => {
      await this.handleTranscription(result);
    });
    
    // Handle emotion detection
    this.whisper.on('emotion-detected', (emotion: EmotionalState) => {
      this.context.lastEmotion = emotion;
      this.personality.updateEmotionalContext(emotion);
    });
    
    // Handle silence (end of utterance)
    this.whisper.on('silence-detected', () => {
      if (this.pendingUtterance) {
        this.processCompleteUtterance();
      }
    });
    
    // Handle errors
    this.whisper.on('error', (error: Error) => {
      this.emit('error', error);
    });
  }
  
  /**
   * Start voice interaction
   */
  async startListening(): Promise<void> {
    this.context.isListening = true;
    await this.whisper.startListening();
    this.emit('ready', 'Listening for your voice...');
  }
  
  /**
   * Stop voice interaction
   */
  async stopListening(): Promise<void> {
    this.context.isListening = false;
    await this.whisper.stopListening();
    this.emit('stopped');
  }
  
  /**
   * Handle incoming transcription
   */
  private async handleTranscription(result: TranscriptionResult): Promise<void> {
    this.context.lastTranscription = result;
    
    // Apply voice-specific corrections
    const corrected = await this.applyVoiceCorrections(result.text);
    
    // Handle incremental speech
    if (this.isIncremental(corrected)) {
      this.pendingUtterance += ' ' + corrected;
      this.emit('partial-transcription', this.pendingUtterance);
    } else {
      // Complete utterance
      const fullUtterance = this.pendingUtterance + ' ' + corrected;
      this.pendingUtterance = '';
      
      await this.processUtterance(fullUtterance.trim(), result);
    }
  }
  
  /**
   * Apply voice-specific corrections
   */
  private async applyVoiceCorrections(text: string): Promise<string> {
    let corrected = text;
    
    // Remove filler words based on user profile
    if (this.context.voiceProfile?.fillerWords) {
      for (const filler of this.context.voiceProfile.fillerWords) {
        corrected = corrected.replace(new RegExp(`\\b${filler}\\b`, 'gi'), '');
      }
    }
    
    // Apply known mispronunciation corrections
    if (this.context.voiceProfile?.commonMispronunciations) {
      for (const [wrong, right] of this.context.voiceProfile.commonMispronunciations) {
        corrected = corrected.replace(new RegExp(wrong, 'gi'), right);
      }
    }
    
    // Handle common voice transcription errors
    corrected = this.fixCommonTranscriptionErrors(corrected);
    
    // Clean up spacing and punctuation
    corrected = corrected.replace(/\s+/g, ' ').trim();
    
    return corrected;
  }
  
  /**
   * Fix common voice transcription errors
   */
  private fixCommonTranscriptionErrors(text: string): string {
    const corrections = {
      // Common NixOS-related corrections
      'next OS': 'NixOS',
      'nicks OS': 'NixOS',
      'mix OS': 'NixOS',
      'fire fox': 'firefox',
      'V S code': 'VS Code',
      'get hub': 'GitHub',
      
      // Common command corrections
      'in stall': 'install',
      'up date': 'update',
      'system D': 'systemd',
      
      // Natural speech patterns
      'can you please': 'please',
      'I want to': '',
      'I need to': '',
      'could you': 'please',
      'would you': 'please'
    };
    
    let corrected = text;
    for (const [pattern, replacement] of Object.entries(corrections)) {
      corrected = corrected.replace(new RegExp(pattern, 'gi'), replacement);
    }
    
    return corrected;
  }
  
  /**
   * Check if transcription is incremental (not complete)
   */
  private isIncremental(text: string): boolean {
    // Heuristics for incomplete utterances
    const incompletePatterns = [
      /\b(and|or|but|with|for|to|of)$/i,
      /\b(the|a|an)$/i,
      /\b(install|update|show|get|find)$/i,
      /[,]$/
    ];
    
    return incompletePatterns.some(pattern => pattern.test(text.trim()));
  }
  
  /**
   * Process when silence indicates end of utterance
   */
  private async processCompleteUtterance(): Promise<void> {
    if (!this.pendingUtterance) return;
    
    const utterance = this.pendingUtterance.trim();
    this.pendingUtterance = '';
    
    await this.processUtterance(utterance, this.context.lastTranscription!);
  }
  
  /**
   * Process a complete utterance
   */
  private async processUtterance(
    utterance: string, 
    transcription: TranscriptionResult
  ): Promise<void> {
    // Skip empty utterances
    if (!utterance || utterance.length < 2) {
      return;
    }
    
    // Check for corrections
    if (this.isCorrection(utterance)) {
      await this.handleCorrection(utterance);
      return;
    }
    
    // Check for confirmations
    if (this.confirmationPending && this.isConfirmation(utterance)) {
      await this.handleConfirmation(utterance);
      return;
    }
    
    // Process as new command
    try {
      // Parse with NLP
      const nlpResult = await this.nlp.parse(utterance);
      
      // Add emotional context
      if (this.context.lastEmotion) {
        nlpResult.emotionalContext = this.context.lastEmotion;
      }
      
      // Check if we need confirmation
      if (this.needsConfirmation(nlpResult)) {
        await this.requestConfirmation(nlpResult);
        return;
      }
      
      // Execute the command
      const result = await this.executeCommand(nlpResult);
      
      // Add to conversation history
      this.context.conversationHistory.push({
        timestamp: new Date(),
        userInput: utterance,
        systemResponse: result.response,
        emotion: this.context.lastEmotion,
        success: result.success
      });
      
      // Learn from interaction
      await this.learnFromInteraction(utterance, nlpResult, result);
      
      // Emit result
      this.emit('command-result', result);
      
    } catch (error) {
      this.handleProcessingError(utterance, error as Error);
    }
  }
  
  /**
   * Check if utterance is a correction
   */
  private isCorrection(utterance: string): boolean {
    const correctionPatterns = [
      /^(no|not|sorry|wait)/i,
      /^I (?:meant|said)/i,
      /^actually/i,
      /instead/i
    ];
    
    return correctionPatterns.some(pattern => pattern.test(utterance));
  }
  
  /**
   * Handle corrections
   */
  private async handleCorrection(correction: string): Promise<void> {
    // Get the last command from history
    const lastTurn = this.context.conversationHistory[this.context.conversationHistory.length - 1];
    if (!lastTurn) return;
    
    // Parse the correction
    const correctionIntent = this.parseCorrectionIntent(correction, lastTurn.userInput);
    
    // Apply correction and reprocess
    const correctedInput = this.applyCorrectionToInput(lastTurn.userInput, correctionIntent);
    
    this.emit('correction-applied', {
      original: lastTurn.userInput,
      correction: correction,
      corrected: correctedInput
    });
    
    // Process the corrected command
    await this.processUtterance(correctedInput, this.context.lastTranscription!);
  }
  
  /**
   * Check if utterance is a confirmation
   */
  private isConfirmation(utterance: string): boolean {
    const confirmPatterns = [
      /^(yes|yeah|yep|sure|okay|ok|correct|right|go ahead|do it)$/i,
      /^(no|nope|cancel|stop|wait|wrong)$/i
    ];
    
    return confirmPatterns.some(pattern => pattern.test(utterance.trim()));
  }
  
  /**
   * Check if command needs confirmation
   */
  private needsConfirmation(nlpResult: any): boolean {
    // Destructive or system-wide operations need confirmation
    const needsConfirm = [
      'system.update',
      'package.remove',
      'service.stop',
      'config.modify'
    ];
    
    return needsConfirm.includes(nlpResult.intent);
  }
  
  /**
   * Request confirmation from user
   */
  private async requestConfirmation(nlpResult: any): Promise<void> {
    this.confirmationPending = true;
    
    const confirmMessage = this.personality.generateConfirmationMessage(nlpResult);
    
    this.emit('confirmation-needed', {
      command: nlpResult,
      message: confirmMessage
    });
  }
  
  /**
   * Execute the processed command
   */
  private async executeCommand(nlpResult: any): Promise<CommandResult> {
    // This would integrate with the actual command execution system
    // For now, return a simulated result
    return {
      success: true,
      response: this.personality.generateResponse(nlpResult, true),
      command: nlpResult.command,
      output: 'Command executed successfully'
    };
  }
  
  /**
   * Learn from the interaction
   */
  private async learnFromInteraction(
    utterance: string, 
    nlpResult: any, 
    result: CommandResult
  ): Promise<void> {
    // Update voice profile
    this.updateVoiceProfile(utterance);
    
    // Learn phrase patterns
    if (result.success) {
      this.context.typicalPhrases.push(utterance);
      
      // Keep only recent phrases
      if (this.context.typicalPhrases.length > 100) {
        this.context.typicalPhrases = this.context.typicalPhrases.slice(-100);
      }
    }
    
    // Update personality based on interaction
    await this.personality.learn({
      input: utterance,
      intent: nlpResult.intent,
      emotion: this.context.lastEmotion,
      success: result.success
    });
  }
  
  /**
   * Update voice profile based on utterance
   */
  private updateVoiceProfile(utterance: string): void {
    // This would analyze speech patterns over time
    // For now, we'll just track basic patterns
    
    // Detect filler words
    const fillers = ['um', 'uh', 'like', 'you know', 'I mean'];
    const detectedFillers = fillers.filter(filler => 
      new RegExp(`\\b${filler}\\b`, 'i').test(utterance)
    );
    
    if (detectedFillers.length > 0 && this.context.voiceProfile) {
      this.context.voiceProfile.fillerWords = [
        ...new Set([...this.context.voiceProfile.fillerWords, ...detectedFillers])
      ];
    }
  }
  
  /**
   * Handle processing errors
   */
  private handleProcessingError(utterance: string, error: Error): void {
    console.error('Error processing utterance:', error);
    
    const errorResponse = this.personality.generateErrorResponse(error, {
      isVoice: true,
      emotion: this.context.lastEmotion
    });
    
    this.emit('error', {
      utterance,
      error: error.message,
      response: errorResponse
    });
  }
  
  /**
   * Parse correction intent
   */
  private parseCorrectionIntent(correction: string, original: string): any {
    // Simple correction parsing
    // In practice, this would be more sophisticated
    
    if (correction.includes('not')) {
      return { type: 'negation' };
    }
    
    if (correction.includes('instead')) {
      const match = correction.match(/(.+)\s+instead/i);
      if (match) {
        return { type: 'replacement', replacement: match[1] };
      }
    }
    
    return { type: 'full-replacement', replacement: correction };
  }
  
  /**
   * Apply correction to original input
   */
  private applyCorrectionToInput(original: string, correctionIntent: any): string {
    switch (correctionIntent.type) {
      case 'negation':
        // Add "don't" or similar
        return original.replace(/^(\w+)/, "don't $1");
        
      case 'replacement':
        // Replace last significant word
        const words = original.split(' ');
        words[words.length - 1] = correctionIntent.replacement;
        return words.join(' ');
        
      case 'full-replacement':
        return correctionIntent.replacement;
        
      default:
        return original;
    }
  }
  
  /**
   * Handle confirmation response
   */
  private async handleConfirmation(response: string): Promise<void> {
    this.confirmationPending = false;
    
    const isPositive = /^(yes|yeah|yep|sure|okay|ok|correct|right|go ahead|do it)$/i.test(response);
    
    this.emit('confirmation-received', {
      confirmed: isPositive,
      response
    });
  }
}