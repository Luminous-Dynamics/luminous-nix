/**
 * Adaptive UI Demo
 * Demonstrates the three-stage evolution system
 */

import React, { useState } from 'react';
import { AdaptiveUIContainer } from './components/AdaptiveUIContainer';
import { PersonalityStyle } from '../personality/types';

export const AdaptiveUIDemo: React.FC = () => {
  const [selectedPersonality, setSelectedPersonality] = useState<PersonalityStyle>(
    PersonalityStyle.FRIENDLY
  );
  const [commandLog, setCommandLog] = useState<string[]>([]);
  const [showDemo, setShowDemo] = useState(false);

  const handleCommand = async (command: string, params?: any): Promise<any> => {
    // Simulate command processing
    const logEntry = params?.query || command;
    setCommandLog(prev => [`${new Date().toLocaleTimeString()}: ${logEntry}`, ...prev.slice(0, 19)]);

    // Simulate async processing
    await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));

    // Simulate occasional errors for testing
    if (Math.random() < 0.1) {
      throw new Error('Simulated error for testing');
    }

    return {
      success: true,
      message: `Executed: ${logEntry}`
    };
  };

  return (
    <div className="adaptive-ui-demo">
      {!showDemo ? (
        <div className="demo-setup">
          <h1>Nix for Humanity - Adaptive UI Demo</h1>
          <p>Experience how the interface evolves with your mastery!</p>

          <div className="personality-selector">
            <h3>Choose Your Starting Personality:</h3>
            <div className="personality-options">
              {Object.entries({
                [PersonalityStyle.MINIMAL]: { label: 'Minimal', icon: '🤖' },
                [PersonalityStyle.FRIENDLY]: { label: 'Friendly', icon: '😊' },
                [PersonalityStyle.ENCOURAGING]: { label: 'Encouraging', icon: '🌟' },
                [PersonalityStyle.PLAYFUL]: { label: 'Playful', icon: '🎮' },
                [PersonalityStyle.SACRED]: { label: 'Sacred', icon: '🕉️' }
              }).map(([style, { label, icon }]) => (
                <button
                  key={style}
                  className={`personality-option ${selectedPersonality === style ? 'selected' : ''}`}
                  onClick={() => setSelectedPersonality(style as PersonalityStyle)}
                >
                  <span className="icon">{icon}</span>
                  <span className="label">{label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="stage-explanation">
            <h3>The Three Stages:</h3>
            <div className="stages">
              <div className="stage">
                <h4>🏛️ Sanctuary</h4>
                <p>Rich visual guidance for beginners. Everything is explained clearly.</p>
              </div>
              <div className="stage">
                <h4>🏃 Gymnasium</h4>
                <p>Adaptive learning phase. Shortcuts appear, interface streamlines.</p>
              </div>
              <div className="stage">
                <h4>🌅 Open Sky</h4>
                <p>Invisible excellence. The interface nearly disappears.</p>
              </div>
            </div>
          </div>

          <button 
            className="start-demo"
            onClick={() => setShowDemo(true)}
          >
            Start Demo with {PersonalityStyle[selectedPersonality]} Personality
          </button>
        </div>
      ) : (
        <div className="demo-container">
          <AdaptiveUIContainer
            personality={selectedPersonality}
            onCommand={handleCommand}
            userId="demo-user"
          />

          {/* Command log sidebar */}
          <div className="command-log">
            <h4>Command History</h4>
            <div className="log-entries">
              {commandLog.length === 0 ? (
                <p className="empty">No commands yet...</p>
              ) : (
                commandLog.map((entry, i) => (
                  <div key={i} className="log-entry">{entry}</div>
                ))
              )}
            </div>
            <button 
              className="reset-demo"
              onClick={() => {
                setShowDemo(false);
                setCommandLog([]);
                localStorage.removeItem('adaptive-ui-state-demo-user');
              }}
            >
              Reset Demo
            </button>
          </div>
        </div>
      )}

      <style jsx>{`
        .adaptive-ui-demo {
          min-height: 100vh;
          font-family: -apple-system, system-ui, sans-serif;
        }

        .demo-setup {
          max-width: 800px;
          margin: 0 auto;
          padding: 2rem;
        }

        .demo-setup h1 {
          text-align: center;
          color: #1976d2;
          margin-bottom: 0.5rem;
        }

        .demo-setup > p {
          text-align: center;
          color: #666;
          margin-bottom: 3rem;
        }

        .personality-selector {
          background: white;
          border-radius: 12px;
          padding: 2rem;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
          margin-bottom: 2rem;
        }

        .personality-selector h3 {
          margin-bottom: 1.5rem;
          color: #333;
        }

        .personality-options {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 1rem;
        }

        .personality-option {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 0.5rem;
          padding: 1.5rem 1rem;
          background: #f5f5f5;
          border: 2px solid transparent;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.2s;
        }

        .personality-option:hover {
          background: #eeeeee;
          transform: translateY(-2px);
        }

        .personality-option.selected {
          background: #e3f2fd;
          border-color: #1976d2;
        }

        .personality-option .icon {
          font-size: 2rem;
        }

        .personality-option .label {
          font-weight: 500;
          color: #333;
        }

        .stage-explanation {
          background: white;
          border-radius: 12px;
          padding: 2rem;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
          margin-bottom: 2rem;
        }

        .stage-explanation h3 {
          margin-bottom: 1.5rem;
          color: #333;
        }

        .stages {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1.5rem;
        }

        .stage {
          padding: 1.5rem;
          background: #f8f9fa;
          border-radius: 8px;
        }

        .stage h4 {
          margin: 0 0 0.5rem 0;
          color: #1976d2;
        }

        .stage p {
          margin: 0;
          color: #666;
          font-size: 0.9rem;
        }

        .start-demo {
          display: block;
          margin: 0 auto;
          padding: 1rem 2rem;
          background: #1976d2;
          color: white;
          border: none;
          border-radius: 8px;
          font-size: 1.125rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
        }

        .start-demo:hover {
          background: #1565c0;
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(25, 118, 210, 0.3);
        }

        .demo-container {
          position: relative;
          min-height: 100vh;
        }

        .command-log {
          position: fixed;
          top: 1rem;
          right: 1rem;
          width: 300px;
          max-height: calc(100vh - 2rem);
          background: rgba(0, 0, 0, 0.9);
          color: white;
          border-radius: 8px;
          padding: 1rem;
          overflow: hidden;
          display: flex;
          flex-direction: column;
        }

        .command-log h4 {
          margin: 0 0 1rem 0;
          font-size: 0.875rem;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          opacity: 0.7;
        }

        .log-entries {
          flex: 1;
          overflow-y: auto;
          font-family: 'SF Mono', Monaco, monospace;
          font-size: 0.75rem;
        }

        .log-entry {
          padding: 0.25rem 0;
          opacity: 0.8;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .log-entry:first-child {
          opacity: 1;
          color: #4caf50;
        }

        .empty {
          opacity: 0.5;
          font-style: italic;
        }

        .reset-demo {
          margin-top: 1rem;
          padding: 0.5rem 1rem;
          background: #f44336;
          color: white;
          border: none;
          border-radius: 4px;
          font-size: 0.875rem;
          cursor: pointer;
          transition: background 0.2s;
        }

        .reset-demo:hover {
          background: #d32f2f;
        }
      `}</style>
    </div>
  );
};