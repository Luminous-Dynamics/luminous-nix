/**
 * Adaptive UI Framework Exports
 * The three-stage evolution system for Nix for Humanity
 */

// Core framework
export {
  AdaptiveUIFramework,
  UIStage,
  type CompetencyMetric,
  type AdaptiveUIState,
  type UIRecommendations,
  type StageComponents
} from './adaptive-ui-framework';

// Components
export { SanctuaryStage } from './components/SanctuaryStage';
export { GymnasiumStage } from './components/GymnasiumStage';
export { OpenSkyStage } from './components/OpenSkyStage';
export { AdaptiveUIContainer } from './components/AdaptiveUIContainer';

// Hooks
export { useAdaptiveUI } from './hooks/useAdaptiveUI';

// Demo
export { AdaptiveUIDemo } from './AdaptiveUIDemo';