/**
 * Adaptive UI Framework
 * Implements the three-stage evolution: Sanctuary → Gymnasium → Open Sky
 */

import { PersonalityStyle } from '../personality/types';

export enum UIStage {
  SANCTUARY = 'sanctuary',      // Beginners: Maximum guidance
  GYMNASIUM = 'gymnasium',      // Learning: Progressive challenges
  OPEN_SKY = 'open-sky'        // Masters: Invisible excellence
}

export interface CompetencyMetric {
  feature: string;
  successCount: number;
  errorCount: number;
  lastUsed: Date;
  confidenceScore: number;  // 0.0 - 1.0
}

export interface AdaptiveUIState {
  // Core state
  currentStage: UIStage;
  personality: PersonalityStyle;
  
  // Evolution metrics
  overallCompetency: number;              // 0.0 - 1.0
  competencyMetrics: Map<string, CompetencyMetric>;
  sessionCount: number;
  totalInteractions: number;
  
  // Visual adaptation
  visualComplexity: number;               // 1.0 (full) → 0.1 (minimal)
  guidanceLevel: number;                  // 1.0 (maximum) → 0.0 (none)
  confirmationRequired: boolean;          // true → false with mastery
  animationDuration: number;              // 300ms → 0ms
  
  // Feature visibility
  visibleFeatures: Set<string>;
  hiddenFeatures: Set<string>;
  shortcuts: Map<string, string>;
  
  // User preferences (can override automatic)
  preferredComplexity?: number;
  lockedStage?: UIStage;
}

export class AdaptiveUIFramework {
  private state: AdaptiveUIState;
  private stageTransitionCallbacks: ((newStage: UIStage) => void)[] = [];
  
  constructor(personality: PersonalityStyle) {
    this.state = this.initializeState(personality);
  }
  
  /**
   * Initialize state based on personality
   */
  private initializeState(personality: PersonalityStyle): AdaptiveUIState {
    // Different personalities start at different stages
    const initialStage = this.getInitialStage(personality);
    
    return {
      currentStage: initialStage,
      personality,
      
      // Start as beginner
      overallCompetency: 0.0,
      competencyMetrics: new Map(),
      sessionCount: 1,
      totalInteractions: 0,
      
      // Visual settings for initial stage
      visualComplexity: initialStage === UIStage.SANCTUARY ? 1.0 : 0.7,
      guidanceLevel: initialStage === UIStage.SANCTUARY ? 1.0 : 0.5,
      confirmationRequired: initialStage === UIStage.SANCTUARY,
      animationDuration: initialStage === UIStage.SANCTUARY ? 300 : 150,
      
      // All features visible at start
      visibleFeatures: new Set([
        'install', 'remove', 'update', 'search',
        'help', 'status', 'settings'
      ]),
      hiddenFeatures: new Set(),
      shortcuts: new Map()
    };
  }
  
  /**
   * Get initial stage based on personality
   */
  private getInitialStage(personality: PersonalityStyle): UIStage {
    switch (personality) {
      case PersonalityStyle.MINIMAL:
        return UIStage.GYMNASIUM;  // Start more advanced
      case PersonalityStyle.PLAYFUL:
      case PersonalityStyle.ENCOURAGING:
        return UIStage.SANCTUARY;   // Start with full guidance
      default:
        return UIStage.SANCTUARY;
    }
  }
  
  /**
   * Record user interaction and update competency
   */
  recordInteraction(feature: string, success: boolean, timeToComplete?: number) {
    this.state.totalInteractions++;
    
    // Get or create metric
    let metric = this.state.competencyMetrics.get(feature);
    if (!metric) {
      metric = {
        feature,
        successCount: 0,
        errorCount: 0,
        lastUsed: new Date(),
        confidenceScore: 0.5
      };
      this.state.competencyMetrics.set(feature, metric);
    }
    
    // Update metric
    if (success) {
      metric.successCount++;
      metric.confidenceScore = Math.min(1.0, metric.confidenceScore + 0.1);
    } else {
      metric.errorCount++;
      metric.confidenceScore = Math.max(0.0, metric.confidenceScore - 0.2);
    }
    metric.lastUsed = new Date();
    
    // Quick success → higher confidence boost
    if (success && timeToComplete && timeToComplete < 5000) {
      metric.confidenceScore = Math.min(1.0, metric.confidenceScore + 0.05);
    }
    
    // Update overall competency
    this.updateOverallCompetency();
    
    // Check for stage transition
    this.checkStageTransition();
  }
  
  /**
   * Update overall competency score
   */
  private updateOverallCompetency() {
    const metrics = Array.from(this.state.competencyMetrics.values());
    if (metrics.length === 0) {
      this.state.overallCompetency = 0;
      return;
    }
    
    // Weighted average based on recency and frequency
    const now = Date.now();
    let totalWeight = 0;
    let weightedSum = 0;
    
    metrics.forEach(metric => {
      const recencyWeight = Math.exp(-(now - metric.lastUsed.getTime()) / (7 * 24 * 60 * 60 * 1000)); // Decay over week
      const frequencyWeight = Math.log(metric.successCount + 1);
      const weight = recencyWeight * frequencyWeight;
      
      totalWeight += weight;
      weightedSum += metric.confidenceScore * weight;
    });
    
    this.state.overallCompetency = totalWeight > 0 ? weightedSum / totalWeight : 0;
  }
  
  /**
   * Check if user should transition to new stage
   */
  private checkStageTransition() {
    // Don't transition if locked
    if (this.state.lockedStage) return;
    
    const competency = this.state.overallCompetency;
    const interactions = this.state.totalInteractions;
    const currentStage = this.state.currentStage;
    
    let newStage: UIStage | null = null;
    
    // Sanctuary → Gymnasium
    if (currentStage === UIStage.SANCTUARY) {
      if (competency > 0.6 && interactions > 20) {
        newStage = UIStage.GYMNASIUM;
      }
    }
    
    // Gymnasium → Open Sky
    else if (currentStage === UIStage.GYMNASIUM) {
      if (competency > 0.8 && interactions > 50) {
        newStage = UIStage.OPEN_SKY;
      }
      // Can go back to Sanctuary if struggling
      else if (competency < 0.3 && interactions > 10) {
        newStage = UIStage.SANCTUARY;
      }
    }
    
    // Open Sky → Can return to Gymnasium
    else if (currentStage === UIStage.OPEN_SKY) {
      if (competency < 0.5) {
        newStage = UIStage.GYMNASIUM;
      }
    }
    
    if (newStage) {
      this.transitionToStage(newStage);
    }
  }
  
  /**
   * Transition to new stage
   */
  private transitionToStage(newStage: UIStage) {
    this.state.currentStage = newStage;
    
    // Update visual parameters
    switch (newStage) {
      case UIStage.SANCTUARY:
        this.state.visualComplexity = 1.0;
        this.state.guidanceLevel = 1.0;
        this.state.confirmationRequired = true;
        this.state.animationDuration = 300;
        break;
        
      case UIStage.GYMNASIUM:
        this.state.visualComplexity = 0.7;
        this.state.guidanceLevel = 0.5;
        this.state.confirmationRequired = false;
        this.state.animationDuration = 150;
        this.enableShortcuts();
        break;
        
      case UIStage.OPEN_SKY:
        this.state.visualComplexity = 0.2;
        this.state.guidanceLevel = 0.0;
        this.state.confirmationRequired = false;
        this.state.animationDuration = 0;
        this.enableAdvancedFeatures();
        break;
    }
    
    // Notify listeners
    this.stageTransitionCallbacks.forEach(cb => cb(newStage));
  }
  
  /**
   * Enable shortcuts for gymnasium stage
   */
  private enableShortcuts() {
    this.state.shortcuts = new Map([
      ['i', 'install'],
      ['r', 'remove'],
      ['u', 'update'],
      ['s', 'search'],
      ['?', 'help']
    ]);
  }
  
  /**
   * Enable advanced features for open sky
   */
  private enableAdvancedFeatures() {
    this.state.visibleFeatures.add('batch-operations');
    this.state.visibleFeatures.add('command-palette');
    this.state.visibleFeatures.add('predictive-actions');
    
    // Hide basic UI elements
    this.state.hiddenFeatures.add('help-tooltips');
    this.state.hiddenFeatures.add('confirmation-dialogs');
    this.state.hiddenFeatures.add('tutorial-hints');
  }
  
  /**
   * Get UI recommendations for current state
   */
  getUIRecommendations(): UIRecommendations {
    const stage = this.state.currentStage;
    const personality = this.state.personality;
    
    return {
      // Visual density
      showLabels: stage === UIStage.SANCTUARY,
      showIcons: true,
      showDescriptions: stage !== UIStage.OPEN_SKY,
      
      // Interaction patterns  
      requireConfirmation: this.state.confirmationRequired,
      showProgress: stage !== UIStage.OPEN_SKY,
      animationSpeed: this.state.animationDuration,
      
      // Guidance
      showTooltips: this.state.guidanceLevel > 0.3,
      showHints: this.state.guidanceLevel > 0.5,
      showTutorial: stage === UIStage.SANCTUARY && this.state.sessionCount <= 3,
      
      // Features
      enableShortcuts: stage !== UIStage.SANCTUARY,
      enableCommandPalette: stage === UIStage.OPEN_SKY,
      enablePredictive: stage === UIStage.OPEN_SKY,
      
      // Personality adjustments
      useEmoji: personality === PersonalityStyle.PLAYFUL,
      useEncouragement: personality === PersonalityStyle.ENCOURAGING,
      useMindfulness: personality === PersonalityStyle.SACRED
    };
  }
  
  /**
   * Get stage-specific UI components
   */
  getStageComponents(): StageComponents {
    switch (this.state.currentStage) {
      case UIStage.SANCTUARY:
        return {
          primaryInput: 'guided-form',
          feedback: 'detailed-confirmation',
          navigation: 'step-by-step',
          help: 'always-visible'
        };
        
      case UIStage.GYMNASIUM:
        return {
          primaryInput: 'smart-searchbar',
          feedback: 'subtle-notification',
          navigation: 'searchable-menu',
          help: 'on-demand'
        };
        
      case UIStage.OPEN_SKY:
        return {
          primaryInput: 'command-palette',
          feedback: 'peripheral-glow',
          navigation: 'keyboard-only',
          help: 'hidden'
        };
    }
  }
  
  /**
   * Manual stage override (user preference)
   */
  setPreferredStage(stage: UIStage, lock: boolean = false) {
    this.transitionToStage(stage);
    if (lock) {
      this.state.lockedStage = stage;
    }
  }
  
  /**
   * Subscribe to stage transitions
   */
  onStageTransition(callback: (newStage: UIStage) => void) {
    this.stageTransitionCallbacks.push(callback);
  }
  
  /**
   * Get current state for persistence
   */
  getState(): AdaptiveUIState {
    return { ...this.state };
  }
  
  /**
   * Restore from saved state
   */
  restoreState(state: Partial<AdaptiveUIState>) {
    this.state = { ...this.state, ...state };
  }
}

// Type definitions
export interface UIRecommendations {
  // Visual
  showLabels: boolean;
  showIcons: boolean;
  showDescriptions: boolean;
  
  // Interaction
  requireConfirmation: boolean;
  showProgress: boolean;
  animationSpeed: number;
  
  // Guidance
  showTooltips: boolean;
  showHints: boolean;
  showTutorial: boolean;
  
  // Features
  enableShortcuts: boolean;
  enableCommandPalette: boolean;
  enablePredictive: boolean;
  
  // Personality
  useEmoji: boolean;
  useEncouragement: boolean;
  useMindfulness: boolean;
}

export interface StageComponents {
  primaryInput: 'guided-form' | 'smart-searchbar' | 'command-palette';
  feedback: 'detailed-confirmation' | 'subtle-notification' | 'peripheral-glow';
  navigation: 'step-by-step' | 'searchable-menu' | 'keyboard-only';
  help: 'always-visible' | 'on-demand' | 'hidden';
}