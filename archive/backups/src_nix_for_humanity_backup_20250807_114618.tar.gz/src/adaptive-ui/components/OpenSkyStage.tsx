/**
 * Open Sky Stage Component
 * Invisible excellence - interface fades to almost nothing
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { UIStage, UIRecommendations } from '../adaptive-ui-framework';

interface OpenSkyStageProps {
  recommendations: UIRecommendations;
  onAction: (action: string, params?: any) => void;
  peripheralGlow?: {
    type: 'success' | 'working' | 'attention' | 'none';
    intensity: number;
  };
}

export const OpenSkyStage: React.FC<OpenSkyStageProps> = ({
  recommendations,
  onAction,
  peripheralGlow = { type: 'none', intensity: 0 }
}) => {
  const [isTyping, setIsTyping] = useState(false);
  const [command, setCommand] = useState('');
  const [showInterface, setShowInterface] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const hideTimeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    // Global keyboard listener for activation
    const handleGlobalKey = (e: KeyboardEvent) => {
      // Any alphanumeric key starts typing
      if (!showInterface && e.key.match(/^[a-zA-Z0-9]$/)) {
        setShowInterface(true);
        setCommand(e.key);
        setIsTyping(true);
      }
      
      // Escape hides interface
      if (e.key === 'Escape') {
        setShowInterface(false);
        setCommand('');
        setIsTyping(false);
      }
    };

    window.addEventListener('keydown', handleGlobalKey);
    return () => window.removeEventListener('keydown', handleGlobalKey);
  }, [showInterface]);

  useEffect(() => {
    // Focus input when interface shows
    if (showInterface && inputRef.current) {
      inputRef.current.focus();
      // Place cursor after pre-typed character
      inputRef.current.setSelectionRange(command.length, command.length);
    }
  }, [showInterface, command]);

  useEffect(() => {
    // Auto-hide interface after inactivity
    if (showInterface && !isTyping) {
      hideTimeoutRef.current = setTimeout(() => {
        setShowInterface(false);
        setCommand('');
      }, 3000);
    }

    return () => {
      if (hideTimeoutRef.current) {
        clearTimeout(hideTimeoutRef.current);
      }
    };
  }, [showInterface, isTyping]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (command.trim()) {
      onAction('natural', { query: command });
      setCommand('');
      setShowInterface(false);
      setIsTyping(false);
    }
  };

  const getGlowColor = () => {
    switch (peripheralGlow.type) {
      case 'success': return 'rgba(76, 175, 80, intensity)';
      case 'working': return 'rgba(33, 150, 243, intensity)';
      case 'attention': return 'rgba(255, 152, 0, intensity)';
      default: return 'transparent';
    }
  };

  return (
    <div className="opensky-stage">
      {/* Peripheral glow feedback */}
      <motion.div 
        className="peripheral-glow"
        animate={{
          boxShadow: peripheralGlow.type !== 'none' 
            ? `inset 0 0 ${100 * peripheralGlow.intensity}px ${getGlowColor().replace('intensity', String(peripheralGlow.intensity * 0.3))}`
            : 'none'
        }}
        transition={{ duration: 0.5 }}
      />

      {/* Minimal command interface */}
      <AnimatePresence>
        {showInterface && (
          <motion.div
            className="minimal-interface"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.15 }}
          >
            <form onSubmit={handleSubmit}>
              <input
                ref={inputRef}
                type="text"
                value={command}
                onChange={(e) => {
                  setCommand(e.target.value);
                  setIsTyping(true);
                }}
                onBlur={() => setIsTyping(false)}
                className="minimal-input"
                placeholder=""
                autoComplete="off"
                spellCheck={false}
              />
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Almost invisible hint */}
      {!showInterface && (
        <motion.div 
          className="invisible-hint"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.05 }}
          transition={{ delay: 2 }}
        >
          Type to begin
        </motion.div>
      )}

      <style jsx>{`
        .opensky-stage {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .peripheral-glow {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          pointer-events: none;
          transition: box-shadow 0.5s ease;
        }

        .minimal-interface {
          position: relative;
          z-index: 10;
        }

        .minimal-input {
          background: rgba(255, 255, 255, 0.9);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(0, 0, 0, 0.1);
          border-radius: 4px;
          padding: 0.75rem 1rem;
          font-size: 1rem;
          width: 400px;
          box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
          font-family: -apple-system, system-ui, sans-serif;
        }

        .minimal-input:focus {
          outline: none;
          border-color: rgba(0, 0, 0, 0.2);
        }

        .invisible-hint {
          position: absolute;
          bottom: 2rem;
          left: 50%;
          transform: translateX(-50%);
          font-size: 0.875rem;
          color: #000;
          pointer-events: none;
          user-select: none;
        }

        /* Ultra-minimal mode for true masters */
        @media (prefers-color-scheme: dark) {
          .minimal-input {
            background: rgba(0, 0, 0, 0.8);
            color: white;
            border-color: rgba(255, 255, 255, 0.1);
          }

          .minimal-input:focus {
            border-color: rgba(255, 255, 255, 0.2);
          }

          .invisible-hint {
            color: #fff;
          }
        }

        /* Even more minimal for reduced motion */
        @media (prefers-reduced-motion: reduce) {
          * {
            transition: none !important;
            animation: none !important;
          }
        }
      `}</style>
    </div>
  );
};