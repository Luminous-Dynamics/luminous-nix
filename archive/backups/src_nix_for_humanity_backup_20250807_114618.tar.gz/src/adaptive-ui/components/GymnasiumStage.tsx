/**
 * Gymnasium Stage Component
 * Adaptive learning with the user - balanced guidance
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { UIStage, UIRecommendations } from '../adaptive-ui-framework';

interface GymnasiumStageProps {
  recommendations: UIRecommendations;
  onAction: (action: string, params?: any) => void;
  shortcuts: Map<string, string>;
  recentCommands: string[];
}

export const GymnasiumStage: React.FC<GymnasiumStageProps> = ({
  recommendations,
  onAction,
  shortcuts,
  recentCommands
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showCommandPalette, setShowCommandPalette] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Focus search on mount
    searchInputRef.current?.focus();
  }, []);

  useEffect(() => {
    // Keyboard shortcuts
    const handleKeyDown = (e: KeyboardEvent) => {
      // Command palette
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setShowCommandPalette(true);
      }
      
      // Direct shortcuts when not typing
      if (!showCommandPalette && document.activeElement !== searchInputRef.current) {
        const action = shortcuts.get(e.key);
        if (action) {
          e.preventDefault();
          onAction(action);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [shortcuts, showCommandPalette, onAction]);

  const commonActions = [
    { id: 'install', label: 'Install', icon: '📦', shortcut: 'i' },
    { id: 'remove', label: 'Remove', icon: '🗑️', shortcut: 'r' },
    { id: 'update', label: 'Update', icon: '🔄', shortcut: 'u' },
    { id: 'search', label: 'Search', icon: '🔍', shortcut: 's' },
    { id: 'help', label: 'Help', icon: '❓', shortcut: '?' },
  ];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onAction('natural', { query: searchQuery });
      setSearchQuery('');
    }
  };

  return (
    <div className="gymnasium-stage">
      {/* Smart search bar */}
      <div className="search-container">
        <form onSubmit={handleSearchSubmit}>
          <motion.input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Type what you want to do..."
            className="smart-searchbar"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
          />
          {recommendations.showHints && (
            <motion.div 
              className="search-hint"
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
            >
              Press Enter to submit or Ctrl+K for command palette
            </motion.div>
          )}
        </form>
      </div>

      {/* Quick actions with shortcuts */}
      <div className="quick-actions">
        {commonActions.map((action) => (
          <motion.button
            key={action.id}
            className="action-button"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onAction(action.id)}
            title={`Shortcut: ${action.shortcut}`}
          >
            <span className="action-icon">{action.icon}</span>
            <span className="action-label">{action.label}</span>
            <span className="action-shortcut">{action.shortcut}</span>
          </motion.button>
        ))}
      </div>

      {/* Recent commands - learning from user */}
      {recentCommands.length > 0 && (
        <motion.div 
          className="recent-section"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <h3>Recent</h3>
          <div className="recent-commands">
            {recentCommands.slice(0, 5).map((cmd, i) => (
              <motion.button
                key={i}
                className="recent-command"
                whileHover={{ x: 5 }}
                onClick={() => onAction('repeat', { command: cmd })}
              >
                {cmd}
              </motion.button>
            ))}
          </div>
        </motion.div>
      )}

      {/* Command palette */}
      <AnimatePresence>
        {showCommandPalette && (
          <motion.div
            className="command-palette-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowCommandPalette(false)}
          >
            <motion.div
              className="command-palette"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
            >
              <input
                type="text"
                placeholder="Type a command..."
                className="command-input"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Escape') setShowCommandPalette(false);
                }}
              />
              <div className="command-list">
                {/* Command suggestions would go here */}
                <div className="command-item">Install package...</div>
                <div className="command-item">Update system</div>
                <div className="command-item">Check status</div>
                <div className="command-item">View logs</div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Subtle status indicators */}
      {recommendations.showProgress && (
        <motion.div 
          className="status-bar"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.6 }}
        >
          <div className="status-item">Ready</div>
          <div className="status-item">No updates</div>
          <div className="status-item">All systems normal</div>
        </motion.div>
      )}

      <style jsx>{`
        .gymnasium-stage {
          max-width: 700px;
          margin: 0 auto;
          padding: 2rem;
        }

        .search-container {
          margin-bottom: 2rem;
        }

        .smart-searchbar {
          width: 100%;
          padding: 1rem 1.5rem;
          font-size: 1.125rem;
          border: 2px solid #e0e0e0;
          border-radius: 12px;
          transition: all 0.2s;
          background: white;
        }

        .smart-searchbar:focus {
          outline: none;
          border-color: #1976d2;
          box-shadow: 0 0 0 3px rgba(25, 118, 210, 0.1);
        }

        .search-hint {
          margin-top: 0.5rem;
          font-size: 0.875rem;
          color: #757575;
          text-align: center;
        }

        .quick-actions {
          display: flex;
          gap: 1rem;
          margin-bottom: 2rem;
          flex-wrap: wrap;
        }

        .action-button {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.75rem 1.25rem;
          background: white;
          border: 1px solid #e0e0e0;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.2s;
          position: relative;
        }

        .action-button:hover {
          border-color: #1976d2;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .action-icon {
          font-size: 1.25rem;
        }

        .action-label {
          font-weight: 500;
          color: #424242;
        }

        .action-shortcut {
          position: absolute;
          top: -8px;
          right: -8px;
          background: #1976d2;
          color: white;
          font-size: 0.75rem;
          padding: 2px 6px;
          border-radius: 4px;
          font-weight: 600;
        }

        .recent-section {
          margin-top: 3rem;
        }

        .recent-section h3 {
          color: #616161;
          font-size: 0.875rem;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          margin-bottom: 1rem;
        }

        .recent-commands {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .recent-command {
          padding: 0.75rem 1rem;
          background: #f5f5f5;
          border: none;
          border-radius: 6px;
          text-align: left;
          cursor: pointer;
          transition: all 0.2s;
          color: #424242;
        }

        .recent-command:hover {
          background: #eeeeee;
        }

        .command-palette-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
        }

        .command-palette {
          background: white;
          border-radius: 12px;
          width: 600px;
          max-width: 90%;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
          overflow: hidden;
        }

        .command-input {
          width: 100%;
          padding: 1.25rem;
          font-size: 1.125rem;
          border: none;
          border-bottom: 1px solid #e0e0e0;
        }

        .command-input:focus {
          outline: none;
        }

        .command-list {
          max-height: 400px;
          overflow-y: auto;
        }

        .command-item {
          padding: 1rem 1.25rem;
          cursor: pointer;
          transition: background 0.1s;
        }

        .command-item:hover {
          background: #f5f5f5;
        }

        .status-bar {
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          background: rgba(255, 255, 255, 0.95);
          border-top: 1px solid #e0e0e0;
          padding: 0.5rem 1rem;
          display: flex;
          gap: 2rem;
          font-size: 0.875rem;
          color: #757575;
        }

        .status-item {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        @media (prefers-reduced-motion: reduce) {
          * {
            animation: none !important;
            transition: none !important;
          }
        }
      `}</style>
    </div>
  );
};