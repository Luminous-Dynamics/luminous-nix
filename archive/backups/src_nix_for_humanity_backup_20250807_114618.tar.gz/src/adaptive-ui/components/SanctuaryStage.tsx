/**
 * Sanctuary Stage Component
 * Maximum guidance for beginners - everything is clear and explained
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { UIStage, UIRecommendations } from '../adaptive-ui-framework';

interface SanctuaryStageProps {
  recommendations: UIRecommendations;
  onAction: (action: string, params?: any) => void;
  currentHint?: string;
}

export const SanctuaryStage: React.FC<SanctuaryStageProps> = ({
  recommendations,
  onAction,
  currentHint
}) => {
  const [showTutorial, setShowTutorial] = useState(recommendations.showTutorial);
  const [currentStep, setCurrentStep] = useState(0);
  
  const tutorialSteps = [
    "Welcome! I'm here to help you navigate NixOS.",
    "You can type what you want to do in simple words.",
    "I'll guide you through each step with clear explanations.",
    "Let's start with something simple - what would you like to do?"
  ];

  return (
    <div className="sanctuary-stage">
      {/* Always-visible help */}
      <motion.div 
        className="help-banner"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="help-icon">💡</div>
        <div className="help-text">
          {currentHint || "Type what you want to do, like 'install firefox' or 'connect to wifi'"}
        </div>
      </motion.div>

      {/* Tutorial overlay */}
      <AnimatePresence>
        {showTutorial && (
          <motion.div
            className="tutorial-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="tutorial-card"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
            >
              <h3>Getting Started</h3>
              <p>{tutorialSteps[currentStep]}</p>
              <div className="tutorial-navigation">
                {currentStep < tutorialSteps.length - 1 ? (
                  <button 
                    onClick={() => setCurrentStep(currentStep + 1)}
                    className="btn-primary"
                  >
                    Next
                  </button>
                ) : (
                  <button 
                    onClick={() => setShowTutorial(false)}
                    className="btn-primary"
                  >
                    Let's Begin!
                  </button>
                )}
              </div>
              <div className="tutorial-dots">
                {tutorialSteps.map((_, i) => (
                  <span 
                    key={i} 
                    className={`dot ${i === currentStep ? 'active' : ''}`}
                  />
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Guided form interface */}
      <div className="guided-form">
        <div className="form-section">
          <h2>What would you like to do?</h2>
          
          {/* Common actions with clear labels and descriptions */}
          <div className="action-grid">
            <motion.button
              className="action-card"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onAction('install')}
            >
              <span className="action-icon">📦</span>
              <span className="action-label">Install Software</span>
              <span className="action-description">Add new programs to your computer</span>
            </motion.button>

            <motion.button
              className="action-card"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onAction('remove')}
            >
              <span className="action-icon">🗑️</span>
              <span className="action-label">Remove Software</span>
              <span className="action-description">Uninstall programs you don't need</span>
            </motion.button>

            <motion.button
              className="action-card"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onAction('update')}
            >
              <span className="action-icon">🔄</span>
              <span className="action-label">Update System</span>
              <span className="action-description">Get the latest versions of everything</span>
            </motion.button>

            <motion.button
              className="action-card"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onAction('settings')}
            >
              <span className="action-icon">⚙️</span>
              <span className="action-label">Change Settings</span>
              <span className="action-description">Adjust how your computer works</span>
            </motion.button>

            <motion.button
              className="action-card"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onAction('help')}
            >
              <span className="action-icon">❓</span>
              <span className="action-label">Get Help</span>
              <span className="action-description">Learn how to do something</span>
            </motion.button>

            <motion.button
              className="action-card"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onAction('status')}
            >
              <span className="action-icon">📊</span>
              <span className="action-label">Check Status</span>
              <span className="action-description">See what's happening on your system</span>
            </motion.button>
          </div>

          {/* Natural language input with clear prompt */}
          <div className="text-input-section">
            <label htmlFor="natural-input">Or describe what you need:</label>
            <input
              id="natural-input"
              type="text"
              placeholder="For example: 'My printer isn't working' or 'I want to play music'"
              className="natural-input"
              onKeyPress={(e) => {
                if (e.key === 'Enter' && e.currentTarget.value.trim()) {
                  onAction('natural', { query: e.currentTarget.value });
                  e.currentTarget.value = '';
                }
              }}
            />
            <span className="input-hint">Press Enter to submit</span>
          </div>
        </div>
      </div>

      <style jsx>{`
        .sanctuary-stage {
          max-width: 800px;
          margin: 0 auto;
          padding: 2rem;
        }

        .help-banner {
          background: linear-gradient(135deg, #e3f2fd 0%, #f3e5f5 100%);
          border-radius: 12px;
          padding: 1rem 1.5rem;
          display: flex;
          align-items: center;
          gap: 1rem;
          margin-bottom: 2rem;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .help-icon {
          font-size: 1.5rem;
        }

        .help-text {
          flex: 1;
          color: #424242;
          font-size: 1rem;
        }

        .tutorial-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
        }

        .tutorial-card {
          background: white;
          border-radius: 16px;
          padding: 2rem;
          max-width: 500px;
          width: 90%;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
        }

        .tutorial-card h3 {
          margin: 0 0 1rem 0;
          color: #1976d2;
        }

        .tutorial-navigation {
          margin-top: 2rem;
          display: flex;
          justify-content: flex-end;
        }

        .btn-primary {
          background: #1976d2;
          color: white;
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: 8px;
          font-size: 1rem;
          cursor: pointer;
          transition: background 0.2s;
        }

        .btn-primary:hover {
          background: #1565c0;
        }

        .tutorial-dots {
          display: flex;
          gap: 0.5rem;
          justify-content: center;
          margin-top: 1.5rem;
        }

        .dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #e0e0e0;
          transition: background 0.3s;
        }

        .dot.active {
          background: #1976d2;
        }

        .form-section h2 {
          color: #424242;
          margin-bottom: 1.5rem;
          font-size: 1.5rem;
        }

        .action-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1rem;
          margin-bottom: 2rem;
        }

        .action-card {
          background: white;
          border: 2px solid #e0e0e0;
          border-radius: 12px;
          padding: 1.5rem;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 0.5rem;
          cursor: pointer;
          transition: all 0.2s;
          text-align: center;
        }

        .action-card:hover {
          border-color: #1976d2;
          box-shadow: 0 4px 12px rgba(25, 118, 210, 0.1);
        }

        .action-icon {
          font-size: 2rem;
        }

        .action-label {
          font-weight: 600;
          color: #424242;
          font-size: 1rem;
        }

        .action-description {
          font-size: 0.875rem;
          color: #757575;
        }

        .text-input-section {
          margin-top: 2rem;
        }

        .text-input-section label {
          display: block;
          margin-bottom: 0.5rem;
          color: #424242;
          font-weight: 500;
        }

        .natural-input {
          width: 100%;
          padding: 1rem;
          font-size: 1rem;
          border: 2px solid #e0e0e0;
          border-radius: 8px;
          transition: border-color 0.2s;
        }

        .natural-input:focus {
          outline: none;
          border-color: #1976d2;
        }

        .input-hint {
          display: block;
          margin-top: 0.5rem;
          font-size: 0.875rem;
          color: #757575;
        }
      `}</style>
    </div>
  );
};