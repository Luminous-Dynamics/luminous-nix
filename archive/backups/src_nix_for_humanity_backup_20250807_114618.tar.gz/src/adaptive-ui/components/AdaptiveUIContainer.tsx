/**
 * Adaptive UI Container
 * Orchestrates the three stages based on user mastery
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  AdaptiveUIFramework, 
  UIStage, 
  UIRecommendations,
  CompetencyMetric 
} from '../adaptive-ui-framework';
import { PersonalityStyle } from '../../personality/types';
import { SanctuaryStage } from './SanctuaryStage';
import { GymnasiumStage } from './GymnasiumStage';
import { OpenSkyStage } from './OpenSkyStage';

interface AdaptiveUIContainerProps {
  personality: PersonalityStyle;
  onCommand: (command: string, params?: any) => Promise<any>;
  userId?: string;
}

export const AdaptiveUIContainer: React.FC<AdaptiveUIContainerProps> = ({
  personality,
  onCommand,
  userId = 'current-user'
}) => {
  const [framework] = useState(() => new AdaptiveUIFramework(personality));
  const [currentStage, setCurrentStage] = useState<UIStage>(UIStage.SANCTUARY);
  const [recommendations, setRecommendations] = useState<UIRecommendations>(
    framework.getUIRecommendations()
  );
  const [recentCommands, setRecentCommands] = useState<string[]>([]);
  const [currentHint, setCurrentHint] = useState<string>('');
  const [peripheralGlow, setPeripheralGlow] = useState({ 
    type: 'none' as const, 
    intensity: 0 
  });

  useEffect(() => {
    // Subscribe to stage transitions
    framework.onStageTransition((newStage) => {
      setCurrentStage(newStage);
      setRecommendations(framework.getUIRecommendations());
      
      // Announce transition
      announceTransition(newStage);
    });

    // Load saved state
    loadSavedState();
  }, [framework]);

  const loadSavedState = () => {
    const savedState = localStorage.getItem(`adaptive-ui-state-${userId}`);
    if (savedState) {
      try {
        const state = JSON.parse(savedState);
        framework.restoreState(state);
        setCurrentStage(state.currentStage);
        setRecentCommands(state.recentCommands || []);
      } catch (error) {
        console.error('Failed to restore UI state:', error);
      }
    }
  };

  const saveState = () => {
    const state = framework.getState();
    localStorage.setItem(`adaptive-ui-state-${userId}`, JSON.stringify({
      ...state,
      recentCommands
    }));
  };

  const announceTransition = (stage: UIStage) => {
    const messages = {
      [UIStage.SANCTUARY]: "Welcome! I'll guide you through everything step by step.",
      [UIStage.GYMNASIUM]: "You're getting the hang of this! Keyboard shortcuts are now available.",
      [UIStage.OPEN_SKY]: "You've achieved mastery. The interface is now minimal - just start typing."
    };
    
    // Could trigger a notification or subtle animation
    console.log(`🌟 Stage transition: ${messages[stage]}`);
  };

  const handleAction = async (action: string, params?: any) => {
    const startTime = Date.now();
    let success = false;

    try {
      // Show working state
      if (currentStage === UIStage.OPEN_SKY) {
        setPeripheralGlow({ type: 'working', intensity: 0.3 });
      }

      // Execute command
      const result = await onCommand(action, params);
      success = true;

      // Track success
      const duration = Date.now() - startTime;
      framework.recordInteraction(action, true, duration);

      // Update recent commands
      if (params?.query) {
        setRecentCommands(prev => [params.query, ...prev.slice(0, 9)]);
      }

      // Show success feedback
      if (currentStage === UIStage.OPEN_SKY) {
        setPeripheralGlow({ type: 'success', intensity: 0.5 });
        setTimeout(() => setPeripheralGlow({ type: 'none', intensity: 0 }), 1000);
      }

      // Save state
      saveState();

      return result;
    } catch (error) {
      // Track failure
      framework.recordInteraction(action, false);

      // Show error feedback
      if (currentStage === UIStage.OPEN_SKY) {
        setPeripheralGlow({ type: 'attention', intensity: 0.7 });
        setTimeout(() => setPeripheralGlow({ type: 'none', intensity: 0 }), 2000);
      }

      throw error;
    }
  };

  const getShortcuts = (): Map<string, string> => {
    const state = framework.getState();
    return state.shortcuts;
  };

  const renderStage = () => {
    switch (currentStage) {
      case UIStage.SANCTUARY:
        return (
          <SanctuaryStage
            recommendations={recommendations}
            onAction={handleAction}
            currentHint={currentHint}
          />
        );

      case UIStage.GYMNASIUM:
        return (
          <GymnasiumStage
            recommendations={recommendations}
            onAction={handleAction}
            shortcuts={getShortcuts()}
            recentCommands={recentCommands}
          />
        );

      case UIStage.OPEN_SKY:
        return (
          <OpenSkyStage
            recommendations={recommendations}
            onAction={handleAction}
            peripheralGlow={peripheralGlow}
          />
        );
    }
  };

  return (
    <div className={`adaptive-ui-container stage-${currentStage}`}>
      <AnimatePresence mode="wait">
        <motion.div
          key={currentStage}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          {renderStage()}
        </motion.div>
      </AnimatePresence>

      {/* Debug panel (only in development) */}
      {process.env.NODE_ENV === 'development' && (
        <div className="debug-panel">
          <h4>Debug Info</h4>
          <p>Stage: {currentStage}</p>
          <p>Competency: {framework.getState().overallCompetency.toFixed(2)}</p>
          <p>Interactions: {framework.getState().totalInteractions}</p>
          <button onClick={() => framework.setPreferredStage(UIStage.SANCTUARY)}>
            Force Sanctuary
          </button>
          <button onClick={() => framework.setPreferredStage(UIStage.GYMNASIUM)}>
            Force Gymnasium
          </button>
          <button onClick={() => framework.setPreferredStage(UIStage.OPEN_SKY)}>
            Force Open Sky
          </button>
        </div>
      )}

      <style jsx>{`
        .adaptive-ui-container {
          min-height: 100vh;
          background: #fafafa;
          transition: background 0.5s ease;
        }

        .adaptive-ui-container.stage-sanctuary {
          background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }

        .adaptive-ui-container.stage-gymnasium {
          background: #ffffff;
        }

        .adaptive-ui-container.stage-open-sky {
          background: #f8f9fa;
        }

        .debug-panel {
          position: fixed;
          bottom: 1rem;
          right: 1rem;
          background: rgba(0, 0, 0, 0.8);
          color: white;
          padding: 1rem;
          border-radius: 8px;
          font-size: 0.875rem;
          font-family: monospace;
        }

        .debug-panel h4 {
          margin: 0 0 0.5rem 0;
        }

        .debug-panel p {
          margin: 0.25rem 0;
        }

        .debug-panel button {
          display: block;
          margin-top: 0.5rem;
          padding: 0.25rem 0.5rem;
          background: #1976d2;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 0.75rem;
        }

        .debug-panel button:hover {
          background: #1565c0;
        }
      `}</style>
    </div>
  );
};