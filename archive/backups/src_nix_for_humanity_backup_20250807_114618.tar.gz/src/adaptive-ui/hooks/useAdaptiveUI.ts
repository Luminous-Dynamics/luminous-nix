/**
 * useAdaptiveUI Hook
 * Easy integration of adaptive UI functionality
 */

import { useState, useEffect, useCallback } from 'react';
import { 
  AdaptiveUIFramework, 
  UIStage, 
  UIRecommendations,
  AdaptiveUIState 
} from '../adaptive-ui-framework';
import { PersonalityStyle } from '../../personality/types';

interface UseAdaptiveUIOptions {
  personality: PersonalityStyle;
  userId?: string;
  onStageChange?: (stage: UIStage) => void;
  persistState?: boolean;
}

interface UseAdaptiveUIReturn {
  // Current state
  stage: UIStage;
  recommendations: UIRecommendations;
  competency: number;
  
  // Actions
  recordSuccess: (feature: string, duration?: number) => void;
  recordError: (feature: string) => void;
  setPreferredStage: (stage: UIStage, lock?: boolean) => void;
  
  // Utilities
  shouldShowFeature: (feature: string) => boolean;
  getAnimationDuration: () => number;
  isFeatureEnabled: (feature: string) => boolean;
}

export function useAdaptiveUI({
  personality,
  userId = 'current-user',
  onStageChange,
  persistState = true
}: UseAdaptiveUIOptions): UseAdaptiveUIReturn {
  const [framework] = useState(() => new AdaptiveUIFramework(personality));
  const [state, setState] = useState<AdaptiveUIState>(framework.getState());
  const [recommendations, setRecommendations] = useState<UIRecommendations>(
    framework.getUIRecommendations()
  );

  // Load saved state on mount
  useEffect(() => {
    if (persistState) {
      const savedState = localStorage.getItem(`adaptive-ui-${userId}`);
      if (savedState) {
        try {
          const parsed = JSON.parse(savedState);
          framework.restoreState(parsed);
          setState(framework.getState());
          setRecommendations(framework.getUIRecommendations());
        } catch (error) {
          console.error('Failed to restore adaptive UI state:', error);
        }
      }
    }
  }, [framework, userId, persistState]);

  // Subscribe to stage transitions
  useEffect(() => {
    const unsubscribe = framework.onStageTransition((newStage) => {
      setState(framework.getState());
      setRecommendations(framework.getUIRecommendations());
      
      if (onStageChange) {
        onStageChange(newStage);
      }
      
      // Persist state
      if (persistState) {
        localStorage.setItem(
          `adaptive-ui-${userId}`,
          JSON.stringify(framework.getState())
        );
      }
    });

    // Return cleanup function
    return () => {
      // Note: Framework doesn't have unsubscribe yet, 
      // but we'd call it here if it did
    };
  }, [framework, onStageChange, userId, persistState]);

  // Record successful interaction
  const recordSuccess = useCallback((feature: string, duration?: number) => {
    framework.recordInteraction(feature, true, duration);
    setState(framework.getState());
    setRecommendations(framework.getUIRecommendations());
    
    if (persistState) {
      localStorage.setItem(
        `adaptive-ui-${userId}`,
        JSON.stringify(framework.getState())
      );
    }
  }, [framework, userId, persistState]);

  // Record error/failure
  const recordError = useCallback((feature: string) => {
    framework.recordInteraction(feature, false);
    setState(framework.getState());
    setRecommendations(framework.getUIRecommendations());
    
    if (persistState) {
      localStorage.setItem(
        `adaptive-ui-${userId}`,
        JSON.stringify(framework.getState())
      );
    }
  }, [framework, userId, persistState]);

  // Set preferred stage
  const setPreferredStage = useCallback((stage: UIStage, lock = false) => {
    framework.setPreferredStage(stage, lock);
    setState(framework.getState());
    setRecommendations(framework.getUIRecommendations());
  }, [framework]);

  // Check if feature should be shown
  const shouldShowFeature = useCallback((feature: string): boolean => {
    return state.visibleFeatures.has(feature) && 
           !state.hiddenFeatures.has(feature);
  }, [state]);

  // Get animation duration based on stage
  const getAnimationDuration = useCallback((): number => {
    return state.animationDuration;
  }, [state]);

  // Check if feature is enabled
  const isFeatureEnabled = useCallback((feature: string): boolean => {
    const featureMap: Record<string, keyof UIRecommendations> = {
      'shortcuts': 'enableShortcuts',
      'commandPalette': 'enableCommandPalette',
      'predictive': 'enablePredictive',
      'tooltips': 'showTooltips',
      'hints': 'showHints',
      'tutorial': 'showTutorial',
      'emoji': 'useEmoji',
      'encouragement': 'useEncouragement',
      'mindfulness': 'useMindfulness'
    };
    
    const key = featureMap[feature];
    return key ? recommendations[key] as boolean : false;
  }, [recommendations]);

  return {
    // Current state
    stage: state.currentStage,
    recommendations,
    competency: state.overallCompetency,
    
    // Actions
    recordSuccess,
    recordError,
    setPreferredStage,
    
    // Utilities
    shouldShowFeature,
    getAnimationDuration,
    isFeatureEnabled
  };
}