/**
 * Gesture Recognition Engine
 * Opt-in system for understanding interaction patterns
 */

import { EventEmitter } from 'events';
import {
  GestureConfig,
  GesturePattern,
  InteractionPattern,
  HesitationPattern,
  ConfusionPattern,
  ConfidencePattern,
  FrustrationPattern,
  GestureInsight,
  InteractionContext,
  GestureCalibration,
  PrivacyNotice
} from './types';

export class GestureEngine extends EventEmitter {
  private config: GestureConfig;
  private isActive: boolean = false;
  private calibration?: GestureCalibration;
  
  // Tracking data (only stored if user opts in)
  private currentPath: { x: number; y: number; time: number }[] = [];
  private clickHistory: { element: string; time: number }[] = [];
  private hoverStartTime?: number;
  private lastInteractionTime: number = 0;
  
  constructor(config?: Partial<GestureConfig>) {
    super();
    
    this.config = {
      enabled: false, // OPT-IN by default
      sensitivity: 'medium',
      detectHesitation: true,
      detectConfusion: true,
      detectConfidence: true,
      detectFrustration: true,
      storePatterns: false, // Don't store by default
      anonymizeData: true,
      localOnly: true,
      enableGestureShortcuts: false,
      touchGesturesEnabled: false,
      mouseGesturesEnabled: false,
      ...config
    };
  }
  
  /**
   * Get privacy notice for user consent
   */
  getPrivacyNotice(): PrivacyNotice {
    return {
      title: 'Gesture Recognition Privacy Notice',
      description: 'This feature helps adapt the interface to your interaction style. All data stays on your device.',
      dataCollected: [
        'Mouse movement patterns (not specific locations)',
        'Click timing (not what you click)',
        'Scroll patterns',
        'General interaction speed'
      ],
      dataUsage: [
        'Detect when you might need help',
        'Simplify interface if you seem confused',
        'Offer shortcuts for repeated actions',
        'Improve your experience over time'
      ],
      optOutInstructions: 'You can disable this anytime in Settings > Privacy > Gesture Recognition'
    };
  }
  
  /**
   * Enable gesture recognition (requires explicit user consent)
   */
  async enable(): Promise<boolean> {
    if (this.config.enabled) {
      return true; // Already enabled
    }
    
    // Show privacy notice and get consent
    const consent = await this.requestUserConsent();
    
    if (consent) {
      this.config.enabled = true;
      this.isActive = true;
      this.startTracking();
      
      this.emit('enabled', {
        timestamp: new Date(),
        config: this.config
      });
      
      // Calibrate to user's baseline
      await this.calibrate();
      
      return true;
    }
    
    return false;
  }
  
  /**
   * Disable gesture recognition
   */
  disable(): void {
    this.config.enabled = false;
    this.isActive = false;
    this.stopTracking();
    
    // Clear any stored data
    this.clearData();
    
    this.emit('disabled', {
      timestamp: new Date()
    });
  }
  
  /**
   * Request user consent
   */
  private async requestUserConsent(): Promise<boolean> {
    // In a real implementation, this would show a UI dialog
    // For now, we'll emit an event for the UI to handle
    
    return new Promise((resolve) => {
      this.emit('consent-required', {
        notice: this.getPrivacyNotice(),
        onAccept: () => resolve(true),
        onDecline: () => resolve(false)
      });
    });
  }
  
  /**
   * Start tracking interactions
   */
  private startTracking(): void {
    if (!this.isActive) return;
    
    // Mouse tracking
    if (this.config.mouseGesturesEnabled) {
      document.addEventListener('mousemove', this.handleMouseMove);
      document.addEventListener('mousedown', this.handleMouseDown);
      document.addEventListener('mouseup', this.handleMouseUp);
    }
    
    // Touch tracking
    if (this.config.touchGesturesEnabled) {
      document.addEventListener('touchstart', this.handleTouchStart, { passive: true });
      document.addEventListener('touchmove', this.handleTouchMove, { passive: true });
      document.addEventListener('touchend', this.handleTouchEnd);
    }
    
    // Common events
    document.addEventListener('click', this.handleClick);
    document.addEventListener('scroll', this.handleScroll, { passive: true });
  }
  
  /**
   * Stop tracking interactions
   */
  private stopTracking(): void {
    document.removeEventListener('mousemove', this.handleMouseMove);
    document.removeEventListener('mousedown', this.handleMouseDown);
    document.removeEventListener('mouseup', this.handleMouseUp);
    document.removeEventListener('touchstart', this.handleTouchStart);
    document.removeEventListener('touchmove', this.handleTouchMove);
    document.removeEventListener('touchend', this.handleTouchEnd);
    document.removeEventListener('click', this.handleClick);
    document.removeEventListener('scroll', this.handleScroll);
  }
  
  /**
   * Handle mouse movement
   */
  private handleMouseMove = (e: MouseEvent): void => {
    if (!this.isActive || !this.config.mouseGesturesEnabled) return;
    
    const now = Date.now();
    
    // Track path (limit to last 50 points)
    this.currentPath.push({ x: e.clientX, y: e.clientY, time: now });
    if (this.currentPath.length > 50) {
      this.currentPath.shift();
    }
    
    // Detect patterns every 500ms
    if (now - this.lastInteractionTime > 500) {
      this.analyzeCurrentPattern();
      this.lastInteractionTime = now;
    }
  };
  
  /**
   * Handle click events
   */
  private handleClick = (e: MouseEvent): void => {
    if (!this.isActive) return;
    
    const element = (e.target as HTMLElement).tagName;
    const now = Date.now();
    
    // Store click history (anonymized)
    if (this.config.anonymizeData) {
      this.clickHistory.push({ element, time: now });
      if (this.clickHistory.length > 20) {
        this.clickHistory.shift();
      }
    }
    
    // Check for rapid clicks (frustration)
    if (this.config.detectFrustration) {
      const recentClicks = this.clickHistory.filter(c => now - c.time < 1000);
      if (recentClicks.length > 5) {
        this.emitPattern({
          type: 'mouse',
          pattern: {
            frustration: {
              rapidClicks: recentClicks.length,
              aggressiveMovement: false,
              escapeAttempts: 0,
              rageDismissal: false
            }
          },
          confidence: 0.7,
          timestamp: new Date()
        });
      }
    }
  };
  
  /**
   * Analyze current interaction pattern
   */
  private analyzeCurrentPattern(): void {
    if (this.currentPath.length < 5) return;
    
    const pattern: InteractionPattern = {};
    
    // Detect hesitation
    if (this.config.detectHesitation) {
      const hesitation = this.detectHesitation();
      if (hesitation) {
        pattern.hesitation = hesitation;
      }
    }
    
    // Detect confusion
    if (this.config.detectConfusion) {
      const confusion = this.detectConfusion();
      if (confusion) {
        pattern.confusion = confusion;
      }
    }
    
    // Detect confidence
    if (this.config.detectConfidence) {
      const confidence = this.detectConfidence();
      if (confidence) {
        pattern.confidence = confidence;
      }
    }
    
    // Emit pattern if detected
    if (Object.keys(pattern).length > 0) {
      this.emitPattern({
        type: 'mouse',
        pattern,
        confidence: this.calculatePatternConfidence(pattern),
        timestamp: new Date()
      });
    }
  }
  
  /**
   * Detect hesitation pattern
   */
  private detectHesitation(): HesitationPattern | null {
    if (this.currentPath.length < 10) return null;
    
    // Calculate movement speed
    const recentPath = this.currentPath.slice(-10);
    let totalDistance = 0;
    let directionChanges = 0;
    let lastDirection = 0;
    
    for (let i = 1; i < recentPath.length; i++) {
      const dx = recentPath[i].x - recentPath[i-1].x;
      const dy = recentPath[i].y - recentPath[i-1].y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      totalDistance += distance;
      
      // Count direction changes
      const direction = Math.atan2(dy, dx);
      if (i > 1 && Math.abs(direction - lastDirection) > Math.PI / 4) {
        directionChanges++;
      }
      lastDirection = direction;
    }
    
    const timeSpan = recentPath[recentPath.length - 1].time - recentPath[0].time;
    const speed = totalDistance / (timeSpan / 1000); // pixels per second
    
    // Hesitation detected if slow movement with direction changes
    if (speed < 100 && directionChanges > 3) {
      return {
        hoverDuration: timeSpan,
        movementSpeed: speed,
        changeOfDirection: directionChanges,
        distanceToTarget: totalDistance
      };
    }
    
    return null;
  }
  
  /**
   * Detect confusion pattern
   */
  private detectConfusion(): ConfusionPattern | null {
    if (this.currentPath.length < 20) return null;
    
    // Look for back-and-forth or circular movements
    let backAndForth = 0;
    let circularMovements = 0;
    
    // Simple circular detection (checking if path curves back)
    const startPoint = this.currentPath[0];
    const endPoint = this.currentPath[this.currentPath.length - 1];
    const directDistance = Math.sqrt(
      Math.pow(endPoint.x - startPoint.x, 2) + 
      Math.pow(endPoint.y - startPoint.y, 2)
    );
    
    let pathDistance = 0;
    for (let i = 1; i < this.currentPath.length; i++) {
      const dx = this.currentPath[i].x - this.currentPath[i-1].x;
      const dy = this.currentPath[i].y - this.currentPath[i-1].y;
      pathDistance += Math.sqrt(dx * dx + dy * dy);
    }
    
    // If path is much longer than direct distance, suggests confusion
    if (pathDistance > directDistance * 3) {
      return {
        backAndForth: Math.floor(pathDistance / directDistance),
        circularMovements: 1,
        repeatClicks: 0,
        scrollingPattern: 'searching'
      };
    }
    
    return null;
  }
  
  /**
   * Detect confidence pattern
   */
  private detectConfidence(): ConfidencePattern | null {
    if (this.currentPath.length < 5) return null;
    
    // Look for direct, purposeful movement
    const startPoint = this.currentPath[0];
    const endPoint = this.currentPath[this.currentPath.length - 1];
    
    // Calculate directness
    const directDistance = Math.sqrt(
      Math.pow(endPoint.x - startPoint.x, 2) + 
      Math.pow(endPoint.y - startPoint.y, 2)
    );
    
    let pathDistance = 0;
    for (let i = 1; i < this.currentPath.length; i++) {
      const dx = this.currentPath[i].x - this.currentPath[i-1].x;
      const dy = this.currentPath[i].y - this.currentPath[i-1].y;
      pathDistance += Math.sqrt(dx * dx + dy * dy);
    }
    
    const directness = directDistance / pathDistance;
    const timeSpan = endPoint.time - startPoint.time;
    
    // Confidence detected if movement is direct and quick
    if (directness > 0.8 && timeSpan < 1000) {
      return {
        directMovement: true,
        clickSpeed: timeSpan,
        accuracy: directness,
        flowState: true
      };
    }
    
    return null;
  }
  
  /**
   * Calculate pattern confidence
   */
  private calculatePatternConfidence(pattern: InteractionPattern): number {
    // Simple confidence calculation based on pattern clarity
    let confidence = 0.5;
    
    if (pattern.hesitation) confidence += 0.2;
    if (pattern.confusion) confidence += 0.2;
    if (pattern.confidence) confidence += 0.3;
    if (pattern.frustration) confidence += 0.3;
    
    return Math.min(1, confidence);
  }
  
  /**
   * Emit pattern event
   */
  private emitPattern(pattern: GesturePattern): void {
    // Generate insight
    const insight = this.generateInsight(pattern);
    
    this.emit('pattern-detected', {
      pattern,
      insight,
      timestamp: new Date()
    });
    
    // Store if opted in
    if (this.config.storePatterns && this.config.localOnly) {
      this.storePatternLocally(pattern);
    }
  }
  
  /**
   * Generate insight from pattern
   */
  private generateInsight(pattern: GesturePattern): GestureInsight {
    const { pattern: interactionPattern } = pattern;
    
    if (interactionPattern.hesitation) {
      return {
        pattern: interactionPattern,
        interpretation: 'User seems to be hesitating',
        confidence: pattern.confidence,
        suggestion: {
          type: 'help',
          message: 'Need help? Try hovering over elements for tooltips',
          priority: 'low'
        }
      };
    }
    
    if (interactionPattern.confusion) {
      return {
        pattern: interactionPattern,
        interpretation: 'User may be confused or searching',
        confidence: pattern.confidence,
        suggestion: {
          type: 'simplify',
          message: 'Simplifying interface to help you focus',
          priority: 'medium'
        }
      };
    }
    
    if (interactionPattern.frustration) {
      return {
        pattern: interactionPattern,
        interpretation: 'User showing signs of frustration',
        confidence: pattern.confidence,
        suggestion: {
          type: 'alternative',
          message: 'Try using voice commands instead',
          priority: 'high'
        }
      };
    }
    
    return {
      pattern: interactionPattern,
      interpretation: 'Normal interaction pattern',
      confidence: pattern.confidence
    };
  }
  
  /**
   * Calibrate to user's baseline
   */
  private async calibrate(): Promise<void> {
    // Simple calibration - in practice would be more sophisticated
    this.calibration = {
      baseline: {
        averageMouseSpeed: 200, // pixels/second
        averageHoverTime: 500, // ms
        averageClickAccuracy: 0.8,
        preferredGestures: []
      },
      lastCalibrated: new Date()
    };
    
    this.emit('calibrated', this.calibration);
  }
  
  /**
   * Store pattern locally
   */
  private storePatternLocally(pattern: GesturePattern): void {
    // In practice, use IndexedDB or similar
    const key = `gesture-pattern-${Date.now()}`;
    try {
      localStorage.setItem(key, JSON.stringify(pattern));
      
      // Clean old patterns (keep last 100)
      const keys = Object.keys(localStorage)
        .filter(k => k.startsWith('gesture-pattern-'))
        .sort();
      
      if (keys.length > 100) {
        keys.slice(0, -100).forEach(k => localStorage.removeItem(k));
      }
    } catch (error) {
      console.error('Failed to store pattern locally:', error);
    }
  }
  
  /**
   * Clear all stored data
   */
  private clearData(): void {
    this.currentPath = [];
    this.clickHistory = [];
    this.hoverStartTime = undefined;
    
    // Clear localStorage if used
    if (this.config.storePatterns && this.config.localOnly) {
      Object.keys(localStorage)
        .filter(k => k.startsWith('gesture-pattern-'))
        .forEach(k => localStorage.removeItem(k));
    }
    
    this.emit('data-cleared', { timestamp: new Date() });
  }
  
  /**
   * Update configuration
   */
  updateConfig(updates: Partial<GestureConfig>): void {
    const wasEnabled = this.config.enabled;
    this.config = { ...this.config, ...updates };
    
    // Handle enable/disable changes
    if (wasEnabled && !this.config.enabled) {
      this.disable();
    } else if (!wasEnabled && this.config.enabled) {
      this.enable();
    }
    
    this.emit('config-updated', this.config);
  }
  
  /**
   * Get current configuration
   */
  getConfig(): GestureConfig {
    return { ...this.config };
  }
  
  // Touch handlers (simplified)
  private handleTouchStart = (e: TouchEvent): void => {
    // Implementation for touch gestures
  };
  
  private handleTouchMove = (e: TouchEvent): void => {
    // Implementation for touch gestures
  };
  
  private handleTouchEnd = (e: TouchEvent): void => {
    // Implementation for touch gestures
  };
  
  private handleScroll = (e: Event): void => {
    // Implementation for scroll pattern detection
  };
  
  private handleMouseDown = (e: MouseEvent): void => {
    this.hoverStartTime = Date.now();
  };
  
  private handleMouseUp = (e: MouseEvent): void => {
    this.hoverStartTime = undefined;
  };
}