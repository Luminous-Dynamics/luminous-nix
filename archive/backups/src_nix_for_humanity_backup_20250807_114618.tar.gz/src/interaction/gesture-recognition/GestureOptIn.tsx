/**
 * Gesture Recognition Opt-In Component
 * Clear, transparent consent interface for gesture tracking
 */

import React, { useState } from 'react';
import { GestureEngine } from './gesture-engine';
import { GestureConfig, PrivacyNotice } from './types';

interface GestureOptInProps {
  engine: GestureEngine;
  onComplete: (enabled: boolean) => void;
}

export const GestureOptIn: React.FC<GestureOptInProps> = ({ engine, onComplete }) => {
  const [showDetails, setShowDetails] = useState(false);
  const [selectedFeatures, setSelectedFeatures] = useState<Partial<GestureConfig>>({
    detectHesitation: true,
    detectConfusion: true,
    detectConfidence: false,
    detectFrustration: true,
    storePatterns: false,
    anonymizeData: true,
    localOnly: true
  });
  
  const privacyNotice = engine.getPrivacyNotice();
  
  const handleAccept = () => {
    engine.updateConfig({
      ...selectedFeatures,
      enabled: true,
      mouseGesturesEnabled: true
    });
    onComplete(true);
  };
  
  const handleDecline = () => {
    onComplete(false);
  };
  
  const toggleFeature = (feature: keyof GestureConfig) => {
    setSelectedFeatures(prev => ({
      ...prev,
      [feature]: !prev[feature as keyof typeof prev]
    }));
  };
  
  return (
    <div className="gesture-opt-in fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-xl">
        {/* Header */}
        <div className="p-6 border-b">
          <h2 className="text-2xl font-bold mb-2">
            Help Us Understand Your Needs Better
          </h2>
          <p className="text-gray-600">
            Optional gesture recognition can help adapt the interface to your interaction style
          </p>
        </div>
        
        {/* Privacy Notice */}
        <div className="p-6 space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="font-semibold text-blue-900 mb-2 flex items-center">
              <span className="mr-2">🔒</span>
              {privacyNotice.title}
            </h3>
            <p className="text-blue-800 text-sm">
              {privacyNotice.description}
            </p>
          </div>
          
          {/* What We Track */}
          <div>
            <h4 className="font-semibold mb-2">What We Track (If You Opt In):</h4>
            <ul className="space-y-1">
              {privacyNotice.dataCollected.map((item, index) => (
                <li key={index} className="flex items-start text-sm">
                  <span className="text-green-600 mr-2">✓</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          
          {/* How We Use It */}
          <div>
            <h4 className="font-semibold mb-2">How This Helps You:</h4>
            <ul className="space-y-1">
              {privacyNotice.dataUsage.map((item, index) => (
                <li key={index} className="flex items-start text-sm">
                  <span className="text-blue-600 mr-2">💡</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Customization */}
          <div className="border-t pt-4">
            <button
              onClick={() => setShowDetails(!showDetails)}
              className="text-blue-600 hover:text-blue-700 text-sm font-medium"
            >
              {showDetails ? '▼ Hide' : '▶ Show'} Customization Options
            </button>
            
            {showDetails && (
              <div className="mt-4 space-y-3 bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-600 mb-3">
                  Choose what patterns to detect:
                </p>
                
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={selectedFeatures.detectHesitation}
                    onChange={() => toggleFeature('detectHesitation')}
                    className="mr-3"
                  />
                  <div>
                    <span className="font-medium">Hesitation Detection</span>
                    <p className="text-sm text-gray-600">
                      Notices when you pause or hover, offering help
                    </p>
                  </div>
                </label>
                
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={selectedFeatures.detectConfusion}
                    onChange={() => toggleFeature('detectConfusion')}
                    className="mr-3"
                  />
                  <div>
                    <span className="font-medium">Confusion Detection</span>
                    <p className="text-sm text-gray-600">
                      Recognizes searching behavior, simplifies interface
                    </p>
                  </div>
                </label>
                
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={selectedFeatures.detectFrustration}
                    onChange={() => toggleFeature('detectFrustration')}
                    className="mr-3"
                  />
                  <div>
                    <span className="font-medium">Frustration Detection</span>
                    <p className="text-sm text-gray-600">
                      Identifies rapid clicking, offers alternatives
                    </p>
                  </div>
                </label>
                
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={selectedFeatures.detectConfidence}
                    onChange={() => toggleFeature('detectConfidence')}
                    className="mr-3"
                  />
                  <div>
                    <span className="font-medium">Confidence Recognition</span>
                    <p className="text-sm text-gray-600">
                      Notices smooth interactions, offers advanced features
                    </p>
                  </div>
                </label>
                
                <div className="border-t pt-3 mt-3">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={selectedFeatures.storePatterns}
                      onChange={() => toggleFeature('storePatterns')}
                      className="mr-3"
                    />
                    <div>
                      <span className="font-medium">Remember My Patterns</span>
                      <p className="text-sm text-gray-600">
                        Store patterns locally to improve over time (never sent anywhere)
                      </p>
                    </div>
                  </label>
                </div>
              </div>
            )}
          </div>
          
          {/* Privacy Guarantees */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <h4 className="font-semibold text-green-900 mb-2">
              Our Privacy Guarantees:
            </h4>
            <ul className="space-y-1 text-sm text-green-800">
              <li>• All data stays on your device</li>
              <li>• No tracking across websites</li>
              <li>• You can turn this off anytime</li>
              <li>• We never share or sell your data</li>
              <li>• {privacyNotice.optOutInstructions}</li>
            </ul>
          </div>
        </div>
        
        {/* Actions */}
        <div className="p-6 border-t bg-gray-50 flex justify-between">
          <button
            onClick={handleDecline}
            className="px-6 py-2 text-gray-700 hover:text-gray-900"
          >
            No Thanks
          </button>
          
          <div className="space-x-3">
            <button
              onClick={() => {
                // Accept with minimal features
                engine.updateConfig({
                  enabled: true,
                  detectHesitation: true,
                  detectConfusion: true,
                  detectFrustration: false,
                  detectConfidence: false,
                  storePatterns: false,
                  mouseGesturesEnabled: true
                });
                onComplete(true);
              }}
              className="px-6 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg"
            >
              Basic Only
            </button>
            
            <button
              onClick={handleAccept}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
            >
              Enable Selected Features
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};