/**
 * Gesture Recognition Types
 * Opt-in system for understanding user interaction patterns
 */

export interface GestureConfig {
  enabled: boolean;
  sensitivity: 'low' | 'medium' | 'high';
  
  // Opt-in features
  detectHesitation: boolean;
  detectConfusion: boolean;
  detectConfidence: boolean;
  detectFrustration: boolean;
  
  // Privacy settings
  storePatterns: boolean;
  anonymizeData: boolean;
  localOnly: boolean;
  
  // Accessibility
  enableGestureShortcuts: boolean;
  touchGesturesEnabled: boolean;
  mouseGesturesEnabled: boolean;
}

export interface GesturePattern {
  type: 'mouse' | 'touch' | 'keyboard';
  pattern: InteractionPattern;
  confidence: number;
  timestamp: Date;
  context?: InteractionContext;
}

export interface InteractionPattern {
  // Movement patterns
  hesitation?: HesitationPattern;
  confusion?: ConfusionPattern;
  confidence?: ConfidencePattern;
  frustration?: FrustrationPattern;
  
  // Gesture types
  gesture?: RecognizedGesture;
}

export interface HesitationPattern {
  hoverDuration: number; // ms hovering before action
  movementSpeed: number; // pixels/second
  changeOfDirection: number; // number of direction changes
  distanceToTarget: number; // pixels moved before clicking
}

export interface ConfusionPattern {
  backAndForth: number; // times moving between options
  circularMovements: number; // circular mouse patterns
  repeatClicks: number; // clicking same thing multiple times
  scrollingPattern: 'erratic' | 'searching' | 'normal';
}

export interface ConfidencePattern {
  directMovement: boolean; // straight line to target
  clickSpeed: number; // time from movement start to click
  accuracy: number; // how close to center of target
  flowState: boolean; // continuous smooth actions
}

export interface FrustrationPattern {
  rapidClicks: number; // clicks per second
  aggressiveMovement: boolean; // fast, jerky movements
  escapeAttempts: number; // ESC key or back button
  rageDismissal: boolean; // quickly closing things
}

export interface RecognizedGesture {
  name: string;
  type: 'swipe' | 'tap' | 'longPress' | 'pinch' | 'drag' | 'shake';
  direction?: 'up' | 'down' | 'left' | 'right';
  distance?: number;
  duration?: number;
  fingers?: number; // for touch gestures
}

export interface InteractionContext {
  element?: string; // what element was interacted with
  task?: string; // what task user is trying to complete
  previousAction?: string; // what happened before
  timeInTask?: number; // how long on current task
}

export interface GestureInsight {
  pattern: InteractionPattern;
  interpretation: string;
  confidence: number;
  suggestion?: InteractionSuggestion;
}

export interface InteractionSuggestion {
  type: 'help' | 'simplify' | 'shortcut' | 'alternative';
  message: string;
  action?: () => void;
  priority: 'low' | 'medium' | 'high';
}

export interface PrivacyNotice {
  title: string;
  description: string;
  dataCollected: string[];
  dataUsage: string[];
  optOutInstructions: string;
}

export interface GestureCalibration {
  userId?: string; // anonymous ID
  baseline: {
    averageMouseSpeed: number;
    averageHoverTime: number;
    averageClickAccuracy: number;
    preferredGestures: string[];
  };
  lastCalibrated: Date;
}

export interface GestureAccessibility {
  // Alternative inputs
  keyboardShortcuts: Map<string, RecognizedGesture>;
  voiceCommands: Map<string, RecognizedGesture>;
  
  // Gesture customization
  customGestures: RecognizedGesture[];
  disabledGestures: string[];
  
  // Assistance features
  gestureGuides: boolean;
  hapticFeedback: boolean;
  audioFeedback: boolean;
}