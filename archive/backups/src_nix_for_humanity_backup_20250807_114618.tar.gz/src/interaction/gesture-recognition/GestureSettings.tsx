/**
 * Gesture Recognition Settings
 * User control panel for gesture recognition features
 */

import React, { useState, useEffect } from 'react';
import { GestureEngine } from './gesture-engine';
import { GestureConfig } from './types';

interface GestureSettingsProps {
  engine: GestureEngine;
}

export const GestureSettings: React.FC<GestureSettingsProps> = ({ engine }) => {
  const [config, setConfig] = useState<GestureConfig>(engine.getConfig());
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [dataClearConfirm, setDataClearConfirm] = useState(false);
  
  useEffect(() => {
    // Listen for config updates
    const handleConfigUpdate = (newConfig: GestureConfig) => {
      setConfig(newConfig);
    };
    
    engine.on('config-updated', handleConfigUpdate);
    
    return () => {
      engine.off('config-updated', handleConfigUpdate);
    };
  }, [engine]);
  
  const updateSetting = (key: keyof GestureConfig, value: any) => {
    const updates = { [key]: value };
    engine.updateConfig(updates);
  };
  
  const handleToggleGestures = () => {
    if (config.enabled) {
      engine.disable();
    } else {
      engine.enable();
    }
  };
  
  const handleClearData = () => {
    if (dataClearConfirm) {
      engine.emit('clear-data-requested');
      setDataClearConfirm(false);
    } else {
      setDataClearConfirm(true);
      setTimeout(() => setDataClearConfirm(false), 3000);
    }
  };
  
  return (
    <div className="gesture-settings max-w-2xl">
      <h2 className="text-xl font-semibold mb-4">Gesture Recognition Settings</h2>
      
      {/* Main Toggle */}
      <div className="bg-white rounded-lg shadow p-6 mb-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-medium">Gesture Recognition</h3>
            <p className="text-sm text-gray-600">
              Help the interface adapt to your interaction style
            </p>
          </div>
          <button
            onClick={handleToggleGestures}
            className={`
              relative inline-flex h-6 w-11 items-center rounded-full transition-colors
              ${config.enabled ? 'bg-blue-600' : 'bg-gray-200'}
            `}
            role="switch"
            aria-checked={config.enabled}
          >
            <span
              className={`
                inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                ${config.enabled ? 'translate-x-6' : 'translate-x-1'}
              `}
            />
          </button>
        </div>
        
        {config.enabled && (
          <div className="text-sm text-green-600 flex items-center">
            <span className="mr-2">✓</span>
            Gesture recognition is active and helping improve your experience
          </div>
        )}
      </div>
      
      {/* Feature Controls */}
      {config.enabled && (
        <div className="bg-white rounded-lg shadow p-6 mb-4">
          <h3 className="font-medium mb-4">Detection Features</h3>
          
          <div className="space-y-3">
            <label className="flex items-center justify-between">
              <div>
                <span className="font-medium">Hesitation Detection</span>
                <p className="text-sm text-gray-600">Offer help when you pause</p>
              </div>
              <input
                type="checkbox"
                checked={config.detectHesitation}
                onChange={(e) => updateSetting('detectHesitation', e.target.checked)}
                className="h-4 w-4 text-blue-600 rounded"
              />
            </label>
            
            <label className="flex items-center justify-between">
              <div>
                <span className="font-medium">Confusion Detection</span>
                <p className="text-sm text-gray-600">Simplify when you seem lost</p>
              </div>
              <input
                type="checkbox"
                checked={config.detectConfusion}
                onChange={(e) => updateSetting('detectConfusion', e.target.checked)}
                className="h-4 w-4 text-blue-600 rounded"
              />
            </label>
            
            <label className="flex items-center justify-between">
              <div>
                <span className="font-medium">Frustration Detection</span>
                <p className="text-sm text-gray-600">Offer alternatives when stuck</p>
              </div>
              <input
                type="checkbox"
                checked={config.detectFrustration}
                onChange={(e) => updateSetting('detectFrustration', e.target.checked)}
                className="h-4 w-4 text-blue-600 rounded"
              />
            </label>
            
            <label className="flex items-center justify-between">
              <div>
                <span className="font-medium">Confidence Recognition</span>
                <p className="text-sm text-gray-600">Show advanced features when ready</p>
              </div>
              <input
                type="checkbox"
                checked={config.detectConfidence}
                onChange={(e) => updateSetting('detectConfidence', e.target.checked)}
                className="h-4 w-4 text-blue-600 rounded"
              />
            </label>
          </div>
        </div>
      )}
      
      {/* Sensitivity */}
      {config.enabled && (
        <div className="bg-white rounded-lg shadow p-6 mb-4">
          <h3 className="font-medium mb-4">Sensitivity</h3>
          <p className="text-sm text-gray-600 mb-3">
            How quickly should we respond to patterns?
          </p>
          
          <div className="flex space-x-4">
            {(['low', 'medium', 'high'] as const).map((level) => (
              <button
                key={level}
                onClick={() => updateSetting('sensitivity', level)}
                className={`
                  flex-1 py-2 px-4 rounded-lg border transition-colors capitalize
                  ${config.sensitivity === level
                    ? 'bg-blue-50 border-blue-300 text-blue-700'
                    : 'bg-white border-gray-200 hover:bg-gray-50'
                  }
                `}
              >
                {level}
              </button>
            ))}
          </div>
          
          <p className="text-xs text-gray-500 mt-2">
            {config.sensitivity === 'low' && 'Only responds to very clear patterns'}
            {config.sensitivity === 'medium' && 'Balanced detection and response'}
            {config.sensitivity === 'high' && 'Quickly adapts to subtle patterns'}
          </p>
        </div>
      )}
      
      {/* Privacy Settings */}
      <div className="bg-white rounded-lg shadow p-6 mb-4">
        <h3 className="font-medium mb-4">Privacy & Data</h3>
        
        <div className="space-y-3">
          <label className="flex items-center justify-between">
            <div>
              <span className="font-medium">Remember Patterns</span>
              <p className="text-sm text-gray-600">
                Store patterns locally to improve over time
              </p>
            </div>
            <input
              type="checkbox"
              checked={config.storePatterns}
              onChange={(e) => updateSetting('storePatterns', e.target.checked)}
              className="h-4 w-4 text-blue-600 rounded"
              disabled={!config.enabled}
            />
          </label>
          
          <label className="flex items-center justify-between">
            <div>
              <span className="font-medium">Anonymize Data</span>
              <p className="text-sm text-gray-600">
                Remove identifying information from patterns
              </p>
            </div>
            <input
              type="checkbox"
              checked={config.anonymizeData}
              onChange={(e) => updateSetting('anonymizeData', e.target.checked)}
              className="h-4 w-4 text-blue-600 rounded"
              disabled={!config.enabled || !config.storePatterns}
            />
          </label>
          
          <div className="pt-3 border-t">
            <button
              onClick={handleClearData}
              className={`
                px-4 py-2 rounded-lg transition-colors
                ${dataClearConfirm
                  ? 'bg-red-600 hover:bg-red-700 text-white'
                  : 'bg-gray-200 hover:bg-gray-300'
                }
              `}
            >
              {dataClearConfirm ? 'Click Again to Confirm' : 'Clear All Gesture Data'}
            </button>
          </div>
        </div>
      </div>
      
      {/* Advanced Settings */}
      <div className="bg-white rounded-lg shadow p-6">
        <button
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="flex items-center font-medium w-full"
        >
          <span className="mr-2">{showAdvanced ? '▼' : '▶'}</span>
          Advanced Settings
        </button>
        
        {showAdvanced && (
          <div className="mt-4 space-y-3 pt-4 border-t">
            <label className="flex items-center justify-between">
              <div>
                <span className="font-medium">Mouse Gestures</span>
                <p className="text-sm text-gray-600">Track mouse movement patterns</p>
              </div>
              <input
                type="checkbox"
                checked={config.mouseGesturesEnabled}
                onChange={(e) => updateSetting('mouseGesturesEnabled', e.target.checked)}
                className="h-4 w-4 text-blue-600 rounded"
                disabled={!config.enabled}
              />
            </label>
            
            <label className="flex items-center justify-between">
              <div>
                <span className="font-medium">Touch Gestures</span>
                <p className="text-sm text-gray-600">Track touch and swipe patterns</p>
              </div>
              <input
                type="checkbox"
                checked={config.touchGesturesEnabled}
                onChange={(e) => updateSetting('touchGesturesEnabled', e.target.checked)}
                className="h-4 w-4 text-blue-600 rounded"
                disabled={!config.enabled}
              />
            </label>
            
            <label className="flex items-center justify-between">
              <div>
                <span className="font-medium">Gesture Shortcuts</span>
                <p className="text-sm text-gray-600">Enable custom gesture commands</p>
              </div>
              <input
                type="checkbox"
                checked={config.enableGestureShortcuts}
                onChange={(e) => updateSetting('enableGestureShortcuts', e.target.checked)}
                className="h-4 w-4 text-blue-600 rounded"
                disabled={!config.enabled}
              />
            </label>
          </div>
        )}
      </div>
      
      {/* Info Box */}
      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <h4 className="font-medium text-blue-900 mb-1">About Gesture Recognition</h4>
        <p className="text-sm text-blue-800">
          This feature helps us understand when you might need help without you having to ask. 
          All processing happens on your device, and you're always in control of what's tracked.
        </p>
      </div>
    </div>
  );
};