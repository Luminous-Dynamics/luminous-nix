/**
 * Gesture Recognition Demo
 * Interactive demonstration of opt-in gesture tracking
 */

import React, { useState, useEffect, useRef } from 'react';
import { GestureEngine } from './gesture-engine';
import { GestureOptIn } from './GestureOptIn';
import { GestureSettings } from './GestureSettings';
import { GesturePattern, GestureInsight } from './types';

export const GestureDemo: React.FC = () => {
  const [engine] = useState(() => new GestureEngine());
  const [isEnabled, setIsEnabled] = useState(false);
  const [showOptIn, setShowOptIn] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [detectedPatterns, setDetectedPatterns] = useState<Array<{
    pattern: GesturePattern;
    insight: GestureInsight;
    timestamp: Date;
  }>>([]);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mouseTrail, setMouseTrail] = useState<{ x: number; y: number }[]>([]);
  
  useEffect(() => {
    // Check if already enabled
    setIsEnabled(engine.getConfig().enabled);
    
    // Listen for consent requests
    engine.on('consent-required', (data) => {
      setShowOptIn(true);
    });
    
    // Listen for pattern detection
    engine.on('pattern-detected', (data) => {
      setDetectedPatterns(prev => [...prev.slice(-4), data]);
      
      // Show visual feedback
      showPatternFeedback(data.pattern.pattern);
    });
    
    // Listen for enable/disable
    engine.on('enabled', () => setIsEnabled(true));
    engine.on('disabled', () => setIsEnabled(false));
  }, [engine]);
  
  // Mouse trail visualization (only when enabled)
  useEffect(() => {
    if (!isEnabled || !canvasRef.current) return;
    
    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvasRef.current!.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      setMouseTrail(prev => [...prev.slice(-20), { x, y }]);
    };
    
    const canvas = canvasRef.current;
    canvas.addEventListener('mousemove', handleMouseMove);
    
    return () => {
      canvas.removeEventListener('mousemove', handleMouseMove);
    };
  }, [isEnabled]);
  
  // Draw mouse trail
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;
    
    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    
    if (mouseTrail.length > 1) {
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.3)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      
      mouseTrail.forEach((point, index) => {
        if (index === 0) {
          ctx.moveTo(point.x, point.y);
        } else {
          ctx.lineTo(point.x, point.y);
        }
      });
      
      ctx.stroke();
    }
  }, [mouseTrail]);
  
  const showPatternFeedback = (pattern: any) => {
    // Visual feedback for detected patterns
    const feedback = document.createElement('div');
    feedback.className = 'pattern-feedback';
    feedback.textContent = 
      pattern.hesitation ? '🤔' :
      pattern.confusion ? '😕' :
      pattern.frustration ? '😤' :
      pattern.confidence ? '😎' : '👍';
    
    document.body.appendChild(feedback);
    
    setTimeout(() => {
      feedback.remove();
    }, 2000);
  };
  
  const handleEnableClick = async () => {
    const enabled = await engine.enable();
    if (!enabled) {
      // User declined in opt-in dialog
      setShowOptIn(false);
    }
  };
  
  const handleOptInComplete = (enabled: boolean) => {
    setShowOptIn(false);
    setIsEnabled(enabled);
  };
  
  return (
    <div className="gesture-demo min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto p-6">
        <h1 className="text-3xl font-bold mb-2">Gesture Recognition Demo</h1>
        <p className="text-gray-600 mb-8">
          Opt-in interaction pattern detection for better user experience
        </p>
        
        {/* Status Banner */}
        <div className={`
          mb-6 p-4 rounded-lg flex items-center justify-between
          ${isEnabled 
            ? 'bg-green-50 border border-green-200' 
            : 'bg-gray-50 border border-gray-200'
          }
        `}>
          <div>
            <h3 className="font-medium">
              {isEnabled ? '✓ Gesture Recognition Active' : 'Gesture Recognition Disabled'}
            </h3>
            <p className="text-sm text-gray-600">
              {isEnabled 
                ? 'Your interaction patterns are being used to improve your experience'
                : 'Enable gesture recognition to get adaptive help when you need it'
              }
            </p>
          </div>
          
          <div className="flex space-x-2">
            {!isEnabled && (
              <button
                onClick={handleEnableClick}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
              >
                Enable
              </button>
            )}
            
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg"
            >
              Settings
            </button>
          </div>
        </div>
        
        {/* Demo Area */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Interactive Canvas */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">Try It Out</h2>
            <p className="text-sm text-gray-600 mb-4">
              {isEnabled 
                ? 'Move your mouse around, hesitate, or click rapidly to see detection'
                : 'Enable gesture recognition to see pattern detection in action'
              }
            </p>
            
            <div className="relative">
              <canvas
                ref={canvasRef}
                width={400}
                height={300}
                className="w-full border border-gray-200 rounded-lg cursor-crosshair"
                style={{ backgroundColor: '#f9fafb' }}
              />
              
              {/* Demo UI Elements */}
              <div className="absolute inset-0 p-4 pointer-events-none">
                <div className="grid grid-cols-2 gap-4 h-full">
                  <button className="pointer-events-auto bg-blue-100 hover:bg-blue-200 rounded-lg p-4 transition-colors">
                    Option A
                  </button>
                  <button className="pointer-events-auto bg-green-100 hover:bg-green-200 rounded-lg p-4 transition-colors">
                    Option B
                  </button>
                  <button className="pointer-events-auto bg-purple-100 hover:bg-purple-200 rounded-lg p-4 transition-colors">
                    Option C
                  </button>
                  <button className="pointer-events-auto bg-yellow-100 hover:bg-yellow-200 rounded-lg p-4 transition-colors">
                    Option D
                  </button>
                </div>
              </div>
            </div>
            
            {/* Pattern Hints */}
            <div className="mt-4 p-3 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>Try these patterns:</strong><br />
                • Hover without clicking (hesitation)<br />
                • Move back and forth between options (confusion)<br />
                • Click rapidly on one button (frustration)<br />
                • Move directly to a button and click (confidence)
              </p>
            </div>
          </div>
          
          {/* Detection Log */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">Pattern Detection Log</h2>
            
            {!isEnabled ? (
              <p className="text-gray-500 text-center py-8">
                Enable gesture recognition to see detected patterns
              </p>
            ) : detectedPatterns.length === 0 ? (
              <p className="text-gray-500 text-center py-8">
                No patterns detected yet. Try interacting with the demo area!
              </p>
            ) : (
              <div className="space-y-3">
                {detectedPatterns.map((detection, index) => (
                  <div key={index} className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-start justify-between mb-1">
                      <span className="font-medium">
                        {detection.insight.interpretation}
                      </span>
                      <span className="text-xs text-gray-500">
                        {new Date(detection.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    
                    {detection.insight.suggestion && (
                      <div className="mt-2 p-2 bg-blue-50 rounded text-sm">
                        <span className="text-blue-800">
                          💡 {detection.insight.suggestion.message}
                        </span>
                      </div>
                    )}
                    
                    <div className="mt-2 text-xs text-gray-500">
                      Confidence: {Math.round(detection.insight.confidence * 100)}%
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        
        {/* Settings Panel */}
        {showSettings && (
          <div className="mt-6">
            <GestureSettings engine={engine} />
          </div>
        )}
        
        {/* Feature Explanation */}
        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="font-semibold mb-3">🔒 Privacy First</h3>
            <ul className="text-sm space-y-2 text-gray-600">
              <li>• Requires explicit opt-in consent</li>
              <li>• All data stays on your device</li>
              <li>• No tracking across sites</li>
              <li>• Clear data anytime</li>
              <li>• Disable with one click</li>
            </ul>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="font-semibold mb-3">🎯 Smart Detection</h3>
            <ul className="text-sm space-y-2 text-gray-600">
              <li>• Recognizes hesitation patterns</li>
              <li>• Detects confusion behaviors</li>
              <li>• Identifies frustration signals</li>
              <li>• Celebrates confident usage</li>
              <li>• Adapts to your style</li>
            </ul>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="font-semibold mb-3">💡 Helpful Actions</h3>
            <ul className="text-sm space-y-2 text-gray-600">
              <li>• Offers help when needed</li>
              <li>• Simplifies confusing interfaces</li>
              <li>• Suggests alternatives</li>
              <li>• Provides shortcuts</li>
              <li>• Never interrupts flow</li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Opt-in Dialog */}
      {showOptIn && (
        <GestureOptIn
          engine={engine}
          onComplete={handleOptInComplete}
        />
      )}
      
      {/* CSS for pattern feedback */}
      <style jsx global>{`
        .pattern-feedback {
          position: fixed;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          font-size: 3rem;
          animation: fadeInOut 2s ease-in-out;
          pointer-events: none;
          z-index: 9999;
        }
        
        @keyframes fadeInOut {
          0% { opacity: 0; transform: translate(-50%, -50%) scale(0.5); }
          50% { opacity: 1; transform: translate(-50%, -50%) scale(1.2); }
          100% { opacity: 0; transform: translate(-50%, -50%) scale(1); }
        }
      `}</style>
    </div>
  );
};