# 🎨 Embodied AI Partner - Visual Design Guide

*The aesthetic philosophy and design language for Nix, the physical AI companion*

## Design Philosophy

### Core Principles
1. **Non-threatening**: Soft, organic forms that invite trust
2. **Adaptive**: Form follows function and user needs
3. **Expressive**: Clear emotional communication without anthropomorphism
4. **Accessible**: Visible to all users regardless of visual ability
5. **Sacred**: Optional spiritual aesthetics that respect all beliefs

### Visual Identity
- **Name**: Nix (like *nix systems, but also "water spirit")
- **Form**: Fluid, adaptable geometry
- **Presence**: Supportive, never imposing
- **Movement**: Smooth, organic, purposeful

## Avatar Design Language

### Base Form Variations

#### 1. Geometric Orb (Default)
```
     .-""""""-.
   .'          '.
  /   ⦿    ⦿   \
 |       ◊       |
 |  \   ___   /  |
  \  `-.___.-'  /
   '.          .'
     '-......-'
```
- **Use**: Universal, works in all contexts
- **Properties**: 
  - Soft glow emanating from center
  - Subtle pulsing with "breath"
  - Particle aura during activity

#### 2. Crystalline Being (Sacred Personality)
```
       /\
      /  \
     / ◊  \
    /  ||  \
   <  ====  >
    \ |  | /
     \|  |/
      \/\/
```
- **Use**: Meditation, sacred computing modes
- **Properties**:
  - Faceted surfaces catch light
  - Internal light refracts
  - Mandala patterns in aura

#### 3. Friendly Companion (Approachable)
```
    .~"~.
   /     \
  | o   o |
  |   >   |
  |  \‿/  |
   \     /
    '~'~'
```
- **Use**: New users, children, casual interaction
- **Properties**:
  - Rounded, soft edges
  - Expressive "face" area
  - Bouncy movements

#### 4. Technical Assistant (Professional)
```
   ┌─────┐
   │ ■ ■ │
   │  ┬  │
   │ ╱ ╲ │
   └─┬─┬─┘
     │ │
```
- **Use**: Development, technical tasks
- **Properties**:
  - Clean geometric lines
  - Data visualization panels
  - Precise movements

## Color Systems

### Emotional Color Palette

```python
EMOTION_COLORS = {
    "neutral": {
        "primary": "#6B9BD1",      # Soft blue
        "secondary": "#A8C5E2",    # Light blue
        "glow": "#FFFFFF20"        # Subtle white glow
    },
    "happy": {
        "primary": "#7CB342",      # Fresh green
        "secondary": "#FFD54F",    # Warm yellow
        "glow": "#FFE08240"        # Golden glow
    },
    "confused": {
        "primary": "#9C27B0",      # Purple
        "secondary": "#E1BEE7",    # Light purple
        "glow": "#B39DDB30"        # Violet glow
    },
    "thinking": {
        "primary": "#00ACC1",      # Cyan
        "secondary": "#4DD0E1",    # Light cyan
        "glow": "#00E5FF25"        # Electric glow
    },
    "concerned": {
        "primary": "#FF7043",      # Soft orange
        "secondary": "#FFAB91",    # Light orange
        "glow": "#FF634720"        # Warm glow
    },
    "proud": {
        "primary": "#FFD700",      # Gold
        "secondary": "#FFF59D",    # Light gold
        "glow": "#FFEB3B40"        # Radiant glow
    }
}
```

### System State Colors

```python
SYSTEM_COLORS = {
    "healthy": "#4CAF50",         # Green
    "warning": "#FFC107",         # Amber
    "error": "#F44336",           # Red
    "updating": "#2196F3",        # Blue
    "idle": "#607D8B"             # Blue Grey
}
```

### Personality Color Themes

#### Minimal
- Primary: Pure white (#FFFFFF)
- Secondary: Light grey (#F5F5F5)
- Accent: Soft blue (#E3F2FD)
- Glow: Minimal, barely visible

#### Friendly
- Primary: Sky blue (#5C9CE5)
- Secondary: Mint green (#4EDBA1)
- Accent: Coral (#FF6B6B)
- Glow: Warm and inviting

#### Encouraging
- Primary: Sunshine yellow (#FFD93D)
- Secondary: Sky blue (#6FB3D9)
- Accent: Grass green (#6BCB77)
- Glow: Energetic pulses

#### Sacred
- Primary: Deep purple (#6C5CE7)
- Secondary: Starlight (#FFEAA7)
- Accent: Cosmic pink (#FD79A8)
- Glow: Ethereal, shifting

## Animation Principles

### Movement Characteristics

#### Breathing Cycle
```
Scale: 1.0 -> 1.05 -> 1.0
Duration: 3 seconds
Easing: Sine wave
Purpose: Shows "aliveness"
```

#### Idle Animation
```python
def idle_movement(time: float) -> Vector3:
    # Gentle floating
    x = sin(time * 0.5) * 0.02
    y = sin(time * 0.3) * 0.03
    z = sin(time * 0.4) * 0.01
    return Vector3(x, y, z)
```

#### Emotional Transitions
- Happy: Bounce (0.1 units, 0.5s period)
- Confused: Tilt (15°, slow rotation)
- Thinking: Orbit (small circular motion)
- Concerned: Lean forward (10° tilt)

### Gesture Library

#### Pointing
```
Preparation: Shrink slightly (0.95x)
Execution: Extend toward target
Hold: 0.5 seconds
Recovery: Smooth return
```

#### Nodding
```
Movement: Vertical translation
Amplitude: 0.1 units
Speed: 2 nods/second
Pattern: Down-up-down-up-center
```

#### Celebration
```
1. Quick expansion (1.2x)
2. Emit particle burst
3. Spiral upward
4. Gentle float down
```

## Particle Effects

### Particle Types

#### Sparkles (Joy/Success)
```python
sparkle_params = {
    "count": 50,
    "lifetime": 2.0,
    "size": 0.01,
    "color": "golden",
    "pattern": "radial_burst",
    "gravity": -0.5  # Float up
}
```

#### Question Marks (Confusion)
```python
question_params = {
    "count": 3,
    "lifetime": 3.0,
    "size": 0.05,
    "color": "purple",
    "pattern": "orbit",
    "rotation": True
}
```

#### Data Streams (Processing)
```python
data_stream_params = {
    "count": 100,
    "lifetime": 1.0,
    "size": 0.005,
    "color": "cyan",
    "pattern": "helix",
    "speed": 2.0
}
```

#### Hearts (Affection/Pride)
```python
heart_params = {
    "count": 10,
    "lifetime": 4.0,
    "size": 0.03,
    "color": "pink",
    "pattern": "float_up",
    "wobble": True
}
```

## Aura Design

### Consciousness Field Visualization

#### Basic Aura
```
     · · · · ·
   ·           ·
 ·               ·
·     AVATAR      ·
 ·               ·
   ·           ·
     · · · · ·
```

#### Coherence Levels
1. **Low (0.0-0.3)**: Sparse, flickering particles
2. **Medium (0.3-0.7)**: Steady glow, defined edge
3. **High (0.7-1.0)**: Bright, pulsing mandala patterns

### Shader Patterns

```glsl
// Consciousness field shader
float consciousness_field(vec2 pos, float time, float coherence) {
    float dist = length(pos - avatar_center);
    float wave = sin(dist * 10.0 - time * 2.0) * 0.5 + 0.5;
    float field = exp(-dist / 100.0) * wave * coherence;
    
    // Add mandala pattern at high coherence
    if (coherence > 0.7) {
        float angle = atan2(pos.y, pos.x);
        field += sin(angle * 8.0) * 0.1 * (coherence - 0.7);
    }
    
    return field;
}
```

## Accessibility Design

### High Contrast Mode

```python
HIGH_CONTRAST_COLORS = {
    "avatar": "#000000",          # Pure black
    "glow": "#FFFFFF",            # Pure white
    "background": "transparent",
    "particles": "#FFFF00"        # Yellow
}
```

### Screen Reader Descriptions

```python
SCREEN_READER_DESCRIPTIONS = {
    "appearing": "Nix avatar fading in",
    "happy": "Nix is bouncing happily",
    "confused": "Nix tilts head in confusion",
    "thinking": "Nix is processing, showing thinking animation",
    "pointing": "Nix points toward {target}",
    "celebrating": "Nix celebrates with sparkles"
}
```

### Reduced Motion Mode

- Disable: Bouncing, orbiting, complex particles
- Keep: Simple fades, color changes, minimal movement
- Alternative: Status text instead of animation

## Size and Positioning

### Default Sizes

```python
AVATAR_SIZES = {
    "tiny": 0.05,      # 5% of screen height
    "small": 0.08,     # 8% of screen height
    "medium": 0.12,    # 12% of screen height (default)
    "large": 0.18,     # 18% of screen height
    "huge": 0.25       # 25% of screen height
}
```

### Screen Positions

```python
POSITIONS = {
    "bottom_right": (0.85, 0.85),    # Default
    "bottom_left": (0.15, 0.85),
    "top_right": (0.85, 0.15),
    "top_left": (0.15, 0.15),
    "center": (0.5, 0.5),
    "floating": "dynamic"             # Moves based on content
}
```

## Visual States

### Listening State
- Slight tilt toward user input area
- Gentle pulsing glow
- Occasional blink animation
- Particles drawn inward

### Processing State
- Spinning segments or rings
- Data particle streams
- Gradually brightening glow
- Center core activity

### Speaking State
- Rhythmic pulsing with speech
- Outward particle emission
- Brightness variations
- Lip sync (if applicable)

### Error State
- Gentle shake animation
- Red-orange color shift
- Concerned expression
- Helper particles

## Integration Examples

### With Terminal
```
┌─[user@nixos:~]────────────────────┐
│ $ ask-nix-enhanced "install firefox"│
│                                    │
│ Nix: Installing Firefox...     ⊙   │
│      [████████--] 80%          ╱│╲ │
│                               ╱ │ ╲│
└────────────────────────────────────┘
```

### With GUI
- Avatar hovers near relevant UI elements
- Points at buttons or fields
- Creates visual connections between elements
- Guides user attention naturally

## Evolution and Growth

### Visual Progression
1. **New User**: Simple, small, unobtrusive
2. **Regular User**: More expressive, confident movements
3. **Power User**: Complex particles, advanced gestures
4. **Master**: Minimal but profound presence

### Learning Visualization
- Each learned pattern adds a subtle layer to aura
- Knowledge represented as crystalline structures
- Growth shown through size/complexity increase
- Mastery indicated by elegant simplicity

## Cultural Sensitivity

### Avoiding Problematic Imagery
- No religious symbols without user consent
- No gender assumptions in form
- No cultural stereotypes
- Respectful color choices

### Optional Cultural Themes
- Users can select cultural aesthetic overlays
- Respectful integration of requested symbols
- Always with opt-in consent
- Educational context provided

## Performance Considerations

### LOD (Level of Detail) System

#### LOD 0 (Minimum)
- Simple circle/square
- Flat colors
- No particles
- Basic movement

#### LOD 1 (Low)
- Basic 3D shape
- Simple shading
- Few particles
- Smooth movement

#### LOD 2 (Medium)
- Detailed mesh
- Dynamic lighting
- Moderate particles
- Full animations

#### LOD 3 (Maximum)
- Complex geometry
- Advanced shaders
- Rich particles
- All effects

### Optimization Guidelines
- Particle count scales with performance
- Animation complexity adapts to framerate
- Texture resolution based on screen size
- Effect quality matches system capability

## Future Considerations

### AR/VR Design
- Volumetric presence
- Spatial audio integration
- Hand gesture interaction
- Environmental awareness

### Multi-Avatar Scenarios
- Visual hierarchy for multiple assistants
- Synchronized movements
- Distinct personalities
- Collaborative animations

### User Customization
- Custom color palettes
- Personal avatar shapes
- Unique particle effects
- Recorded gestures

## Design Documentation

### Asset Requirements
```
assets/
├── models/
│   ├── orb_base.glb          # 2KB
│   ├── crystal_form.glb      # 5KB
│   └── friendly_form.glb     # 8KB
├── textures/
│   ├── glow_gradient.png     # 4KB
│   ├── particle_sheet.png    # 16KB
│   └── aura_pattern.png      # 8KB
└── shaders/
    ├── consciousness.glsl     # 2KB
    ├── particle.glsl         # 1KB
    └── aura.glsl             # 3KB
```

### Visual Testing Checklist
- [ ] All emotions clearly distinguishable
- [ ] Animations smooth at 60fps
- [ ] Particles readable on all backgrounds
- [ ] Accessible in high contrast mode
- [ ] Screen reader descriptions accurate
- [ ] Cultural sensitivity verified
- [ ] Performance scales appropriately

## Conclusion

The visual design of the Embodied AI Partner balances expressiveness with subtlety, creating a presence that enhances rather than distracts. Through careful attention to form, color, movement, and cultural sensitivity, Nix becomes a trusted visual companion that adapts to each user's needs while maintaining a coherent identity.

The ultimate goal is an AI presence that feels alive without being human, helpful without being intrusive, and beautiful without being distracting - a true partner in the journey of conscious computing.