# Execution Defaults Summary

As of 2025-01-28, all Nix for Humanity tools default to **REAL EXECUTION** mode:

## Tool Defaults

### ask-nix-modern
- `self.dry_run = False` (line 68)
- Executes commands by default
- Use `--dry-run` flag for safe mode

### nix-profile-do
- `dry_run = False` (line 124)
- Executes commands by default
- Use `--dry-run` flag for safe mode

### nix-do
- `dry_run = False` (line 158)
- Executes commands by default
- Use `--dry-run` flag for safe mode

### execution-bridge.js
- No dry-run concept - always executes when called
- Provides safe command execution through spawn()
- Handles timeouts and educational errors

## Philosophy

The tools now follow "execution by default" principle:
- Users expect commands to work, not just show instructions
- Dry-run is available as an option for safety
- Educational error messages help when things fail
- Bridge pattern provides safe execution

## Usage Examples

```bash
# These all EXECUTE by default:
ask-nix-modern "install firefox"      # Actually installs
nix-profile-do "install htop"         # Actually installs
nix-do "search firefox"               # Actually searches

# Use --dry-run for safety:
ask-nix-modern --dry-run "update system"  # Shows what would happen
```