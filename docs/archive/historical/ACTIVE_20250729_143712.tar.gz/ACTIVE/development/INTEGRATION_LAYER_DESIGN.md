# 🔗 Integration Layer Design - Connecting the Pieces

## Overview

The integration layer connects our TypeScript NLP engine with command-line execution. We have two solid ends - we just need the bridge.

## Current Architecture

```
User Input → CLI Tool → ??? → NLP Engine → ??? → Executor → NixOS
              (Python)         (TypeScript)       (TypeScript)
```

## Proposed Integration Architecture

```
User Input 
    ↓
CLI Entry Point (bin/ask-nix)
    ↓
Node.js Bridge (bin/nix-nlp-bridge.js)
    ↓
NLP Engine (packages/nlp/src/index.ts)
    ↓
Command Executor (packages/nlp/src/core/command-executor.ts)
    ↓
NixOS Commands
```

## Key Code Snippets Needed

### 1. Node.js CLI Bridge (`bin/nix-nlp-bridge.js`)

```javascript
#!/usr/bin/env node

import { NLPEngine } from '../packages/nlp/dist/index.js';
import { parseArgs } from 'util';

// Parse command line arguments
const { values, positionals } = parseArgs({
  options: {
    execute: { type: 'boolean', default: false },
    'dry-run': { type: 'boolean', default: true },
    personality: { type: 'string', default: 'friendly' },
    quiet: { type: 'boolean', default: false }
  }
});

// Create NLP engine with proper config
const nlpConfig = {
  mode: values.execute ? 'full' : 'standard',
  enableLearning: true,
  enableContext: true,
  enableFuzzyMatching: true,
  executeReal: values.execute && !values['dry-run']
};

const engine = new NLPEngine(nlpConfig);

// Process input
const input = positionals.join(' ');
const result = await engine.processInput(input);

// Output result
if (values.quiet) {
  console.log(result.response);
} else {
  console.log('🎯 Intent:', result.intent?.type || 'unknown');
  console.log('📦 Command:', result.command || 'none');
  console.log('\n' + result.response);
  
  if (result.suggestions?.length > 0) {
    console.log('\n💡 Suggestions:');
    result.suggestions.forEach(s => console.log(`  - ${s}`));
  }
}

process.exit(result.success ? 0 : 1);
```

### 2. Update NLP Config (`packages/nlp/src/index.ts`)

Add to NLPConfig interface:

```typescript
export interface NLPConfig {
  mode: 'minimal' | 'standard' | 'full';
  enableLearning?: boolean;
  enableContext?: boolean;
  enableFuzzyMatching?: boolean;
  sacredMode?: boolean;
  executeReal?: boolean;  // ADD THIS
}
```

Update CommandExecutor initialization:

```typescript
// In NLPEngine constructor
this.commandExecutor = new CommandExecutor({
  dryRun: !config.executeReal,
  defaultTimeout: 30000
});
```

### 3. Update Command Executor (`packages/nlp/src/core/command-executor.ts`)

Add configuration support:

```typescript
export interface ExecutorConfig {
  dryRun: boolean;
  defaultTimeout: number;
  requireConfirmation?: boolean;
}

export class CommandExecutor {
  private config: ExecutorConfig;
  
  constructor(config: ExecutorConfig = { dryRun: true, defaultTimeout: 30000 }) {
    this.config = config;
  }
  
  async execute(
    command: SafeCommand, 
    options: ExecutionOptions = {}
  ): Promise<CommandResult> {
    // Use config.dryRun as default, allow override
    const dryRun = options.dryRun ?? this.config.dryRun;
    
    if (dryRun) {
      return this.dryRunExecution(command);
    }
    
    // Add confirmation for dangerous commands
    if (this.config.requireConfirmation && this.isDangerousCommand(command)) {
      const confirmed = await this.confirmExecution(command);
      if (!confirmed) {
        return {
          success: false,
          response: 'Command cancelled by user',
          command: this.formatCommandString(command)
        };
      }
    }
    
    // ... rest of execution logic
  }
}
```

### 4. Unified CLI Entry Point (`bin/ask-nix`)

```bash
#!/usr/bin/env bash
# Unified entry point that delegates to the right tool

# Check if Node.js is available
if command -v node >/dev/null 2>&1; then
    # Use the integrated TypeScript version
    exec node "$(dirname "$0")/nix-nlp-bridge.js" "$@"
else
    # Fall back to Python version
    exec python3 "$(dirname "$0")/ask-nix-v3" "$@"
fi
```

## Files to Modify

### Priority 1 - Core Integration
1. `packages/nlp/src/index.ts` - Add executeReal flag
2. `packages/nlp/src/core/command-executor.ts` - Support real execution
3. Create `bin/nix-nlp-bridge.js` - Node.js CLI wrapper
4. Create `bin/ask-nix` - Unified entry point

### Priority 2 - Enhanced Integration  
5. `packages/nlp/src/types.ts` - Add execution config types
6. `packages/executor/src/index.ts` - If separate executor needed
7. Update `package.json` - Add CLI script entries

### Priority 3 - Testing & Polish
8. Create `test/integration/cli-test.js` - Integration tests
9. Update `bin/ask-nix-v3` - Align flags with new CLI
10. Create `docs/CLI_USAGE.md` - Document the unified interface

## Connection Points

### TypeScript → Command Line
```typescript
// In packages/nlp/package.json
{
  "bin": {
    "nix-nlp": "./dist/cli.js"
  },
  "scripts": {
    "build:cli": "esbuild src/cli.ts --bundle --platform=node --outfile=dist/cli.js"
  }
}
```

### Python → TypeScript (Alternative)
```python
# In bin/ask-nix-hybrid
import subprocess
import json

def call_nlp_engine(query, options):
    """Call TypeScript NLP engine via Node.js"""
    cmd = ['node', 'bin/nix-nlp-bridge.js', '--json'] + options + [query]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return json.loads(result.stdout)
```

## Testing the Integration

```bash
# Test 1: Dry run (default)
./bin/ask-nix "install firefox"
# Should show: "Would execute: nix-env -iA nixos.firefox"

# Test 2: Real execution
./bin/ask-nix --execute --no-dry-run "install firefox"
# Should actually install Firefox

# Test 3: Search command
./bin/ask-nix --execute "search python"
# Should return real search results

# Test 4: With personality
./bin/ask-nix --personality minimal "update system"
# Should give minimal response style
```

## Success Metrics

1. **Single Entry Point**: Users only need to know about `ask-nix`
2. **Consistent Behavior**: Same flags and options across implementations
3. **Real Execution**: Commands actually run when requested
4. **Graceful Fallback**: Works even if Node.js unavailable
5. **Clear Output**: Users understand what happened

## Next Steps

1. Implement the Node.js bridge (30 mins)
2. Update NLP engine config (15 mins)
3. Test with real commands (30 mins)
4. Create unified entry point (15 mins)
5. Document the integration (30 mins)

Total: ~2 hours to full integration