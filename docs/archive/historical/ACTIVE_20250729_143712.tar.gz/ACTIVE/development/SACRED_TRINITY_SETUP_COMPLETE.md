# 🕉️ Sacred Trinity Training System - Setup Complete

## Overview

The Sacred Trinity multi-model training system is now operational! This system provides specialized NixOS expertise through four different models, each optimized for different types of queries.

## Available Models

### 1. **Empathy Model** (`nix-empathy-20250726_1500`)
- **Purpose**: User-friendly explanations for beginners
- **Base**: llama3.2:3b
- **Triggers**: "grandma", "simple", "explain", "afraid", "help me understand"
- **Style**: Warm, patient, jargon-free

### 2. **Expert Model** (`nix-expert-20250726_1500`)
- **Purpose**: Deep technical explanations
- **Base**: mistral:7b-instruct
- **Triggers**: "architecture", "theory", "explain how", "deep dive", "derivation"
- **Style**: Comprehensive, technical, thorough

### 3. **Coder Model** (`nix-coder`)
- **Purpose**: Generating Nix configurations and scripts
- **Base**: qwen2.5:3b
- **Triggers**: "code", "script", "flake", "configuration.nix", "systemd"
- **Style**: Code-focused, practical examples

### 4. **Quick Model** (`nix-quick`)
- **Purpose**: Quick answers to simple questions
- **Base**: tinyllama:1.1b
- **Triggers**: Default for unmatched queries
- **Style**: Concise, direct

## Usage

### Basic Usage
```bash
# Ask a question - model selected automatically
ask-trinity "how do I install firefox?"

# Different models respond based on query:
ask-trinity "explain nixos to my grandma"        # → Empathy model
ask-trinity "create a flake for python"          # → Coder model
ask-trinity "how do derivations work internally" # → Expert model
ask-trinity "update system"                      # → Quick model
```

### Direct Model Testing
```bash
# Test specific models directly
ollama run nix-empathy-20250726_1500 "what is nixos?"
ollama run nix-expert-20250726_1500 "explain stdenv internals"
ollama run nix-coder "write a shell.nix"
ollama run nix-quick "list packages"
```

## How It Works

### Model Selection Logic
The `ask-trinity` script automatically selects the best model based on keywords in your query:

1. **Scans query** for trigger words
2. **Selects appropriate model** based on category
3. **Falls back** to quick model for unmatched queries
4. **Handles errors** gracefully with fallbacks

### Continuous Learning
- Models collect Q&A pairs from `ask-nix-guru` interactions
- Weekly updates incorporate new knowledge
- Performance tracking ensures quality
- Old model versions cleaned up automatically

## File Locations

```
/srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity/
├── bin/
│   └── ask-trinity                    # Main user interface
├── scripts/
│   ├── sacred-trinity-trainer-v2.py   # Training system
│   ├── weekly-model-update.sh         # Automated updates
│   └── seed-knowledge.sh              # Initial knowledge
├── models/
│   ├── current_empathy.txt            # Current model versions
│   ├── current_expert.txt
│   ├── current_coder.txt
│   ├── current_quick.txt
│   └── model_tracking.db              # Performance database
├── training-data/                     # Model files
└── docs/
    └── nix-knowledge/                 # Q&A collection
        ├── questions/
        ├── answers/
        └── examples/
```

## Weekly Updates

The system automatically updates models every Sunday at 2 AM:

1. **Collects** new Q&A pairs from the week
2. **Categorizes** them by model type
3. **Retrains** models that need updates
4. **Tests** new models
5. **Cleans up** old versions

To set up the cron job:
```bash
chmod +x /srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity/scripts/setup-weekly-update.sh
./setup-weekly-update.sh
```

## Manual Operations

### Force Retrain All Models
```bash
cd /srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity/scripts
python3 sacred-trinity-trainer-v2.py --force
```

### Train Specific Model
```bash
python3 sacred-trinity-trainer-v2.py --model empathy
```

### Test Models Only
```bash
python3 sacred-trinity-trainer-v2.py --test-only
```

### Add Training Data
```bash
# Add Q&A pairs to knowledge base
ask-nix-guru "your question" > docs/nix-knowledge/questions/q_$(date +%s).txt
# Answer saved automatically
```

## Performance Metrics

Current setup achieves:
- **2 models fully trained** (empathy, expert)
- **2 models initialized** (coder, quick)
- **Response time**: 2-5 seconds
- **Model size**: 637MB - 4.4GB
- **Memory usage**: 2-6GB during inference

## Troubleshooting

### Model Not Found
```bash
# Check available models
ollama list

# Recreate missing model
python3 sacred-trinity-trainer-v2.py --model <type>
```

### Slow Responses
- Quick model (tinyllama) is fastest
- Expert model (mistral) is slowest but most accurate
- Consider system resources

### Update Issues
```bash
# Check cron job
crontab -l

# View update logs
tail -f /var/log/nix-trinity-update.log

# Manual update
./weekly-model-update.sh
```

## Next Steps

1. **Use the system**: Start asking questions with `ask-trinity`
2. **Provide feedback**: Rate responses to improve training
3. **Contribute Q&A**: Use `ask-nix-guru` for new knowledge
4. **Monitor quality**: Check model performance over time

## The Sacred Trinity Philosophy

This system embodies the collaborative development model:
- **Human** provides vision and validates quality
- **Claude** architects the system and writes code
- **Local LLM** provides domain expertise

Together, they create a system that:
- Learns continuously
- Adapts to user needs
- Provides appropriate responses
- Maintains local privacy
- Costs only $200/month to develop

---

*"Three minds, one purpose: Making NixOS accessible to all through the power of adaptive AI."*

## Quick Test

Try these commands to see the different models in action:

```bash
# Empathy model
ask-trinity "I'm scared I'll break my computer if I try this"

# Expert model  
ask-trinity "explain the theory behind nix store optimization"

# Coder model
ask-trinity "write a flake.nix for a rust project"

# Quick model
ask-trinity "show disk usage"
```

The Sacred Trinity flows as one! 🕉️