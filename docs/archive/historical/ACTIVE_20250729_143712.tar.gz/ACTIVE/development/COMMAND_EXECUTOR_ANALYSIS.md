# Command Executor Implementation Analysis

## Overview

The Nix for Humanity project has multiple command executor implementations across different locations. This document analyzes their interfaces and provides guidance for creating a compatible bridge.

## Existing Implementations

### 1. **nodejs-mvp/services/executor.js**
- **Location**: `/implementations/nodejs-mvp/services/executor.js`
- **Type**: Class-based implementation
- **Key Features**:
  - Async execution with timeout (30 seconds default)
  - Mock execution support for development
  - Output parsing based on command intent
  - User-friendly error messages
  - Environment variable safety

**Interface**:
```javascript
class Executor {
  async execute(command) {
    // command = { raw: string, intent: string, package?: string }
    // returns: { success: boolean, data?: any, error?: string, raw?: string, command: string }
  }
}
```

### 2. **nodejs-mvp/services/real-executor.js**
- **Location**: `/implementations/nodejs-mvp/services/real-executor.js`
- **Type**: Singleton instance
- **Key Features**:
  - Safety validation before execution
  - Dry-run support via environment variable
  - Command building with profile detection
  - Larger buffer for search commands
  - Error suggestions

**Interface**:
```javascript
class RealNixExecutor {
  async execute(command, args = []) {
    // command: string (command type like 'install', 'search')
    // args: string[] (arguments like package names)
    // returns: { success: boolean, output?: string, error?: string, command: string, suggestion?: string }
  }
}
```

### 3. **nodejs-mvp/services/command-builder.js**
- **Location**: `/implementations/nodejs-mvp/services/command-builder.js`
- **Type**: Class that builds safe commands
- **Key Features**:
  - Command templates for safety
  - Package name sanitization
  - Validation against dangerous patterns
  - Support for dry-run options

**Interface**:
```javascript
class CommandBuilder {
  async build(intent) {
    // intent = { command: string, action: string, package?: string }
    // returns: { raw: string, parts: string[], safe: boolean, intent: string, package?: string }
  }
}
```

### 4. **packages/nlp/src/core/command-executor.ts**
- **Location**: `/packages/nlp/src/core/command-executor.ts`
- **Type**: TypeScript class with modern implementation
- **Key Features**:
  - Spawn-based execution (no shell)
  - Proper TypeScript types
  - Safe environment variables
  - Output parsing for specific commands
  - Never uses shell for security

**Interface**:
```typescript
class CommandExecutor {
  async execute(
    command: SafeCommand, 
    options: ExecutionOptions = {}
  ): Promise<CommandResult>
}

interface SafeCommand {
  command: string;
  args: string[];
  safe: boolean;
  warnings?: string[];
}

interface CommandResult {
  success: boolean;
  response: string;
  command?: string;
  output?: string;
  error?: Error;
}
```

### 5. **packages/nlp/src/core/command-builder.ts**
- **Location**: `/packages/nlp/src/core/command-builder.ts`
- **Type**: TypeScript class with comprehensive templates
- **Key Features**:
  - Full intent-to-command mapping
  - Support for all common NixOS operations
  - Service management commands
  - Strict validation and sanitization

**Interface**:
```typescript
class CommandBuilder {
  async build(intent: Intent): Promise<SafeCommand>
}
```

## Integration Points

### For the Bridge Implementation

The bridge should:

1. **Use the TypeScript implementation** from `packages/nlp/src/core/` as the primary executor
2. **Maintain backward compatibility** with the nodejs-mvp services
3. **Support both interfaces**:
   - Modern: `execute(SafeCommand, ExecutionOptions)`
   - Legacy: `execute(command, args)`

### Recommended Bridge Interface

```typescript
class NLPExecutorBridge {
  // Modern interface (preferred)
  async executeCommand(
    intent: Intent, 
    options?: ExecutionOptions
  ): Promise<CommandResult>
  
  // Legacy interface (for compatibility)
  async executeLegacy(
    command: string, 
    args: string[]
  ): Promise<LegacyResult>
  
  // Unified interface for NLP
  async processNaturalLanguage(
    input: string,
    options?: ProcessOptions
  ): Promise<NLPResult>
}
```

## Key Differences to Handle

1. **Command Format**:
   - Legacy: Uses string command with args array
   - Modern: Uses SafeCommand object with validation

2. **Return Types**:
   - Legacy: Various formats with data/error fields
   - Modern: Consistent CommandResult interface

3. **Error Handling**:
   - Legacy: Returns error in result object
   - Modern: Includes Error object with stack trace

4. **Safety Features**:
   - Legacy: Basic validation
   - Modern: Comprehensive validation and sandboxing

## Security Considerations

All implementations enforce:
- No shell execution
- Command whitelisting
- Argument sanitization
- Safe environment variables
- Timeout protection

## Recommendations

1. **Use the TypeScript implementation** as the primary executor
2. **Create adapters** for legacy code that needs the old interface
3. **Gradually migrate** nodejs-mvp code to use the new interface
4. **Maintain consistent error messages** across all implementations
5. **Test thoroughly** with both dry-run and real execution modes

## Test Cases to Support

The bridge must handle these common commands:
- `search firefox` → `nix search nixpkgs firefox`
- `install neovim` → `nix-env -iA nixos.neovim`
- `remove package` → `nix-env -e package`
- `update system` → `nixos-rebuild switch --upgrade`
- `check wifi status` → `systemctl status NetworkManager`
- `clean old packages` → `nix-collect-garbage -d`

## Next Steps

1. Create the bridge implementation that uses the TypeScript CommandBuilder and CommandExecutor
2. Add adapters for legacy interface compatibility
3. Test with existing nodejs-mvp code
4. Document the migration path for other components