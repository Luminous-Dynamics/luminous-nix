# 🐍 Python Environment Setup - Nix for Humanity

## The Issue

Python 3 is not available in the default system PATH but is provided through the nix-shell environment.

## Quick Solution

### Option 1: Enter Nix Shell (Recommended)

```bash
cd /srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity
nix-shell

# Now Python 3 is available
python3 --version  # Python 3.12.7
```

### Option 2: Use the Helper Script

```bash
# Run any command with Python available
./run-in-nix-shell.sh python3 scripts/nix-knowledge-engine.py

# Test the enhanced tool
./run-in-nix-shell.sh ./test-enhanced-tool.sh
```

### Option 3: Automatic Shell Entry

The test scripts now automatically enter nix-shell if needed:

```bash
# Just run directly - it will enter nix-shell automatically
./test-enhanced-tool.sh
```

## Why Nix Shell?

Nix for Humanity uses a declarative development environment defined in `shell.nix` that provides:

- **Python 3.12.7** with pip, flask, gunicorn
- **Node.js 20** for the web implementation
- **SQLite** for the knowledge base
- **Development tools** like git, curl, jq
- **SSL/TLS support** via openssl

This ensures all developers have the exact same environment regardless of their system configuration.

## What's Available in Nix Shell

```bash
# Check what's available
nix-shell
echo $IN_NIX_SHELL  # Should show "pure" or "impure"

# Python tools
python3 --version   # Python 3.12.7
pip --version       # pip package manager
python3 -m flask --version  # Flask web framework

# Other tools
node --version      # Node.js 20
npm --version       # NPM package manager
sqlite3 --version   # SQLite database
```

## Development Workflow

### 1. Always Start with Nix Shell

```bash
cd /srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity
nix-shell

# Your prompt should change to show you're in nix-shell
# Now all tools are available
```

### 2. Run Python Scripts

```bash
# Test the knowledge engine
python3 scripts/nix-knowledge-engine.py

# Run the hybrid assistant
python3 bin/ask-nix-hybrid "How do I install Firefox?"

# Test the enhanced tool
./bin/ask-nix-enhanced "What is NixOS?"
```

### 3. Exit When Done

```bash
exit  # Leave nix-shell
```

## Troubleshooting

### "python3: command not found"

You're not in nix-shell. Run `nix-shell` first.

### "No such file or directory"

Make sure you're in the project directory:
```bash
cd /srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity
```

### Slow First Run

The first time you run `nix-shell`, it may download dependencies. This is normal and only happens once.

## VS Code / Editor Integration

If using VS Code or another editor:

1. Open terminal in VS Code
2. Run `nix-shell` in the terminal
3. Now Python LSP and linting will work correctly

## Summary

- **Always use `nix-shell`** for development
- **Python 3.12.7** is available inside nix-shell
- **Scripts automatically detect** and enter nix-shell when needed
- **All dependencies** are managed declaratively

This ensures consistent development environments across all contributors!