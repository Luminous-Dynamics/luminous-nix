# 📚 Training Local Models on NixOS Documentation

*Creating specialized NixOS expertise for the Sacred Trinity workflow*

## Overview

Training our local models (Mistral-7B, CodeLlama-13B) on NixOS documentation will dramatically improve their ability to provide accurate, idiomatic NixOS advice. This guide covers ethical scraping, processing, and fine-tuning approaches.

## Why Train on NixOS Docs?

### Current Limitations
- General models have limited NixOS knowledge
- Often suggest outdated or non-idiomatic patterns
- Miss NixOS-specific best practices
- Can't provide flake-based examples

### After Training Benefits
- Deep understanding of NixOS concepts
- Current best practices and patterns
- Flake-first recommendations
- Accurate troubleshooting advice
- Understanding of NixOS philosophy

## Data Sources

### Primary Sources
```yaml
Official Documentation:
  - NixOS Manual: https://nixos.org/manual/nixos/stable/
  - Nix Manual: https://nixos.org/manual/nix/stable/
  - Nixpkgs Manual: https://nixos.org/manual/nixpkgs/stable/
  - NixOS Wiki: https://nixos.wiki/
  - Nix Pills: https://nixos.org/guides/nix-pills/

Community Resources:
  - Discourse Forum: https://discourse.nixos.org/
  - Reddit r/NixOS: High-quality posts only
  - GitHub nixpkgs: Issue discussions & PRs
  - Blog posts from prominent community members

Code Examples:
  - Official examples repository
  - Well-maintained dotfiles repos
  - NixOS configurations from experts
```

### Quality Criteria
- Official sources weighted highest
- Community content filtered by engagement
- Code examples must be recent (post-flakes)
- Exclude outdated practices

## Ethical Scraping Approach

### Respect robots.txt
```python
import requests
from urllib.robotparser import RobotFileParser

def can_fetch(url):
    rp = RobotFileParser()
    rp.set_url(url + "/robots.txt")
    rp.read()
    return rp.can_fetch("*", url)
```

### Rate Limiting
```python
import time
from functools import wraps

def rate_limit(calls_per_second=1):
    min_interval = 1.0 / calls_per_second
    last_called = [0.0]
    
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            elapsed = time.time() - last_called[0]
            left_to_wait = min_interval - elapsed
            if left_to_wait > 0:
                time.sleep(left_to_wait)
            ret = func(*args, **kwargs)
            last_called[0] = time.time()
            return ret
        return wrapper
    return decorator
```

### Attribution & Licensing
```yaml
Data Collection Rules:
  - Always preserve source URLs
  - Respect content licenses
  - Attribute authors when known
  - Follow NixOS documentation license (MIT)
  - Include license in training data
```

## Data Collection Pipeline

### 1. Documentation Scraper
```python
#!/usr/bin/env python3
# scripts/scrape-nixos-docs.py

import requests
from bs4 import BeautifulSoup
import json
import time
from pathlib import Path

class NixOSDocScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'NixForHumanity-DocBot/1.0 (Educational)'
        })
        self.output_dir = Path('training-data/nixos-docs')
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    @rate_limit(0.5)  # 2 requests per second
    def fetch_page(self, url):
        response = self.session.get(url)
        response.raise_for_status()
        return response.text
    
    def parse_manual_page(self, html, source_url):
        soup = BeautifulSoup(html, 'html.parser')
        
        # Extract main content
        content = soup.find('div', class_='chapter') or soup.find('div', class_='section')
        if not content:
            return None
        
        # Clean and structure
        return {
            'source': source_url,
            'title': soup.find('title').text,
            'content': content.get_text(strip=True),
            'code_examples': [code.text for code in content.find_all('pre')],
            'timestamp': time.time()
        }
    
    def save_training_data(self, data, filename):
        output_path = self.output_dir / f"{filename}.json"
        with open(output_path, 'w') as f:
            json.dump(data, f, indent=2)
```

### 2. Data Processor
```python
#!/usr/bin/env python3
# scripts/process-training-data.py

import json
from pathlib import Path
import re

class TrainingDataProcessor:
    def __init__(self):
        self.input_dir = Path('training-data/nixos-docs')
        self.output_dir = Path('training-data/processed')
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def create_qa_pairs(self, doc):
        """Extract Q&A pairs from documentation"""
        qa_pairs = []
        
        # Pattern: Headers followed by content
        sections = re.split(r'\n#{1,3}\s+', doc['content'])
        
        for i in range(0, len(sections)-1):
            if '?' in sections[i]:  # Likely a question
                qa_pairs.append({
                    'question': sections[i].strip(),
                    'answer': sections[i+1].strip(),
                    'source': doc['source']
                })
        
        return qa_pairs
    
    def create_instruction_data(self, doc):
        """Create instruction-following format"""
        instructions = []
        
        for example in doc['code_examples']:
            # Extract explanation before code
            context = self.extract_context(doc['content'], example)
            
            instructions.append({
                'instruction': f"How do I {context}?",
                'input': '',
                'output': example,
                'source': doc['source']
            })
        
        return instructions
    
    def process_all_documents(self):
        all_qa = []
        all_instructions = []
        
        for doc_path in self.input_dir.glob('*.json'):
            with open(doc_path) as f:
                doc = json.load(f)
            
            all_qa.extend(self.create_qa_pairs(doc))
            all_instructions.extend(self.create_instruction_data(doc))
        
        # Save processed data
        with open(self.output_dir / 'qa_pairs.json', 'w') as f:
            json.dump(all_qa, f, indent=2)
        
        with open(self.output_dir / 'instructions.json', 'w') as f:
            json.dump(all_instructions, f, indent=2)
```

### 3. Training Data Formatter
```python
#!/usr/bin/env python3
# scripts/format-for-training.py

class TrainingFormatter:
    def __init__(self):
        self.formats = {
            'alpaca': self.format_alpaca,
            'conversation': self.format_conversation,
            'completion': self.format_completion
        }
    
    def format_alpaca(self, data):
        """Format for Alpaca-style fine-tuning"""
        return {
            'instruction': data['question'],
            'input': '',
            'output': data['answer']
        }
    
    def format_conversation(self, data):
        """Format as conversation"""
        return {
            'conversations': [
                {'from': 'human', 'value': data['question']},
                {'from': 'assistant', 'value': data['answer']}
            ]
        }
    
    def format_completion(self, data):
        """Format for completion-style training"""
        return f"Q: {data['question']}\nA: {data['answer']}"
```

## Fine-Tuning Approaches

### Option 1: LoRA Fine-Tuning (Recommended)
```bash
# Using Ollama with custom modelfile
cat > Modelfile.nixos << 'EOF'
FROM mistral:7b

# Set parameters
PARAMETER temperature 0.7
PARAMETER top_p 0.9

# Add NixOS-specific system prompt
SYSTEM """You are a NixOS expert assistant. You provide accurate, 
idiomatic NixOS advice following current best practices. You prefer 
declarative configuration, flakes, and reproducible approaches."""

# Add training data
ADAPTER ./nixos-lora-adapter.bin
EOF

# Create the model
ollama create nixos-expert -f Modelfile.nixos
```

### Option 2: Embedding-Based Retrieval
```python
# Create embeddings database
from sentence_transformers import SentenceTransformer
import numpy as np
import faiss

class NixOSKnowledgeBase:
    def __init__(self):
        self.embedder = SentenceTransformer('all-MiniLM-L6-v2')
        self.index = faiss.IndexFlatL2(384)  # Embedding dimension
        self.documents = []
    
    def add_documents(self, docs):
        embeddings = self.embedder.encode(docs)
        self.index.add(embeddings)
        self.documents.extend(docs)
    
    def search(self, query, k=5):
        query_embedding = self.embedder.encode([query])
        distances, indices = self.index.search(query_embedding, k)
        
        return [self.documents[i] for i in indices[0]]
```

### Option 3: Context Injection
```python
# Inject relevant docs into prompts
class ContextualNixGuru:
    def __init__(self, knowledge_base):
        self.kb = knowledge_base
    
    def answer(self, question):
        # Find relevant documentation
        relevant_docs = self.kb.search(question, k=3)
        
        # Build context
        context = "\n\n".join([
            f"From {doc['source']}:\n{doc['content'][:500]}..."
            for doc in relevant_docs
        ])
        
        # Create enhanced prompt
        prompt = f"""Based on the following NixOS documentation:

{context}

Question: {question}

Answer with NixOS best practices:"""
        
        return self.llm.generate(prompt)
```

## Implementation Plan

### Phase 1: Data Collection (Week 1)
```bash
# Set up scraping infrastructure
cd scripts/
python scrape-nixos-docs.py --source official-manual
python scrape-nixos-docs.py --source nix-pills
python scrape-nixos-docs.py --source wiki --quality-filter
```

### Phase 2: Processing (Week 2)
```bash
# Process into training formats
python process-training-data.py
python format-for-training.py --format alpaca
python create-embeddings.py
```

### Phase 3: Training (Week 3-4)
```bash
# Fine-tune models
python train-lora.py --model mistral:7b --data training-data/
python train-lora.py --model codellama:13b --data training-data/

# Or create embedding database
python build-knowledge-base.py
```

### Phase 4: Integration (Week 5)
```bash
# Update ask-nix-guru to use trained models
cat > config/trained-models.nix << 'EOF'
{
  models = {
    "mistral-nixos": {
      base = "mistral:7b";
      adapter = "./adapters/nixos-expert.bin";
      description = "Mistral fine-tuned on NixOS docs";
    };
    
    "codellama-nixos": {
      base = "codellama:13b";
      adapter = "./adapters/nixos-deep.bin";
      description = "CodeLlama with deep NixOS knowledge";
    };
  };
}
EOF
```

## Testing & Validation

### Benchmark Questions
```yaml
Basic:
  - "How do I install a package in NixOS?"
  - "What's the difference between nix-env and configuration.nix?"
  - "How do I update NixOS?"

Intermediate:
  - "How do I create a custom NixOS module?"
  - "Explain overlays with an example"
  - "How do I use flakes?"

Advanced:
  - "How do I debug infinite recursion in Nix?"
  - "Explain fixed-output derivations"
  - "How does Nix ensure reproducibility?"

Best Practices:
  - "Should I use channels or flakes?"
  - "How do I manage secrets in NixOS?"
  - "What's the best way to organize a multi-machine config?"
```

### Evaluation Metrics
- Accuracy of technical information
- Use of current best practices
- Code example correctness
- Explanation clarity
- Response relevance

## Continuous Improvement

### Update Cycle
```yaml
Monthly:
  - Scrape new documentation
  - Update Q&A pairs
  - Retrain adapters
  
Quarterly:
  - Major retraining
  - Evaluate model drift
  - Community feedback integration
```

### Community Contributions
```bash
# Accept community-curated training data
cat > CONTRIBUTING_TRAINING_DATA.md << 'EOF'
# Contributing Training Data

Submit high-quality NixOS Q&A pairs:
1. Must be accurate and current
2. Include source/attribution
3. Follow best practices
4. Test code examples

Format:
```json
{
  "question": "How do I create a systemd service in NixOS?",
  "answer": "Use systemd.services in configuration.nix...",
  "source": "personal experience",
  "nixos_version": "24.05",
  "tested": true
}
```
EOF
```

## Ethical Considerations

### Transparency
- Document all training data sources
- Make training data publicly available
- Clear attribution in responses

### Accuracy
- Regular validation against official docs
- Community review process
- Clear version dating

### Privacy
- No personal configs in training data
- Sanitize any sensitive information
- Respect contributor privacy

## Expected Outcomes

### Before Training
```
User: "How do I install Firefox?"
Model: "You can use apt-get install firefox or yum install firefox"
```

### After Training
```
User: "How do I install Firefox?"
Model: "In NixOS, add Firefox to your configuration.nix:

environment.systemPackages = with pkgs; [
  firefox
];

Then run: sudo nixos-rebuild switch

For temporary use: nix-shell -p firefox"
```

## Resource Requirements

### Storage
- Raw documentation: ~500MB
- Processed training data: ~200MB
- Model adapters: ~100MB per model
- Total: < 1GB

### Compute
- Data processing: 2-4 hours
- Fine-tuning: 8-24 hours (GPU recommended)
- Embedding generation: 1-2 hours

### Maintenance
- Monthly updates: 2-4 hours
- Community curation: Ongoing

## Conclusion

Training our local models on NixOS documentation will transform them from general assistants into NixOS experts. This creates a powerful Sacred Trinity where:

1. **Human** provides vision and user empathy
2. **Claude** architects sophisticated solutions
3. **NixOS-trained LLM** ensures everything follows best practices

The result: A development workflow that combines human creativity, AI capability, and deep domain expertise - all for $200/month.

---

*"When our models speak NixOS fluently, our users will too."*