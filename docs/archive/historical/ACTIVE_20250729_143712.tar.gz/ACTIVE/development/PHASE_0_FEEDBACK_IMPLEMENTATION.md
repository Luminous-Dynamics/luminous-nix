# 📊 Phase 0: Feedback Collection Implementation Guide

*The first seed of symbiotic evolution - implementing user feedback collection*

## Overview

This document provides detailed implementation instructions for the Phase 0 feedback mechanism, transforming the theoretical concepts from our Symbiotic Intelligence research into working code.

## Implementation Components

### 1. Core Feedback Collector Module

**File**: `scripts/feedback_collector.py`

```python
#!/usr/bin/env python3
"""
Feedback Collector for Nix for Humanity
Implements implicit and explicit feedback collection as per Symbiotic Intelligence research
"""

import sqlite3
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional, Tuple, List
from enum import Enum

class FeedbackType(Enum):
    EXPLICIT_POSITIVE = "explicit_positive"
    EXPLICIT_NEGATIVE = "explicit_negative"
    IMPLICIT_ACCEPT = "implicit_accept"
    IMPLICIT_MODIFY = "implicit_modify"
    IMPLICIT_REJECT = "implicit_reject"
    IMPLICIT_RETRY = "implicit_retry"

class InteractionOutcome(Enum):
    SUCCESS = "success"
    PARTIAL_SUCCESS = "partial_success"
    FAILURE = "failure"
    ABANDONED = "abandoned"

class FeedbackCollector:
    def __init__(self, db_path: str = None):
        """Initialize feedback collector with database"""
        if db_path is None:
            base_dir = Path("/srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity")
            db_path = base_dir / "data" / "feedback.db"
            db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.db_path = db_path
        self.conn = sqlite3.connect(str(self.db_path))
        self._init_database()
        
    def _init_database(self):
        """Initialize database schema for feedback collection"""
        # Main feedback table
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                session_id TEXT,
                
                -- User context
                user_state TEXT,  -- flow, focused, struggling, idle
                command_history TEXT,  -- JSON array of recent commands
                
                -- Interaction details
                user_prompt TEXT NOT NULL,
                ai_response TEXT NOT NULL,
                response_type TEXT,  -- command, explanation, error, suggestion
                confidence_score REAL,
                
                -- Feedback data
                feedback_type TEXT NOT NULL,
                was_helpful BOOLEAN,
                user_modification TEXT,
                better_response TEXT,
                time_to_feedback REAL,  -- seconds between response and feedback
                
                -- Outcomes
                interaction_outcome TEXT,
                command_executed BOOLEAN,
                execution_result TEXT,
                
                -- Learning metadata
                used_for_training BOOLEAN DEFAULT FALSE,
                training_batch INTEGER,
                preference_pair_id TEXT  -- Links chosen/rejected pairs
            )
        """)
        
        # Preference pairs for RLHF
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS preference_pairs (
                id TEXT PRIMARY KEY,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                prompt TEXT NOT NULL,
                chosen_response TEXT NOT NULL,
                rejected_response TEXT NOT NULL,
                chosen_feedback_id INTEGER,
                rejected_feedback_id INTEGER,
                confidence REAL,
                FOREIGN KEY (chosen_feedback_id) REFERENCES feedback(id),
                FOREIGN KEY (rejected_feedback_id) REFERENCES feedback(id)
            )
        """)
        
        # User patterns table
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS user_patterns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT,
                pattern_type TEXT,  -- preference, behavior, skill_level
                pattern_data TEXT,  -- JSON
                confidence REAL,
                first_observed DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_observed DATETIME DEFAULT CURRENT_TIMESTAMP,
                observation_count INTEGER DEFAULT 1
            )
        """)
        
        self.conn.commit()
    
    def collect_explicit_feedback(self, 
                                  prompt: str, 
                                  response: str,
                                  session_id: str = None) -> Tuple[bool, Optional[str]]:
        """Collect explicit yes/no feedback with optional improvement"""
        print("\n" + "="*50)
        print("📊 Feedback Collection")
        print("="*50)
        
        # Simple yes/no first
        helpful = input("\nWas this response helpful? (y/n): ").lower().strip() == 'y'
        
        better_response = None
        feedback_type = FeedbackType.EXPLICIT_POSITIVE if helpful else FeedbackType.EXPLICIT_NEGATIVE
        
        if not helpful:
            print("\nI'd like to learn from this. You can:")
            print("1. Tell me what would have been better")
            print("2. Skip (press Enter)")
            better_response = input("\nBetter response: ").strip()
            if not better_response:
                better_response = None
        
        # Store feedback
        self.store_feedback(
            prompt=prompt,
            ai_response=response,
            feedback_type=feedback_type,
            was_helpful=helpful,
            better_response=better_response,
            session_id=session_id
        )
        
        # Show appreciation
        if helpful:
            print("\n✅ Thank you! Your feedback helps me improve.")
        else:
            print("\n📝 I appreciate your feedback. I'll learn from this.")
        
        return helpful, better_response
    
    def collect_implicit_feedback(self,
                                  prompt: str,
                                  suggested_command: str,
                                  user_action: str,
                                  actual_command: str = None,
                                  execution_result: str = None,
                                  session_id: str = None):
        """Collect implicit feedback from user actions"""
        
        # Determine feedback type from action
        if user_action == "executed_as_suggested":
            feedback_type = FeedbackType.IMPLICIT_ACCEPT
            was_helpful = True
        elif user_action == "executed_modified":
            feedback_type = FeedbackType.IMPLICIT_MODIFY
            was_helpful = False  # Partially helpful
        elif user_action == "ignored":
            feedback_type = FeedbackType.IMPLICIT_REJECT
            was_helpful = False
        elif user_action == "asked_again":
            feedback_type = FeedbackType.IMPLICIT_RETRY
            was_helpful = False
        else:
            return  # Unknown action
        
        # Store implicit feedback
        self.store_feedback(
            prompt=prompt,
            ai_response=suggested_command,
            feedback_type=feedback_type,
            was_helpful=was_helpful,
            user_modification=actual_command,
            command_executed=execution_result is not None,
            execution_result=execution_result,
            session_id=session_id
        )
    
    def store_feedback(self, **kwargs):
        """Store feedback in database"""
        # Set defaults
        kwargs.setdefault('session_id', self._get_session_id())
        kwargs.setdefault('response_type', 'command')
        kwargs.setdefault('confidence_score', 0.0)
        kwargs.setdefault('command_executed', False)
        
        # Convert enums to strings
        if isinstance(kwargs.get('feedback_type'), FeedbackType):
            kwargs['feedback_type'] = kwargs['feedback_type'].value
        
        # Build insert query
        columns = ', '.join(kwargs.keys())
        placeholders = ', '.join(['?' for _ in kwargs])
        query = f"INSERT INTO feedback ({columns}) VALUES ({placeholders})"
        
        cursor = self.conn.execute(query, list(kwargs.values()))
        self.conn.commit()
        
        return cursor.lastrowid
    
    def create_preference_pair(self, prompt: str, chosen: str, rejected: str) -> str:
        """Create a preference pair for RLHF training"""
        import uuid
        pair_id = str(uuid.uuid4())
        
        self.conn.execute("""
            INSERT INTO preference_pairs 
            (id, prompt, chosen_response, rejected_response)
            VALUES (?, ?, ?, ?)
        """, (pair_id, prompt, chosen, rejected))
        
        self.conn.commit()
        return pair_id
    
    def get_training_batch(self, batch_size: int = 100) -> List[Dict]:
        """Get a batch of unprocessed feedback for training"""
        cursor = self.conn.execute("""
            SELECT * FROM feedback 
            WHERE used_for_training = FALSE 
            AND better_response IS NOT NULL
            ORDER BY timestamp
            LIMIT ?
        """, (batch_size,))
        
        columns = [desc[0] for desc in cursor.description]
        results = []
        
        for row in cursor.fetchall():
            feedback = dict(zip(columns, row))
            results.append(feedback)
            
            # Create preference pair
            self.create_preference_pair(
                prompt=feedback['user_prompt'],
                chosen=feedback['better_response'],
                rejected=feedback['ai_response']
            )
        
        # Mark as used
        if results:
            ids = [r['id'] for r in results]
            placeholders = ','.join(['?' for _ in ids])
            self.conn.execute(
                f"UPDATE feedback SET used_for_training = TRUE WHERE id IN ({placeholders})",
                ids
            )
            self.conn.commit()
        
        return results
    
    def analyze_patterns(self, session_id: str = None) -> Dict:
        """Analyze user patterns from feedback"""
        # Get recent feedback
        query = "SELECT * FROM feedback"
        params = []
        if session_id:
            query += " WHERE session_id = ?"
            params.append(session_id)
        query += " ORDER BY timestamp DESC LIMIT 1000"
        
        cursor = self.conn.execute(query, params)
        feedback_data = cursor.fetchall()
        
        patterns = {
            'total_interactions': len(feedback_data),
            'helpful_rate': 0.0,
            'modification_rate': 0.0,
            'common_issues': [],
            'learning_velocity': 0.0
        }
        
        if feedback_data:
            helpful_count = sum(1 for f in feedback_data if f[10])  # was_helpful column
            patterns['helpful_rate'] = helpful_count / len(feedback_data)
            
            modifications = sum(1 for f in feedback_data if f[11])  # user_modification column
            patterns['modification_rate'] = modifications / len(feedback_data)
        
        return patterns
    
    def _get_session_id(self) -> str:
        """Get or create session ID"""
        # In production, this would be more sophisticated
        return os.getenv('NIX_HUMANITY_SESSION', 'default')
    
    def close(self):
        """Close database connection"""
        self.conn.close()
```

### 2. Integration with ask-nix Commands

**File**: `bin/ask-nix-with-feedback`

```python
#!/usr/bin/env python3
"""
Enhanced ask-nix with integrated feedback collection
"""

import sys
import os
import subprocess
from pathlib import Path

# Add project to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root / "scripts"))

from feedback_collector import FeedbackCollector
from nix_knowledge_engine import NixOSKnowledgeEngine

def main():
    if len(sys.argv) < 2:
        print("Usage: ask-nix-with-feedback 'your question'")
        sys.exit(1)
    
    query = ' '.join(sys.argv[1:])
    
    # Initialize components
    knowledge = NixOSKnowledgeEngine()
    feedback = FeedbackCollector()
    
    try:
        # Process query
        intent = knowledge.extract_intent(query)
        solution = knowledge.get_solution(intent)
        response = knowledge.format_response(intent, solution)
        
        # Show response
        print(response)
        
        # Collect feedback (can be disabled via env var)
        if os.getenv('NIX_HUMANITY_FEEDBACK', '1') == '1':
            feedback.collect_explicit_feedback(
                prompt=query,
                response=response
            )
    
    finally:
        feedback.close()

if __name__ == "__main__":
    main()
```

### 3. Background Learning Service

**File**: `scripts/background_learner.py`

```python
#!/usr/bin/env python3
"""
Background learning service for continuous improvement
Implements the continuous adaptation loop from Living Model research
"""

import time
import sqlite3
from pathlib import Path
from feedback_collector import FeedbackCollector
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BackgroundLearner:
    def __init__(self):
        self.feedback_collector = FeedbackCollector()
        self.learning_interval = 3600  # 1 hour
        self.min_batch_size = 20
        
    def should_trigger_learning(self) -> bool:
        """Check if we have enough feedback for learning"""
        batch = self.feedback_collector.get_training_batch(1)
        return len(batch) >= self.min_batch_size
    
    def prepare_training_data(self):
        """Prepare preference pairs for training"""
        batch = self.feedback_collector.get_training_batch(self.min_batch_size)
        
        if not batch:
            return None
        
        # Format for DPO training
        training_data = []
        for feedback in batch:
            training_data.append({
                'prompt': feedback['user_prompt'],
                'chosen': feedback['better_response'],
                'rejected': feedback['ai_response']
            })
        
        return training_data
    
    def trigger_model_update(self, training_data):
        """Trigger model fine-tuning (placeholder)"""
        logger.info(f"Would trigger training with {len(training_data)} examples")
        # In production: Call LoRA fine-tuning pipeline
        
    def update_patterns(self):
        """Update user pattern analysis"""
        patterns = self.feedback_collector.analyze_patterns()
        logger.info(f"Current patterns: {patterns}")
        
    def continuous_learning_loop(self):
        """Main learning loop"""
        logger.info("Starting background learning service")
        
        while True:
            try:
                if self.should_trigger_learning():
                    logger.info("Sufficient feedback collected, preparing training")
                    
                    # Prepare data
                    training_data = self.prepare_training_data()
                    
                    if training_data:
                        # Trigger update
                        self.trigger_model_update(training_data)
                        
                        # Update patterns
                        self.update_patterns()
                
                # Sleep until next check
                time.sleep(self.learning_interval)
                
            except Exception as e:
                logger.error(f"Error in learning loop: {e}")
                time.sleep(60)  # Short sleep on error

if __name__ == "__main__":
    learner = BackgroundLearner()
    learner.continuous_learning_loop()
```

### 4. Feedback Analytics Dashboard

**File**: `scripts/feedback_analytics.py`

```python
#!/usr/bin/env python3
"""
Analytics dashboard for feedback data
"""

from feedback_collector import FeedbackCollector
from datetime import datetime, timedelta
import json

class FeedbackAnalytics:
    def __init__(self):
        self.collector = FeedbackCollector()
    
    def generate_report(self, days: int = 7) -> Dict:
        """Generate analytics report for the last N days"""
        
        # Get feedback from time period
        since = datetime.now() - timedelta(days=days)
        
        cursor = self.collector.conn.execute("""
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN was_helpful = 1 THEN 1 ELSE 0 END) as helpful_count,
                AVG(CASE WHEN was_helpful = 1 THEN 1.0 ELSE 0.0 END) as helpful_rate,
                COUNT(DISTINCT session_id) as unique_sessions,
                COUNT(better_response) as improvements_suggested
            FROM feedback
            WHERE timestamp > ?
        """, (since,))
        
        stats = cursor.fetchone()
        
        # Get common issues
        cursor = self.collector.conn.execute("""
            SELECT user_prompt, COUNT(*) as count
            FROM feedback
            WHERE was_helpful = 0 AND timestamp > ?
            GROUP BY user_prompt
            ORDER BY count DESC
            LIMIT 10
        """, (since,))
        
        common_issues = cursor.fetchall()
        
        return {
            'period_days': days,
            'total_interactions': stats[0],
            'helpful_count': stats[1],
            'helpful_rate': stats[2],
            'unique_sessions': stats[3],
            'improvements_suggested': stats[4],
            'common_issues': [
                {'prompt': issue[0], 'count': issue[1]} 
                for issue in common_issues
            ]
        }
    
    def print_report(self):
        """Print formatted analytics report"""
        report = self.generate_report()
        
        print("\n" + "="*60)
        print("📊 Nix for Humanity Feedback Analytics")
        print("="*60)
        print(f"\nPeriod: Last {report['period_days']} days")
        print(f"Total Interactions: {report['total_interactions']}")
        print(f"Helpful Rate: {report['helpful_rate']:.1%}")
        print(f"Unique Sessions: {report['unique_sessions']}")
        print(f"Improvements Suggested: {report['improvements_suggested']}")
        
        if report['common_issues']:
            print("\n🔍 Common Issues:")
            for i, issue in enumerate(report['common_issues'], 1):
                print(f"{i}. \"{issue['prompt']}\" ({issue['count']} times)")
        
        print("\n" + "="*60)

if __name__ == "__main__":
    analytics = FeedbackAnalytics()
    analytics.print_report()
```

## Installation Instructions

### 1. Create Directory Structure
```bash
cd /srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity
mkdir -p data scripts
```

### 2. Install Dependencies
```bash
# Ensure SQLite is available
nix-shell -p python3 python3Packages.sqlite3
```

### 3. Initialize Database
```python
python3 -c "from scripts.feedback_collector import FeedbackCollector; FeedbackCollector()"
```

### 4. Update Existing Commands
Replace current `ask-nix` commands with feedback-enabled versions:
```bash
cd bin
mv ask-nix ask-nix-original
ln -s ask-nix-with-feedback ask-nix
```

### 5. Start Background Learner (Optional)
```bash
# Run as systemd service or in screen/tmux
python3 scripts/background_learner.py
```

## Usage Examples

### Basic Usage
```bash
# Ask a question and provide feedback
ask-nix "How do I install firefox?"
# ... response shown ...
# Was this helpful? (y/n): n
# Better response: Add firefox to configuration.nix: environment.systemPackages = with pkgs; [ firefox ];
```

### View Analytics
```bash
python3 scripts/feedback_analytics.py
```

### Disable Feedback (Temporarily)
```bash
export NIX_HUMANITY_FEEDBACK=0
ask-nix "install python"
```

## Testing Strategy

### Unit Tests
```python
# File: tests/test_feedback_collector.py
import unittest
from scripts.feedback_collector import FeedbackCollector

class TestFeedbackCollector(unittest.TestCase):
    def setUp(self):
        self.collector = FeedbackCollector(":memory:")
    
    def test_explicit_feedback(self):
        # Test storing explicit feedback
        feedback_id = self.collector.store_feedback(
            prompt="test prompt",
            ai_response="test response",
            feedback_type="explicit_positive",
            was_helpful=True
        )
        self.assertIsNotNone(feedback_id)
    
    def test_preference_pair_creation(self):
        # Test creating preference pairs
        pair_id = self.collector.create_preference_pair(
            prompt="install vim",
            chosen="nix-env -iA nixos.vim",
            rejected="apt-get install vim"
        )
        self.assertIsNotNone(pair_id)
```

### Integration Tests
```bash
# Test full flow
echo "n" | ask-nix "test question" | grep -q "Feedback Collection"
```

## Success Metrics

### Week 1 Goals
- [ ] 100+ feedback entries collected
- [ ] 50%+ helpful rate baseline established  
- [ ] 10+ improvement suggestions gathered
- [ ] Analytics dashboard functional

### Month 1 Goals
- [ ] 1000+ feedback entries
- [ ] Helpful rate improving trend
- [ ] First batch of preference pairs ready
- [ ] User patterns identified

## Next Steps

After successful Phase 0 implementation:
1. Implement local preference model (Phase 1.1)
2. Add implicit feedback collection 
3. Create first LoRA fine-tuning pipeline
4. Build user pattern detection

## Troubleshooting

### Database Locked Error
```bash
# Kill any hanging processes
pkill -f feedback_collector.py
```

### No Feedback Collected
Check environment variable:
```bash
echo $NIX_HUMANITY_FEEDBACK  # Should be 1 or unset
```

---

*This implementation brings the Symbiotic Intelligence vision to life, one feedback at a time.*