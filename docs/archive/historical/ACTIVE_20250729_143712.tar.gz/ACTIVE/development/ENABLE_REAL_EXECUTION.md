# 🚀 Enable Real Execution - Making Commands Actually Work

## Starting Point: Enable "nix search" Command

The `nix search` command is the safest starting point because:
- Read-only operation (no system changes)
- Provides immediate visible results
- Tests the full execution pipeline
- No sudo required

## Step 1: Find What to Uncomment

### In `packages/nlp/src/core/command-executor.ts`

**Current Code (Line 21-23):**
```typescript
if (options.dryRun) {
  return this.dryRunExecution(command);
}
```

**Change to:**
```typescript
if (options.dryRun !== false) {  // Default to real execution
  return this.dryRunExecution(command);
}
```

**Better: Add explicit execution mode:**
```typescript
// Add at top of file
const SAFE_COMMANDS = ['nix', 'nix-channel', 'systemctl'];
const SAFE_SUBCOMMANDS = ['search', 'info', 'status', 'list'];

// In execute method
if (options.dryRun || !this.isCommandSafe(command)) {
  return this.dryRunExecution(command);
}

// Add new method
private isCommandSafe(command: SafeCommand): boolean {
  if (!SAFE_COMMANDS.includes(command.command)) {
    return false;
  }
  
  // Check subcommand for nix commands
  if (command.command === 'nix' && command.args.length > 0) {
    return SAFE_SUBCOMMANDS.includes(command.args[0]);
  }
  
  return true;
}
```

## Step 2: Safety Measures to Keep

### Keep These Safety Features:

1. **Command Validation** (keep as-is):
```typescript
private getSafeEnvironment(): NodeJS.ProcessEnv {
  return {
    PATH: '/run/current-system/sw/bin:/usr/bin:/bin',
    HOME: process.env.HOME || '/tmp',
    USER: process.env.USER || 'nobody',
    LANG: 'en_US.UTF-8',
  };
}
```

2. **Timeout Protection** (keep as-is):
```typescript
timeout: options.timeout || 30000, // 30 second default
```

3. **No Shell Execution** (keep as-is):
```typescript
shell: false, // Never use shell for security
```

### Add These Safety Features:

1. **Command Whitelist**:
```typescript
const ALLOWED_COMMANDS = {
  'nix': ['search', 'info', 'show-config'],
  'nix-env': ['-q', '--query'],
  'systemctl': ['status', 'list-units'],
  'nix-channel': ['--list']
};

private isCommandAllowed(command: SafeCommand): boolean {
  const allowed = ALLOWED_COMMANDS[command.command];
  if (!allowed) return false;
  
  // Check if first arg is in allowed list
  return allowed.includes(command.args[0]);
}
```

2. **Execution Logging**:
```typescript
private logExecution(command: SafeCommand, result: CommandResult): void {
  const logEntry = {
    timestamp: new Date().toISOString(),
    command: this.formatCommandString(command),
    success: result.success,
    error: result.error?.message
  };
  
  // Write to ~/.nix-humanity/execution.log
  fs.appendFileSync(
    path.join(os.homedir(), '.nix-humanity', 'execution.log'),
    JSON.stringify(logEntry) + '\n'
  );
}
```

## Step 3: Testing Approach

### Test Script (`test/test-real-execution.js`):

```javascript
#!/usr/bin/env node

import { NLPEngine } from '../packages/nlp/dist/index.js';

async function testSearch() {
  console.log('🧪 Testing nix search with real execution...\n');
  
  const engine = new NLPEngine({
    mode: 'full',
    executeReal: true
  });
  
  // Test 1: Safe search command
  console.log('Test 1: Searching for firefox');
  const result1 = await engine.processInput('search firefox');
  console.log('Result:', result1.response);
  console.log('Success:', result1.success);
  
  // Test 2: Should still be dry-run (not whitelisted)
  console.log('\nTest 2: Installing package (should be dry-run)');
  const result2 = await engine.processInput('install firefox');
  console.log('Result:', result2.response);
  console.log('Command:', result2.command);
  
  // Test 3: Another safe search
  console.log('\nTest 3: Searching for python');
  const result3 = await engine.processInput('search python');
  console.log('Result:', result3.response);
}

testSearch().catch(console.error);
```

### Manual Testing Steps:

```bash
# 1. Build the TypeScript packages
cd packages/nlp
npm run build

# 2. Run the test script
node test/test-real-execution.js

# 3. Check execution log
cat ~/.nix-humanity/execution.log

# 4. Test via CLI
./bin/ask-nix --execute "search firefox"
```

## Step 4: Progressive Enablement

### Phase 1: Read-Only Commands (Safe)
- `nix search <package>`
- `nix info <package>` 
- `systemctl status <service>`
- `nix-channel --list`

### Phase 2: User-Space Modifications (Medium Risk)
- `nix-env -iA <package>` (with confirmation)
- `nix-env -e <package>` (with confirmation)

### Phase 3: System Modifications (High Risk)
- `nixos-rebuild switch` (with double confirmation)
- `systemctl restart <service>` (with confirmation)

## Code to Update

### 1. Update `packages/nlp/src/index.ts`:

```typescript
// Add to NLPConfig
export interface NLPConfig {
  // ... existing fields
  executeReal?: boolean;
  safeCommandsOnly?: boolean; // New safety flag
}

// Update constructor
constructor(config: NLPConfig = { mode: 'standard' }) {
  // ... existing code
  
  // Pass execution config to command executor
  this.commandExecutor = new CommandExecutor({
    enableRealExecution: config.executeReal || false,
    safeCommandsOnly: config.safeCommandsOnly !== false
  });
}
```

### 2. Update `packages/nlp/src/core/command-executor.ts`:

Add the full safety implementation from above.

### 3. Create `bin/ask-nix-safe`:

```bash
#!/usr/bin/env bash
# Safe version that only allows read-only commands

exec node "$(dirname "$0")/nix-nlp-bridge.js" \
  --execute \
  --safe-commands-only \
  "$@"
```

## Verification Checklist

- [ ] `nix search firefox` returns real results (not mock)
- [ ] `nix-env -iA firefox` still shows dry-run warning
- [ ] Execution log is created and populated
- [ ] Timeout works (try `nix search` with no args)
- [ ] Error handling works (try searching for "nonexistentpackage123")

## Rollback Plan

If something goes wrong:

1. **Immediate**: Set `executeReal: false` in config
2. **Quick Fix**: Rename `ask-nix` to `ask-nix-unsafe`, restore old version
3. **Full Rollback**: `git checkout -- packages/nlp/src/core/command-executor.ts`

## Success Criteria

✅ `ask-nix "search firefox"` returns real Nix search results
✅ Execution is logged for audit
✅ Unsafe commands still dry-run
✅ No security vulnerabilities introduced
✅ User experience is improved (real results!)

## Next Command to Enable

After search works, enable:
1. `nix info <package>` - Also read-only
2. `nix-env -q` - Query installed packages
3. `systemctl status` - Check service status

Build confidence with read-only commands before enabling any write operations.