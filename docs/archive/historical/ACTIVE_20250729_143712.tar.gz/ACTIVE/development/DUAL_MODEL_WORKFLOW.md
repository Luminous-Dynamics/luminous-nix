# 🎯 Dual Model Workflow for Power Users

*How to leverage both Mistral-7B and CodeLlama-13B-Instruct for maximum productivity*

## Overview

With 32GB RAM, you can strategically use different models to optimize your Sacred Trinity workflow. This guide shows you when and how to use each model effectively.

## The Two-Model Strategy

### 🚀 Mistral-7B - Your Daily Driver
**RAM**: 6GB | **Speed**: 2-5 seconds | **Role**: Rapid iteration

Use Mistral-7B (default) for:
- ✅ Quick questions during active coding
- ✅ Syntax reminders
- ✅ Common patterns
- ✅ Brief explanations
- ✅ Maintaining flow state

### 🧠 CodeLlama-13B-Instruct - Your Deep Dive Companion  
**RAM**: 13GB | **Speed**: 5-10 seconds | **Role**: Complex understanding

Switch to CodeLlama-13B for:
- ✅ Writing NixOS modules
- ✅ Complex derivations
- ✅ Debugging intricate issues
- ✅ Learning new concepts
- ✅ Code generation
- ✅ Detailed explanations with examples

## Practical Workflows

### Workflow 1: Feature Development

```bash
# 1. Initial exploration (quick with Mistral)
ask-nix-guru "What's the basic structure of a systemd service?"

# 2. Deep implementation (detailed with CodeLlama)
NIX_GURU_MODEL=codellama:13b-instruct ask-nix-guru \
  "Show me a complete NixOS systemd service with timers and dependencies"

# 3. Quick syntax check (back to Mistral)
ask-nix-guru "What's the syntax for After= in systemd?"
```

### Workflow 2: Learning Session

```bash
# Set CodeLlama for the entire session
export NIX_GURU_MODEL=codellama:13b-instruct

# Now all queries use the detailed model
ask-nix-guru "Explain Nix flakes with examples"
ask-nix-guru "How do overlays work in NixOS?"
ask-nix-guru "What's the difference between override and overrideAttrs?"

# Reset to default when done
unset NIX_GURU_MODEL
```

### Workflow 3: Debugging Complex Issues

```bash
# Start with quick diagnosis (Mistral)
ask-nix-guru "Why would nixos-rebuild fail with 'infinite recursion'?"

# Get detailed debugging help (CodeLlama)
NIX_GURU_MODEL=codellama:13b-instruct ask-nix-guru \
  "Debug this error: infinite recursion encountered at..."

# Quick fix verification (Mistral)
ask-nix-guru "Does imports = [ ./foo.nix ] cause recursion if foo.nix imports back?"
```

## Model Comparison Examples

### Example 1: Package Installation

**Mistral-7B** (2 seconds):
```
Q: How do I install firefox?
A: Add firefox to environment.systemPackages in configuration.nix:

environment.systemPackages = with pkgs; [
  firefox
];

Then run: sudo nixos-rebuild switch
```

**CodeLlama-13B** (6 seconds):
```
Q: How do I install firefox?
A: There are several ways to install Firefox in NixOS:

1. System-wide (declarative, recommended):
   Edit /etc/nixos/configuration.nix:
   ```nix
   environment.systemPackages = with pkgs; [
     firefox  # or firefox-esr for extended support
   ];
   ```
   Then: sudo nixos-rebuild switch

2. User-specific (home-manager):
   ```nix
   home.packages = with pkgs; [ firefox ];
   ```

3. Temporary (imperative):
   ```bash
   nix-env -iA nixos.firefox  # Not recommended
   ```

4. One-time use:
   ```bash
   nix-shell -p firefox --run firefox
   ```

The declarative approach ensures reproducibility...
```

### Example 2: Module Creation

**Mistral-7B** (3 seconds):
```
Q: How do I create a NixOS module?
A: Create a file with:

{ config, lib, pkgs, ... }:
{
  options = {
    services.myService.enable = lib.mkEnableOption "my service";
  };
  
  config = lib.mkIf config.services.myService.enable {
    # Your configuration here
  };
}
```

**CodeLlama-13B** (8 seconds):
```
Q: How do I create a NixOS module?
A: Here's a complete guide to creating a NixOS module:

Structure:
```nix
{ config, lib, pkgs, ... }:

with lib;

let
  cfg = config.services.myService;
in {
  # Option declarations
  options.services.myService = {
    enable = mkEnableOption "My custom service";
    
    port = mkOption {
      type = types.int;
      default = 8080;
      description = "Port to listen on";
    };
    
    user = mkOption {
      type = types.str;
      default = "myservice";
      description = "User to run the service";
    };
  };
  
  # Implementation
  config = mkIf cfg.enable {
    # Create system user
    users.users.${cfg.user} = {
      isSystemUser = true;
      group = cfg.user;
    };
    users.groups.${cfg.user} = {};
    
    # Systemd service
    systemd.services.myService = {
      description = "My Custom Service";
      after = [ "network.target" ];
      wantedBy = [ "multi-user.target" ];
      
      serviceConfig = {
        Type = "simple";
        User = cfg.user;
        ExecStart = "${pkgs.myPackage}/bin/myservice -p ${toString cfg.port}";
        Restart = "always";
      };
    };
    
    # Firewall
    networking.firewall.allowedTCPPorts = [ cfg.port ];
  };
}
```

Best practices:
- Use mkOption for all configuration
- Include descriptions
- Set sensible defaults
- Use mkIf for conditional config...
```

## Quick Switching Techniques

### 1. Temporary Override
```bash
# Just for one command
NIX_GURU_MODEL=codellama:13b-instruct ask-nix-guru "complex question"
```

### 2. Session Override
```bash
# For current shell session
export NIX_GURU_MODEL=codellama:13b-instruct
# All commands now use CodeLlama
# ...work...
unset NIX_GURU_MODEL  # Back to default
```

### 3. Create Aliases
Add to your shell config:
```bash
alias nix-quick='ask-nix-guru'
alias nix-detail='NIX_GURU_MODEL=codellama:13b-instruct ask-nix-guru'
alias nix-code='NIX_GURU_MODEL=deepseek-coder:6.7b ask-nix-guru'
```

### 4. Function for Easy Switching
```bash
nix-guru() {
  local model="${1:-mistral:7b}"
  shift
  NIX_GURU_MODEL="$model" ask-nix-guru "$@"
}

# Usage:
nix-guru mistral "quick question"
nix-guru codellama "detailed question"
```

## Performance Tips

### 1. Keep Both Models Loaded
```bash
# Pre-load both models to avoid startup delay
ollama pull mistral:7b
ollama pull codellama:13b-instruct

# Keep Ollama running
ollama serve &
```

### 2. Use Mistral for Iteration
During active development, stick with Mistral for speed:
- Syntax questions
- Quick clarifications  
- Error meanings
- Command reminders

### 3. Schedule CodeLlama Sessions
Use CodeLlama for dedicated learning/design time:
- Morning architecture planning
- End-of-day code review
- Weekend learning sessions
- Complex debugging

### 4. Model Memory Usage
With 32GB RAM, you can run:
- Mistral (6GB) + Heavy IDE (8GB) + Browser (4GB) = Comfortable
- CodeLlama (13GB) + Moderate IDE (4GB) + Browser (4GB) = Still good
- Both models loaded + Light editing = Possible

## Decision Tree

```
Is this a quick question?
├─ YES → Use Mistral (default)
└─ NO
   ├─ Do I need code examples?
   │  ├─ YES → Use CodeLlama
   │  └─ NO → Use Mistral
   ├─ Is this about complex Nix concepts?
   │  ├─ YES → Use CodeLlama
   │  └─ NO → Use Mistral
   └─ Do I have time to wait 5-10 seconds?
      ├─ YES → Consider CodeLlama
      └─ NO → Use Mistral
```

## Sacred Trinity Integration

### How It Works with Dual Models

1. **Human** identifies the type of help needed
2. **Local LLM** (Mistral or CodeLlama) provides NixOS expertise
3. **Claude** implements based on the guidance
4. **Human** validates the result

### Example Sacred Trinity Session

```bash
# Human: "I need to create a complex service with multiple dependencies"

# Quick overview (Mistral)
ask-nix-guru "What are systemd service dependencies?"
# Fast response helps Claude understand basics

# Detailed implementation (CodeLlama)  
NIX_GURU_MODEL=codellama:13b-instruct ask-nix-guru \
  "Create a complete example of a multi-service NixOS module with dependencies"
# Detailed response gives Claude a complete template

# Human tests and validates
# Quick debugging questions back to Mistral for speed
```

## Best Practices

1. **Start Fast**: Begin with Mistral for exploration
2. **Go Deep When Needed**: Switch to CodeLlama for complexity
3. **Document Insights**: Save valuable CodeLlama responses
4. **Stay in Flow**: Use Mistral during active coding
5. **Learn Deeply**: Use CodeLlama for study sessions

## Conclusion

Having 32GB RAM gives you the flexibility to choose the right tool for each moment. Mistral-7B keeps you in flow during active development, while CodeLlama-13B-Instruct provides the depth when you need to understand complex concepts or generate sophisticated code.

The key is knowing when speed matters more than detail, and when comprehensive understanding is worth the extra seconds.

---

*"Two models, one workflow: Speed when you need it, depth when it matters."*