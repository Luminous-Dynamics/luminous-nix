# 🌉 NLP to Execution Bridge - Connecting Intent to Action

## Current Disconnection Points

### The Gap
```
NLP Engine (TypeScript)          Command Executor (TypeScript)
    ↓                                    ↑
[Intent Recognition]                [Execution Logic]
    ↓                                    ↑
[Command Building]                  [Subprocess Spawn]
    ↓                                    ↑
    ❌ <-- No connection here --> ❌
```

### The Problem
1. NLP Engine creates `SafeCommand` objects
2. CommandExecutor can execute `SafeCommand` objects
3. But NLP Engine always passes `dryRun: true`
4. No configuration to change this behavior

## Bridge Implementation

### Solution 1: Configuration Bridge (Simplest)

**File: `packages/nlp/src/execution-bridge.ts`**

```typescript
import { NLPEngine, NLPConfig } from './index';
import { CommandExecutor } from './core/command-executor';

export interface ExecutionBridgeConfig extends NLPConfig {
  enableExecution: boolean;
  requireConfirmation: boolean;
  allowedCommands?: string[];
}

export class NLPExecutionBridge {
  private nlpEngine: NLPEngine;
  private config: ExecutionBridgeConfig;
  
  constructor(config: ExecutionBridgeConfig) {
    this.config = config;
    
    // Create NLP engine with execution support
    this.nlpEngine = new NLPEngine({
      ...config,
      // Override the internal command executor
      commandExecutorOptions: {
        dryRun: !config.enableExecution,
        requireConfirmation: config.requireConfirmation
      }
    });
  }
  
  async executeNaturalCommand(input: string): Promise<{
    success: boolean;
    executed: boolean;
    result: any;
  }> {
    // Process through NLP
    const nlpResult = await this.nlpEngine.processInput(input);
    
    // Check if we should execute
    if (!nlpResult.success || !nlpResult.command) {
      return {
        success: false,
        executed: false,
        result: nlpResult
      };
    }
    
    // Check if command is allowed
    if (this.config.allowedCommands) {
      const baseCommand = nlpResult.command.split(' ')[0];
      if (!this.config.allowedCommands.includes(baseCommand)) {
        return {
          success: false,
          executed: false,
          result: {
            ...nlpResult,
            response: `Command '${baseCommand}' is not allowed. Allowed commands: ${this.config.allowedCommands.join(', ')}`
          }
        };
      }
    }
    
    return {
      success: nlpResult.success,
      executed: this.config.enableExecution,
      result: nlpResult
    };
  }
}
```

### Solution 2: Direct Integration (Better)

**Modify: `packages/nlp/src/index.ts`**

Add execution control directly to NLPEngine:

```typescript
export interface NLPConfig {
  mode: 'minimal' | 'standard' | 'full';
  enableLearning?: boolean;
  enableContext?: boolean;
  enableFuzzyMatching?: boolean;
  sacredMode?: boolean;
  // Add execution control
  execution?: {
    enabled: boolean;
    requireConfirmation?: boolean;
    allowedCommands?: string[];
    safeMode?: boolean;
  };
}

// In constructor
constructor(config: NLPConfig = { mode: 'standard' }) {
  // ... existing code ...
  
  // Create command executor with execution config
  const executorConfig = {
    dryRun: !config.execution?.enabled,
    requireConfirmation: config.execution?.requireConfirmation || false,
    safeMode: config.execution?.safeMode !== false
  };
  
  this.commandExecutor = new CommandExecutor(executorConfig);
}

// Modify processInput method
async processInput(input: string): Promise<NLPResult> {
  try {
    // ... existing intent recognition code ...
    
    // Build safe command
    const command = await this.commandBuilder.build(intent);
    
    // Execute command with config-based settings
    const result = await this.commandExecutor.execute(command, {
      dryRun: this.config.mode === 'minimal' && !this.config.execution?.enabled,
      // Pass through execution config
      requireConfirmation: this.config.execution?.requireConfirmation
    });
    
    // ... rest of method
  }
}
```

## Current Code That Needs Connection

### 1. In `packages/nlp/src/index.ts` (Line 154):
```typescript
// CURRENT - Always dry-run in minimal mode
const result = await this.commandExecutor.execute(
  command, 
  { dryRun: this.config.mode === 'minimal' }
);

// CHANGE TO - Respect execution config
const result = await this.commandExecutor.execute(
  command, 
  { 
    dryRun: !this.config.execution?.enabled,
    requireConfirmation: this.config.execution?.requireConfirmation
  }
);
```

### 2. In `packages/nlp/src/core/command-executor.ts` (Line 21):
```typescript
// CURRENT - Default to dry-run
if (options.dryRun) {
  return this.dryRunExecution(command);
}

// CHANGE TO - Default based on config
if (options.dryRun !== false) {
  return this.dryRunExecution(command);
}
```

## End-to-End Example

### User Input: "search firefox"

**Step 1: CLI Entry**
```bash
$ ask-nix --execute "search firefox"
```

**Step 2: CLI Creates NLP Engine**
```javascript
const engine = new NLPEngine({
  mode: 'full',
  execution: {
    enabled: true,
    safeMode: true,
    allowedCommands: ['nix', 'nix-env', 'systemctl']
  }
});
```

**Step 3: NLP Processes Input**
```javascript
// Intent recognition
intent = { 
  type: 'search_package', 
  entities: { package: 'firefox' },
  confidence: 0.95
}

// Command building
command = {
  command: 'nix',
  args: ['search', 'nixpkgs', 'firefox'],
  safe: true
}
```

**Step 4: Executor Runs Command**
```javascript
// With execution.enabled = true
// CommandExecutor.execute() runs actual command
const result = spawn('nix', ['search', 'nixpkgs', 'firefox']);
```

**Step 5: Real Results Returned**
```
🎯 Intent: search_package
📦 Command: nix search nixpkgs firefox

Found packages:
* nixpkgs.firefox (108.0.1)
* nixpkgs.firefox-esr (102.6.0esr)
* nixpkgs.firefox-bin (108.0.1)
```

## Implementation Steps

### Quick Fix (15 minutes)
1. Modify `packages/nlp/src/index.ts`:
   - Add `execution` to `NLPConfig`
   - Update `processInput` to respect execution config
   
2. Modify `packages/nlp/src/core/command-executor.ts`:
   - Change dry-run default logic
   - Add safety checks for allowed commands

3. Test with:
   ```bash
   node -e "
   import { NLPEngine } from './packages/nlp/dist/index.js';
   const engine = new NLPEngine({ 
     mode: 'full', 
     execution: { enabled: true, safeMode: true } 
   });
   engine.processInput('search firefox').then(console.log);
   "
   ```

### Full Implementation (1 hour)
1. Create execution bridge class
2. Add confirmation prompts for dangerous commands
3. Implement command whitelisting
4. Add execution logging
5. Create CLI wrapper with proper flags
6. Write integration tests

## Testing the Bridge

```javascript
// test/test-execution-bridge.js
import { NLPEngine } from '../packages/nlp/dist/index.js';

async function testBridge() {
  // Test 1: Execution disabled (default)
  const safeEngine = new NLPEngine({ mode: 'standard' });
  const safeResult = await safeEngine.processInput('install firefox');
  console.log('Safe mode:', safeResult.response); // Should be dry-run
  
  // Test 2: Execution enabled
  const execEngine = new NLPEngine({
    mode: 'full',
    execution: { 
      enabled: true,
      safeMode: true,
      allowedCommands: ['nix']
    }
  });
  
  const execResult = await execEngine.processInput('search firefox');
  console.log('Exec mode:', execResult.response); // Should be real results
  
  // Test 3: Blocked command
  const blockedResult = await execEngine.processInput('install firefox');
  console.log('Blocked:', blockedResult.response); // Should be blocked
}

testBridge();
```

## Success Criteria

✅ NLP engine can be configured to execute real commands
✅ Safety controls remain in place
✅ Clear separation between dry-run and execution modes
✅ Commands flow from intent → building → execution seamlessly
✅ User gets real results when execution is enabled

## Common Issues and Solutions

### Issue: "Cannot find module"
**Solution**: Rebuild TypeScript packages
```bash
cd packages/nlp && npm run build
```

### Issue: "Permission denied"
**Solution**: Some commands need different permissions
```javascript
// Add to executor
if (command.command === 'systemctl' && command.args[0] === 'restart') {
  return {
    success: false,
    response: 'This command requires sudo. Please run with appropriate permissions.',
    command: this.formatCommandString(command)
  };
}
```

### Issue: "Command not found"
**Solution**: Ensure PATH is set correctly
```javascript
env: {
  ...this.getSafeEnvironment(),
  PATH: process.env.PATH // Use system PATH for nix commands
}
```