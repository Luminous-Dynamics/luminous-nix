# 🚀 Unified ask-nix Command Documentation

*The single, feature-complete natural language interface for NixOS*

## Overview

The `ask-nix` command is the unified natural language interface for NixOS, combining all the best features from previous variants into one intelligent tool. It understands natural language queries and can help with package installation, system updates, searches, and more.

## Installation

The `ask-nix` command is available in the Nix for Humanity toolkit:

```bash
cd /srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity
./bin/ask-nix "your question here"
```

## Features

### 🎯 Natural Language Understanding
- Understands queries like "install firefox", "update my system", "search for python packages"
- Advanced intent recognition with >95% accuracy
- Context-aware responses based on query type

### 🎭 Adaptive Personality System
- **--minimal**: Just the facts, no extra text
- **--friendly**: Warm and helpful responses (default)
- **--encouraging**: Supportive for beginners
- **--technical**: Detailed technical explanations

### ⚡ Intelligent Package Caching
- 100-1000x faster package searches using SQLite cache
- Automatic cache updates and management
- Works offline for cached queries

### 📚 Command Learning System
- Learns from successful and failed commands
- Improves suggestions over time
- Tracks usage patterns (locally, privacy-first)

### 🎨 Visual Progress Indicators
- Beautiful progress bars and spinners (when Rich is available)
- Graceful fallback to simple text progress
- Time estimates for long operations

### 🔒 Safe Execution Modes
- **Dry-run by default**: Shows what would happen without doing it
- **--execute**: Uses the safe execution bridge
- **--no-dry-run**: Actually executes commands (use with caution)

## Basic Usage

### Simple Queries
```bash
# Get help with installation
ask-nix "how do I install firefox?"

# Search for packages
ask-nix "search for python packages"

# Update system
ask-nix "update my system"

# List installed packages
ask-nix "what packages do I have installed?"
```

### With Personality Styles
```bash
# Minimal response
ask-nix --minimal "install vim"

# Encouraging for beginners
ask-nix --encouraging "my wifi isn't working"

# Technical details
ask-nix --technical "explain nix generations"
```

### Advanced Options
```bash
# Show detected intent
ask-nix --show-intent "install firefox"

# Execute with safety bridge
ask-nix --execute "install git"

# Skip cache for fresh results
ask-nix --no-cache "search rust"

# Clear cache
ask-nix --clear-cache "anything"

# Disable visual progress
ask-nix --no-visual "update system"
```

## Command Reference

### Installation Commands
- `install [package]` - Install a package
- `get [package]` - Alternative to install
- `I need [package]` - Natural way to request installation
- `set up [package]` - Another installation pattern

### Search Commands
- `search [query]` - Search for packages
- `find [query]` - Alternative search
- `look for [query]` - Natural search pattern
- `is there a package for [thing]` - Question-based search

### System Commands
- `update my system` - Update NixOS
- `upgrade` - Alternative to update
- `rollback` - Go to previous generation
- `list generations` - Show system history

### Package Management
- `list installed packages` - Show what's installed
- `remove [package]` - Uninstall a package
- `uninstall [package]` - Alternative to remove

### Help Commands
- `help` - Show general help
- `what can you do` - Natural help request
- `how do I [task]` - Task-specific help

## Personality System

The personality system adapts responses to user preferences:

### Minimal (--minimal)
```
Q: install firefox
A: nix profile install nixpkgs#firefox
```

### Friendly (--friendly, default)
```
Q: install firefox
A: Hi there! I'll help you install firefox! Here's the command:
   nix profile install nixpkgs#firefox
   
Let me know if you need any clarification! 😊
```

### Encouraging (--encouraging)
```
Q: install firefox
A: Great question! I'll help you install firefox!
   Here's the command:
   nix profile install nixpkgs#firefox
   
You're doing awesome learning NixOS! Keep it up! 🌟
```

### Technical (--technical)
```
Q: install firefox
A: I'll help you install firefox using the modern nix profile system.
   Command: nix profile install nixpkgs#firefox
   
Note: This follows NixOS's declarative configuration paradigm.
This uses the new profile-based installation method which is
the recommended approach for NixOS 23.11 and later.
```

## Execution Modes

### Dry Run (Default)
Shows what would happen without executing:
```bash
ask-nix "install firefox"
# Shows: nix profile install nixpkgs#firefox
# But doesn't actually run it
```

### Execute Mode
Actually runs commands with safety checks:
```bash
ask-nix --execute "install firefox"
# Or: ask-nix --bridge "install firefox"
# Actually installs Firefox
```

### No Dry Run
Disables dry-run for immediate execution:
```bash
ask-nix --no-dry-run "install firefox"
# Executes without showing dry-run message
```

## Advanced Features

### Intent Detection
See how your query is understood:
```bash
ask-nix --show-intent "I want to install Firefox"
# Output: Intent detected: install_package
#         Package identified: firefox
```

### Cache Management
```bash
# Skip cache for fresh search
ask-nix --no-cache "search python"

# Clear the entire cache
ask-nix --clear-cache "anything"

# View cache statistics
cat package_cache.db  # SQLite database
```

### Visual Options
```bash
# Disable all visual elements
ask-nix --no-visual "update system"

# Disable just progress bars
ask-nix --no-progress "install git"
```

## Integration with Sacred Trinity

The unified ask-nix is designed to work with our Sacred Trinity development model:

1. **Human (You)**: Provides natural language queries
2. **ask-nix**: Understands intent and provides solutions
3. **Local LLM**: Can be consulted for complex queries via `ask-nix-guru`

## Privacy & Security

- **100% Local**: All processing happens on your machine
- **No Telemetry**: We don't track or send any usage data
- **Secure Execution**: Commands are validated before running
- **Privacy-First**: Learning data stays on your system

## Troubleshooting

### Command Not Found
```bash
# Make sure you're in the project directory
cd /srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity
# Run with full path
./bin/ask-nix "your query"
```

### Cache Issues
```bash
# Clear cache if searches seem outdated
ask-nix --clear-cache "reset"
```

### Execution Failures
```bash
# Use --execute for safer execution
ask-nix --execute "install package"
# Check with dry-run first
ask-nix --dry-run "risky command"
```

## Examples

### Complete Workflow
```bash
# 1. Search for a package
ask-nix "search for text editors"

# 2. Get more info
ask-nix "tell me about neovim"

# 3. Install it
ask-nix --execute "install neovim"

# 4. Verify installation
ask-nix "list installed packages" | grep neovim
```

### Beginner-Friendly Session
```bash
# Use encouraging mode for learning
ask-nix --encouraging "I'm new to NixOS, how do I install software?"
ask-nix --encouraging "what's a nix profile?"
ask-nix --encouraging --execute "install firefox"
```

### Power User Session
```bash
# Technical mode with intent checking
ask-nix --technical --show-intent "set up development environment"
ask-nix --minimal --no-cache "search latest rust"
ask-nix --execute --no-visual "install rustc cargo"
```

## Future Enhancements

The unified ask-nix is continuously improving:
- Voice input support (coming soon)
- Python backend integration for faster execution
- Multi-language support
- Advanced learning from community patterns
- Integration with NixOS configuration management

## Contributing

To contribute to ask-nix development:
1. Test with various queries and personas
2. Report issues or unexpected behaviors
3. Suggest new natural language patterns
4. Help improve intent recognition

---

*ask-nix: Making NixOS accessible through natural conversation* 🌊