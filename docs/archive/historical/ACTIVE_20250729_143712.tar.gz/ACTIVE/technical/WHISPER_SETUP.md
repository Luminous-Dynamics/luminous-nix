# 🎤 Whisper.cpp Voice Integration Setup

## Overview

Nix for Humanity uses Whisper.cpp for local, privacy-preserving speech recognition. This enables natural voice conversations without sending audio to cloud services.

## Installation

### NixOS Configuration

Add to your `configuration.nix`:

```nix
{ config, pkgs, ... }:

{
  environment.systemPackages = with pkgs; [
    # Whisper.cpp and dependencies
    whisper-cpp
    
    # Audio processing
    alsa-utils
    pulseaudio
    
    # Optional: for better audio quality
    sox
    ffmpeg
  ];
  
  # Enable audio
  sound.enable = true;
  hardware.pulseaudio.enable = true;
  
  # Or use PipeWire (recommended)
  services.pipewire = {
    enable = true;
    alsa.enable = true;
    pulse.enable = true;
  };
}
```

### Download Whisper Models

```bash
# Create models directory
mkdir -p ~/.config/nix-for-humanity/models

# Download base model (good balance of speed/accuracy)
wget https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin \
  -O ~/.config/nix-for-humanity/models/whisper-base.bin

# For better accuracy (slower):
wget https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin \
  -O ~/.config/nix-for-humanity/models/whisper-small.bin

# For best accuracy (requires more RAM):
wget https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-medium.bin \
  -O ~/.config/nix-for-humanity/models/whisper-medium.bin
```

### Model Sizes and Requirements

| Model | Size | RAM Required | Speed | Accuracy |
|-------|------|--------------|-------|----------|
| Tiny | 39 MB | ~150 MB | Very Fast | Good for commands |
| Base | 142 MB | ~500 MB | Fast | Good balance |
| Small | 466 MB | ~1 GB | Moderate | Better accuracy |
| Medium | 1.5 GB | ~2.5 GB | Slower | Best accuracy |

## Configuration

### Application Settings

Create `~/.config/nix-for-humanity/voice.json`:

```json
{
  "whisper": {
    "modelPath": "~/.config/nix-for-humanity/models/whisper-base.bin",
    "language": "en",
    "threads": 4,
    "vadThreshold": 0.6,
    "audioContext": "conversation"
  },
  "audio": {
    "inputDevice": "default",
    "sampleRate": 16000,
    "channels": 1,
    "noiseReduction": true
  },
  "behavior": {
    "autoListen": false,
    "wakeWord": "hey nix",
    "confirmDestructive": true,
    "feedbackSounds": true
  }
}
```

## Usage

### Basic Voice Commands

```typescript
// Initialize voice interface
const voice = new WhisperIntegration({
  modelPath: expandPath('~/.config/nix-for-humanity/models/whisper-base.bin')
});

// Start listening
await voice.startListening();

// Handle transcriptions
voice.on('transcription', (result) => {
  console.log('You said:', result.text);
});
```

### With Emotion Detection

```typescript
// Voice with emotion awareness
const pipeline = new VoiceToNLPPipeline({
  modelPath: modelPath,
  audioContext: 'conversation'
});

pipeline.on('emotion-detected', (emotion) => {
  if (emotion.frustration > 0.7) {
    // Adapt response style
  }
});
```

## Microphone Setup

### Test Microphone

```bash
# List audio devices
arecord -l

# Test recording
arecord -d 5 test.wav
aplay test.wav

# Check levels
alsamixer
```

### Noise Reduction

For better recognition in noisy environments:

```bash
# Install noise suppression
nix-env -iA nixos.rnnoise-plugin

# Configure PulseAudio
pactl load-module module-echo-cancel
```

## Performance Optimization

### For Faster Response

1. **Use smaller model**: Tiny or Base for commands
2. **Reduce threads**: Match CPU cores
3. **Adjust VAD threshold**: Higher = less sensitive
4. **Use command context**: Limits vocabulary

### For Better Accuracy

1. **Use larger model**: Small or Medium
2. **Increase beam size**: Better search
3. **Lower VAD threshold**: More sensitive
4. **Use conversation context**: Better flow

## Troubleshooting

### No Audio Input

```bash
# Check PulseAudio
pactl info

# Set default input
pactl set-default-source <source-name>

# Test with Whisper directly
whisper-cpp -m model.bin -f test.wav
```

### Poor Recognition

1. Check microphone quality
2. Reduce background noise
3. Speak clearly, normal pace
4. Try different model size
5. Adjust VAD threshold

### High CPU Usage

1. Use smaller model
2. Reduce thread count
3. Increase VAD threshold
4. Use command context mode

## Privacy & Security

### Local Processing

- All audio processing happens locally
- No internet connection required
- Audio is not stored by default
- Models run entirely on your machine

### Audio Data Handling

```typescript
// Audio is processed in memory only
const audioBuffer = new Float32Array(16000); // 1 second

// Explicitly save if needed
if (userConsent) {
  await saveAudioForTraining(audioBuffer);
}
```

## Integration with Personas

### Grandma Rose (Voice-First)
- Larger model for better accuracy
- Lower VAD for patient listening
- Confirmation sounds enabled
- Simple vocabulary context

### Maya (Speed-Focused)
- Tiny model for instant response
- Higher VAD threshold
- Minimal feedback
- Command context only

### Alex (Accessibility)
- Medium model for accuracy
- Audio feedback for all actions
- Detailed transcription events
- Screen reader compatible

## Advanced Features

### Custom Wake Words

```typescript
// Train custom wake word
const wakeWordDetector = new WakeWordDetector({
  model: 'hey-nix',
  sensitivity: 0.7
});
```

### Multi-Language Support

```typescript
// Switch languages dynamically
voice.setLanguage('es'); // Spanish
voice.setLanguage('de'); // German
voice.setLanguage('fr'); // French
```

### Continuous Listening

```typescript
// For hands-free operation
const continuousMode = new ContinuousVoiceMode({
  wakeWord: 'hey nix',
  timeout: 30000, // 30 seconds
  autoSleep: true
});
```

## Development

### Testing Voice Recognition

```bash
# Run voice tests
npm run test:voice

# Test with specific persona
npm run test:voice -- --persona=grandma-rose

# Benchmark performance
npm run benchmark:whisper
```

### Adding Voice Commands

```typescript
// Extend voice patterns
const voicePatterns = {
  'update my [system|computer]': 'system.update',
  'install {package}': 'package.install',
  'show me {what}': 'query.show'
};
```

## Best Practices

1. **Start Simple**: Use base model first
2. **Test Thoroughly**: With target personas
3. **Handle Errors**: Network, audio, model issues
4. **Provide Feedback**: Visual and audio cues
5. **Respect Privacy**: Always process locally

---

*Voice is the most natural interface - let's make it work for everyone!*