# 🔄 ask-nix Migration Plan - Integrating Headless Architecture

## Overview

This document outlines the migration strategy for updating the existing `ask-nix` command to use the new headless core architecture while maintaining:
- ✅ Complete backward compatibility
- ✅ All existing features
- ✅ Plugin system integration
- ✅ Performance improvements
- ✅ Minimal disruption to users

## Current State Analysis

### What We Have
The current `ask-nix` (1422 lines) includes:
- Direct integration of all components
- Plugin system already integrated
- Multiple knowledge engines
- Feedback collection
- Learning systems
- Cache management
- Rich terminal support

### Architecture Benefits of Migration
1. **Separation of Concerns** - Intelligence vs presentation
2. **Reusability** - Same engine for CLI, GUI, API, Voice
3. **Testability** - Engine can be tested independently
4. **Maintainability** - Cleaner, modular codebase
5. **Future-Proofing** - Ready for multiple frontends

## Migration Strategy

### Phase 1: Parallel Implementation (Week 1)
Create the infrastructure while keeping existing code intact.

#### Tasks:
1. **Import Headless Components**
   ```python
   # Add to imports section
   from core.headless_engine import HeadlessEngine
   from adapters.cli_adapter import CLIAdapter
   ```

2. **Create Feature Flag**
   ```python
   # Environment variable to control which engine to use
   USE_HEADLESS_ENGINE = os.getenv('NIX_USE_HEADLESS', 'false').lower() == 'true'
   ```

3. **Add Adapter Initialization**
   ```python
   class UnifiedNixAssistant:
       def __init__(self):
           if USE_HEADLESS_ENGINE:
               self.adapter = CLIAdapter(use_server=False)
               self.use_headless = True
           else:
               # Keep existing initialization
               self.use_headless = False
               self._init_legacy_components()
   ```

### Phase 2: Method-by-Method Migration (Week 2)
Gradually redirect methods to use the headless engine.

#### Priority Order:
1. **Query Processing** (Highest Impact)
   ```python
   def process_query(self, query, personality='friendly'):
       if self.use_headless:
           context = Context(
               personality=personality,
               execution_mode=self.execution_mode,
               collect_feedback=self.collect_feedback
           )
           return self.adapter.process_query(query, context)
       else:
           # Existing implementation
           return self._legacy_process_query(query, personality)
   ```

2. **Plugin Integration**
   - Headless engine already supports plugins
   - Just need to ensure compatibility

3. **Feedback Collection**
   - Map existing feedback methods to headless API

4. **Command Execution**
   - Preserve existing execution logic
   - Pass through headless engine

### Phase 3: Testing & Validation (Week 3)
Ensure feature parity and performance.

#### Test Matrix:
| Feature | Legacy | Headless | Status |
|---------|--------|----------|--------|
| Basic queries | ✅ | ✅ | Ready |
| Personalities | ✅ | ✅ | Ready |
| Plugin system | ✅ | ✅ | Ready |
| Execution modes | ✅ | ⚠️ | Need mapping |
| Rich terminal | ✅ | ⚠️ | Need integration |
| Voice interface | ✅ | ⚠️ | Need adapter |
| Learning system | ✅ | ⚠️ | Need migration |

#### Performance Benchmarks:
```bash
# Compare response times
time ask-nix "install firefox"  # Legacy
NIX_USE_HEADLESS=true time ask-nix "install firefox"  # Headless

# Memory usage comparison
/usr/bin/time -v ask-nix --summary
```

### Phase 4: Gradual Rollout (Week 4)
Progressive deployment to users.

#### Rollout Strategy:
1. **Internal Testing**
   ```bash
   # Team uses headless version
   export NIX_USE_HEADLESS=true
   ```

2. **Beta Users (10%)**
   ```bash
   # Update wrapper script
   if [[ $(($RANDOM % 10)) -eq 0 ]]; then
       export NIX_USE_HEADLESS=true
   fi
   ```

3. **Opt-in for Power Users**
   ```bash
   # Add flag
   ask-nix --use-headless "query"
   ```

4. **Default Flip (50%)**
   ```bash
   # Gradual increase
   if [[ $(($RANDOM % 2)) -eq 0 ]]; then
       export NIX_USE_HEADLESS=true
   fi
   ```

5. **Full Migration**
   - Make headless default
   - Keep legacy as fallback

## Implementation Details

### Preserving Existing Features

#### 1. Rich Terminal Support
```python
# In CLI adapter
if 'visual' in context.capabilities and RICH_AVAILABLE:
    self._display_rich_response(response)
else:
    self._display_plain_response(response)
```

#### 2. Progress Indicators
```python
# Add to headless engine
class HeadlessEngine:
    def process(self, input_text, context):
        if context.show_progress:
            context.progress_callback("Processing...", 0.2)
        # ... processing ...
        if context.show_progress:
            context.progress_callback("Formatting response...", 0.8)
```

#### 3. Interactive Mode
```python
# Preserve existing interactive experience
def run_interactive(self):
    if self.use_headless:
        self.adapter.run_interactive(self.default_context)
    else:
        self._legacy_interactive_mode()
```

### Handling Edge Cases

#### 1. Direct Component Access
Some code might directly access components:
```python
# Legacy code
result = self.knowledge.extract_intent(query)

# Migration wrapper
@property
def knowledge(self):
    if self.use_headless:
        # Proxy to headless engine
        return self.adapter.engine.knowledge
    else:
        return self._knowledge
```

#### 2. Plugin Compatibility
Ensure plugins work with both engines:
```python
# Plugin interface adapter
class PluginCompatibilityLayer:
    def __init__(self, engine):
        self.engine = engine
    
    def register_plugin(self, plugin):
        if hasattr(self.engine, 'plugin_manager'):
            self.engine.plugin_manager.register(plugin)
        else:
            # Legacy registration
            self._legacy_register(plugin)
```

## Rollback Plan

If issues arise during migration:

### Quick Rollback
```bash
# Disable headless engine globally
export NIX_USE_HEADLESS=false

# Or remove the feature flag check
sed -i 's/USE_HEADLESS_ENGINE = .*/USE_HEADLESS_ENGINE = False/' ask-nix
```

### Data Preservation
- Feedback data compatible between versions
- Learning data shared
- Cache remains valid

## Success Criteria

### Functional Requirements
- [ ] All existing commands work identically
- [ ] No performance regression (±10%)
- [ ] All tests pass with both engines
- [ ] Plugins function correctly
- [ ] Interactive mode preserved

### User Experience
- [ ] No visible changes for users
- [ ] Response quality maintained
- [ ] Error messages consistent
- [ ] Help text accurate

### Technical Metrics
- [ ] Code coverage ≥95%
- [ ] Response time <2s
- [ ] Memory usage stable
- [ ] No new dependencies for users

## Timeline

### Week 1: Foundation
- [ ] Import headless components
- [ ] Add feature flag system
- [ ] Create compatibility layer
- [ ] Set up parallel testing

### Week 2: Migration
- [ ] Migrate query processing
- [ ] Integrate plugin system
- [ ] Port feedback collection
- [ ] Adapt execution logic

### Week 3: Testing
- [ ] Comprehensive test suite
- [ ] Performance benchmarks
- [ ] Edge case validation
- [ ] User acceptance testing

### Week 4: Deployment
- [ ] Beta rollout (10%)
- [ ] Monitor metrics
- [ ] Gradual increase
- [ ] Full migration

## Post-Migration Benefits

Once migration is complete:

1. **New Frontends Possible**
   - GUI using same engine
   - Web API endpoint
   - Voice assistant
   - VSCode extension

2. **Improved Testing**
   - Unit test engine separately
   - Mock adapters for testing
   - Better test coverage

3. **Cleaner Codebase**
   - 400 lines vs 1400 lines
   - Clear separation of concerns
   - Easier to maintain

4. **Future Features**
   - Server mode for performance
   - Multiple engine instances
   - Remote engine option
   - Load balancing

## Conclusion

This migration plan ensures a smooth transition to the headless architecture while maintaining the excellent user experience of the current `ask-nix` command. By using feature flags and gradual rollout, we minimize risk while gaining all the benefits of the new architecture.

The key is patience and thorough testing at each phase. The end result will be a more maintainable, extensible, and powerful system that can serve as the foundation for Nix for Humanity's future growth.

---

*"Evolution, not revolution - the path to sustainable architecture."*