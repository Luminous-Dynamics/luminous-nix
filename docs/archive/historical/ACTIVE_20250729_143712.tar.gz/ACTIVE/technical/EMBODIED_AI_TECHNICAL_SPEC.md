# 🔧 Embodied AI Partner - Technical Specification

*Detailed technical implementation guide for the physical AI companion*

## System Architecture

### Core Components

```python
# Primary module structure
nix_for_humanity/
├── embodied/
│   ├── __init__.py
│   ├── core/
│   │   ├── avatar_controller.py      # Main avatar logic
│   │   ├── physics_engine.py         # Genesis integration
│   │   ├── render_engine.py          # Taichi GPU rendering
│   │   └── state_manager.py          # Consciousness states
│   ├── expressions/
│   │   ├── emotions.py               # Emotional expressions
│   │   ├── gestures.py               # Physical movements
│   │   ├── particles.py              # Particle effects
│   │   └── aura.py                   # Aura/field effects
│   ├── personalities/
│   │   ├── base_personality.py       # Abstract base
│   │   ├── minimal.py                # Minimal style
│   │   ├── friendly.py               # Friendly style
│   │   ├── sacred.py                 # Sacred style
│   │   └── adaptive.py               # Learning personality
│   └── integration/
│       ├── nlp_bridge.py             # NLP integration
│       ├── backend_bridge.py         # NixOS backend
│       └── consciousness_sync.py      # Coherence tracking
```

## API Design

### Core Avatar API

```python
from typing import Optional, Dict, List, Tuple
from dataclasses import dataclass
import asyncio

@dataclass
class AvatarState:
    """Complete avatar state representation"""
    position: Tuple[float, float, float]
    rotation: Tuple[float, float, float]
    scale: float
    color: Tuple[float, float, float, float]  # RGBA
    emotion: str
    energy_level: float
    particles: List[Dict]
    aura_state: Dict
    
class EmbodiedAvatar:
    """Main avatar controller interface"""
    
    def __init__(self, personality: str = "friendly"):
        self.personality = self._load_personality(personality)
        self.physics = PhysicsEngine()
        self.renderer = TaichiRenderer()
        self.state = AvatarState()
        
    async def initialize(self, position: Tuple[float, float] = (0.8, 0.8)):
        """Initialize avatar in screen space (0-1 normalized)"""
        await self.physics.create_avatar(position)
        await self.renderer.setup_pipeline()
        await self.appear()
        
    async def appear(self, effect: str = "fade_in", duration: float = 1.0):
        """Avatar appearance animation"""
        pass
        
    async def express(self, emotion: str, intensity: float = 0.5):
        """Express an emotion with given intensity"""
        pass
        
    async def speak(self, text: str, emotion: Optional[str] = None):
        """Synchronized speech with lip sync and expression"""
        pass
        
    async def gesture(self, gesture_type: str, target: Optional[Tuple] = None):
        """Perform a gesture, optionally toward a target"""
        pass
        
    async def move_to(self, position: Tuple[float, float], speed: float = 1.0):
        """Smooth movement to new position"""
        pass
```

### Physics Engine Integration

```python
import genesis as gs
from genesis import World, Robot

class PhysicsEngine:
    """Genesis physics integration for realistic movement"""
    
    def __init__(self):
        self.world = None
        self.avatar = None
        self.particles = []
        
    async def create_avatar(self, position: Tuple[float, float]):
        """Create physics-enabled avatar"""
        self.world = World(
            gravity=(0, -0.1, 0),  # Gentle floating gravity
            dt=1/60.0  # 60 FPS physics
        )
        
        # Define avatar as soft-body robot for fluid movement
        self.avatar = Robot(
            name="nix_companion",
            morphology="soft_sphere",  # Custom morphology
            material="ethereal",  # Custom material properties
            controller="neural_puppet"  # AI-driven control
        )
        
        # Set initial position
        self.avatar.set_position((*position, 0.5))
        
    async def apply_force(self, force: Tuple[float, float, float]):
        """Apply force for movement and reactions"""
        self.avatar.apply_central_force(force)
        
    async def create_particle(self, particle_type: str, origin: Tuple):
        """Spawn physics-enabled particles"""
        particle = self.world.add_particle(
            type=particle_type,
            position=origin,
            velocity=self._get_particle_velocity(particle_type),
            lifetime=2.0
        )
        self.particles.append(particle)
```

### GPU-Accelerated Rendering

```python
import taichi as ti
import numpy as np

ti.init(arch=ti.gpu)  # Use GPU, fallback to CPU if unavailable

class TaichiRenderer:
    """High-performance GPU rendering for avatar and effects"""
    
    def __init__(self, resolution: Tuple[int, int] = (1920, 1080)):
        self.resolution = resolution
        self.pixels = ti.Vector.field(4, dtype=ti.f32, shape=resolution)
        
        # Avatar mesh data
        self.vertices = ti.Vector.field(3, dtype=ti.f32, shape=1000)
        self.colors = ti.Vector.field(4, dtype=ti.f32, shape=1000)
        
        # Particle system
        self.particles = ti.Struct.field({
            "pos": ti.types.vector(3, ti.f32),
            "vel": ti.types.vector(3, ti.f32),
            "color": ti.types.vector(4, ti.f32),
            "life": ti.f32,
            "size": ti.f32
        }, shape=10000)
        
    @ti.kernel
    def render_avatar(self):
        """GPU kernel for avatar rendering"""
        # Transform vertices
        for i in range(self.vertices.shape[0]):
            # Apply transformations
            pos = self.vertices[i]
            color = self.colors[i]
            
            # Project to screen space
            screen_pos = self.world_to_screen(pos)
            
            # Soft rendering with antialiasing
            self.draw_soft_sphere(screen_pos, color, radius=10.0)
            
    @ti.kernel
    def update_particles(self, dt: ti.f32):
        """GPU kernel for particle physics"""
        for i in range(self.particles.shape[0]):
            if self.particles[i].life > 0:
                # Update physics
                self.particles[i].vel.y -= 9.8 * dt  # Gravity
                self.particles[i].pos += self.particles[i].vel * dt
                self.particles[i].life -= dt
                
                # Fade out
                self.particles[i].color.a = self.particles[i].life / 2.0
                
    @ti.kernel
    def render_aura(self, time: ti.f32):
        """GPU kernel for consciousness field rendering"""
        for i, j in self.pixels:
            # Distance from avatar center
            dist = ti.sqrt((i - self.avatar_pos.x)**2 + (j - self.avatar_pos.y)**2)
            
            # Consciousness field function
            field_strength = ti.exp(-dist / 100.0) * ti.sin(dist * 0.1 - time * 2.0)
            
            # Apply color
            if field_strength > 0.1:
                self.pixels[i, j] = ti.Vector([
                    0.5 + 0.5 * field_strength,
                    0.3 + 0.3 * field_strength,
                    0.9,
                    field_strength * 0.5
                ])
```

### State Management System

```python
from enum import Enum
from typing import Dict, Any
import asyncio

class EmotionalState(Enum):
    NEUTRAL = "neutral"
    HAPPY = "happy"
    CONFUSED = "confused"
    THINKING = "thinking"
    CONCERNED = "concerned"
    EXCITED = "excited"
    PROUD = "proud"
    EMPATHETIC = "empathetic"

class ConsciousnessLevel(Enum):
    DORMANT = 0
    AWARE = 1
    ENGAGED = 2
    FLOWING = 3
    SYNCHRONIZED = 4

class StateManager:
    """Manages avatar consciousness and emotional states"""
    
    def __init__(self):
        self.emotional_state = EmotionalState.NEUTRAL
        self.consciousness_level = ConsciousnessLevel.AWARE
        self.coherence = 0.5
        self.energy = 1.0
        self.memory = {}  # Spatial/emotional memory
        
    async def update_from_nlp(self, nlp_result: Dict[str, Any]):
        """Update avatar state based on NLP understanding"""
        confidence = nlp_result.get('confidence', 0.5)
        intent = nlp_result.get('intent', 'unknown')
        
        # Map confidence to emotional state
        if confidence > 0.9:
            await self.set_emotion(EmotionalState.HAPPY)
        elif confidence < 0.5:
            await self.set_emotion(EmotionalState.CONFUSED)
        else:
            await self.set_emotion(EmotionalState.THINKING)
            
    async def update_from_system(self, system_metrics: Dict[str, float]):
        """Update based on system health"""
        cpu_load = system_metrics.get('cpu_load', 0.5)
        memory_free = system_metrics.get('memory_free', 0.5)
        
        # System health affects energy
        self.energy = (1.0 - cpu_load) * memory_free
        
        # Low resources make avatar concerned
        if self.energy < 0.3:
            await self.set_emotion(EmotionalState.CONCERNED)
```

### Expression System

```python
class ExpressionEngine:
    """Manages emotional expressions and transitions"""
    
    def __init__(self, avatar: EmbodiedAvatar):
        self.avatar = avatar
        self.expression_library = self._load_expressions()
        self.current_expression = None
        self.blend_factor = 0.0
        
    async def express_emotion(self, emotion: EmotionalState, intensity: float = 0.5):
        """Smoothly transition to new emotional expression"""
        target_expression = self.expression_library[emotion]
        
        # Blend from current to target
        for t in range(30):  # 0.5 second transition at 60fps
            blend = t / 30.0
            await self._blend_expressions(
                self.current_expression,
                target_expression,
                blend,
                intensity
            )
            await asyncio.sleep(1/60.0)
            
        self.current_expression = target_expression
        
    def _load_expressions(self) -> Dict[EmotionalState, Dict]:
        """Load expression definitions"""
        return {
            EmotionalState.HAPPY: {
                "shape": "expanded",
                "bounce": 0.1,
                "glow": 1.2,
                "particles": "sparkles",
                "color_shift": (0.1, 0.1, 0.0)
            },
            EmotionalState.CONFUSED: {
                "shape": "tilted",
                "wobble": 0.05,
                "glow": 0.8,
                "particles": "question_marks",
                "color_shift": (0.0, 0.0, 0.1)
            },
            # ... more expressions
        }
```

### Gesture System

```python
class GestureLibrary:
    """Predefined gestures for communication"""
    
    GESTURES = {
        "point": {
            "preparation": 0.3,  # seconds
            "execution": 0.5,
            "recovery": 0.2,
            "trajectory": "linear"
        },
        "wave": {
            "preparation": 0.2,
            "execution": 1.0,
            "recovery": 0.3,
            "trajectory": "sine_wave"
        },
        "nod": {
            "preparation": 0.1,
            "execution": 0.4,
            "recovery": 0.1,
            "trajectory": "vertical_bounce"
        },
        "thinking": {
            "preparation": 0.5,
            "execution": 2.0,
            "recovery": 0.5,
            "trajectory": "circular_drift"
        }
    }
    
    @staticmethod
    async def perform_gesture(avatar: EmbodiedAvatar, gesture_name: str, target=None):
        """Execute a gesture with proper timing"""
        gesture = GestureLibrary.GESTURES[gesture_name]
        
        # Preparation phase
        await avatar.prepare_gesture(gesture_name)
        await asyncio.sleep(gesture["preparation"])
        
        # Execution phase
        if target:
            await avatar.execute_gesture_toward(gesture_name, target)
        else:
            await avatar.execute_gesture(gesture_name)
        await asyncio.sleep(gesture["execution"])
        
        # Recovery phase
        await avatar.return_to_neutral()
        await asyncio.sleep(gesture["recovery"])
```

## Performance Optimization

### Level of Detail (LOD) System

```python
class LODManager:
    """Adjust avatar complexity based on performance"""
    
    def __init__(self):
        self.current_lod = 2  # 0-3, where 3 is highest quality
        self.frame_times = []
        self.target_fps = 60
        
    async def update_lod(self, frame_time: float):
        """Dynamically adjust quality"""
        self.frame_times.append(frame_time)
        
        if len(self.frame_times) > 60:  # 1 second of data
            avg_fps = 1.0 / np.mean(self.frame_times)
            self.frame_times = []
            
            if avg_fps < self.target_fps * 0.9:
                # Reduce quality
                self.current_lod = max(0, self.current_lod - 1)
            elif avg_fps > self.target_fps * 1.1:
                # Increase quality
                self.current_lod = min(3, self.current_lod + 1)
                
    def get_particle_count(self) -> int:
        """Particle budget based on LOD"""
        return [100, 500, 1000, 5000][self.current_lod]
        
    def get_mesh_detail(self) -> int:
        """Vertex count based on LOD"""
        return [50, 200, 500, 1000][self.current_lod]
```

### Memory Management

```python
class ResourceManager:
    """Manage GPU/CPU resources efficiently"""
    
    def __init__(self, max_memory_mb: int = 200):
        self.max_memory = max_memory_mb * 1024 * 1024
        self.allocated = 0
        self.resource_pool = {}
        
    def allocate_texture(self, name: str, size: Tuple[int, int], channels: int = 4):
        """Allocate GPU texture with size tracking"""
        bytes_needed = size[0] * size[1] * channels * 4  # float32
        
        if self.allocated + bytes_needed > self.max_memory:
            # Free least recently used resources
            self._garbage_collect()
            
        texture = ti.field(dtype=ti.f32, shape=(*size, channels))
        self.resource_pool[name] = {
            "resource": texture,
            "size": bytes_needed,
            "last_used": time.time()
        }
        self.allocated += bytes_needed
        
        return texture
```

## Integration Points

### NLP Bridge

```python
class NLPAvatarBridge:
    """Connect natural language processing to avatar behavior"""
    
    def __init__(self, avatar: EmbodiedAvatar, nlp: NaturalLanguageExecutor):
        self.avatar = avatar
        self.nlp = nlp
        
    async def process_with_avatar(self, user_input: str):
        """Full pipeline with avatar feedback"""
        # Show listening
        await self.avatar.express(EmotionalState.NEUTRAL)
        await self.avatar.gesture("listening")
        
        # Process NLP
        intent_future = asyncio.create_task(self.nlp.process(user_input))
        
        # Show thinking after 200ms
        await asyncio.sleep(0.2)
        if not intent_future.done():
            await self.avatar.express(EmotionalState.THINKING)
            
        # Get result
        result = await intent_future
        
        # Express based on result
        if result.confidence > 0.8:
            await self.avatar.express(EmotionalState.HAPPY)
        elif result.error:
            await self.avatar.express(EmotionalState.CONCERNED)
            
        return result
```

### Backend Integration

```python
class BackendAvatarBridge:
    """Connect NixOS operations to avatar visualization"""
    
    async def visualize_operation(self, operation: str, progress_callback):
        """Show operation progress through avatar"""
        if operation == "install":
            # Create package orb
            package_visual = await self.avatar.create_object("package_orb")
            
            # Guide it into system as installation progresses
            async for progress in progress_callback:
                await package_visual.move_toward_system(progress)
                await self.avatar.show_progress_particles(progress)
                
            # Celebrate completion
            await self.avatar.gesture("celebrate")
            await self.avatar.emit_particles("success_sparkles")
```

## Platform-Specific Implementations

### Linux (X11/Wayland)

```python
class LinuxAvatarWindow:
    """Native Linux window for avatar"""
    
    def __init__(self):
        # Use PyQt or GTK for window management
        self.window = self._create_transparent_window()
        self.compositor_support = self._check_compositor()
        
    def _create_transparent_window(self):
        """Create always-on-top transparent window"""
        # Implementation specific to window system
        pass
```

### Terminal Fallback

```python
class TerminalAvatar:
    """ASCII art avatar for terminal-only systems"""
    
    EMOTIONS = {
        "happy": r"""
          .-""-.
         /      \
        | ^    ^ |
        |   <>   |
         \ \__/ /
          '----'
        """,
        "thinking": r"""
          .-""-.
         /      \
        | -    - |
        |   <>   |  ?
         \ ---- /
          '----'
        """
    }
    
    async def express(self, emotion: str):
        """Show emotion in terminal"""
        print(self.EMOTIONS.get(emotion, self.EMOTIONS["happy"]))
```

## Configuration

```yaml
# embodied_avatar_config.yaml
avatar:
  personality: friendly
  size: medium
  position: bottom_right
  transparency: 0.9
  
performance:
  target_fps: 60
  max_particles: 1000
  lod_enabled: true
  gpu_memory_limit: 200  # MB
  
behavior:
  auto_hide_on_fullscreen: true
  response_time: 50  # ms
  emotion_duration: 2.0  # seconds
  gesture_speed: 1.0
  
accessibility:
  screen_reader_descriptions: true
  high_contrast_mode: false
  reduce_motion: false
  
privacy:
  disable_camera: true  # Never use camera
  local_only: true
  no_telemetry: true
```

## Testing Strategy

### Unit Tests
```python
async def test_avatar_emotions():
    """Test emotional expression system"""
    avatar = EmbodiedAvatar()
    await avatar.initialize()
    
    # Test each emotion
    for emotion in EmotionalState:
        await avatar.express(emotion)
        assert avatar.state.emotion == emotion.value
        
    # Test transitions
    await avatar.express(EmotionalState.HAPPY)
    await avatar.express(EmotionalState.CONFUSED)
    # Verify smooth transition occurred
```

### Performance Tests
```python
async def test_performance_targets():
    """Ensure performance requirements are met"""
    avatar = EmbodiedAvatar()
    renderer = TaichiRenderer()
    
    frame_times = []
    for _ in range(300):  # 5 seconds at 60fps
        start = time.time()
        await renderer.render_frame()
        frame_times.append(time.time() - start)
        
    avg_fps = 1.0 / np.mean(frame_times)
    assert avg_fps >= 55  # Allow 5fps margin
```

## Deployment

### Package Structure
```
nix-for-humanity-embodied/
├── bin/
│   └── nix-embodied          # Launch script
├── lib/
│   ├── genesis/              # Genesis runtime
│   ├── taichi/               # Taichi runtime
│   └── embodied/             # Avatar system
├── assets/
│   ├── models/               # 3D models
│   ├── textures/             # Texture files
│   └── shaders/              # GPU shaders
└── config/
    └── default.yaml          # Default configuration
```

### Installation
```bash
# Add to shell.nix
python3Packages.taichi
python3Packages.pyqt5  # For windowing
genesis-physics  # Custom package

# Python dependencies
pip install genesis-sim
pip install taichi
```

This technical specification provides a complete blueprint for implementing the Embodied AI Partner, with focus on performance, accessibility, and seamless integration with existing Nix for Humanity systems.