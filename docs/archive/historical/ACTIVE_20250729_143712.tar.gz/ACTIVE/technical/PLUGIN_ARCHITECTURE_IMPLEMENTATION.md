# 🔌 Plugin Architecture Implementation Guide

*How the Nix for Humanity plugin system works*

## Overview

The plugin architecture enables modular extension of ask-nix functionality without modifying core code. This allows for:
- Easy addition of new features
- Customizable personality styles
- Third-party extensions
- Clean separation of concerns

## Architecture

```
scripts/
├── core/
│   ├── __init__.py
│   ├── plugin_base.py      # Base interfaces all plugins implement
│   ├── plugin_loader.py    # Dynamic plugin discovery and loading
│   └── plugin_manager.py   # Simplified API for ask-nix integration
│
└── plugins/
    ├── __init__.py
    ├── personality/        # Personality transformation plugins
    │   ├── __init__.py
    │   ├── minimal_personality.py
    │   └── friendly_personality.py
    │
    └── features/          # Feature plugins (search, install, etc.)
        ├── __init__.py
        ├── package_search_plugin.py
        └── install_instructions_plugin.py
```

## Plugin Types

### 1. Personality Plugins
Transform responses to match different communication styles.

```python
class MinimalPersonalityPlugin(PersonalityPlugin):
    def apply_personality(self, response: str, context: Dict[str, Any]) -> str:
        # Strip down to just the facts
        return minimal_version
```

### 2. Feature Plugins
Add new capabilities and handle specific intents.

```python
class PackageSearchPlugin(FeaturePlugin):
    def get_supported_intents(self) -> List[str]:
        return ["search_package", "find_package"]
    
    def handle(self, intent: str, context: Dict[str, Any]) -> Dict[str, Any]:
        # Handle the search request
        return search_results
```

## Creating a New Plugin

### Step 1: Choose Plugin Type

**Personality Plugin**: For response transformation
**Feature Plugin**: For new functionality

### Step 2: Create Plugin File

```python
#!/usr/bin/env python3
"""
My Awesome Plugin
Description of what it does
"""

from typing import Dict, Any, List
import sys
import os

# Add parent directories to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from core.plugin_base import FeaturePlugin, PluginInfo


class MyAwesomePlugin(FeaturePlugin):
    """Plugin description"""
    
    def get_info(self) -> PluginInfo:
        return PluginInfo(
            name="my_awesome_plugin",
            version="1.0.0",
            description="Does awesome things",
            author="Your Name",
            capabilities=["awesome", "cool"],
            dependencies=[]
        )
    
    def initialize(self, context: Dict[str, Any]) -> bool:
        """Initialize the plugin"""
        # Setup code here
        self._initialized = True
        return True
    
    def get_supported_intents(self) -> List[str]:
        """Return intents this plugin handles"""
        return ["do_awesome_thing"]
    
    def handle(self, intent: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Handle the intent"""
        return {
            'success': True,
            'response': "I did the awesome thing!",
            'data': {},
            'actions': []
        }
```

### Step 3: Place in Correct Directory

- Personality plugins: `scripts/plugins/personality/`
- Feature plugins: `scripts/plugins/features/`

### Step 4: Test Your Plugin

```bash
python3 scripts/test_plugin_system.py
```

## Plugin API Reference

### PluginInfo
```python
@dataclass
class PluginInfo:
    name: str                    # Unique plugin identifier
    version: str                 # Semantic version
    description: str             # Human-readable description
    author: str = "..."          # Plugin author
    capabilities: List[str]      # What the plugin can do
    dependencies: List[str]      # Required dependencies
```

### PluginBase Methods

#### Required Methods
- `get_info()` - Return plugin metadata
- `initialize(context)` - Initialize with system context
- `can_handle(intent, context)` - Check if plugin handles intent
- `handle(intent, context)` - Process the request

#### Optional Methods
- `cleanup()` - Cleanup on unload
- `get_commands()` - CLI commands added
- `get_flags()` - CLI flags added
- `enhance_response(response, context)` - Modify other responses
- `collect_metrics()` - Return usage metrics

### Response Format
```python
{
    'success': bool,           # Whether request succeeded
    'response': str,           # Formatted response text
    'data': Dict[str, Any],    # Additional data
    'actions': List[Dict]      # Actions taken
}
```

## Integration with ask-nix

### Using Plugin Manager

```python
from core.plugin_manager import get_plugin_manager

# Get singleton instance
manager = get_plugin_manager()

# Load all plugins
manager.load_all_plugins()

# Set personality
manager.set_personality('minimal')

# Apply personality to response
response = manager.apply_personality(base_response)

# Handle an intent
result = manager.handle_intent('search_package', {
    'query': 'search for firefox',
    'package': 'firefox'
})
```

### Adding Plugin Flags to CLI

```python
# Get all plugin flags
plugin_flags = manager.get_all_flags()

# Add to argparse
for flag_config in plugin_flags:
    parser.add_argument(
        flag_config['flag'],
        help=flag_config.get('help', ''),
        action=flag_config.get('action', 'store'),
        # ... other args
    )
```

## Best Practices

### 1. Keep Plugins Focused
Each plugin should do one thing well.

### 2. Handle Errors Gracefully
```python
try:
    # Plugin logic
except Exception as e:
    return {
        'success': False,
        'response': f"Plugin error: {str(e)}",
        'data': None,
        'actions': []
    }
```

### 3. Document Dependencies
Clearly list what your plugin needs in the `dependencies` field.

### 4. Test Thoroughly
- Test with different inputs
- Test error cases
- Test with other plugins loaded

### 5. Follow Naming Conventions
- Plugin files: `lowercase_with_underscores.py`
- Class names: `PascalCasePlugin`
- Plugin names: `lowercase_with_underscores`

## Example Plugins

### Minimal Personality
Strips responses down to just the essential information.

### Friendly Personality  
Adds warmth and encouragement to responses.

### Package Search
Searches for NixOS packages with intelligent caching.

### Install Instructions
Provides detailed installation instructions without execution.

## Future Plugin Ideas

### Technical Personality
Deep technical explanations with examples.

### Symbiotic Personality
Co-evolutionary responses that admit uncertainty.

### Home Manager Plugin
Specialized support for Home Manager configurations.

### Flakes Plugin
NixOS Flakes support and migration assistance.

### Learning Plugin
Track usage patterns and adapt over time.

### Voice Plugin
Integration with speech recognition/synthesis.

## Troubleshooting

### Plugin Not Loading
- Check file is in correct directory
- Verify Python syntax is correct
- Check class inherits from correct base
- Look for import errors

### Plugin Not Handling Intent
- Verify intent name matches exactly
- Check `can_handle()` returns True
- Ensure plugin is initialized

### Import Errors
- Use provided import pattern
- Ensure __init__.py files exist
- Check Python path manipulation

## Conclusion

The plugin architecture makes ask-nix infinitely extensible while maintaining clean separation between core functionality and extensions. This enables:

- Community contributions
- Custom organizational plugins
- Experimental features
- Easy maintenance

Start with the example plugins and build from there!

---

*"With plugins, ask-nix grows to meet each user's unique needs."*