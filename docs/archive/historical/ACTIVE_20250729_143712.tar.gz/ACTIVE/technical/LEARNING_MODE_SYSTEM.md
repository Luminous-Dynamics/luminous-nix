# 📚 Learning Mode System

*Step-by-step guidance with examples for users who learn best through structured walkthroughs*

## Overview

The Learning Mode System addresses a critical need identified in our persona testing: users like Carlos (52, career switcher) who struggle with command-line interfaces need more than just answers - they need structured learning paths with examples at every step.

This system transforms Nix for Humanity from a question-answering tool into a comprehensive learning platform.

## Target Users

### Primary Persona: Carlos
- **Background**: Transitioning from non-tech career
- **Challenge**: Command-line anxiety, fear of breaking things
- **Need**: Step-by-step guidance with examples
- **Success Metric**: 33% → 90% task completion

### Secondary Beneficiaries
- Grandma Rose (voice-guided learning)
- Luna (predictable, structured progression)
- Viktor (clear examples overcome language barriers)
- Any user new to NixOS

## System Architecture

### Core Components

```
┌─────────────────────────────────────────┐
│          User Interface Layer            │
│         (ask-nix-learning CLI)           │
├─────────────────────────────────────────┤
│         Learning Mode Engine             │
│  ┌─────────┬──────────┬──────────────┐ │
│  │Module   │Progress  │Practice       │ │
│  │Library  │Tracker   │Exercises      │ │
│  └─────────┴──────────┴──────────────┘ │
├─────────────────────────────────────────┤
│    Integration Layer                     │
│  ┌─────────┬──────────┬──────────────┐ │
│  │Knowledge│Adaptive  │State          │ │
│  │Engine   │Formatter │Persistence    │ │
│  └─────────┴──────────┴──────────────┘ │
└─────────────────────────────────────────┘
```

### Learning Modules

Each module contains:
1. **Title & Overview** - What you'll learn
2. **Prerequisites** - What you need to know first
3. **Steps** - Detailed walkthrough with:
   - Action description
   - Why you're doing it
   - Exact command to run
   - Expected output
   - Common mistakes to avoid
   - Visual aids where helpful
4. **Practice Exercises** - Reinforce learning
5. **Success Indicators** - How to know you've succeeded
6. **Troubleshooting** - Common problems and solutions

### Available Modules

1. **Installing Software** (`install_package`)
   - 5 steps from terminal opening to verification
   - Covers search, install, and launch
   - Examples: Firefox, htop, vim

2. **Updating System** (`update_system`)
   - 4 steps for safe system updates
   - Includes preview and verification
   - Emphasizes backup importance

3. **Removing Software** (`remove_package`)
   - 3 steps for clean removal
   - Includes garbage collection
   - Shows how to verify removal

4. **Searching Packages** (`search_package`)
   - 3 steps for effective searching
   - Keywords vs exact names
   - Using package details

5. **System Rollback** (`rollback_system`)
   - 3 steps for undoing changes
   - Understanding generations
   - Emergency recovery

6. **Checking Status** (`check_status`)
   - 4 steps for system inspection
   - Version info, package lists
   - Disk usage awareness

## User Experience Flow

### Starting a Module
```
User: "teach me how to install software"
System: Shows module overview, prerequisites, and step 1
```

### Navigation Commands
- `next step` - Progress forward
- `previous step` - Go back
- `restart` - Begin module again
- `practice` - Show exercises
- `help` - Context-aware troubleshooting

### Progress Tracking
- Current module and step saved between sessions
- Completed modules tracked
- Progress percentage shown
- Achievements unlocked (future)

## Implementation Details

### State Management
```python
learning_state = {
    'current_module': 'install_package',
    'current_step': 3,
    'completed_modules': ['search_package'],
    'user_level': 'beginner'
}
```

Stored in: `~/.nix-for-humanity/learning-state.json`

### Step Structure
```python
@dataclass
class LearningStep:
    number: int
    action: str                    # What to do
    explanation: str               # Why to do it
    command: Optional[str]         # Exact command
    example_output: Optional[str]  # What to expect
    common_mistakes: Optional[List[str]]
    visual_aid: Optional[str]      # Emoji/diagram
```

### Adaptive Integration

The Learning Mode integrates with our Adaptive Response System:
- Frustrated users get extra reassurance
- Fast learners can skip explanations
- Visual learners get more examples
- Screen reader users get simplified output

## Success Metrics

### Quantitative
- Step completion rate
- Module completion rate
- Time to complete tasks
- Error frequency reduction

### Qualitative
- User confidence surveys
- "Aha!" moment tracking
- Willingness to explore
- Reduced help requests

## Example Interaction

```
User: "I want to learn to install Firefox"

System: 📚 **Learning: Installing Software on NixOS**

*Learn how to install software packages on NixOS with different methods*

**Before you start:**
  • Terminal/command line basics
  • Know the name of software you want to install

**Steps:**
  ✅ Step 1: Open your terminal
  → Step 2: Check if package exists
  ⏭️  Step 3: Install using nix profile
  ⏭️  Step 4: Verify installation
  ⏭️  Step 5: Launch the application

→ **Step 2: Check if package exists**
   First, let's make sure the software is available.

   💻 **Run this command:**
   ```
   nix search nixpkgs firefox
   ```

   📋 **You should see something like:**
   ```
   * legacyPackages.x86_64-linux.firefox (119.0)
     Mozilla Firefox - the browser, reloaded
   ```

   ⚠️  **Common mistakes to avoid:**
   • Forgetting 'nixpkgs' before package name

**Navigation:**
  ← Say 'previous step' to go back
  → Say 'next step' to continue
  ↺ Say 'start over' to begin again
```

## Future Enhancements

### Phase 2 Features
- Video walkthroughs
- Interactive simulations
- Peer learning groups
- Mentorship matching

### Phase 3 Features
- AI-powered mistake prediction
- Personalized learning paths
- Certification system
- Community-contributed modules

## Design Philosophy

### Principles
1. **Never assume prior knowledge** - Explain everything
2. **Show, don't just tell** - Examples everywhere
3. **Celebrate small wins** - Build confidence
4. **Safe to fail** - Mistakes are learning opportunities
5. **Progressive disclosure** - Complexity emerges gradually

### Anti-patterns Avoided
- Information overload
- Skipping steps
- Abstract explanations without examples
- Assuming comfort with terminals
- One-size-fits-all pacing

## Integration with Roadmap

This Learning Mode directly addresses:
- **Phase 1, Week 1-2**: Emergency fix for Carlos
- **Success Metric**: Carlos 33% → 90% success rate
- **Deliverable**: Working tool for vulnerable users
- **Philosophy**: "Serve the vulnerable first"

## Testing the System

### Manual Testing
```bash
# Start learning journey
bin/ask-nix-learning "teach me to install software"

# Navigate through module
bin/ask-nix-learning "next step"

# Get help when stuck
bin/ask-nix-learning "help"

# Check progress
bin/ask-nix-learning
```

### Demo Script
```bash
python3 scripts/demo/demo-learning-mode.py
```

## Conclusion

The Learning Mode System transforms Nix for Humanity from a tool that answers questions to a patient teacher that guides users through their NixOS journey. By providing structured, step-by-step learning with examples at every stage, we make NixOS accessible to users who would otherwise be left behind.

This is consciousness-first computing in action: meeting users where they are and lifting them to where they want to be.

---

*"Technology should be a patient teacher, not an impatient master."*