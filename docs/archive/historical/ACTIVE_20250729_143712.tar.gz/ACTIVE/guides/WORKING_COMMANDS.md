# 🎯 Working Commands - Nix for Humanity

*Last updated: 2025-01-28 - v0.4.1*

## 🆕 Major Update: Unified ask-nix Command!

We've consolidated all the ask-nix variants into a single, feature-complete command that combines the best of all versions.

## What Actually Works Today

This document lists ONLY the commands and features that are verified to work in the current implementation.

## ✅ Working Executables

### 🌟 NEW: `ask-nix` - The Unified Command (RECOMMENDED)
```bash
# Basic usage
ask-nix "How do I install Firefox?"

# With personality styles
ask-nix --minimal "install python"
ask-nix --friendly "my wifi stopped working"
ask-nix --encouraging "set up development environment"
ask-nix --technical "explain nix profiles"

# Advanced features
ask-nix --show-intent "I need vscode"              # Shows intent detection
ask-nix --execute "install firefox"                # Safe execution with bridge
ask-nix --no-cache "search for rust"               # Skip cache for fresh results
ask-nix --dry-run "remove old packages"            # Preview what would happen
ask-nix --no-visual "update system"                # Disable progress bars
```

**What it does:**
- ✅ Combines ALL features from ask-nix-hybrid, ask-nix-v3, and ask-nix-modern
- ✅ Natural language understanding with intent detection
- ✅ 4 personality styles (minimal, friendly, encouraging, technical)
- ✅ Intelligent package caching (100-1000x faster searches!)
- ✅ Command learning system (tracks success/failure patterns)
- ✅ Visual progress indicators with graceful fallback
- ✅ Safe execution modes (dry-run by default)
- ✅ Modern nix profile commands (not deprecated nix-env)
- ✅ Works with both basic and modern knowledge engines

**Key advantages:**
- Single command to remember
- All features in one place
- Consistent interface
- Best performance (cached searches)
- Safest execution (multiple safety modes)

### 1. `ask-nix-hybrid` - Basic Natural Language Interface (Still Works)
```bash
# Basic usage
ask-nix-hybrid "How do I install Firefox?"

# With personality styles
ask-nix-hybrid --minimal "Install python"
ask-nix-hybrid --friendly "My WiFi stopped working"
ask-nix-hybrid --encouraging "Set up a development environment"
ask-nix-hybrid --technical "Install docker"
```

**What it does:**
- Provides accurate NixOS instructions
- Uses SQLite knowledge base for reliable information
- Offers 4 personality styles
- **LIMITATION**: Only provides instructions, does NOT execute commands

### 2. `ask-nix-v3` - Enhanced Version with Dry-Run Capability
```bash
# Basic usage (dry-run by default)
ask-nix-v3 "install firefox"

# Show intent detection
ask-nix-v3 --show-intent "I need vscode"

# Execute mode (still experimental)
ask-nix-v3 --execute "install firefox"  # Performs dry-run
ask-nix-v3 --execute --no-dry-run "install firefox"  # CAUTION: Real execution
```

**What it does:**
- Everything ask-nix-hybrid does
- Can show intent detection process
- Has execution capability (defaults to safe dry-run)
- **LIMITATION**: Real execution is experimental and may not work for all commands

### 3. `nix-profile-do` - Modern nix profile executor
```bash
# Basic usage
nix-profile-do "install firefox"

# Dry-run mode (default)
nix-profile-do --dry-run "install vscode"

# Force execution
nix-profile-do --no-dry-run "install firefox"
```

**What it does:**
- Uses modern `nix profile` commands instead of legacy `nix-env`
- More reliable for current NixOS versions
- **LIMITATION**: Limited to install and search operations

## 🔧 Working Features

### Natural Language Understanding
- ✅ Package installation requests ("install firefox", "I need python")
- ✅ Package search queries ("search for text editors", "find docker")
- ✅ System update requests ("update my system", "upgrade nixos")
- ✅ WiFi/Network help ("my wifi isn't working", "network issues")
- ✅ Rollback requests ("rollback", "undo last update")

### Knowledge Base
- ✅ SQLite database with common NixOS patterns
- ✅ Package name aliases (firefox → firefox, code → vscode, etc.)
- ✅ Multiple installation methods documented
- ✅ Common problem solutions

### Personality Styles
- ✅ **Minimal**: Just the facts, no fluff
- ✅ **Friendly**: Warm and helpful (default)
- ✅ **Encouraging**: Supportive for beginners
- ✅ **Technical**: Detailed explanations

## ❌ NOT Working Yet

### Major Features
- ❌ Actual package installation (all tools default to dry-run or instructions)
- ❌ Voice interface (no implementation)
- ❌ Learning system (framework exists but not functional)
- ❌ Dynamic personality adaptation (styles are static)
- ❌ Python backend integration with nixos-rebuild-ng
- ❌ Real-time progress feedback
- ❌ Multi-language support

### Commands That Don't Work
- ❌ `ask-nix-enhanced` - Has Python import errors
- ❌ `ask-nix-hybrid-v2` - Module path issues
- ❌ `ask-trinity` - Depends on missing modules
- ❌ `ask-trinity-rag` - RAG system not implemented

## 📝 Usage Examples

### Getting Help with Installation
```bash
# These all work and provide accurate instructions:
ask-nix-hybrid "How do I install Firefox?"
ask-nix-hybrid "I want to install VS Code"
ask-nix-hybrid "Need Python development environment"
```

### Checking What Would Happen
```bash
# Safe dry-run to see what would be executed:
ask-nix-v3 --execute "install firefox"
nix-profile-do --dry-run "install nodejs"
```

### Getting Different Response Styles
```bash
# For experienced users who want just commands:
ask-nix-hybrid --minimal "install docker"

# For beginners who need encouragement:
ask-nix-hybrid --encouraging "How do I update my system?"

# For technical users who want details:
ask-nix-hybrid --technical "Set up PostgreSQL"
```

## 🚀 Quick Start

1. **Simplest working command:**
   ```bash
   ask-nix-hybrid "install firefox"
   ```

2. **See what it understands:**
   ```bash
   ask-nix-v3 --show-intent "I need a text editor"
   ```

3. **Test dry-run execution:**
   ```bash
   ask-nix-v3 --execute "install vim"
   ```

## ⚠️ Important Notes

1. **All execution is experimental** - The tools can show you correct commands but actual execution may fail
2. **Use dry-run first** - Always test with dry-run before attempting real execution
3. **Manual fallback** - You can always copy the suggested commands and run them manually
4. **Local only** - Everything runs locally, no cloud services required

## 🔍 Troubleshooting

If a command doesn't work:
1. Try the simplest version first: `ask-nix-hybrid "your question"`
2. Check if the query is supported (install, search, update, wifi, rollback)
3. Use `--show-intent` to see how your query is interpreted
4. Fall back to copying the suggested command and running it manually

## 📊 Version Information

- Current version: 0.3.0 (not 0.1.0 as VERSION file states)
- Most stable tool: `ask-nix-hybrid`
- Most features: `ask-nix-v3`
- Most modern: `nix-profile-do`

---

*For the full vision of what we're building, see docs/VISION/. This document reflects only what works TODAY.*