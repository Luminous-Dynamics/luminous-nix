# Nix for Humanity - Simple User Guide

## What is Nix for Humanity?

A natural language interface for NixOS. Instead of typing complex commands, just tell it what you want in plain English!

## Quick Start

```bash
# Install the tool
cd /srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity
./bin/ask-nix "install firefox"
```

## The 5 Things You Can Do

### 1. 🔍 Search for Packages
```bash
ask-nix "search firefox"
ask-nix "find a text editor"
ask-nix "is there a package for python"
```

### 2. 📦 Install Software
```bash
ask-nix "install firefox"
ask-nix "install vim"
ask-nix "get me vscode"
```

### 3. 📋 List What's Installed
```bash
ask-nix "list installed packages"
ask-nix "show my packages"
ask-nix "what do I have installed"
```

### 4. 🗑️ Remove Software
```bash
ask-nix "remove firefox"
ask-nix "uninstall vim"
ask-nix "delete that package"
```

### 5. 🔄 Update Everything
```bash
ask-nix "update my system"
ask-nix "update my packages"
ask-nix "upgrade everything"
```

## Safety Features

### Dry Run Mode (Preview Changes)
```bash
ask-nix --dry-run "install firefox"  # Shows what would happen
ask-nix --dry-run "remove vim"       # Preview before removing
```

### Skip Confirmations
```bash
ask-nix --yes "install tree"  # Don't ask for confirmation
```

### Different Personalities
```bash
ask-nix --minimal "install vim"      # Just the facts
ask-nix --friendly "install vim"     # Warm and helpful (default)
ask-nix --encouraging "install vim"  # Great for beginners
ask-nix --technical "install vim"    # Detailed explanations
```

## Common Examples

### Installing Development Tools
```bash
ask-nix "install git"
ask-nix "I need python"
ask-nix "set up nodejs"
```

### Managing Your System
```bash
ask-nix "update without sudo"        # User packages only
ask-nix "show what I have installed"
ask-nix "remove old stuff"           # (Coming soon: garbage collection)
```

### Getting Help
```bash
ask-nix "how do I install software"
ask-nix "search for text editors"
ask-nix "what can I do"
```

## Tips

1. **Natural Language Works** - Don't worry about exact phrasing
2. **It Validates First** - Won't install invalid packages
3. **Progress Indicators** - Shows what's happening
4. **Safe by Default** - Always asks before making changes
5. **Modern Commands** - Uses latest Nix features

## Troubleshooting

### "Package not found"
- Check spelling: `ask-nix "search <partial-name>"`
- Try variations: "vscode" vs "code" vs "visual studio code"

### "Command timed out"
- Large operations can take time
- System updates may take 5-10 minutes
- The tool will retry automatically

### "Permission denied"
- Some operations need sudo (system updates)
- Try: `ask-nix "update without sudo"` for user packages

## What's Next?

This tool is actively growing! Coming soon:
- Voice commands ("Hey Nix, install Firefox")
- Learning your preferences
- Rollback and history features
- Configuration file editing
- Multi-language support

## Need Help?

The tool is designed to be helpful:
- It suggests alternatives when things fail
- Shows tips after each operation
- Provides troubleshooting guidance

Just talk to it naturally - it's here to help!