# User Feedback Template

## Overall Experience Rating: ___/5

## The 5 Core Commands

### 1. Search Command
- **Tested**: `ask-nix "search ______"`
- **Worked?**: Yes / No
- **Output Clear?**: Yes / No
- **Suggestions**: ________________________________

### 2. Install Command  
- **Tested**: `ask-nix "install ______"`
- **Worked?**: Yes / No
- **Validation Helpful?**: Yes / No
- **Progress Clear?**: Yes / No
- **Suggestions**: ________________________________

### 3. List Command
- **Tested**: `ask-nix "list packages"`
- **Worked?**: Yes / No
- **Output Readable?**: Yes / No
- **Suggestions**: ________________________________

### 4. Remove Command
- **Tested**: `ask-nix "remove ______"`
- **Worked?**: Yes / No
- **Found Package?**: Yes / No
- **Confirmation Clear?**: Yes / No
- **Suggestions**: ________________________________

### 5. Update Command
- **Tested**: `ask-nix "update my system"`
- **Worked?**: Yes / No
- **Progress Shown?**: Yes / No
- **Time Reasonable?**: Yes / No
- **Suggestions**: ________________________________

## Natural Language Understanding

### What Phrases Worked Well?
1. ________________________________
2. ________________________________
3. ________________________________

### What Phrases Didn't Work?
1. ________________________________
2. ________________________________
3. ________________________________

## Safety Features

### Dry Run Mode
- **Tested?**: Yes / No
- **Helpful?**: Yes / No
- **Clear Output?**: Yes / No

### Confirmations
- **Too Many?**: Yes / No
- **Too Few?**: Yes / No
- **Just Right?**: Yes / No

## Error Handling

### Did You Encounter Errors?
- **What Command?**: ________________________________
- **Error Message**: ________________________________
- **Was it Helpful?**: Yes / No
- **What Would Help?**: ________________________________

## Personality System

### Which Style Did You Prefer?
- [ ] Minimal (just facts)
- [ ] Friendly (default)
- [ ] Encouraging (beginner-friendly)
- [ ] Technical (detailed)

### Why? ________________________________

## Overall Impressions

### What Surprised You (Positively)?
________________________________
________________________________

### What Frustrated You?
________________________________
________________________________

### Missing Features You Expected?
1. ________________________________
2. ________________________________
3. ________________________________

### Would You Use This Daily?
- [ ] Definitely
- [ ] Probably
- [ ] Maybe
- [ ] Unlikely

### Why? ________________________________

## Compared to Normal Nix Commands

### Ease of Use
- Normal Nix: ___/5
- Nix for Humanity: ___/5

### Confidence Level
- Normal Nix: ___/5
- Nix for Humanity: ___/5

### Speed to Complete Tasks
- Normal Nix: ___/5
- Nix for Humanity: ___/5

## The One Thing to Improve

If you could change ONE thing, what would it be?
________________________________
________________________________

## Final Thoughts

Any other feedback?
________________________________
________________________________
________________________________

---

**Thank you for testing Nix for Humanity!**

Your feedback helps make NixOS accessible to everyone.