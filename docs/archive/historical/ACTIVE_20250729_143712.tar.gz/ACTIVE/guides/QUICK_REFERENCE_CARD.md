# Nix for Humanity - Quick Reference Card

## 🚀 Basic Commands

| What You Want | What to Type |
|---------------|--------------|
| Search | `ask-nix "search firefox"` |
| Install | `ask-nix "install firefox"` |
| List | `ask-nix "list packages"` |
| Remove | `ask-nix "remove firefox"` |
| Update | `ask-nix "update my system"` |

## 🛡️ Safety Options

| Option | What It Does | Example |
|--------|--------------|---------|
| `--dry-run` | Preview only | `ask-nix --dry-run "install vim"` |
| `--yes` | Skip prompts | `ask-nix --yes "remove tree"` |
| `--show-intent` | Debug mode | `ask-nix --show-intent "update"` |

## 🎭 Personality Styles

```bash
ask-nix --minimal "install vim"      # 📄 Just facts
ask-nix --friendly "install vim"     # 😊 Default
ask-nix --encouraging "install vim"  # 🌟 For beginners
ask-nix --technical "install vim"    # 🔧 Details
```

## 💬 Natural Language Examples

### Installing
- "install firefox"
- "I need python"
- "get me a text editor"
- "set up docker without sudo"

### Searching
- "search rust"
- "find video players"
- "is there neovim?"
- "what editors are available"

### Listing
- "list packages"
- "show installed"
- "what do I have"
- "my packages"

### Removing
- "remove firefox"
- "uninstall vim"
- "delete htop"
- "get rid of tree"

### Updating
- "update system"
- "upgrade packages"
- "update without sudo"
- "refresh everything"

## ⚡ Pro Tips

1. **Tab Complete**: Package names auto-complete
2. **Fuzzy Match**: "ffox" → "firefox"
3. **No Sudo**: Prefer "without sudo" for user packages
4. **Validation**: Invalid packages caught before install
5. **Progress**: Long operations show time estimates

## 🔧 Troubleshooting

| Problem | Solution |
|---------|----------|
| "Package not found" | Try `ask-nix "search <name>"` |
| "Timeout" | Normal for big updates, will retry |
| "Permission denied" | Add "without sudo" to command |
| "Already installed" | Use `ask-nix "list packages"` to check |

## 📍 Location

```bash
/srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity/bin/ask-nix
```

## 🌟 Remember

- Speak naturally - it understands!
- Always previews before changes
- Modern `nix profile` commands
- 100% local, 100% private

---
*Version 1.0.0-beta | All 5 core commands working!*