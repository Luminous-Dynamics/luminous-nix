# 🚀 Feedback Session Quick Start

## Running a Feedback Session in 3 Steps

### 1. Setup (One Time)
```bash
cd /srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity

# Make sure ask-nix-hybrid is available
./bin/ask-nix-hybrid --help

# Ensure feedback script is executable
chmod +x bin/feedback-session
```

### 2. Run Session
```bash
# Start the interactive feedback session
./bin/feedback-session

# Or from anywhere if in PATH:
feedback-session
```

The session will:
- Guide you through 5 test scenarios
- Ask quick questions after each test
- Collect final feedback
- Save results automatically

### 3. Analyze Results
```bash
# After collecting feedback from multiple users:
./bin/analyze-feedback

# View the analysis:
cat FEEDBACK_ANALYSIS.md
```

## 📋 Session Overview

**Time Required**: 15-20 minutes

**What You'll Test**:
1. Installing software
2. Checking what's installed
3. Removing software
4. Searching for packages
5. System updates

**Output Files**:
- `feedback_[timestamp].log` - Human readable
- `feedback_[timestamp].json` - For analysis
- `FEEDBACK_ANALYSIS.md` - Summary report

## 💡 Tips for Good Feedback

- **Be Honest**: We need to know what's confusing
- **Try Variations**: Don't just use the example commands
- **Think Aloud**: Your thought process helps us
- **Compare**: How does this compare to regular nix commands?

## 🎭 Testing Different Personalities

Try the same command with different styles:
```bash
ask-nix-hybrid --minimal "install firefox"
ask-nix-hybrid --friendly "install firefox"
ask-nix-hybrid --encouraging "install firefox"
ask-nix-hybrid --technical "install firefox"
```

## 📊 What We're Measuring

- **Ease of Use**: Can non-technical users understand?
- **Clarity**: Are responses clear and actionable?
- **Trust**: Do users feel safe following suggestions?
- **Speed**: Are responses fast enough?
- **Completeness**: Do we answer the actual question?

## 🤝 Sharing Your Results

After running a session:
1. Check the generated log files
2. Share feedback_*.json files with the team
3. Or submit via GitHub issue with your thoughts

Thank you for helping make NixOS accessible to everyone! 🌊