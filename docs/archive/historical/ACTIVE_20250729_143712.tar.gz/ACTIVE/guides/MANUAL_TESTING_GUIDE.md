# 🧪 Manual Testing Guide for Nix for Humanity

## Quick Test Commands

### 1. Basic Install Test (Safe - Dry Run)
```bash
# Test intent recognition and execution flow
./bin/ask-nix-modern --dry-run --bridge "install htop"
```

### 2. Search Test (Safe - Read Only)
```bash
# Test search with timeout handling
./bin/ask-nix-modern --bridge "search for terminal emulators"
```

### 3. List Packages (Safe - Read Only)
```bash
# Test listing installed packages
./bin/ask-nix-modern "list my packages"
```

### 4. Educational Error Test (Safe)
```bash
# Test educational error messages
./bin/ask-nix-modern --bridge --dry-run "install fakepkg123"
```

### 5. Real Installation Test (CAUTION - Actually Installs)
```bash
# This will ACTUALLY install the package
./bin/ask-nix-modern --bridge --yes "install tree"
```

### 6. Update Test (Safe - Dry Run)
```bash
# Test update command recognition
./bin/ask-nix-modern --dry-run --bridge "update my packages"
```

## What to Look For

### ✅ Success Indicators
- Commands execute without Python errors
- Intent is correctly recognized (shown with --show-intent)
- Educational errors provide helpful suggestions
- Search results are nicely formatted
- Progress indicators appear for long operations

### ❌ Potential Issues
- Timeout on search (expected - will show helpful message)
- Package not found (should show educational error)
- Permission errors (should suggest alternatives)
- Network issues (should provide troubleshooting tips)

## Test Scenarios by Persona

### 1. Grandma Rose Test
```bash
./bin/ask-nix-modern --encouraging "how do I get firefox on my computer"
```
Expected: Friendly explanation and offer to install

### 2. Developer David Test
```bash
./bin/ask-nix-modern --technical "install docker"
```
Expected: Technical details about the installation

### 3. Privacy Jamie Test
```bash
./bin/ask-nix-modern --minimal --dry-run "install tor browser"
```
Expected: Minimal output, clear about what will happen

## Automated Test Suite

Run all tests at once:
```bash
cd /srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity
./test-all-commands.sh
```

## Safety Notes

1. Always use `--dry-run` when testing to avoid unwanted installations
2. The `--yes` flag skips confirmations - use carefully
3. System updates require sudo and can take 10-30 minutes
4. Package searches can be slow (30s timeout implemented)

## Debugging Tips

1. Use `--show-intent` to see how commands are interpreted
2. Check `~/.nix-profile/bin/` for installed packages
3. Use `nix profile list` to see what's installed
4. Logs are written to stderr, output to stdout

## Next Steps After Testing

Based on test results, we may need to:
1. Fine-tune intent recognition patterns
2. Adjust timeout values
3. Improve error message clarity
4. Add more package aliases
5. Optimize search performance