# 🚀 Nix for Humanity - Quick Development Reference

## 🛑 BEFORE CODING - The STOP Protocol
```
S - Stop: "Does this already exist?"
T - Take time to search implementations/
O - Open existing code first
P - Proceed only if truly new
```

## 📁 Where Things Live
```
implementations/web-based/js/nlp/  → EXISTING NLP ENGINE (USE THIS!)
packages/patterns/                 → ALL PATTERNS (SINGLE SOURCE)
packages/nlp/                      → NLP modules (DON'T RECREATE)
packages/executor/                 → Command execution (ONE PLACE)
docs/development/STANDARDS.md      → Tech stack & rules (FOLLOW THIS)
```

## 🎯 Tech Stack (LOCKED IN)
- **Language**: TypeScript (NOT JavaScript)
- **Backend**: Node.js 20+ (NOT Deno/Bun)
- **Desktop**: Tauri (NOT Electron)
- **Database**: SQLite (NOT PostgreSQL)
- **Testing**: Node's built-in (NOT Jest)
- **Build**: esbuild (NOT webpack)
- **Shebangs**: `#!/usr/bin/env bash` (NOT `#!/bin/bash`)

## 🎭 Personas = Design Thinking
```typescript
// ✅ RIGHT: "Would Grandma Rose understand this error?"
// ❌ WRONG: class PersonaSystem { }
```

## 🔍 Quick Searches
```bash
# Find existing NLP code
find . -path "*/nlp/*" -name "*.ts"

# Find patterns
grep -r "PATTERNS" --include="*.ts"

# Find command execution
grep -r "spawn" --include="*.ts"
```

## 📝 File Template
```typescript
// packages/[module]/[feature]/index.ts

// One concept, clear exports, no side effects
export class FeatureName {
  // Implementation
}

// NO console.log, NO multiple classes, NO pattern definitions
```

## ⚡ Common Imports
```typescript
// NLP (already exists!)
import { NLPEngine } from '@nix-humanity/nlp';

// Patterns (single source!)
import { PATTERNS } from '@nix-humanity/patterns';

// Command execution
import { CommandExecutor } from '@nix-humanity/executor';

// DON'T create new versions!
```

## 🧪 Testing Quick Reference
```typescript
// Test implementation for algorithms
test('fuzzy match algorithm', () => {
  expect(fuzzy.distance('firefox', 'firefx')).toBe(1);
});

// Test behavior for APIs
test('processes install command', () => {
  expect(await process('install firefox')).toHaveProperty('success', true);
});

// Test all personas
testAllPersonas('can use feature', async (persona) => {
  expect(await feature(persona.input)).toWork();
});
```

## ⚠️ Error Handling
```typescript
// Always user-friendly
throw new CommandError(
  "I couldn't find that program",           // User sees this
  ["Try 'search firefox'", "Check spelling"], // Suggestions
  "Package not found: firefx",              // Debug info
  true                                       // Learn from this
);
```

## ⚡ Performance Limits
- Startup: < 3 seconds
- Commands: < 2 seconds  
- Memory: < 300MB active
- CPU: < 25% active

## 🔒 Security Checklist
- ✓ Validate ALL input
- ✓ Use spawn, never exec
- ✓ No shell execution
- ✓ Sandbox everything
- ✓ Log safely (no PII)

## 🚫 Red Flags
- Creating a new NLP engine
- Defining patterns outside packages/patterns/
- Adding npm dependencies without discussion
- Implementing persona/personality systems
- Using CommonJS require()
- Adding build complexity
- Shell execution (exec with string)
- Logging personal data
- Missing error suggestions
- No test coverage

## ✅ Green Flags  
- Reusing existing implementations/
- Importing from packages/
- Using TypeScript
- Testing with persona scenarios
- Following established patterns
- Keeping it simple
- spawn with array args
- Privacy-preserving logs
- User-friendly errors
- >80% test coverage

## 🎯 The Golden Rules
1. **Check First** - Search before creating
2. **Test Everything** - Behavior + implementation  
3. **Secure by Default** - Validate & sandbox
4. **Fast for Everyone** - Especially Maya
5. **Clear for Everyone** - Especially Grandma & Viktor
6. **Private Always** - Everything local
7. **Document Why** - Reason > what
8. **Learn & Improve** - Update standards

---
**Remember**: If you're writing something that feels familiar, it probably already exists! 🌊