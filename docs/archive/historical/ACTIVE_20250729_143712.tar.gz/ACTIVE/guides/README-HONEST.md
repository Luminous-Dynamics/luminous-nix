# Nix for Humanity

*Natural language interface for NixOS package management*

## What It Is

A command-line tool that lets you manage NixOS packages using plain English instead of memorizing commands.

### ✅ What Works Today

```bash
# Instead of: nix profile install nixpkgs#firefox
ask-nix-modern "install firefox"

# Instead of: nix profile list
ask-nix-modern "show my packages"

# Instead of: nix profile remove <index>
ask-nix-modern "remove firefox"

# Instead of: nix search nixpkgs terminal
ask-nix-modern "search for terminal"
```

### 🎯 Key Features

- **Natural language understanding** for basic package operations
- **Educational error messages** when things go wrong
- **Real execution** by default (use --dry-run for preview)
- **Progress indicators** for long operations
- **Safe command execution** (no shell injection)

## Installation

```bash
# Clone the repository
git clone https://github.com/Luminous-Dynamics/nix-for-humanity
cd nix-for-humanity

# Make tools executable
chmod +x bin/*

# Run validation
./validate-setup.sh
```

## Usage

### Basic Commands

```bash
# Install a package
./bin/ask-nix-modern "install htop"

# Remove a package
./bin/ask-nix-modern "remove htop"

# List installed packages
./bin/ask-nix-modern "what's installed?"

# Search for packages (warning: slow)
./bin/ask-nix-modern "search for editors"
```

### Options

```bash
# Preview without executing
./bin/ask-nix-modern --dry-run "install firefox"

# Skip confirmation prompts
./bin/ask-nix-modern --yes "install firefox"

# Use execution bridge (recommended)
./bin/ask-nix-modern --bridge "install firefox"

# Show intent detection
./bin/ask-nix-modern --show-intent "install something"
```

## Current Limitations

- **No voice interface** (CLI only)
- **Search is slow** (30+ seconds, may timeout)
- **No learning** (doesn't remember your preferences)
- **Basic patterns only** (complex queries may fail)
- **No system configuration** (can't edit configuration.nix)

## Architecture

```
Python (NLP) → JSON Intent → Node.js Bridge → Nix Command
```

- **Python**: Natural language processing and intent extraction
- **Node.js**: Safe command execution with spawn()
- **SQLite**: Knowledge base of package mappings

## Development Status

### Working
- ✅ Install packages
- ✅ Remove packages
- ✅ List packages
- ✅ Search packages (slow)
- ✅ Educational errors

### In Progress
- 🚧 Performance optimization
- 🚧 Command context/history
- 🚧 Tool consolidation

### Planned
- 📋 Voice interface
- 📋 Web GUI
- 📋 Learning system
- 📋 Home Manager integration

## Contributing

This project uses the "Sacred Trinity" development model:
- **Human**: Vision and user testing
- **Claude Code Max**: Implementation
- **Local LLM**: NixOS expertise

See [CONTRIBUTING.md](docs/development/CONTRIBUTING.md) for details.

## Philosophy

Making NixOS accessible to everyone through natural conversation. If Grandma can say "install Firefox", Firefox should be installed.

## License

MIT - See LICENSE file

---

**Note**: This is an active experiment in making NixOS more accessible. Many planned features don't exist yet. See [HONEST_STATUS_ASSESSMENT.md](HONEST_STATUS_ASSESSMENT.md) for current state.