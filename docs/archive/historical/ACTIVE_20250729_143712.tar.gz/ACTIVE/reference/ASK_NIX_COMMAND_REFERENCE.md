# ask-nix Command Reference

## Overview
`ask-nix` is the unified natural language interface for NixOS. It combines all functionality into a single, intelligent command.

## Design Philosophy
- **One Command**: No variants, no confusion
- **Progressive Enhancement**: Basic features work everywhere, advanced features when available
- **Feature Flags**: New capabilities added via flags, not new commands
- **Backward Compatible**: Old flags continue to work

## Basic Usage
```bash
ask-nix "How do I install Firefox?"
ask-nix "My WiFi isn't working"
ask-nix "Update my system"
```

## Feature Flags

### Execution Modes
- `--dry-run` (default) - Show what would be done
- `--execute` - Actually run commands
- `--interactive` - Ask before each action

### Personality Modes
- `--minimal` - Just the facts
- `--friendly` (default) - Warm and helpful
- `--encouraging` - Supportive for beginners
- `--technical` - Detailed explanations
- `--symbiotic` - Admits uncertainty, asks for feedback

### Learning Features
- `--learning-mode` - Step-by-step guidance
- `--collect-feedback` - Enable feedback collection
- `--no-feedback` - Disable feedback collection

### Advanced Features
- `--voice` - Voice input/output mode
- `--cache-only` - Use only cached responses
- `--update-cache` - Refresh package cache

### Information
- `--version` - Show version and active features
- `--features` - List all available features
- `--summary` - Show learning statistics
- `--help` - Show this help

## Configuration
Settings are stored in `~/.config/nix-humanity/config.json`:
```json
{
  "default_personality": "friendly",
  "collect_feedback": true,
  "voice_enabled": false,
  "cache_ttl_days": 7
}
```

## Examples

### Basic Help
```bash
ask-nix "install firefox"
```

### Execute with Confirmation
```bash
ask-nix --execute --interactive "update my system"
```

### Voice Mode for Grandma Rose
```bash
ask-nix --voice --encouraging
```

### Learning Mode for Carlos
```bash
ask-nix --learning-mode "set up development environment"
```

### Technical Mode for Dr. Sarah
```bash
ask-nix --technical --execute "configure nixos containers"
```

## Architecture

### Core Components
1. **NLP Engine** - Natural language understanding
2. **Knowledge Base** - Accurate NixOS information
3. **Execution Bridge** - Safe command execution
4. **Feedback Collector** - Learning from users
5. **Cache Manager** - Fast responses

### Plugin System
New features are added as plugins:
- Plugins are Python modules in `plugins/`
- Automatically discovered and loaded
- Can be enabled/disabled via config

## Future Features
Features planned but not yet implemented:
- `--context` - Maintain conversation context
- `--explain` - Detailed explanation mode
- `--undo` - Reverse last action
- `--profile` - User-specific preferences

## Troubleshooting

### Command Not Found
```bash
# Ensure ask-nix is in PATH
which ask-nix

# Or use full path
/srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity/bin/ask-nix
```

### Slow Responses
```bash
# Update cache
ask-nix --update-cache

# Check cache status
ask-nix --summary
```

### Feedback Not Working
```bash
# Check feedback is enabled
ask-nix --features | grep feedback

# View feedback database
ask-nix --summary
```

## Development

### Adding New Features
1. Create plugin in `plugins/`
2. Add feature flag in main script
3. Update this documentation
4. Add tests

### Testing
```bash
# Run test suite
npm test

# Test specific feature
npm test -- --grep "symbiotic"
```

## Migration Guide

### From Old Commands
- `ask-nix-hybrid` → `ask-nix`
- `ask-nix-v3` → `ask-nix`
- `ask-nix-modern` → `ask-nix`
- `ask-nix-symbiotic` → `ask-nix --symbiotic`

All features preserved, just use appropriate flags.

---

*"One command to rule them all, designed for humans first."*