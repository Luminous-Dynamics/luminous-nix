# 📋 ask-nix --execute Command Documentation

*Generated from comprehensive testing on 2025-01-28*

## Summary

The unified `ask-nix` command supports execution of 18 different command types through the `--execute` flag. Commands are categorized by safety level and sudo requirements.

## ✅ Supported Commands (18 total)

### 🔧 Package Management (Safe - No sudo required)

#### Installation
- `ask-nix --execute "install firefox"`
- `ask-nix --execute "install vscode"`
- `ask-nix --execute "I need python"`
- `ask-nix --execute "set up git"`
- `ask-nix --execute "install docker"`

**Uses**: `nix profile install` - Safe, user-level operation

#### Search
- `ask-nix --execute "search for python packages"`
- `ask-nix --execute "find text editors"`
- `ask-nix --execute "look for games"`

**Uses**: `nix search` - Read-only operation

#### Removal
- `ask-nix --execute "remove firefox"`
- `ask-nix --execute "uninstall vscode"`

**Uses**: `nix profile remove` - Safe, user-level operation

#### Listing
- `ask-nix --execute "list installed packages"`
- `ask-nix --execute "show my packages"`
- `ask-nix --execute "what packages do I have"`

**Uses**: `nix profile list` - Read-only operation

### ⚡ System Management (Requires sudo)

#### Generation Management
- `ask-nix --execute "list generations"` - Shows system history
- `ask-nix --execute "rollback to previous"` - Reverts to last generation
- `ask-nix --execute "switch to generation 5"` - Switches to specific generation

**Uses**: `nixos-rebuild` commands with sudo

#### Network Configuration
- `ask-nix --execute "my wifi isn't working"` - Troubleshoots WiFi
- `ask-nix --execute "enable networking"` - Enables network services

**Uses**: System configuration changes requiring sudo

## ❌ Not Yet Supported (5 commands)

### System Updates
- ❌ "update my system"
- ❌ "upgrade nixos"
- ❌ "update channels"

**Reason**: Complex operations that need better error handling

### Configuration Editing
- ❌ "edit configuration"
- ❌ "rebuild configuration"

**Reason**: Requires file editing and rebuild coordination

## 🛡️ Safety Analysis

### Safe by Default (No sudo)
✅ **Package installation** - Uses nix profile (user-level)
✅ **Package search** - Read-only operations
✅ **Package removal** - User-level changes only
✅ **Package listing** - Information queries

### Requires Admin Privileges (sudo)
⚠️ **System updates** - Modifies system configuration
⚠️ **Channel updates** - Changes system-wide package sources
⚠️ **Generation management** - Affects boot configuration
⚠️ **Configuration changes** - Edits system files
⚠️ **Network configuration** - System-level network settings

## 📝 Usage Examples

### Basic Usage
```bash
# Install a package (executes immediately with confirmation)
ask-nix --execute "install firefox"

# Skip confirmation
ask-nix --execute --yes "install vim"

# Test without executing
ask-nix --execute --dry-run "install git"
```

### Advanced Usage
```bash
# Combine with personality
ask-nix --minimal --execute "search python"

# Show intent detection
ask-nix --show-intent --execute "I need a code editor"

# Use modern commands
ask-nix --modern --execute "list packages"
```

## 🔐 Security Considerations

1. **Confirmation Required**: All destructive operations ask for confirmation
2. **Dry-run Default**: Use `--dry-run` to preview commands
3. **No Shell Execution**: Commands are built programmatically, not via shell
4. **Input Validation**: Package names are validated before execution
5. **Sudo Separation**: System commands clearly indicate sudo requirement

## 🚀 Future Enhancements

1. **System Update Support**: Safe handling of nixos-rebuild
2. **Configuration Editing**: Interactive config file modifications
3. **Progress Streaming**: Real-time feedback during operations
4. **Batch Operations**: Multiple commands in one request
5. **Undo Support**: Reverse recent operations

## 💡 Tips

- Always use `--dry-run` first when unsure
- Add `--yes` to skip confirmations in scripts
- Combine with `--show-intent` to understand parsing
- Use `--minimal` for scripting (less output)
- Check exit codes for automation

---

*This documentation reflects the current state of ask-nix v0.4.1*