# 🐍 Python Migration Guide - From Hybrid to Enhanced

*Moving from subprocess-based ask-nix-hybrid to Python-powered ask-nix-enhanced*

## Overview

This guide helps you transition from the existing `ask-nix-hybrid` tool to the new `ask-nix-enhanced` that leverages NixOS 25.11's Python API capabilities.

## What's Changing

### Old: ask-nix-hybrid
- SQLite knowledge base
- Basic pattern matching
- Personality layers added on top
- No actual NixOS execution
- Subprocess calls for any real work

### New: ask-nix-enhanced
- Same knowledge base PLUS Python backend
- Direct NixOS API integration
- Real execution capabilities
- Progress streaming
- Intelligent error handling

## Quick Start

### Try the New Tool

```bash
# Make sure it's executable
chmod +x /srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity/bin/ask-nix-enhanced

# Interactive mode (recommended for first time)
ask-nix-enhanced

# Command mode with dry run (safe)
ask-nix-enhanced "install firefox"

# Live execution (careful!)
ask-nix-enhanced --live "update system"
```

## Feature Comparison

| Feature | ask-nix-hybrid | ask-nix-enhanced |
|---------|----------------|------------------|
| Natural Language | ✅ | ✅ Enhanced |
| Knowledge Base | ✅ SQLite | ✅ SQLite + API |
| Personality Styles | ✅ 4 styles | ✅ 4 styles |
| Actual Execution | ❌ | ✅ Via Python API |
| Dry Run Mode | ❌ | ✅ Default |
| Progress Feedback | ❌ | ✅ Real-time |
| Error Recovery | Basic | Advanced |
| Learning | ❌ | ✅ From usage |

## Interactive Mode Demo

```bash
$ ask-nix-enhanced

🚀 Enhanced Nix Assistant - Powered by Python Backend
============================================================
Features:
  • Natural language understanding
  • Direct NixOS API integration (no subprocess!)
  • Real-time progress feedback
  • Adaptive personality system
  • Safe mode enabled by default

Commands:
  'mode' - Toggle between dry run and live execution
  'personality <style>' - Change response style
  'help' - Show available commands
  'quit' - Exit
============================================================

[🔒 SAFE] What would you like to do? install firefox

──────────────────────────────────────────────────────────
💬 Hi there! I'll help you install firefox! Here are your options:

1. **Declarative (Recommended)** - Add to your system configuration for permanent installation
   ```
   environment.systemPackages = with pkgs; [ firefox ];
   ```

2. **Home Manager** - User-specific declarative installation
   ```
   home.packages = with pkgs; [ firefox ];
   ```

3. **Imperative** - Quick installation for current user
   ```
   nix-env -iA nixos.firefox
   ```

4. **Temporary Shell** - Try without installing
   ```
   nix-shell -p firefox
   ```

💡 Declarative is preferred for reproducibility

⚠️  DRY RUN - No changes were made
    Switch to live mode with 'mode' command to execute
──────────────────────────────────────────────────────────
```

## Migrating Your Workflow

### Step 1: Test in Dry Run Mode

Start by using `ask-nix-enhanced` in dry run mode (default) to see what it would do:

```bash
# See what would happen
ask-nix-enhanced "update my system"

# It shows the operations without executing
```

### Step 2: Try Simple Commands

Once comfortable, try simple commands in live mode:

```bash
# Interactive mode
ask-nix-enhanced
> mode  # Switch to live mode
> search firefox  # Safe search operation
```

### Step 3: Advanced Usage

```bash
# Different personalities
ask-nix-enhanced --technical "explain generations"
ask-nix-enhanced --encouraging "help me learn NixOS"
ask-nix-enhanced --minimal "install git"

# Batch operations
ask-nix-enhanced --live "install firefox && update system"
```

## Key Improvements

### 1. Real Execution

**Old way (ask-nix-hybrid)**:
```bash
$ ask-nix-hybrid "install firefox"
# Shows you HOW to install, but doesn't do it
```

**New way (ask-nix-enhanced)**:
```bash
$ ask-nix-enhanced --live "install firefox"
# Actually installs Firefox (with confirmation)
```

### 2. Progress Feedback

The enhanced version shows real-time progress:
```
Installing firefox...
[##########----------] 50% Building derivation...
[####################] 100% Complete!
```

### 3. Intelligent Error Handling

If something goes wrong:
```
❌ Installation failed: Package 'fierfix' not found

💡 Suggestions:
    • Did you mean 'firefox'?
    • Try 'search browser' to find alternatives
    • Check your spelling
```

### 4. Learning from Usage

The system learns your preferences:
- Remembers your preferred installation method
- Adapts to your communication style
- Suggests based on past success

## Command Reference

### Personality Flags

Same as before, but with enhanced responses:
```bash
--minimal      # Just the facts
--friendly     # Warm and helpful (default)  
--encouraging  # Supportive for beginners
--technical    # Detailed explanations
```

### Execution Modes

New safety features:
```bash
# Default: dry run (safe)
ask-nix-enhanced "install firefox"

# Live execution (be careful!)
ask-nix-enhanced --live "install firefox"

# Verbose mode for debugging
ask-nix-enhanced --verbose "update system"
```

### Interactive Commands

When in interactive mode:
- `mode` - Toggle dry run / live
- `personality <style>` - Change style
- `help` - Show commands
- `quit` - Exit cleanly

## Migration Tips

### For Safety-Conscious Users

1. Always start in dry run mode
2. Review what would happen
3. Only switch to live mode when confident
4. Use `--verbose` to see details

### For Power Users

1. Jump straight to `--live` mode
2. Use `--minimal` personality
3. Chain commands with `&&`
4. Create aliases for common tasks

### For Learners

1. Use `--encouraging` personality
2. Ask "why" and "how" questions
3. Experiment in dry run mode
4. Read the explanations

## Troubleshooting

### Common Issues

**"Command not found"**
```bash
# Make sure the script is executable
chmod +x /srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity/bin/ask-nix-enhanced
```

**"Module not found"**
```bash
# The Python backend needs to be in the path
cd /srv/luminous-dynamics/11-meta-consciousness/nix-for-humanity
python3 -m backend.python.natural_language_executor
```

**"Permission denied"**
```bash
# Some operations need sudo
ask-nix-enhanced --live "update system"  # Will prompt for sudo
```

## Advanced Features

### Python Backend Integration

The enhanced version uses the Python backend for:
- Direct nixos-rebuild-ng API calls
- Real-time progress monitoring
- Better error messages
- Faster execution

### Future Capabilities

Coming soon:
- Voice input support
- Automated rollback on failure
- Collective learning from all users
- Predictive suggestions

## Summary

The migration from `ask-nix-hybrid` to `ask-nix-enhanced` brings:

1. **Real Power** - Actually execute commands
2. **Safety First** - Dry run by default
3. **Better Feedback** - See what's happening
4. **Smarter Errors** - Understand problems
5. **Future Ready** - Python API foundation

Start with dry run mode, get comfortable, then unleash the full power of natural language NixOS management!

---

*"From showing the way to leading the way - ask-nix-enhanced makes NixOS truly conversational."*