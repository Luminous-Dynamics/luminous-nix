# 🧠 Command Learning System Design

*Activating intelligent learning from user interactions*

## Vision

The learning system transforms ask-nix from a static tool into an evolving partner that learns from every interaction, improving accuracy and understanding user patterns over time.

## Current State

We already have the foundation in place:
- ✅ `CommandLearningSystem` class in `scripts/command-learning-system.py`
- ✅ SQLite database for tracking patterns
- ✅ Hooks in UnifiedNixAssistant for recording outcomes
- ❌ Not yet activated or collecting data
- ❌ No UI for viewing insights

## 🎯 Design Goals

1. **Passive Learning** - Learn without interrupting user flow
2. **Privacy First** - All data stays local
3. **Actionable Insights** - Learning leads to better suggestions
4. **Transparent** - Users can see what's being learned
5. **Opt-in** - Disabled by default, user chooses to enable

## 📊 What to Learn

### 1. Command Success Patterns
```python
{
    "query": "install firefox",
    "intent": "install_package",
    "package": "firefox",
    "executed": true,
    "success": true,
    "error": null,
    "duration": 45.2,
    "timestamp": "2025-01-28T10:30:00Z"
}
```

### 2. User Preferences
- Preferred installation method (nix-env vs nix profile)
- Common package aliases ("code" → "vscode")
- Typical query patterns
- Error recovery strategies

### 3. Context Patterns
- Time of day patterns
- Sequential commands (install X then Y)
- Common workflows
- Mistake corrections

### 4. Communication Style
- Question formulation patterns
- Preferred response verbosity
- Technical level comfort
- Language quirks

## 🏗️ Implementation Architecture

### Phase 1: Data Collection (Week 1)

```python
class EnhancedLearningSystem(CommandLearningSystem):
    def record_interaction(self, interaction):
        """Record full interaction context"""
        self.record_command(
            query=interaction.query,
            intent=interaction.intent,
            success=interaction.success,
            context={
                "time_of_day": self._get_time_category(),
                "previous_command": self._get_previous_command(),
                "session_length": self._get_session_duration(),
                "error_details": interaction.error if not interaction.success else None
            }
        )
    
    def _get_time_category(self):
        hour = datetime.now().hour
        if 6 <= hour < 12: return "morning"
        elif 12 <= hour < 18: return "afternoon"
        elif 18 <= hour < 22: return "evening"
        else: return "night"
```

### Phase 2: Pattern Recognition (Week 2)

```python
class PatternAnalyzer:
    def analyze_user_patterns(self, user_id=None):
        """Identify patterns in user behavior"""
        patterns = {
            "common_packages": self._find_frequent_packages(),
            "peak_usage_times": self._analyze_time_patterns(),
            "success_rate": self._calculate_success_metrics(),
            "common_errors": self._identify_error_patterns(),
            "workflow_sequences": self._detect_command_sequences()
        }
        return patterns
    
    def suggest_improvements(self, patterns):
        """Generate actionable suggestions"""
        suggestions = []
        
        # If user often misspells package names
        if patterns["common_errors"]["typos"]:
            suggestions.append({
                "type": "autocorrect",
                "data": patterns["common_errors"]["typos"]
            })
        
        # If user has repetitive workflows
        if patterns["workflow_sequences"]:
            suggestions.append({
                "type": "macro",
                "data": patterns["workflow_sequences"]
            })
        
        return suggestions
```

### Phase 3: Adaptive Behavior (Week 3)

```python
class AdaptiveNixAssistant(UnifiedNixAssistant):
    def __init__(self):
        super().__init__()
        self.learner = EnhancedLearningSystem()
        self.adapter = BehaviorAdapter()
    
    def answer(self, query):
        # Get base response
        response = super().answer(query)
        
        # Apply learned adaptations
        adapted_response = self.adapter.adapt_response(
            response=response,
            user_patterns=self.learner.get_user_patterns(),
            context=self.get_current_context()
        )
        
        # Record interaction for learning
        self.learner.record_interaction(self.last_interaction)
        
        return adapted_response
```

## 🎮 User Interface Design

### 1. Opt-in Activation
```bash
# Enable learning (creates ~/.config/nix-humanity/learning.db)
ask-nix --enable-learning

# Check learning status
ask-nix --learning-status

# Disable learning and delete data
ask-nix --disable-learning --purge
```

### 2. Insights Dashboard
```bash
# View learning insights
ask-nix --show-insights

Output:
📊 Your Nix Learning Insights
============================
📦 Top packages: firefox (5), vim (4), python (3)
⏰ Most active: evenings (65% of usage)
✅ Success rate: 89% (47/53 commands)
🔄 Common patterns:
   - You often install dev tools on Mondays
   - You prefer minimal responses
   - You search before installing 80% of the time
💡 Suggestions:
   - Create alias: "dev-setup" for your common tool installs
   - Try: "install firefox vim git" for batch operations
```

### 3. Privacy Controls
```bash
# Export your data
ask-nix --export-learning > my-nix-patterns.json

# Clear specific time period
ask-nix --clear-learning --days=30

# View what's being tracked
ask-nix --show-privacy
```

## 🔒 Privacy & Security

### Data Storage
- SQLite database in `~/.config/nix-humanity/learning.db`
- Encrypted at rest if filesystem supports it
- No network transmission ever
- User owns all data

### What We Track
✅ Commands and outcomes
✅ Timestamps (generalized to hour)
✅ Success/failure rates
✅ Error messages (sanitized)

### What We DON'T Track
❌ Actual file paths (only patterns)
❌ Personal information
❌ System identifiers
❌ Network information

## 📈 Success Metrics

### Phase 1 (Data Collection)
- [ ] 1000+ interactions recorded
- [ ] <1ms overhead per command
- [ ] Zero privacy concerns raised

### Phase 2 (Pattern Recognition)
- [ ] 5+ meaningful patterns identified per user
- [ ] 80%+ accuracy in predicting next command
- [ ] Actionable suggestions generated

### Phase 3 (Adaptive Behavior)
- [ ] 10%+ reduction in user errors
- [ ] 20%+ reduction in command retry rate
- [ ] Positive user feedback on adaptations

## 🚀 Implementation Plan

### Week 1: Activate Data Collection
1. Enable learning system in UnifiedNixAssistant
2. Add `--enable-learning` flag
3. Implement privacy controls
4. Add basic insights command
5. Test with real usage

### Week 2: Build Pattern Recognition
1. Implement PatternAnalyzer class
2. Add time-based analysis
3. Create workflow detection
4. Build suggestion engine
5. Test pattern accuracy

### Week 3: Implement Adaptations
1. Create BehaviorAdapter class
2. Add autocorrection for common typos
3. Implement smart defaults
4. Add predictive suggestions
5. Measure improvement metrics

### Week 4: Polish & Launch
1. Refine privacy controls
2. Improve insights visualization
3. Add export/import functionality
4. Document for users
5. Release as experimental feature

## 💡 Future Enhancements

### Advanced Learning
- Multi-user household patterns
- Cross-command learning (vim + tmux = developer)
- Seasonal patterns (game installs in summer)
- Error recovery strategies

### Collective Intelligence
- Opt-in anonymous pattern sharing
- Community-driven package recommendations
- Common problem solutions
- Popular workflows

### Predictive Features
- Suggest commands before asking
- Pre-fetch package information
- Anticipate common sequences
- Proactive error prevention

## 🎯 Key Decisions

1. **Opt-in by default** - Respect user privacy
2. **Local only** - No cloud, no tracking
3. **Transparent** - Users see what we learn
4. **Actionable** - Learning improves experience
5. **Deletable** - Users can purge anytime

## 📝 Example User Journey

```bash
# Day 1: User enables learning
$ ask-nix --enable-learning
✨ Learning enabled! I'll learn from your usage to provide better suggestions.

# Day 7: User makes common typo
$ ask-nix "install friefox"
🔍 I notice you might mean "firefox" (you've installed it 3 times before)
Would you like to install firefox? [Y/n]

# Day 14: User checks insights
$ ask-nix --show-insights
📊 I've learned that you:
- Often install development tools together
- Prefer technical explanations
- Work mostly in the evenings
💡 Tip: Try "ask-nix dev-bundle" to install your common tools!

# Day 30: System adapts automatically
$ ask-nix "install code editor"
Based on your history, I recommend:
1. vscode (installed 5 times) ⭐
2. neovim (searched 3 times)
3. emacs (new suggestion)
```

---

*"A tool that learns with you, not about you."*