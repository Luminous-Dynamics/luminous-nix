"""
Frontend adapters for Nix for Humanity

Each frontend (CLI, GUI, API, Voice) has its own adapter that translates
between the frontend-specific interface and the unified backend.
"""