"""
Example scripts demonstrating Nix for Humanity features
"""