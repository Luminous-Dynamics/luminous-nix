"""Input validator for security - compatibility wrapper."""

# Import everything from validator.py for backward compatibility
from .validator import *